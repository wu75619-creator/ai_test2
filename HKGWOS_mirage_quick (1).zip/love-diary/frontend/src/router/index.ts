import { createRouter, createWebHistory } from 'vue-router'
import ChatView from '../views/ChatView.vue'
import CategoryView from '../views/CategoryView.vue'
import TimelineView from '../views/TimelineView.vue'

const routes = [
  {
    path: '/',
    name: 'Chat',
    component: ChatView,
    meta: { title: '聊天记录' }
  },
  {
    path: '/category',
    name: 'Category',
    component: CategoryView,
    meta: { title: '分类相册' }
  },
  {
    path: '/timeline',
    name: 'Timeline',
    component: TimelineView,
    meta: { title: '恋爱时间轴' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
