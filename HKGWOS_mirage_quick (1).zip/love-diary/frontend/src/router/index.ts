import { createRouter, createWebHistory } from 'vue-router'
import ChatView from '../views/ChatView.vue'

const routes = [
  {
    path: '/',
    name: 'Chat',
    component: ChatView,
    meta: { title: '聊天记录' }
  },
  {
    path: '/timeline',
    name: 'Timeline',
    component: () => import('../views/TimelineView.vue'),
    meta: { title: '全局时间轴' }
  },
  {
    path: '/category/:code',
    name: 'Category',
    component: () => import('../views/CategoryView.vue'),
    meta: { title: '分类归档' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
