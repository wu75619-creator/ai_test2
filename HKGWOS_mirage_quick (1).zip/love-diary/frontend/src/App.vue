<template>
  <div id="app">
    <!-- 顶部标题栏 -->
    <header class="app-header">
      <div class="header-content">
        <span class="logo">💕</span>
        <span class="title">{{ currentPageTitle }}</span>
      </div>
    </header>

    <!-- 主内容区域 -->
    <main class="main-content">
      <router-view />
    </main>

    <!-- 底部Tab导航栏 -->
    <nav class="bottom-nav">
      <router-link to="/" class="nav-item">
        <el-icon :size="22"><ChatDotRound /></el-icon>
        <span>聊天记录</span>
      </router-link>
      <router-link to="/category" class="nav-item">
        <el-icon :size="22"><FolderOpened /></el-icon>
        <span>分类相册</span>
      </router-link>
      <router-link to="/timeline" class="nav-item">
        <el-icon :size="22"><Calendar /></el-icon>
        <span>恋爱时间轴</span>
      </router-link>
    </nav>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { ChatDotRound, FolderOpened, Calendar } from '@element-plus/icons-vue'

const route = useRoute()

const currentPageTitle = computed(() => {
  const path = route.path
  if (path === '/') return '聊天记录'
  if (path.startsWith('/category')) return '分类相册'
  if (path === '/timeline') return '恋爱时间轴'
  return '我们的恋爱日记本'
})
</script>

<style scoped>
#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: #fff5f8;
}

.app-header {
  height: 52px;
  background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
  color: white;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 2px 12px rgba(255, 107, 157, 0.15);
}

.header-content {
  max-width: 768px;
  margin: 0 auto;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 20px;
  gap: 8px;
}

.logo {
  font-size: 20px;
}

.title {
  font-size: 17px;
  font-weight: 600;
  letter-spacing: 0.5px;
}

.main-content {
  flex: 1;
  max-width: 768px;
  width: 100%;
  margin: 0 auto;
  background: white;
  padding-bottom: 70px; /* 给底部导航留空间 */
}

.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: white;
  display: flex;
  justify-content: space-around;
  align-items: center;
  box-shadow: 0 -2px 12px rgba(255, 107, 157, 0.1);
  z-index: 100;
  max-width: 768px;
  margin: 0 auto;
  border-top: 1px solid #ffe3ee;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  text-decoration: none;
  color: #b2bec3;
  font-size: 11px;
  transition: all 0.3s ease;
  padding: 6px 16px;
  border-radius: 12px;
}

.nav-item.router-link-active {
  color: #ff6b9d;
  background: linear-gradient(135deg, #fff0f5 0%, #ffe3ee 100%);
  transform: translateY(-2px);
}

@media (max-width: 768px) {
  .main-content {
    max-width: 100%;
  }
}
</style>
