<template>
  <div id="app">
    <nav class="nav-bar">
      <div class="logo">💕 我们的恋爱日记本</div>
      <div class="nav-links">
        <router-link to="/">
          <el-icon><ChatDotRound /></el-icon>
          聊天
        </router-link>
        <router-link to="/timeline">
          <el-icon><Calendar /></el-icon>
          时间轴
        </router-link>
      </div>
    </nav>
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script setup lang="ts">
import { ChatDotRound, Calendar } from '@element-plus/icons-vue'
</script>

<style scoped>
.nav-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  height: 52px;
  background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 50%, #fecfef 100%);
  color: white;
  position: sticky;
  top: 0;
  z-index: 100;
  box-shadow: 0 2px 12px rgba(255, 107, 157, 0.15);
}

.logo {
  font-size: 17px;
  font-weight: 600;
  letter-spacing: 0.5px;
}

.nav-links {
  display: flex;
  gap: 8px;
}

.nav-links a {
  color: rgba(255, 255, 255, 0.9);
  text-decoration: none;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 4px;
  transition: all 0.3s ease;
}

.nav-links a:hover {
  background: rgba(255, 255, 255, 0.2);
  color: white;
}

.nav-links a.router-link-active {
  background: rgba(255, 255, 255, 0.25);
  color: white;
  font-weight: 500;
}

.main-content {
  max-width: 768px;
  margin: 0 auto;
  min-height: calc(100vh - 52px);
  background: white;
  box-shadow: 0 0 20px rgba(255, 107, 157, 0.08);
}

@media (max-width: 768px) {
  .main-content {
    max-width: 100%;
    box-shadow: none;
  }

  .logo {
    font-size: 15px;
  }

  .nav-links a span {
    display: none;
  }
}
</style>
