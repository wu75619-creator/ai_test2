<template>
  <div class="category-page">
    <!-- 分类Tab栏 -->
    <div class="category-tabs">
      <div
        v-for="cat in categories"
        :key="cat.code"
        class="cat-tab"
        :class="{ active: currentCategory === cat.code }"
        :style="{ '--cat-color': cat.color }"
        @click="selectCategory(cat.code)"
      >
        <span class="cat-icon">{{ cat.icon }}</span>
        <span class="cat-name">{{ cat.name }}</span>
      </div>
    </div>

    <!-- 时间筛选器 -->
    <div class="filter-bar">
      <el-date-picker
        v-model="filterDate"
        type="month"
        placeholder="选择月份筛选"
        format="YYYY年MM月"
        value-format="YYYY-MM"
        clearable
        @change="loadCategoryMessages"
        style="width: 180px"
      />
      <div class="total-count">共 {{ messages.length }} 条记录</div>
    </div>

    <!-- 内容区域 -->
    <div class="content-area">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载中...
      </div>

      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">📭</div>
        <p>这个分类下还没有记录哦</p>
        <p class="sub">快去聊天页记录甜蜜吧~</p>
      </div>

      <div v-else class="cards-container">
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="memory-card"
          :style="{ borderLeftColor: getCategoryColor(msg.category_code) }"
        >
          <div class="card-header">
            <div class="sender-info">
              <div class="avatar" :class="msg.sender_role === 'female' ? 'female-avatar' : 'male-avatar'">
                {{ msg.sender_nickname.charAt(0) }}
              </div>
              <span class="nickname">{{ msg.sender_nickname }}</span>
            </div>
            <span class="date">{{ formatDate(msg.sent_at) }}</span>
          </div>

          <!-- 图片展示 -->
          <div v-if="msg.media_urls && msg.media_urls.length > 0" class="card-images">
            <img
              v-for="(url, idx) in msg.media_urls"
              :key="idx"
              :src="getMediaUrl(url)"
              class="card-image"
            />
          </div>
          <!-- 语音标识 -->
          <div v-if="msg.voice_url" class="voice-badge">
            <el-icon><Microphone /></el-icon>
            语音消息
          </div>
          <div class="card-content">{{ msg.text_content }}</div>

          <div class="card-tags" v-if="msg.tags && msg.tags.length > 0">
            <el-tag
              v-for="tag in msg.tags"
              :key="tag"
              size="small"
              effect="plain"
              class="tag-item"
            >
              #{{ tag }}
            </el-tag>
          </div>

          <div class="ai-summary" v-if="msg.ai_summary">
            <el-icon><MagicStick /></el-icon>
            <span>{{ msg.ai_summary }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, MagicStick, Microphone } from '@element-plus/icons-vue'
import { getCategories, getCategoryMessages, getMediaUrl, type Category, type Message } from '../api/message'

const categories = ref<Category[]>([])
const currentCategory = ref('food')
const filterDate = ref('')
const messages = ref<Message[]>([])
const loading = ref(false)

const getCategoryColor = (code?: string) => {
  const cat = categories.value.find(c => c.code === code)
  return cat?.color || '#ff6b9d'
}

const formatDate = (timeStr: string) => {
  const date = new Date(timeStr)
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`
}

const selectCategory = (code: string) => {
  currentCategory.value = code
  loadCategoryMessages()
}

const loadCategoryMessages = async () => {
  loading.value = true
  try {
    let year: number | undefined
    let month: number | undefined
    if (filterDate.value) {
      const [y, m] = filterDate.value.split('-').map(Number)
      year = y
      month = m
    }
    const data = await getCategoryMessages(currentCategory.value, year, month)
    messages.value = data
  } catch (error) {
    ElMessage.error('加载分类消息失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    const data = await getCategories()
    categories.value = data
    if (data.length > 0) {
      currentCategory.value = data[0].code
      await loadCategoryMessages()
    }
  } catch (error) {
    ElMessage.error('加载分类失败')
    console.error(error)
  }
}

onMounted(() => {
  loadCategories()
})
</script>

<style scoped>
.category-page {
  min-height: calc(100vh - 52px - 60px);
  background: #fff9fb;
  padding-bottom: 20px;
}

.category-tabs {
  display: flex;
  overflow-x: auto;
  gap: 8px;
  padding: 12px 16px;
  background: white;
  border-bottom: 1px solid #ffe3ee;
  scrollbar-width: none;
}

.category-tabs::-webkit-scrollbar {
  display: none;
}

.cat-tab {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 14px;
  border-radius: 20px;
  background: #fff5f8;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 1px solid transparent;
}

.cat-tab.active {
  background: var(--cat-color);
  color: white;
  transform: scale(1.05);
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.cat-icon {
  font-size: 16px;
}

.filter-bar {
  padding: 12px 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: white;
  border-bottom: 1px solid #f0f0f0;
}

.total-count {
  font-size: 12px;
  color: #b2bec3;
}

.content-area {
  padding: 16px;
}

.loading-tip,
.empty-tip {
  text-align: center;
  padding: 60px 20px;
  color: #b2bec3;
}

.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.empty-tip .sub {
  font-size: 12px;
  margin-top: 4px;
}

.cards-container {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.memory-card {
  background: white;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 2px 12px rgba(255, 107, 157, 0.08);
  border-left: 4px solid #ff6b9d;
  transition: transform 0.2s ease;
}

.memory-card:hover {
  transform: translateY(-2px);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.sender-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 14px;
}

.female-avatar {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
}

.male-avatar {
  background: linear-gradient(135deg, #54a0ff 0%, #74b3ff 100%);
}

.nickname {
  font-size: 14px;
  font-weight: 500;
}

.date {
  font-size: 12px;
  color: #b2bec3;
}

.card-images {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 12px;
}

.card-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 8px;
}

.voice-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  background: #e3f0ff;
  color: #54a0ff;
  border-radius: 12px;
  font-size: 12px;
  margin-bottom: 8px;
}

.card-content {
  font-size: 15px;
  line-height: 1.6;
  color: #2d3436;
  margin-bottom: 12px;
}

.card-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 10px;
}

.tag-item {
  border-radius: 8px;
  font-size: 11px;
}

.ai-summary {
  padding: 8px 12px;
  background: linear-gradient(135deg, #f8f5ff 0%, #f0e7ff 100%);
  border-radius: 10px;
  font-size: 12px;
  color: #5f27cd;
  display: flex;
  align-items: center;
  gap: 6px;
}
</style>
