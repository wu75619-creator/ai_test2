<template>
  <div class="category-container">
    <h2>📂 分类归档</h2>
    <p>分类页面开发中...</p>
  </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router'
const route = useRoute()
console.log('分类编码:', route.params.code)
</script>

<style scoped>
.category-container {
  padding: 20px;
}
</style>
