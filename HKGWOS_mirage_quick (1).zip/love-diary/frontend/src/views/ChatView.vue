<template>
  <div class="chat-page">
    <!-- 聊天消息区域 -->
    <div class="messages-container" ref="messagesContainer">
      <div v-if="loading" class="loading-tip">
        <el-icon><Loading /></el-icon>
        加载中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💕</div>
        <p>还没有消息哦，快来记录第一条甜蜜吧~</p>
      </div>
      <div v-else>
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="message-item"
          :class="[msg.sender_role === 'female' ? 'message-right' : 'message-left']"
        >
          <!-- 头像 -->
          <div class="avatar" :class="msg.sender_role === 'female' ? 'female-avatar' : 'male-avatar'">
            {{ msg.sender_nickname.charAt(0) }}
          </div>
          <!-- 消息气泡 -->
          <div class="message-content">
            <div class="nickname">{{ msg.sender_nickname }}</div>
            <div
              class="bubble"
              :class="msg.sender_role === 'female' ? 'bubble-female' : 'bubble-male'"
            >
              {{ msg.text_content }}
            </div>
            <div v-if="msg.ai_processed && msg.ai_summary" class="ai-summary">
              <el-icon><MagicStick /></el-icon>
              <span>AI小结: {{ msg.ai_summary }}</span>
            </div>
            <div class="time">{{ formatTime(msg.sent_at) }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部输入区域 -->
    <div class="input-area">
      <div class="sender-switch">
        <span>当前身份：</span>
        <el-radio-group v-model="currentSender" size="small">
          <el-radio-button value="female">女朋友 💖</el-radio-button>
          <el-radio-button value="male">男朋友 💙</el-radio-button>
        </el-radio-group>
      </div>
      <div class="input-row">
        <el-input
          v-model="inputText"
          type="textarea"
          :rows="2"
          placeholder="随手记录此刻的甜蜜..."
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
        />
        <el-button
          type="primary"
          class="send-btn"
          :loading="sending"
          :disabled="!inputText.trim()"
          @click="handleSend"
        >
          发送
          <el-icon class="el-icon--right"><Promotion /></el-icon>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, MagicStick, Promotion } from '@element-plus/icons-vue'
import { getMessages, createMessage, type Message } from '../api/message'

const messages = ref<Message[]>([])
const loading = ref(false)
const sending = ref(false)
const inputText = ref('')
const currentSender = ref<'male' | 'female'>('female') // 默认女主
const messagesContainer = ref<HTMLElement | null>(null)

// 格式化时间
const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  return `${date.getMonth() + 1}月${date.getDate()}日 ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

// 滚动到底部
const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// 加载历史消息
const loadMessages = async () => {
  loading.value = true
  try {
    const data = await getMessages()
    messages.value = data
    scrollToBottom()
  } catch (error) {
    ElMessage.error('获取历史消息失败，请确认后端是否启动')
    console.error('获取消息失败:', error)
  } finally {
    loading.value = false
  }
}

// 发送消息
const handleSend = async () => {
  const content = inputText.value.trim()
  if (!content) return

  sending.value = true
  try {
    await createMessage({
      sender_role: currentSender.value,
      text_content: content
    })
    inputText.value = ''
    ElMessage.success('发送成功 ❤️')
    // 重新加载消息
    await loadMessages()
  } catch (error) {
    ElMessage.error('发送失败，请重试')
    console.error('发送失败:', error)
  } finally {
    sending.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.chat-page {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 52px);
  background: #fff5f8;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 20px 16px;
}

.loading-tip,
.empty-tip {
  text-align: center;
  padding: 60px 20px;
  color: #b2bec3;
}

.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

/* 消息项布局 */
.message-item {
  display: flex;
  margin-bottom: 20px;
  gap: 10px;
}

.message-right {
  flex-direction: row-reverse;
}

.message-content {
  max-width: 70%;
}

.message-right .message-content {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
}

/* 头像 */
.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  flex-shrink: 0;
  font-size: 16px;
}

.female-avatar {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
}

.male-avatar {
  background: linear-gradient(135deg, #54a0ff 0%, #74b3ff 100%);
}

/* 昵称 */
.nickname {
  font-size: 12px;
  color: #b2bec3;
  margin-bottom: 4px;
  padding: 0 4px;
}

/* 气泡 */
.bubble {
  padding: 10px 14px;
  border-radius: 18px;
  font-size: 15px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.bubble-female {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
  color: white;
  border-bottom-right-radius: 4px;
}

.bubble-male {
  background: white;
  color: #2d3436;
  border: 1px solid #e8e8e8;
  border-bottom-left-radius: 4px;
}

/* AI小结 */
.ai-summary {
  margin-top: 6px;
  padding: 6px 10px;
  background: #f0f9ff;
  border-radius: 12px;
  font-size: 12px;
  color: #5f27cd;
  display: flex;
  align-items: center;
  gap: 4px;
}

/* 时间 */
.time {
  font-size: 11px;
  color: #dfe6e9;
  margin-top: 4px;
  padding: 0 4px;
}

/* 底部输入区域 */
.input-area {
  background: white;
  padding: 12px 16px;
  border-top: 1px solid #ffe3ee;
  box-shadow: 0 -2px 10px rgba(255, 107, 157, 0.05);
}

.sender-switch {
  margin-bottom: 10px;
  font-size: 13px;
  color: #636e72;
  display: flex;
  align-items: center;
  gap: 8px;
}

.input-row {
  display: flex;
  gap: 10px;
  align-items: flex-end;
}

.input-row :deep(.el-textarea__inner) {
  border-radius: 20px;
  padding: 10px 16px;
  border-color: #ffe3ee;
}

.input-row :deep(.el-textarea__inner:focus) {
  border-color: #ff6b9d;
}

.send-btn {
  border-radius: 20px;
  height: 40px;
  padding: 0 20px;
  flex-shrink: 0;
}
</style>
