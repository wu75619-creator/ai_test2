<template>
  <div class="chat-page">
    <!-- 聊天消息区域 -->
    <div class="messages-container" ref="messagesContainer">
      <div v-if="loading" class="loading-tip">
        <el-icon><Loading /></el-icon>
        加载中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💕</div>
        <p>还没有消息哦，快来记录第一条甜蜜吧~</p>
      </div>
      <div v-else>
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="message-item"
          :class="[msg.sender_role === 'female' ? 'message-right' : 'message-left']"
        >
          <div class="avatar" :class="msg.sender_role === 'female' ? 'female-avatar' : 'male-avatar'">
            {{ msg.sender_nickname.charAt(0) }}
          </div>
          <div class="message-content">
            <div class="nickname">{{ msg.sender_nickname }}</div>

            <!-- 图片展示 -->
            <div v-if="msg.media_urls && msg.media_urls.length > 0" class="image-grid">
              <img
                v-for="(url, idx) in msg.media_urls"
                :key="idx"
                :src="getMediaUrl(url)"
                class="chat-image"
                @click="previewImage(getMediaUrl(url))"
              />
            </div>

            <!-- 语音播放器 -->
            <div v-if="msg.voice_url" class="voice-message" @click="playVoice(getMediaUrl(msg.voice_url))">
              <el-icon :size="20"><Microphone /></el-icon>
              <span>{{ msg.voice_duration || 5 }}"</span>
              <el-icon v-if="playingVoice === getMediaUrl(msg.voice_url)" class="playing-icon"><VideoPlay /></el-icon>
            </div>
            <audio ref="voiceAudio" style="display: none"></audio>

            <!-- 文字气泡 -->
            <div
              v-if="msg.text_content"
              class="bubble"
              :class="msg.sender_role === 'female' ? 'bubble-female' : 'bubble-male'"
            >
              {{ msg.text_content }}
            </div>

            <!-- AI标签和分类 -->
            <div v-if="msg.ai_processed && msg.tags && msg.tags.length > 0" class="tags-row">
              <el-tag
                v-for="tag in msg.tags"
                :key="tag"
                size="small"
                effect="plain"
                class="ai-tag"
              >
                #{{ tag }}
              </el-tag>
              <span v-if="msg.category_icon" class="category-badge" :style="{background: msg.category_color + '20', color: msg.category_color}">
                {{ msg.category_icon }} {{ msg.category_name }}
              </span>
            </div>

            <!-- AI小结 -->
            <div v-if="msg.ai_processed && msg.ai_summary" class="ai-summary">
              <el-icon><MagicStick /></el-icon>
              <span>{{ msg.ai_summary }}</span>
            </div>

            <div class="time">{{ formatTime(msg.sent_at) }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部输入区域 -->
    <div class="input-area">
      <!-- AI模式开关 -->
      <div class="mode-switch-row">
        <div class="switch-left">
          <el-switch v-model="isAiAuto" class="ai-switch" />
          <span class="switch-label">
            <el-icon><MagicStick /></el-icon>
            AI自动分类
          </span>
        </div>
        <el-select
          v-if="!isAiAuto"
          v-model="manualCategory"
          placeholder="选择分类"
          size="small"
          class="category-select"
        >
          <el-option
            v-for="cat in categories"
            :key="cat.code"
            :label="cat.icon + ' ' + cat.name"
            :value="cat.code"
          />
        </el-select>
      </div>

      <!-- 已选图片预览 -->
      <div v-if="selectedImages.length > 0" class="selected-images">
        <div v-for="(img, idx) in selectedImages" :key="idx" class="selected-img-item">
          <img :src="URL.createObjectURL(img)" />
          <el-icon class="remove-img" @click="removeImage(idx)"><Close /></el-icon>
        </div>
      </div>

      <!-- 录制中提示 -->
      <div v-if="isRecording" class="recording-tip">
        <el-icon class="recording-icon"><Microphone /></el-icon>
        正在录音... {{ recordDuration }}s
        <el-button size="small" type="danger" @click="stopRecording">完成</el-button>
        <el-button size="small" @click="cancelRecording">取消</el-button>
      </div>

      <!-- 输入框和按钮 -->
      <div class="input-row">
        <div class="action-btns">
          <el-upload
            :show-file-list="false"
            accept="image/*"
            multiple
            :before-upload="handleImageSelect"
          >
            <el-button circle size="small">
              <el-icon><Picture /></el-icon>
            </el-button>
          </el-upload>
          <el-button circle size="small" @click="toggleRecording" :type="isRecording ? 'danger' : ''">
            <el-icon><Microphone /></el-icon>
          </el-button>
        </div>
        <el-input
          v-model="inputText"
          type="textarea"
          :rows="2"
          placeholder="随手记录此刻的甜蜜..."
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
        />
        <div class="send-section">
          <div class="sender-switch-mini">
            <el-radio-group v-model="currentSender" size="small">
              <el-radio-button value="female">她</el-radio-button>
              <el-radio-button value="male">他</el-radio-button>
            </el-radio-group>
          </div>
          <el-button
            type="primary"
            class="send-btn"
            :loading="sending"
            :disabled="!canSend"
            @click="handleSend"
          >
            发送
          </el-button>
        </div>
      </div>
    </div>

    <!-- 图片预览对话框 -->
    <el-dialog v-model="imagePreviewVisible" width="90%" :show-close="true" class="image-preview-dialog">
      <img :src="previewImageUrl" class="preview-img" />
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import {
  Loading, MagicStick, Picture, Microphone, Close, VideoPlay
} from '@element-plus/icons-vue'
import { getMessages, createMessage, getCategories, getMediaUrl, type Message, type Category } from '../api/message'

const messages = ref<Message[]>([])
const categories = ref<Category[]>([])
const loading = ref(false)
const sending = ref(false)
const inputText = ref('')
const currentSender = ref<'male' | 'female'>('female')
const messagesContainer = ref<HTMLElement | null>(null)
const voiceAudio = ref<HTMLAudioElement | null>(null)
const playingVoice = ref('')

// AI模式控制
const isAiAuto = ref(true)
const manualCategory = ref('')

// 图片上传
const selectedImages = ref<File[]>([])

// 语音录制
const isRecording = ref(false)
const recordDuration = ref(0)
const recordedVoice = ref<File | null>(null)
let mediaRecorder: MediaRecorder | null = null
let audioChunks: Blob[] = []
let recordTimer: number | null = null

// 图片预览
const imagePreviewVisible = ref(false)
const previewImageUrl = ref('')

const canSend = computed(() => {
  const hasContent = inputText.value.trim() || selectedImages.value.length > 0 || recordedVoice.value
  if (!isAiAuto.value && !manualCategory.value) return false
  return hasContent && !sending.value
})

const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  return `${date.getMonth() + 1}月${date.getDate()}日 ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

const previewImage = (url: string) => {
  previewImageUrl.value = url
  imagePreviewVisible.value = true
}

const playVoice = (url: string) => {
  if (voiceAudio.value) {
    voiceAudio.value.src = url
    voiceAudio.value.play()
    playingVoice.value = url
    voiceAudio.value.onended = () => {
      playingVoice.value = ''
    }
  }
}

const handleImageSelect = (file: File) => {
  selectedImages.value.push(file)
  return false // 阻止自动上传
}

const removeImage = (idx: number) => {
  selectedImages.value.splice(idx, 1)
}

// 语音录制功能
const toggleRecording = async () => {
  if (isRecording.value) {
    stopRecording()
    return
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    mediaRecorder = new MediaRecorder(stream)
    audioChunks = []
    recordDuration.value = 0

    mediaRecorder.ondataavailable = (e) => {
      audioChunks.push(e.data)
    }

    mediaRecorder.onstop = () => {
      const audioBlob = new Blob(audioChunks, { type: 'audio/webm' })
      recordedVoice.value = new File([audioBlob], `voice_${Date.now()}.webm`, { type: 'audio/webm' })
      stream.getTracks().forEach(track => track.stop())
    }

    mediaRecorder.start()
    isRecording.value = true
    recordTimer = window.setInterval(() => {
      recordDuration.value++
    }, 1000)
  } catch (e) {
    ElMessage.error('无法访问麦克风，请检查权限')
    console.error(e)
  }
}

const stopRecording = () => {
  if (mediaRecorder && isRecording.value) {
    mediaRecorder.stop()
    isRecording.value = false
    if (recordTimer) {
      clearInterval(recordTimer)
      recordTimer = null
    }
    ElMessage.success('语音录制完成')
  }
}

const cancelRecording = () => {
  if (mediaRecorder) {
    mediaRecorder.onstop = () => {}
    mediaRecorder.stop()
    recordedVoice.value = null
  }
  isRecording.value = false
  if (recordTimer) {
    clearInterval(recordTimer)
    recordTimer = null
  }
}

const loadMessages = async () => {
  loading.value = true
  try {
    const data = await getMessages()
    messages.value = data
    scrollToBottom()
  } catch (error) {
    ElMessage.error('获取历史消息失败，请确认后端是否启动')
    console.error('获取消息失败:', error)
  } finally {
    loading.value = false
  }
}

const loadCategories = async () => {
  try {
    categories.value = await getCategories()
  } catch (error) {
    console.error('加载分类失败:', error)
  }
}

const handleSend = async () => {
  if (!canSend.value) {
    if (!isAiAuto.value && !manualCategory.value) {
      ElMessage.warning('手动模式请先选择分类')
    }
    return
  }

  sending.value = true
  try {
    await createMessage({
      sender_role: currentSender.value,
      text_content: inputText.value.trim(),
      is_ai_auto: isAiAuto.value,
      manual_category: isAiAuto.value ? undefined : manualCategory.value,
      images: selectedImages.value.length > 0 ? selectedImages.value : undefined,
      voice: recordedVoice.value
    })

    inputText.value = ''
    selectedImages.value = []
    recordedVoice.value = null
    ElMessage.success('发送成功 ❤️')
    await loadMessages()
  } catch (error: any) {
    ElMessage.error(error.message || '发送失败，请重试')
    console.error('发送失败:', error)
  } finally {
    sending.value = false
  }
}

onMounted(() => {
  loadMessages()
  loadCategories()
})
</script>

<style scoped>
.chat-page {
  display: flex;
  flex-direction: column;
  height: calc(100vh - 52px - 60px);
  background: #fff5f8;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.loading-tip,
.empty-tip {
  text-align: center;
  padding: 60px 20px;
  color: #b2bec3;
}

.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.message-item {
  display: flex;
  margin-bottom: 20px;
  gap: 10px;
}

.message-right {
  flex-direction: row-reverse;
}

.message-content {
  max-width: 75%;
}

.message-right .message-content {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  flex-shrink: 0;
  font-size: 16px;
}

.female-avatar {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
}

.male-avatar {
  background: linear-gradient(135deg, #54a0ff 0%, #74b3ff 100%);
}

.nickname {
  font-size: 12px;
  color: #b2bec3;
  margin-bottom: 4px;
  padding: 0 4px;
}

/* 图片网格 */
.image-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 6px;
  max-width: 240px;
}

.chat-image {
  width: 110px;
  height: 110px;
  object-fit: cover;
  border-radius: 12px;
  cursor: pointer;
}

/* 语音消息 */
.voice-message {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  background: white;
  border-radius: 18px;
  margin-bottom: 6px;
  cursor: pointer;
  min-width: 80px;
}

.message-right .voice-message {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
  color: white;
  border-bottom-right-radius: 4px;
}

.message-left .voice-message {
  background: white;
  border: 1px solid #e8e8e8;
  border-bottom-left-radius: 4px;
}

.playing-icon {
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.bubble {
  padding: 10px 14px;
  border-radius: 18px;
  font-size: 15px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.bubble-female {
  background: linear-gradient(135deg, #ff6b9d 0%, #ff89b3 100%);
  color: white;
  border-bottom-right-radius: 4px;
}

.bubble-male {
  background: white;
  color: #2d3436;
  border: 1px solid #e8e8e8;
  border-bottom-left-radius: 4px;
}

.tags-row {
  margin-top: 6px;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  align-items: center;
}

.ai-tag {
  border-radius: 10px;
  font-size: 11px;
}

.category-badge {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
}

.ai-summary {
  margin-top: 6px;
  padding: 6px 10px;
  background: linear-gradient(135deg, #f8f5ff 0%, #f0e7ff 100%);
  border-radius: 12px;
  font-size: 12px;
  color: #5f27cd;
  display: flex;
  align-items: center;
  gap: 4px;
}

.time {
  font-size: 11px;
  color: #dfe6e9;
  margin-top: 4px;
  padding: 0 4px;
}

/* 输入区域 */
.input-area {
  background: white;
  padding: 10px 12px;
  border-top: 1px solid #ffe3ee;
  box-shadow: 0 -2px 10px rgba(255, 107, 157, 0.05);
}

.mode-switch-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  flex-wrap: wrap;
  gap: 8px;
}

.switch-left {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #636e72;
}

.switch-label {
  display: flex;
  align-items: center;
  gap: 4px;
}

.category-select {
  width: 180px;
}

.selected-images {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
  flex-wrap: wrap;
}

.selected-img-item {
  position: relative;
  width: 60px;
  height: 60px;
}

.selected-img-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 8px;
}

.remove-img {
  position: absolute;
  top: -6px;
  right: -6px;
  background: #ff6b9d;
  color: white;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  cursor: pointer;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.recording-tip {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: #ffe3ee;
  border-radius: 12px;
  margin-bottom: 8px;
  font-size: 13px;
  color: #ff6b9d;
}

.recording-icon {
  animation: pulse 1s infinite;
}

.input-row {
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.action-btns {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.send-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex-shrink: 0;
}

.sender-switch-mini {
  :deep(.el-radio-button__inner) {
    padding: 5px 10px;
    font-size: 12px;
  }
}

.input-row :deep(.el-textarea__inner) {
  border-radius: 20px;
  padding: 10px 16px;
  border-color: #ffe3ee;
}

.input-row :deep(.el-textarea__inner:focus) {
  border-color: #ff6b9d;
}

.send-btn {
  border-radius: 20px;
  height: 40px;
  padding: 0 20px;
}

/* 图片预览 */
.image-preview-dialog {
  text-align: center;
}

.preview-img {
  max-width: 100%;
  max-height: 80vh;
  border-radius: 12px;
}
</style>
