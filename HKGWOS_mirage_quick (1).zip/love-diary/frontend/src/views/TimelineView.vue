<template>
  <div class="timeline-page">
    <div class="page-header">
      <h2>📅 我们的恋爱时间轴</h2>
      <p class="subtitle">一起记录的每一个瞬间，都值得珍藏</p>
    </div>

    <div v-if="loading" class="loading-tip">
      <el-icon class="is-loading"><Loading /></el-icon>
      加载中...
    </div>

    <div v-else-if="messages.length === 0" class="empty-tip">
      <div class="empty-icon">💌</div>
      <p>还没有任何记录</p>
      <p class="sub">快去聊天页写下第一条甜蜜吧~</p>
    </div>

    <el-timeline v-else class="timeline-container">
      <el-timeline-item
        v-for="(group, dateKey) in groupedMessages"
        :key="dateKey"
        :timestamp="formatDateLabel(dateKey)"
        placement="top"
        :type="getTimelineType(group[0])"
        :icon="getTimelineIcon(group[0])"
        size="large"
      >
        <div class="date-card">
          <div class="date-header">
            <span class="date-badge" :style="{ background: getDateColor(group[0]) }">
              {{ getDateEmoji(group[0]) }} {{ formatDateHeader(dateKey) }}
            </span>
            <span class="count-badge">{{ group.length }} 条记录</span>
          </div>

          <div class="day-messages">
            <div
              v-for="msg in group"
              :key="msg.id"
              class="timeline-msg"
            >
              <div class="msg-time">{{ formatTime(msg.sent_at) }}</div>
              <div class="msg-bubble" :class="msg.sender_role">
                <div class="msg-sender">{{ msg.sender_nickname }}</div>
                <div v-if="msg.media_urls && msg.media_urls.length > 0" class="msg-images">
                  <img
                    v-for="(url, idx) in msg.media_urls"
                    :key="idx"
                    :src="getMediaUrl(url)"
                    class="msg-image"
                  />
                </div>
                <div v-if="msg.voice_url" class="msg-voice">
                  <el-icon><Microphone /></el-icon> 语音
                </div>
                <div v-if="msg.text_content" class="msg-content">{{ msg.text_content }}</div>
                <div v-if="msg.category_icon" class="msg-category">
                  {{ msg.category_icon }} {{ msg.category_name }}
                </div>
                <div v-if="msg.ai_summary" class="msg-ai-summary">
                  ✨ {{ msg.ai_summary }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </el-timeline-item>
    </el-timeline>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, Microphone } from '@element-plus/icons-vue'
import { getMessages, getMediaUrl, type Message } from '../api/message'

const messages = ref<Message[]>([])
const loading = ref(false)

// 按日期分组消息
const groupedMessages = computed(() => {
  const groups: Record<string, Message[]> = {}
  messages.value.forEach(msg => {
    const date = new Date(msg.sent_at)
    const dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
    if (!groups[dateKey]) {
      groups[dateKey] = []
    }
    groups[dateKey].push(msg)
  })
  // 按日期倒序
  return Object.fromEntries(
    Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0]))
  )
})

const formatDateLabel = (dateKey: string) => {
  const [year, month, day] = dateKey.split('-')
  return `${year}年${parseInt(month)}月${parseInt(day)}日`
}

const formatDateHeader = (dateKey: string) => {
  const [_, month, day] = dateKey.split('-')
  return `${parseInt(month)}月${parseInt(day)}日`
}

const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}

const getTimelineType = (msg: Message) => {
  if (msg.category_color === '#ff6b9d') return 'danger'
  if (msg.category_color === '#54a0ff') return 'primary'
  if (msg.category_color === '#ff9f43') return 'warning'
  return 'success'
}

const getTimelineIcon = (msg: Message) => {
  return msg.category_icon || '💌'
}

const getDateColor = (msg: Message) => {
  return msg.category_color || '#ff6b9d'
}

const getDateEmoji = (msg: Message) => {
  return msg.category_icon || '💕'
}

const loadMessages = async () => {
  loading.value = true
  try {
    const data = await getMessages()
    // 按时间倒序
    messages.value = data.reverse()
  } catch (error) {
    ElMessage.error('加载时间轴失败')
    console.error(error)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.timeline-page {
  min-height: calc(100vh - 52px - 60px);
  background: #fff9fb;
  padding: 20px 16px;
}

.page-header {
  text-align: center;
  margin-bottom: 30px;
}

.page-header h2 {
  font-size: 22px;
  color: #2d3436;
  margin-bottom: 8px;
}

.subtitle {
  font-size: 13px;
  color: #b2bec3;
}

.loading-tip,
.empty-tip {
  text-align: center;
  padding: 60px 20px;
  color: #b2bec3;
}

.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.empty-tip .sub {
  font-size: 12px;
  margin-top: 4px;
}

.timeline-container {
  padding: 0 10px;
}

.date-card {
  background: white;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 2px 12px rgba(255, 107, 157, 0.08);
  margin-bottom: 12px;
}

.date-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.date-badge {
  padding: 4px 12px;
  border-radius: 20px;
  color: white;
  font-size: 13px;
  font-weight: 500;
}

.count-badge {
  font-size: 12px;
  color: #b2bec3;
  background: #f5f5f5;
  padding: 2px 10px;
  border-radius: 10px;
}

.day-messages {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.timeline-msg {
  display: flex;
  gap: 12px;
}

.msg-time {
  font-size: 12px;
  color: #b2bec3;
  width: 40px;
  flex-shrink: 0;
  padding-top: 2px;
}

.msg-bubble {
  flex: 1;
  padding: 12px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.5;
}

.msg-bubble.female {
  background: linear-gradient(135deg, #ffe3ee 0%, #fff0f5 100%);
}

.msg-bubble.male {
  background: linear-gradient(135deg, #e3f0ff 0%, #f0f7ff 100%);
}

.msg-sender {
  font-size: 12px;
  font-weight: 500;
  margin-bottom: 4px;
  opacity: 0.8;
}

.msg-bubble.female .msg-sender {
  color: #ff6b9d;
}

.msg-bubble.male .msg-sender {
  color: #54a0ff;
}

.msg-images {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 6px;
}

.msg-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 8px;
}

.msg-voice {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #54a0ff;
  margin-bottom: 6px;
}

.msg-content {
  color: #2d3436;
  margin-bottom: 6px;
}

.msg-category {
  font-size: 11px;
  color: #636e72;
  margin-bottom: 4px;
}

.msg-ai-summary {
  font-size: 11px;
  color: #5f27cd;
  padding-top: 6px;
  border-top: 1px dashed rgba(95, 39, 205, 0.15);
  margin-top: 4px;
}

:deep(.el-timeline-item__timestamp) {
  color: #ff6b9d;
  font-weight: 500;
  font-size: 13px;
}
</style>
