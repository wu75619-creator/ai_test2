import request from '../utils/request'

export interface Message {
  id: string
  sender_id: string
  sender_role: 'male' | 'female'
  sender_nickname: string
  sender_color?: string
  message_type: string
  text_content: string
  media_urls?: string[]
  voice_url?: string
  voice_duration?: number
  tags: string[]
  ai_summary: string | null
  ai_confidence?: number
  category_code?: string
  category_name?: string
  category_icon?: string
  category_color?: string
  sent_at: string
  ai_processed: boolean
}

export interface Category {
  id: string
  code: string
  name: string
  icon: string
  color: string
  description: string
}

export interface CreateMessageParams {
  sender_role: 'male' | 'female'
  text_content?: string
  is_ai_auto: boolean
  manual_category?: string
  images?: File[]
  voice?: File | null
}

const API_BASE = 'http://127.0.0.1:8000/api'

// 获取所有历史消息
export const getMessages = () => {
  return request.get<any, Message[]>('/messages')
}

// 发送新消息（支持文件上传）
export const createMessage = async (params: CreateMessageParams): Promise<Message> => {
  const formData = new FormData()
  formData.append('sender_role', params.sender_role)
  formData.append('text_content', params.text_content || '')
  formData.append('is_ai_auto', params.is_ai_auto ? 'true' : 'false')

  if (params.manual_category) {
    formData.append('manual_category', params.manual_category)
  }

  if (params.images && params.images.length > 0) {
    params.images.forEach((img) => {
      formData.append('images', img)
    })
  }

  if (params.voice) {
    formData.append('voice', params.voice)
  }

  const response = await fetch(`${API_BASE}/messages`, {
    method: 'POST',
    body: formData
  })

  if (!response.ok) {
    const error = await response.json()
    throw new Error(error.detail || '发送失败')
  }

  return response.json()
}

// 获取所有分类
export const getCategories = () => {
  return request.get<any, Category[]>('/categories')
}

// 按分类获取消息，支持年/月筛选
export const getCategoryMessages = (categoryCode: string, year?: number, month?: number) => {
  return request.get<any, Message[]>(`/categories/${categoryCode}/messages`, {
    params: { year, month }
  })
}

// 获取静态资源完整URL
export const getMediaUrl = (path: string) => {
  if (path.startsWith('http')) return path
  return `http://127.0.0.1:8000${path}`
}
