import request from '../utils/request'

export interface Message {
  id: string
  sender_id: string
  sender_role: 'male' | 'female'
  sender_nickname: string
  message_type: string
  text_content: string
  sent_at: string
  ai_summary: string | null
  ai_processed: boolean
  main_category_id: string | null
}

export interface CreateMessageParams {
  sender_role: 'male' | 'female'
  text_content: string
}

// 获取所有历史消息
export const getMessages = () => {
  return request.get<any, Message[]>('/messages')
}

// 发送新消息
export const createMessage = (data: CreateMessageParams) => {
  return request.post<any, Message>('/messages', data)
}
