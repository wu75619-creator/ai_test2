# 💕 情侣智能随手恋爱日记本

对话式随手记录、AI 自动分类归档的双人专属恋爱记忆存档工具。

---

## 🛠 技术栈

| 层级 | 技术选型 | 版本 |
|------|---------|------|
| 前端 | Vue 3 + TypeScript + Vite | Vue 3.4 |
| UI框架 | Element Plus | 2.x |
| 状态管理 | Pinia | 2.x |
| 路由 | Vue Router | 4.x |
| 后端 | Python + FastAPI | Python 3.10+ |
| ORM | SQLAlchemy | 2.0 |
| 数据库 | SQLite（无需额外部署） | 3.x |

---

## 📊 核心数据库表结构

SQLite 数据库文件自动生成在 `backend/love_diary.db`

### 1. `couples` - 情侣账号组表（顶层容器）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | String(36) | UUID主键 |
| couple_name | String(100) | 情侣组合昵称 |
| access_password | String(255) | 访问密码(bcrypt加密) |
| start_date | Date | 在一起的日期 |
| created_at | DateTime | 创建时间 |

### 2. `users` - 用户表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | String(36) | UUID主键 |
| couple_id | String(36) | 关联情侣组 |
| role | String(20) | male=男主 / female=女主 |
| nickname | String(50) | 昵称 |
| avatar_url | String(500) | 头像 |
| theme_color | String(20) | 聊天气泡专属色 |

### 3. `categories` - 分类归档表（预置八大核心分类）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | String(36) | UUID主键 |
| code | String(50) | 分类编码（唯一） |
| name | String(50) | 分类名称 |
| icon | String(100) | 图标emoji |
| color | String(20) | 主题色 |
| is_system | Boolean | 是否系统预置 |

**预置八大分类：**
| code | 名称 | 图标 |
|------|------|------|
| food | 美食探店存档 | 🍜 |
| travel | 旅行&外出约会 | ✈️ |
| couple_photo | 情侣合照存档 | 📸 |
| daily_fun | 趣味日常存档 | 😂 |
| nickname | 专属昵称词典 | 💌 |
| deep_talk | 深度谈心存档 | 💬 |
| conflict | 矛盾复盘成长 | 💡 |
| voice | 语音专属存档 | 🎤 |

### 4. `messages` - 消息记录表（核心表）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | String(36) | UUID主键 |
| couple_id | String(36) | 关联情侣组 |
| sender_id | String(36) | 发送人 |
| **message_type** | String(20) | text/image/voice/sticker |
| text_content | Text | 文字内容/图片配文/语音转写 |
| media_urls | JSON | 多图URL数组 |
| voice_url | String(500) | 语音文件URL |
| voice_duration | Integer | 语音时长(秒) |
| **main_category_id** | String(36) | AI识别的**唯一主分类** |
| related_category_ids | JSON | 关联分类ID数组（支持联动归档） |
| tags | JSON | 子标签数组（支持多标签） |
| **ai_summary** | String(500) | AI生成的1-2句温柔小结 |
| ai_confidence | Float | AI分类置信度 0-1 |
| ai_processed | Boolean | AI是否完成处理 |
| ai_raw_response | JSON | AI返回原始数据 |
| **sent_at** | DateTime | 发送时间（全局时间轴排序依据） |
| is_deleted | Boolean | 软删除标记 |

> ✅ 设计满足PRD需求：单条消息唯一主分类 + 多子标签 + 关联分类联动 + 全局时间轴排序

### 5. `nicknames` - 专属昵称库表
自动抓取沉淀双方的专属称呼、私密代号、专属梗

| 字段 | 类型 | 说明 |
|------|------|------|
| id | String(36) | UUID主键 |
| nickname | String(100) | 昵称文本 |
| usage_count | Integer | 使用次数 |
| is_verified | Boolean | 用户确认标记 |

### 6. `media_files` - 文件资源表
统一管理图片、语音文件的元数据

---

## 🚀 启动命令

### 后端启动 (FastAPI)
```bash
cd backend

# 1. 创建虚拟环境（推荐）
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. 安装依赖
pip install -r requirements.txt

# 3. 配置环境变量
cp .env.example .env
# 编辑 .env 文件配置你的API Key（默认Mock模式无需配置即可本地测试）

# 4. 启动服务（首次启动会自动建表+预置数据）
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**✨ Swagger 接口文档地址：http://localhost:8000/docs**

**⚙️ .env 配置说明：**
| 变量 | 说明 | 默认值 |
|------|------|--------|
| `AI_MOCK` | AI模式开关，`true`=本地Mock模式（无需API Key），`false`=真实OpenAI接口 | `true` |
| `OPENAI_API_KEY` | OpenAI API Key（Mock模式下不需要） | - |
| `OPENAI_BASE_URL` | API接口地址，支持第三方兼容接口 | `https://api.openai.com/v1` |
| `OPENAI_MODEL` | 模型名称，需支持视觉多模态 | `gpt-4o-mini` |
- 可在文档页面直接在线调试API
- OpenAPI Schema: http://localhost:8000/openapi.json

### 已实现API接口
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| POST | `/api/messages` | 发送新消息（支持男主/女主角色） |
| GET | `/api/messages` | 获取所有历史消息（按时间正序） |

### 前端启动 (Vue3 + Vite)
```bash
cd frontend

# 1. 安装依赖
npm install

# 2. 启动开发服务器
npm run dev
```

前端访问：http://localhost:5173

默认首页为聊天页，打开即可看到双人对话流界面。

---

## 🔧 常见问题排查（跨域报错）

**如果前端调用API时出现跨域(CORS)报错：**

1. **确认后端已启动**：请先确保后端 `uvicorn app.main:app --reload` 正在运行，访问 http://localhost:8000/api/health 能正常返回

2. **后端CORS已配置**：后端已在 `app/main.py` 中配置 `allow_origins=["*"]` 允许所有源跨域，无需额外配置

3. **后端端口是否正确**：前端默认请求地址为 `http://127.0.0.1:8000/api`，如果后端修改了端口，请修改 `frontend/src/utils/request.ts` 中的 `baseURL`

4. **浏览器缓存问题**：尝试清除浏览器缓存或使用无痕模式打开

5. **检查控制台报错**：按F12打开开发者工具，查看Network面板中请求的具体错误信息

**典型启动顺序：先启动后端 → 再启动前端**

---

## 📁 项目目录结构
```
love-diary/
├── README.md
├── 01-architecture-design.md
├── backend/
│   ├── requirements.txt
│   ├── love_diary.db          # SQLite数据库文件（自动生成）
│   ├── uploads/               # 图片/语音上传目录
│   └── app/
│       ├── __init__.py
│       ├── database.py        # 数据库连接
│       ├── models.py          # SQLAlchemy数据模型 ✅
│       ├── init_db.py         # 数据库初始化脚本
│       └── main.py            # FastAPI入口
└── frontend/
    ├── package.json
    ├── vite.config.ts
    └── src/
        ├── main.ts
        ├── App.vue
        ├── router/
        ├── stores/
        ├── views/
        └── components/
```

---

---

## 🧪 功能测试指南

### 后端启动
```bash
cd backend
# 默认开启AI Mock模式，无需配置真实大模型即可测试
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
- AI Mock开关：设置环境变量 `AI_MOCK=false` 可切换到真实大模型模式（需自行实现API调用）
- Mock模式下会根据关键词自动匹配八大分类，随机生成标签和温柔小结

### 前端启动
```bash
cd frontend
npm run dev
```
访问 http://localhost:5173

### 三个页面测试方式
1. **💬 聊天记录页（默认首页）**
   - **发送纯文字**：输入框输入内容直接发送
   - **发送图片**：点击📷图片按钮，选择一张或多张图片上传，可配文也可纯图片
   - **发送语音**：点击🎤麦克风按钮授权后开始录音，再点一次完成发送
   - **身份切换**：右下角「他/她」按钮切换发送人身份
   - **AI自动/手动模式切换**：
     - ✅ 默认开启「AI自动分类」开关，发送后AI自动识别分类、打标签、写小结
     - ❌ 关闭开关后，会出现分类下拉框，**必须手动选择8个分类之一**才能发送，手动模式无AI小结
   - 点击图片可放大预览，点击语音条可播放
   - 消息气泡显示分类标记、AI标签和AI生成的温柔文案

2. **📂 分类相册页（底部Tab第二个）**
   - 顶部横向滚动切换八大分类：🍜美食、✈️旅行、📸合照、😂日常等
   - 点击月份选择器可按年月筛选历史记录
   - 卡片式展示每条记忆，包含：发送人头像、内容、AI标签、AI小结、日期

3. **📅 恋爱时间轴页（底部Tab第三个）**
   - 使用Element Plus Timeline组件，按日期倒序串联所有记录
   - 不同分类用对应颜色的时间线节点和emoji图标展示
   - 同一天的消息聚合在一起，清晰还原恋爱全过程

## ✨ 核心特性对应表
| PRD需求 | 实现方案 |
|---------|---------|
| 单条内容自动匹配唯一主分类 | `messages.main_category_id` 外键关联 |
| 支持多个子标签 | `messages.tags` JSON数组字段 |
| 分类联动归档 | `messages.related_category_ids` 关联数组 |
| 全局时间轴展示 | `messages.sent_at` 时间戳字段 + 索引 |
| AI自动生成小结 | `messages.ai_summary` 字段 |
| 语音消息支持 | `voice_url` + `voice_duration` + `voice_transcript` |
| 多图一次性上传 | `media_urls` JSON数组 |
| 专属昵称自动沉淀 | 独立`nicknames`表 + 自动检测 |
| 防误删 | `is_deleted` 软删除机制 |
