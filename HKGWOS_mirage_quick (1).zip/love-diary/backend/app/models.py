from sqlalchemy import Column, String, Text, Integer, Float, Boolean, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime
import uuid

Base = declarative_base()


def generate_uuid():
    return str(uuid.uuid4())


class User(Base):
    """用户表 - 男主/女主双角色"""
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    role = Column(String(20), nullable=False, comment="male=男主, female=女主")
    nickname = Column(String(50), nullable=False)
    avatar_url = Column(String(500))
    theme_color = Column(String(20), default="#ff6b9d", comment="气泡专属配色")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages = relationship("Message", back_populates="sender")


class Category(Base):
    """分类表 - 八大核心分类"""
    __tablename__ = "categories"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    code = Column(String(50), unique=True, nullable=False, comment="分类编码")
    name = Column(String(50), nullable=False, comment="分类名称")
    icon = Column(String(100), comment="分类图标emoji")
    color = Column(String(20), comment="分类主题色")
    description = Column(String(200))
    sort_order = Column(Integer, default=0)
    is_system = Column(Boolean, default=True, comment="是否系统预置")
    created_at = Column(DateTime, default=datetime.utcnow)


class Message(Base):
    """消息记录表 - 核心表"""
    __tablename__ = "messages"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    sender_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # 消息类型与内容
    message_type = Column(String(20), nullable=False, default="text", comment="text/image/voice/sticker")
    text_content = Column(Text, comment="文字内容/图片配文/语音转写")
    media_urls = Column(JSON, comment="图片URL数组")
    voice_url = Column(String(500), comment="语音文件URL")
    voice_duration = Column(Integer, comment="语音时长(秒)")
    voice_transcript = Column(Text, comment="语音ASR转文字结果")

    # ========== AI分类相关字段 (PRD要求预留) ==========
    main_category_id = Column(String(36), ForeignKey("categories.id", ondelete="SET NULL"), comment="AI识别的唯一主分类")
    related_category_ids = Column(JSON, comment="关联分类ID数组，支持联动归档")
    tags = Column(JSON, comment="子标签数组")
    ai_summary = Column(String(500), comment="AI生成的1-2句温柔小结")
    ai_confidence = Column(Float, comment="AI分类置信度 0-1")
    ai_processed = Column(Boolean, default=False, comment="AI是否完成处理")
    ai_processed_at = Column(DateTime, comment="AI处理完成时间")
    ai_raw_response = Column(JSON, comment="AI返回的原始结构化数据")

    # 时间与状态
    sent_at = Column(DateTime, default=datetime.utcnow, nullable=False, comment="发送时间")
    is_deleted = Column(Boolean, default=False, comment="软删除标记")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sender = relationship("User", back_populates="messages")
