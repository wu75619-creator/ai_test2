from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import asc
from datetime import datetime
from .database import get_db
from .models import User, Message
from .schemas import MessageCreate, MessageResponse
from .init_db import init_database

# ========== 应用启动：自动初始化数据库 ==========
init_database()

app = FastAPI(
    title="💕 情侣智能随手恋爱日记本 API",
    description="对话式记录 + AI自动归档",
    version="1.0.0"
)

# ========== 配置CORS：允许所有源跨域 ==========
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", tags=["系统"])
async def health_check():
    """健康检查接口"""
    return {"status": "ok", "message": "恋爱日记本API运行中 ❤️", "time": datetime.utcnow()}


# ========== 消息相关核心API ==========

@app.post("/api/messages", response_model=MessageResponse, tags=["消息"])
async def create_message(message: MessageCreate, db: Session = Depends(get_db)):
    """
    创建新消息
    - sender_role: male(男主) / female(女主)
    - text_content: 消息文本内容
    """
    # 验证发送人角色
    if message.sender_role not in ["male", "female"]:
        raise HTTPException(status_code=400, detail="sender_role必须是 'male' 或 'female'")

    # 查询发送人用户
    sender = db.query(User).filter(User.role == message.sender_role).first()
    if not sender:
        raise HTTPException(status_code=404, detail=f"未找到角色为 {message.sender_role} 的用户")

    # 创建消息记录
    db_message = Message(
        sender_id=sender.id,
        message_type=message.message_type,
        text_content=message.text_content,
        sent_at=datetime.utcnow(),
        # ========== TODO: 接入AI分类打标逻辑 ==========
        # 1. 调用NLP/多模态模型识别文本/图片内容
        # 2. 匹配八大主分类之一 -> main_category_id
        # 3. 自动生成子标签 -> tags数组
        # 4. AI生成1-2句温柔小结 -> ai_summary
        # 5. 更新 ai_processed = True, ai_processed_at = datetime.utcnow()
        ai_processed=False
    )

    db.add(db_message)
    db.commit()
    db.refresh(db_message)

    # 构造响应
    return MessageResponse(
        id=db_message.id,
        sender_id=db_message.sender_id,
        sender_role=sender.role,
        sender_nickname=sender.nickname,
        message_type=db_message.message_type,
        text_content=db_message.text_content,
        sent_at=db_message.sent_at,
        ai_summary=db_message.ai_summary,
        ai_processed=db_message.ai_processed,
        main_category_id=db_message.main_category_id
    )


@app.get("/api/messages", response_model=list[MessageResponse], tags=["消息"])
async def get_messages(db: Session = Depends(get_db)):
    """
    获取所有历史消息
    按发送时间正序排列（时间轴顺序）
    """
    messages = db.query(Message).filter(Message.is_deleted == False).order_by(asc(Message.sent_at)).all()

    result = []
    for msg in messages:
        sender = db.query(User).filter(User.id == msg.sender_id).first()
        result.append(MessageResponse(
            id=msg.id,
            sender_id=msg.sender_id,
            sender_role=sender.role if sender else "unknown",
            sender_nickname=sender.nickname if sender else "未知",
            message_type=msg.message_type,
            text_content=msg.text_content,
            sent_at=msg.sent_at,
            ai_summary=msg.ai_summary,
            ai_processed=msg.ai_processed,
            main_category_id=msg.main_category_id
        ))

    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
