from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy import asc, desc
from datetime import datetime
from typing import Optional, List
import os
import uuid
import aiofiles
from .database import get_db
from .models import User, Message, Category
from .init_db import init_database
from .services.ai_service import process_message_content, CATEGORIES

# ========== 应用启动：自动初始化数据库 ==========
init_database()

app = FastAPI(
    title="💕 情侣智能随手恋爱日记本 API",
    description="对话式记录 + AI自动归档",
    version="2.0.0"
)

# ========== 配置CORS：允许所有源跨域 ==========
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ========== 挂载静态文件目录（上传的图片/语音可直接访问） ==========
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.get("/api/health", tags=["系统"])
async def health_check():
    """健康检查接口"""
    return {"status": "ok", "message": "恋爱日记本API运行中 ❤️", "time": datetime.utcnow()}


# ========== 分类相关API ==========
@app.get("/api/categories", tags=["分类"])
async def get_categories(db: Session = Depends(get_db)):
    """获取所有分类（含八大预置分类）"""
    categories = db.query(Category).order_by(Category.sort_order).all()
    return [
        {
            "id": cat.id,
            "code": cat.code,
            "name": cat.name,
            "icon": cat.icon,
            "color": cat.color,
            "description": cat.description
        }
        for cat in categories
    ]


@app.get("/api/categories/{category_code}/messages", tags=["分类"])
async def get_category_messages(
    category_code: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """按分类获取消息，支持按年/月筛选"""
    category = db.query(Category).filter(Category.code == category_code).first()
    if not category:
        raise HTTPException(status_code=404, detail=f"分类 {category_code} 不存在")

    query = db.query(Message).filter(
        Message.is_deleted == False,
        Message.main_category_id == category.id
    )

    # 时间筛选
    if year:
        query = query.filter(
            db.extract('year', Message.sent_at) == year
        )
    if month:
        query = query.filter(
            db.extract('month', Message.sent_at) == month
        )

    messages = query.order_by(desc(Message.sent_at)).all()

    result = []
    for msg in messages:
        sender = db.query(User).filter(User.id == msg.sender_id).first()
        result.append({
            "id": msg.id,
            "sender_id": msg.sender_id,
            "sender_role": sender.role if sender else "unknown",
            "sender_nickname": sender.nickname if sender else "未知",
            "message_type": msg.message_type,
            "text_content": msg.text_content,
            "media_urls": msg.media_urls,
            "voice_url": msg.voice_url,
            "voice_duration": msg.voice_duration,
            "tags": msg.tags or [],
            "ai_summary": msg.ai_summary,
            "ai_confidence": msg.ai_confidence,
            "category_code": category.code,
            "category_name": category.name,
            "category_icon": category.icon,
            "sent_at": msg.sent_at,
        })

    return result


# ========== 消息相关核心API ==========

@app.post("/api/messages", tags=["消息"])
async def create_message(
    sender_role: str = Form(...),
    text_content: Optional[str] = Form(""),
    is_ai_auto: bool = Form(True),
    manual_category: Optional[str] = Form(None),
    images: List[UploadFile] = File(None),
    voice: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    """
    创建新消息 - 支持多媒体上传 + AI自动/手动分类双模式
    - sender_role: male(男主) / female(女主)
    - text_content: 文字内容
    - is_ai_auto: 是否AI自动分类，默认true
    - manual_category: 手动选择的分类code（is_ai_auto=false时必填）
    - images: 上传的图片文件（支持多图）
    - voice: 上传的语音文件
    """
    # 验证发送人角色
    if sender_role not in ["male", "female"]:
        raise HTTPException(status_code=400, detail="sender_role必须是 'male' 或 'female'")

    # 查询发送人用户
    sender = db.query(User).filter(User.role == sender_role).first()
    if not sender:
        raise HTTPException(status_code=404, detail=f"未找到角色为 {sender_role} 的用户")

    # 手动分类模式验证
    if not is_ai_auto and not manual_category:
        raise HTTPException(status_code=400, detail="手动分类模式必须选择分类")

    # 确定消息类型
    message_type = "text"
    media_urls = []
    voice_url = None
    voice_duration = None
    saved_image_paths = []

    # 处理图片上传
    if images and len(images) > 0 and images[0].filename:
        message_type = "image"
        for img in images:
            if img.filename:
                ext = os.path.splitext(img.filename)[1].lower()
                if ext not in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
                    continue
                filename = f"{uuid.uuid4()}{ext}"
                file_path = os.path.join(UPLOAD_DIR, filename)
                async with aiofiles.open(file_path, 'wb') as f:
                    content = await img.read()
                    await f.write(content)
                media_urls.append(f"/uploads/{filename}")
                saved_image_paths.append(file_path)

    # 处理语音上传
    if voice and voice.filename:
        message_type = "voice"
        ext = os.path.splitext(voice.filename)[1].lower()
        filename = f"{uuid.uuid4()}{ext or '.webm'}"
        file_path = os.path.join(UPLOAD_DIR, filename)
        async with aiofiles.open(file_path, 'wb') as f:
            content = await voice.read()
            await f.write(content)
        voice_url = f"/uploads/{filename}"
        # TODO: 可以用ffprobe获取实际时长，这里先默认5秒
        voice_duration = 5

    # ========== AI智能分类处理 ==========
    ai_result = process_message_content(
        text_content=text_content or "",
        message_type=message_type,
        image_paths=saved_image_paths,
        manual_category=manual_category if not is_ai_auto else None
    )

    # 查找对应的分类记录
    main_category = db.query(Category).filter(Category.code == ai_result["main_category_code"]).first()
    main_category_id = main_category.id if main_category else None

    # 创建消息记录
    db_message = Message(
        sender_id=sender.id,
        message_type=message_type,
        text_content=text_content,
        media_urls=media_urls if media_urls else None,
        voice_url=voice_url,
        voice_duration=voice_duration,
        sent_at=datetime.utcnow(),
        # AI写入字段
        main_category_id=main_category_id,
        tags=ai_result["tags"],
        ai_summary=ai_result["ai_summary"],
        ai_confidence=ai_result["confidence"],
        ai_processed=True,
        ai_processed_at=datetime.utcnow(),
        ai_raw_response=ai_result
    )

    db.add(db_message)
    db.commit()
    db.refresh(db_message)

    # 构造响应
    return {
        "id": db_message.id,
        "sender_id": db_message.sender_id,
        "sender_role": sender.role,
        "sender_nickname": sender.nickname,
        "message_type": db_message.message_type,
        "text_content": db_message.text_content,
        "media_urls": db_message.media_urls,
        "voice_url": db_message.voice_url,
        "voice_duration": db_message.voice_duration,
        "tags": db_message.tags,
        "ai_summary": db_message.ai_summary,
        "ai_confidence": db_message.ai_confidence,
        "category_code": ai_result["main_category_code"],
        "category_name": ai_result["main_category_name"],
        "category_icon": main_category.icon if main_category else "💕",
        "category_color": main_category.color if main_category else "#ff6b9d",
        "sent_at": db_message.sent_at,
        "ai_processed": db_message.ai_processed
    }


@app.get("/api/messages", tags=["消息"])
async def get_messages(db: Session = Depends(get_db)):
    """
    获取所有历史消息 - 全局时间轴使用
    按发送时间正序排列（时间轴顺序）
    """
    messages = db.query(Message).filter(Message.is_deleted == False).order_by(asc(Message.sent_at)).all()

    # 预加载所有分类
    categories = {cat.id: cat for cat in db.query(Category).all()}

    result = []
    for msg in messages:
        sender = db.query(User).filter(User.id == msg.sender_id).first()
        category = categories.get(msg.main_category_id) if msg.main_category_id else None
        result.append({
            "id": msg.id,
            "sender_id": msg.sender_id,
            "sender_role": sender.role if sender else "unknown",
            "sender_nickname": sender.nickname if sender else "未知",
            "sender_color": sender.theme_color if sender else "#ff6b9d",
            "message_type": msg.message_type,
            "text_content": msg.text_content,
            "media_urls": msg.media_urls,
            "voice_url": msg.voice_url,
            "voice_duration": msg.voice_duration,
            "tags": msg.tags or [],
            "ai_summary": msg.ai_summary,
            "category_code": category.code if category else None,
            "category_name": category.name if category else None,
            "category_icon": category.icon if category else None,
            "category_color": category.color if category else None,
            "sent_at": msg.sent_at,
            "ai_processed": msg.ai_processed
        })

    return result


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
