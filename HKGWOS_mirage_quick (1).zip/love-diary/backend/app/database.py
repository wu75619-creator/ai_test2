from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

# SQLite 数据库文件路径
SQLALCHEMY_DATABASE_URL = "sqlite:///./love_diary.db"

# 创建引擎，SQLite 需要 check_same_thread=False
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# 数据库依赖
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
