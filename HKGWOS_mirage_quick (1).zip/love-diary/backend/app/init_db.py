from .database import engine, SessionLocal
from .models import Base, User, Category
from datetime import datetime


def init_database():
    """初始化数据库：创建所有表 + 预置基础数据"""
    print("💾 正在初始化SQLite数据库...")
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        # 预置八大系统分类
        existing_cats = db.query(Category).count()
        if existing_cats == 0:
            print("📂 正在预置八大核心分类...")
            system_categories = [
                {"code": "food", "name": "美食探店存档", "icon": "🍜", "color": "#ff9f43",
                 "description": "一起打卡的美食、奶茶、餐厅", "sort_order": 1},
                {"code": "travel", "name": "旅行&外出约会", "icon": "✈️", "color": "#54a0ff",
                 "description": "约会、旅行、逛街、游玩记录", "sort_order": 2},
                {"code": "couple_photo", "name": "情侣合照存档", "icon": "📸", "color": "#ff6b9d",
                 "description": "双人自拍、同框合照", "sort_order": 3},
                {"code": "daily_fun", "name": "趣味日常存档", "icon": "😂", "color": "#feca57",
                 "description": "搞笑对话、互怼日常、可爱瞬间", "sort_order": 4},
                {"code": "nickname", "name": "专属昵称词典", "icon": "💌", "color": "#c8d6e5",
                 "description": "专属称呼、私密代号、专属梗", "sort_order": 5},
                {"code": "deep_talk", "name": "深度谈心存档", "icon": "💬", "color": "#5f27cd",
                 "description": "走心交流、三观碰撞、未来规划、爱意表达", "sort_order": 6},
                {"code": "conflict", "name": "矛盾复盘成长", "icon": "💡", "color": "#ee5253",
                 "description": "矛盾记录、反思道歉、和解感悟、改进约定", "sort_order": 7},
                {"code": "voice", "name": "语音专属存档", "icon": "🎤", "color": "#00d2d3",
                 "description": "所有语音消息甜蜜存档", "sort_order": 8},
            ]
            for cat in system_categories:
                db_cat = Category(
                    code=cat["code"],
                    name=cat["name"],
                    icon=cat["icon"],
                    color=cat["color"],
                    description=cat["description"],
                    sort_order=cat["sort_order"],
                    is_system=True,
                    created_at=datetime.utcnow()
                )
                db.add(db_cat)

        # 预置男女主测试用户
        male_user = db.query(User).filter(User.role == "male").first()
        if not male_user:
            print("👦 创建男主用户...")
            male = User(
                role="male",
                nickname="男朋友",
                theme_color="#54a0ff",
                created_at=datetime.utcnow()
            )
            db.add(male)

        female_user = db.query(User).filter(User.role == "female").first()
        if not female_user:
            print("👧 创建女主用户...")
            female = User(
                role="female",
                nickname="女朋友",
                theme_color="#ff6b9d",
                created_at=datetime.utcnow()
            )
            db.add(female)

        db.commit()
        print("✅ 数据库初始化完成！")
    finally:
        db.close()


if __name__ == "__main__":
    init_database()
