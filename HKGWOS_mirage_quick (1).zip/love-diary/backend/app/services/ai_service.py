import random
import os
import base64
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()

AI_MOCK_MODE = os.getenv("AI_MOCK", "true").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

CATEGORIES = [
    {"code": "food", "name": "美食探店存档", "icon": "\U0001f35c", "tags": ["奶茶", "火锅", "探店", "甜品", "烧烤", "日料", "咖啡"]},
    {"code": "travel", "name": "旅行&外出约会", "icon": "\u2708\ufe0f", "tags": ["约会", "逛街", "看电影", "公园", "旅行", "景点", "散步"]},
    {"code": "couple_photo", "name": "情侣合照存档", "icon": "\U0001f4f8", "tags": ["合照", "自拍", "同框", "纪念照", "合影"]},
    {"code": "daily_fun", "name": "趣味日常存档", "icon": "\U0001f602", "tags": ["搞笑", "互怼", "可爱", "梗", "段子", "表情包"]},
    {"code": "nickname", "name": "专属昵称词典", "icon": "\U0001f48c", "tags": ["昵称", "代号", "专属梗", "暗号"]},
    {"code": "deep_talk", "name": "深度谈心存档", "icon": "\U0001f4ac", "tags": ["谈心", "未来", "爱意", "三观", "告白", "想你"]},
    {"code": "conflict", "name": "矛盾复盘成长", "icon": "\U0001f4a1", "tags": ["矛盾", "吵架", "反思", "和解", "约定", "对不起"]},
    {"code": "voice", "name": "语音专属存档", "icon": "\U0001f3a4", "tags": ["语音", "告白", "晚安", "早安"]},
]

SUMMARY_TEMPLATES = {
    "food": [
        "今天又和宝贝打卡了好吃的，又是被美食和爱意填满的一天呀~",
        "两个人一起吃的饭，总是格外香甜，干饭人情侣的甜蜜瞬间~",
        "记录下这次一起尝的美味，下次还要一起来吃哦\U0001f60b"
    ],
    "travel": [
        "和你一起走过的路，都是最美的风景，今天的约会超开心！",
        "手牵手出门的日子，连风都是甜的，又是值得纪念的约会日~",
        "去哪里不重要，重要的是身边是你，今天也超爱你呀\U0001f970"
    ],
    "couple_photo": [
        "咔嚓！留下我们的同框瞬间，每一张合照都是爱的证明~",
        "和你的每一张合照，都要好好收藏起来，以后慢慢看",
        "最幸福的事就是和你一起拍好多好多照片\U0001f4f8"
    ],
    "daily_fun": [
        "今天也是和宝互怼欢乐多的一天，有你在每天都好好笑哈哈哈",
        "奇奇怪怪可可爱爱的日常，只有我们懂的小乐趣~",
        "和你在一起连无聊都变得有趣，这就是爱情的魔力吧\U0001f602"
    ],
    "nickname": [
        "发现了我们的专属小暗号，这是只属于我们两个人的秘密~",
        "又多了一个可爱的专属昵称，以后就这么叫你啦\U0001f61c",
        "专属昵称库又更新啦，这些暗号只有我们懂"
    ],
    "deep_talk": [
        "今晚和你说了好多心里话，感觉我们的心又更近了一步",
        "谢谢你愿意和我分享所有想法，我们要一直这样坦诚下去呀",
        "和你聊完感觉对未来更有期待了，我们一起加油\U0001f4aa"
    ],
    "conflict": [
        "虽然有小矛盾，但说开了就好，我们又一起成长了一点点",
        "谢谢你愿意包容我，我们约定好下次都不冷战好不好",
        "每一次和解都让我们更懂彼此，感情也会越来越好的\U0001f4a1"
    ],
    "voice": [
        "你的语音我要反复听好多遍，声音真的太好听啦\U0001f3a4",
        "记录下你的声音，想你的时候就拿出来听一听",
        "软软的语音真的太治愈了，所有疲惫都没啦"
    ]
}


def encode_image(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode('utf-8')


def mock_ai_process(text_content: str, message_type: str = "text", image_paths: List[str] = None) -> Dict[str, Any]:
    if message_type == "voice":
        category_code = "voice"
        selected_category = next(c for c in CATEGORIES if c["code"] == category_code)
    else:
        content = text_content or ""
        category_code = None
        if any(keyword in content for keyword in ["吃", "饭", "奶茶", "火锅", "好吃", "餐厅", "探店", "喝", "咖啡"]):
            category_code = "food"
        elif any(keyword in content for keyword in ["约会", "出门", "玩", "旅行", "逛街", "电影", "走", "公园"]):
            category_code = "travel"
        elif any(keyword in content for keyword in ["照片", "合照", "自拍", "拍", "合影"]):
            category_code = "couple_photo"
        elif any(keyword in content for keyword in ["哈哈", "搞笑", "傻", "梗", "笑死"]):
            category_code = "daily_fun"
        elif any(keyword in content for keyword in ["爱你", "喜欢", "未来", "谈心", "心里话", "想你", "告白"]):
            category_code = "deep_talk"
        elif any(keyword in content for keyword in ["对不起", "错了", "吵架", "生气", "反思", "抱歉"]):
            category_code = "conflict"
        else:
            if image_paths and len(image_paths) > 0:
                category_code = random.choice(["food", "travel", "couple_photo", "daily_fun"])
            else:
                selected_category = random.choice(CATEGORIES)
                category_code = selected_category["code"]

        selected_category = next(c for c in CATEGORIES if c["code"] == category_code)

    tag_count = random.randint(1, min(3, len(selected_category["tags"])))
    tags = random.sample(selected_category["tags"], tag_count)
    summary = random.choice(SUMMARY_TEMPLATES[category_code])

    return {
        "main_category_code": category_code,
        "main_category_name": selected_category["name"],
        "tags": tags,
        "ai_summary": summary,
        "confidence": round(random.uniform(0.75, 0.98), 2),
        "processed_at": datetime.utcnow().isoformat()
    }


def real_ai_process(text_content: str, message_type: str = "text", image_paths: List[str] = None) -> Dict[str, Any]:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY, base_url=OPENAI_BASE_URL)

        categories_desc = "\n".join(["- %s: %s (%s)" % (c['code'], c['name'], ','.join(c['tags'])) for c in CATEGORIES])
        prompt = """你是一个情侣恋爱日记的AI分类助手。请根据用户发送的内容，从以下8个分类中选择最合适的一个：

%s

请返回JSON格式（不要其他内容）：
{
  "category_code": "分类code，必须是上面8个之一",
  "tags": ["1-3个简短标签"],
  "summary": "1-2句温柔治愈的小结，语气甜蜜，适合情侣看，50字以内"
}

用户发送的内容：%s""" % (categories_desc, text_content or "(无文本，只有图片)")

        content = [{"type": "text", "text": prompt}]

        if image_paths:
            for img_path in image_paths:
                try:
                    b64_img = encode_image(img_path)
                    ext = img_path.split('.')[-1].lower()
                    mime_map = {'jpg': 'jpeg', 'jpeg': 'jpeg', 'png': 'png', 'gif': 'gif', 'webp': 'webp'}
                    mime_type = "image/%s" % mime_map.get(ext, 'jpeg')
                    content.append({
                        "type": "image_url",
                        "image_url": {"url": "data:%s;base64,%s" % (mime_type, b64_img)}
                    })
                except Exception as e:
                    print("图片编码失败: %s" % e)

        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "你是一个专业的情侣日记AI助手，只返回JSON格式结果。"},
                {"role": "user", "content": content}
            ],
            temperature=0.7,
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)

        valid_codes = [c["code"] for c in CATEGORIES]
        category_code = result.get("category_code", "daily_fun")
        if category_code not in valid_codes:
            category_code = "daily_fun"

        selected_category = next(c for c in CATEGORIES if c["code"] == category_code)

        return {
            "main_category_code": category_code,
            "main_category_name": selected_category["name"],
            "tags": result.get("tags", [])[:3],
            "ai_summary": result.get("summary", "今天也是甜蜜的一天呀~"),
            "confidence": 0.9,
            "processed_at": datetime.utcnow().isoformat()
        }
    except Exception as e:
        print("OpenAI调用失败，降级到Mock: %s" % e)
        return mock_ai_process(text_content, message_type, image_paths)


def process_message_content(
    text_content: str = "",
    message_type: str = "text",
    image_paths: List[str] = None,
    manual_category: Optional[str] = None
) -> Dict[str, Any]:
    if manual_category:
        valid_codes = [c["code"] for c in CATEGORIES]
        if manual_category in valid_codes:
            selected_category = next(c for c in CATEGORIES if c["code"] == manual_category)
            return {
                "main_category_code": manual_category,
                "main_category_name": selected_category["name"],
                "tags": ["手动分类"],
                "ai_summary": None,
                "confidence": 1.0,
                "processed_at": datetime.utcnow().isoformat()
            }

    if AI_MOCK_MODE:
        return mock_ai_process(text_content, message_type, image_paths)
    else:
        return real_ai_process(text_content, message_type, image_paths)
