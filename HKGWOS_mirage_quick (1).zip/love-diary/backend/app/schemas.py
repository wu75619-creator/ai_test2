from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
import uuid


class MessageCreate(BaseModel):
    """创建消息请求体"""
    sender_role: str = Field(..., description="发送人角色: male=男主, female=女主")
    text_content: str = Field(..., min_length=1, description="消息文本内容")
    message_type: Optional[str] = "text"


class MessageResponse(BaseModel):
    """消息响应格式"""
    id: str
    sender_id: str
    sender_role: str
    sender_nickname: str
    message_type: str
    text_content: str
    sent_at: datetime
    ai_summary: Optional[str] = None
    ai_processed: bool
    main_category_id: Optional[str] = None

    class Config:
        from_attributes = True


class UserCreate(BaseModel):
    role: str
    nickname: str
