# 情侣智能随手恋爱日记本 - 核心架构设计文档
## 第1步交付物 | 后续开发基准

---

## 一、技术栈选型确认

| 层级 | 技术选型 | 版本建议 | 选型理由 |
|------|---------|---------|---------|
| **前端框架** | Vue 3 + TypeScript | Vue ^3.4.x | 组合式API适合复杂交互，TS保障代码质量 |
| **构建工具** | Vite | ^5.x | 极速热更新，开发体验优秀 |
| **UI框架** | Element Plus + 自定义主题 | ^2.7.x | 成熟组件库，支持深度定制治愈风配色 |
| **状态管理** | Pinia | ^2.1.x | Vue官方推荐，轻量好用 |
| **路由** | Vue Router | ^4.3.x | 官方路由 |
| **后端框架** | Node.js + Fastify | Node ^20 LTS, Fastify ^4.28.x | 性能优于Express，生态完善，前后端统一JS/TS |
| **数据库** | PostgreSQL | ^16 | 原生支持JSON/数组，比MySQL更适合存储标签、分类等灵活结构化数据 |
| **ORM** | Prisma | ^5.18.x | 类型安全，迁移方便，开发效率高 |
| **文件存储** | 本地文件系统 + 抽象层 | - | 开发阶段本地存储，生产可无缝切换S3/阿里云OSS |
| **AI接口层** | OpenAI兼容协议 + 多模型适配层 | - | 支持GPT-4o/视觉模型/NLP模型切换，处理图像识别+文本分类+文案生成 |
| **实时通信** | WebSocket (ws库) | ^8.x | 聊天消息实时推送、AI处理状态实时同步 |
| **部署** | 前端Nginx静态托管 + 后端PM2/Docker | - | 简单稳定，支持Vercel/Netlify/云服务器 |

---

## 二、核心数据库表结构设计（PostgreSQL DDL）

```sql
-- ============================================
-- 情侣智能随手恋爱日记本 - 数据库设计
-- 数据库: PostgreSQL 16+
-- 设计原则: 支持主分类+子标签机制、全局时间轴、AI处理全流程
-- ============================================

-- 启用UUID扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- --------------------------------------------
-- 1. 情侣账号组表 (顶层容器)
-- --------------------------------------------
CREATE TABLE couples (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_name VARCHAR(100),
    access_password VARCHAR(255) NOT NULL,
    start_date DATE,
    avatar_url VARCHAR(500),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --------------------------------------------
-- 2. 用户表 (仅男女主两个角色)
-- --------------------------------------------
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('male', 'female')),
    nickname VARCHAR(50) NOT NULL,
    avatar_url VARCHAR(500),
    theme_color VARCHAR(20) DEFAULT '#ff6b9d',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(couple_id, role)
);

-- --------------------------------------------
-- 3. 主分类表 (预置八大核心分类)
-- --------------------------------------------
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID REFERENCES couples(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(100),
    color VARCHAR(20),
    description VARCHAR(200),
    sort_order INT DEFAULT 0,
    is_system BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 预置八大核心分类数据
INSERT INTO categories (code, name, icon, color, description, is_system, sort_order) VALUES
('food', '美食探店存档', '🍜', '#ff9f43', '一起打卡的美食、奶茶、餐厅', true, 1),
('travel', '旅行&外出约会', '✈️', '#54a0ff', '约会、旅行、逛街、游玩记录', true, 2),
('couple_photo', '情侣合照存档', '📸', '#ff6b9d', '双人自拍、同框合照', true, 3),
('daily_fun', '趣味日常存档', '😂', '#feca57', '搞笑对话、互怼日常、可爱瞬间', true, 4),
('nickname', '专属昵称词典', '💌', '#c8d6e5', '专属称呼、私密代号、专属梗', true, 5),
('deep_talk', '深度谈心存档', '💬', '#5f27cd', '走心交流、三观碰撞、未来规划、爱意表达', true, 6),
('conflict', '矛盾复盘成长', '💡', '#ee5253', '矛盾记录、反思道歉、和解感悟、改进约定', true, 7),
('voice', '语音专属存档', '🎤', '#00d2d3', '所有语音消息甜蜜存档', true, 8);

-- --------------------------------------------
-- 4. 子标签表 (AI自动打标 + 自定义)
-- --------------------------------------------
CREATE TABLE tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    tag_type VARCHAR(20) DEFAULT 'ai' CHECK (tag_type IN ('ai', 'custom')),
    usage_count INT DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(couple_id, name)
);

-- --------------------------------------------
-- 5. 消息记录表 (核心表，所有聊天内容)
-- --------------------------------------------
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- 消息类型与内容
    message_type VARCHAR(20) NOT NULL CHECK (message_type IN ('text', 'image', 'voice', 'sticker')),
    text_content TEXT,
    media_urls TEXT[],
    voice_url VARCHAR(500),
    voice_duration INT,
    voice_transcript TEXT,
    sticker_code VARCHAR(50),

    -- AI分类处理结果
    main_category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    related_category_ids UUID[],
    ai_summary VARCHAR(500),
    ai_confidence FLOAT,
    ai_processed BOOLEAN NOT NULL DEFAULT false,
    ai_processed_at TIMESTAMPTZ,
    ai_raw_response JSONB,
    is_nickname_detected BOOLEAN DEFAULT false,

    -- 时间与状态
    sent_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    edited_at TIMESTAMPTZ,
    is_deleted BOOLEAN NOT NULL DEFAULT false,
    deleted_by UUID REFERENCES users(id) ON DELETE SET NULL,
    deleted_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 关键索引：支持时间轴、分类筛选、情侣隔离
CREATE INDEX idx_messages_couple_sent ON messages(couple_id, sent_at DESC);
CREATE INDEX idx_messages_category ON messages(couple_id, main_category_id, sent_at DESC);
CREATE INDEX idx_messages_sender ON messages(sender_id);
CREATE INDEX idx_messages_ai_processed ON messages(couple_id, ai_processed) WHERE ai_processed = false;

-- --------------------------------------------
-- 6. 消息-标签关联表 (多对多，单条消息多个子标签)
-- --------------------------------------------
CREATE TABLE message_tags (
    message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    tag_id UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    tagged_by VARCHAR(20) DEFAULT 'ai' CHECK (tagged_by IN ('ai', 'user')),
    confidence FLOAT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (message_id, tag_id)
);

-- --------------------------------------------
-- 7. 专属昵称库表 (特色功能：自动抓取沉淀)
-- --------------------------------------------
CREATE TABLE nicknames (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    nickname VARCHAR(100) NOT NULL,
    first_seen_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
    first_seen_at TIMESTAMPTZ,
    usage_count INT DEFAULT 1,
    context_examples TEXT[],
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(couple_id, nickname)
);

-- --------------------------------------------
-- 8. AI月度/年度汇总表
-- --------------------------------------------
CREATE TABLE ai_summaries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    summary_type VARCHAR(20) NOT NULL CHECK (summary_type IN ('monthly', 'yearly')),
    summary_date DATE NOT NULL,
    content TEXT NOT NULL,
    stats_data JSONB NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(couple_id, summary_type, summary_date)
);

-- --------------------------------------------
-- 9. 文件资源表 (统一管理图片、语音文件)
-- --------------------------------------------
CREATE TABLE media_files (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    couple_id UUID NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    message_id UUID REFERENCES messages(id) ON DELETE CASCADE,
    file_type VARCHAR(20) NOT NULL CHECK (file_type IN ('image', 'voice')),
    file_url VARCHAR(500) NOT NULL,
    file_path VARCHAR(500),
    mime_type VARCHAR(100),
    file_size INT,
    width INT,
    height INT,
    duration INT,
    uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_media_message ON media_files(message_id);
```

### 数据库设计核心要点

| 设计特性 | 实现方式 |
|---------|---------|
| **单条内容唯一主分类** | `messages.main_category_id` 外键，单字段唯一归属 |
| **多子标签支持** | `message_tags` 多对多关联表，单条消息可挂N个子标签 |
| **关联分类联动** | `messages.related_category_ids` UUID数组字段，一条内容可同时出现在多个分类页 |
| **全局时间轴** | `messages.sent_at` 精确时间戳 + 联合索引，天然支持全量内容按时间线排序 |
| **AI全流程状态** | `ai_processed` + `ai_confidence` + `ai_raw_response` 完整追踪 |
| **双人数据隔离** | 所有核心表均带 `couple_id`，确保数据完全隔离 |
| **专属昵称抓取** | 独立 `nicknames` 表 + `is_nickname_detected` 标记 |

---

## 三、系统架构与数据流转说明

### 3.1 整体三层架构

```
┌─────────────────────────────────────────────────────────────┐
│                   前端聊天交互层                              │
│  Vue3 + WebSocket                                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │ 聊天对话框│  │ 分类相册页│  │ 全局时间轴│  │ 昵称/复盘 │     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
└───────────────────────────┬─────────────────────────────────┘
                            │ WebSocket / HTTP
┌───────────────────────────▼─────────────────────────────────┐
│                   后端处理层 (Fastify)                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │ 消息接入 │  │ 文件存储 │  │ 用户鉴权 │  │ 数据持久化│     │
│  │ WebSocket│  │ 图片/语音│  │ 密码验证 │  │ PostgreSQL│     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │
│                            │                                  │
│                    ┌───────▼───────┐                         │
│                    │  AI 任务队列  │  异步处理，不阻塞用户    │
│                    └───────┬───────┘                         │
└───────────────────────────┼─────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────┐
│                   AI 模型分类层                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  NLP文本分类 │  │ 图像内容识别 │  │  ASR语音转写 │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│  ┌──────────────┐  ┌──────────────┐                          │
│  │  标签自动生成 │  │ 温柔小结生成 │                          │
│  └──────────────┘  └──────────────┘                          │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 核心数据流转过程

**流程1：用户发送消息 → AI自动归档（核心链路）**

1. 用户在聊天框发送内容（文字/多图/语音）
2. 前端 WebSocket 实时推送消息到后端
3. 后端立即写入 messages 表（原始数据持久化，ai_processed=false）
4. 后端即时推送「发送成功」回执给前端（用户消息立即显示，无等待感）
5. 后端异步触发 AI 处理任务（后台排队，不阻塞用户）
   - 若含图片 → 调用多模态视觉模型识别内容场景
   - 若含语音 → 先调用ASR转文字，再参与文本分类
   - 纯文本 → 直接调用NLP分类模型
6. AI 模型返回结构化结果：主分类、子标签、关联分类、温柔小结、检测到的昵称、置信度
7. 后端更新 messages 表记录，写入分类、摘要、标签关联
8. 检测到新昵称 → 写入 nicknames 表
9. WebSocket 主动推送 AI 处理完成事件 → 前端静默更新

**流程2：全局时间轴展示查询**
```sql
SELECT * FROM messages 
WHERE couple_id = ? AND is_deleted = false
ORDER BY sent_at DESC
```

**流程3：分类页内容查询**
```sql
SELECT * FROM messages 
WHERE couple_id = ? 
  AND (main_category_id = ? OR ? = ANY(related_category_ids))
  AND is_deleted = false
ORDER BY sent_at DESC
```
> 同时满足：主分类是该分类 OR 该分类在关联数组中，实现联动归档效果

### 3.3 关键架构决策

| 决策 | 原因 |
|------|------|
| **AI处理异步化** | 用户发消息立即入库返回，AI后台处理，用户无感知等待；哪怕AI接口出错，原始消息也不会丢失 |
| **WebSocket实时通信** | 聊天交互需要毫秒级响应，AI处理状态实时推送 |
| **PostgreSQL数组/JSONB** | 避免没必要的关联表，查询更高效 |
| **软删除机制** | `is_deleted`标记，满足情侣"防赌气删除"需求 |
| **通用AI接口层** | 后端抽象出统一AIService接口，可无缝切换不同模型供应商 |

---

## 四、项目目录结构预规划

```
love-diary/
├── 01-architecture-design.md    # 本文档（架构基准）
├── frontend/                    # Vue3 前端
│   ├── src/
│   │   ├── components/         # 聊天气泡、图片预览、播放器等
│   │   ├── views/              # 聊天页、分类页、时间轴页
│   │   ├── stores/             # Pinia状态管理
│   │   └── utils/websocket.ts  # WebSocket客户端
├── backend/                     # Fastify 后端
│   ├── src/
│   │   ├── routes/             # API路由
│   │   ├── services/
│   │   │   ├── ai.service.ts   # AI接口封装
│   │   │   └── message.service.ts
│   │   ├── ws/                 # WebSocket处理
│   │   └── plugins/            # Prisma、文件上传等
│   └── prisma/
│       └── schema.prisma       # 数据库Schema（由DDL转换）
└── uploads/                     # 本地文件存储目录
```

---

**✅ 第1步架构设计完成，以上内容作为后续所有代码开发的严格基准。**
