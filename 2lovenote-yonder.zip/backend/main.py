"""
LoveNote 后端入口
支持三种运行模式：
1. 开发模式：python main.py  →  使用源码目录的 uploads/ 和 ./love_diary.db
2. PyInstaller server.exe：直接运行 server.exe  →  数据写入用户目录
3. 桌面外壳调用：被 desktop.app 通过子进程拉起
"""
import os
import sys
import platform
from contextlib import asynccontextmanager


# ─────────────────────────────────────────────
# 路径解析：兼容源码运行 / PyInstaller 打包 / 桌面exe
# ─────────────────────────────────────────────

def _is_pyinstaller() -> bool:
    return getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS')


def _get_resource_dir() -> str:
    """PyInstaller 解压后的临时资源目录（只读），或源码目录"""
    if _is_pyinstaller():
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


def _get_user_data_dir() -> str:
    """可写数据目录：Windows=%APPDATA%/LoveNote, macOS=~/Library/Application Support/LoveNote, Linux=~/.lovenote"""
    system = platform.system()
    if system == "Windows":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        path = os.path.join(base, "LoveNote")
    elif system == "Darwin":
        path = os.path.expanduser("~/Library/Application Support/LoveNote")
    else:
        path = os.path.expanduser("~/.lovenote")
    os.makedirs(path, exist_ok=True)
    return path


# 资源根目录（dist静态文件、内置资源）
RESOURCE_DIR = _get_resource_dir()

# 用户数据目录（数据库 + uploads）—— 优先使用环境变量，否则用系统目录
DATA_DIR = os.environ.get("LOVENOTE_DATA_DIR", _get_user_data_dir())
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
DB_PATH = os.path.join(DATA_DIR, "love_diary.db")

os.makedirs(os.path.join(UPLOAD_DIR, "images"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "voices"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "videos"), exist_ok=True)

# 将 data 目录注入环境，供 database.py 使用
os.environ["LOVENOTE_DB_PATH"] = DB_PATH
os.environ["LOVENOTE_UPLOAD_DIR"] = UPLOAD_DIR

# 将资源目录加入 sys.path（PyInstaller 后 app 包在 _MEIPASS 里）
if RESOURCE_DIR not in sys.path:
    sys.path.insert(0, RESOURCE_DIR)


# ─────────────────────────────────────────────
# 查找前端 dist 目录（打包后在 RESOURCE_DIR/dist）
# ─────────────────────────────────────────────
DIST_DIR = None
for _p in [
    os.path.join(RESOURCE_DIR, "dist"),
    os.path.join(RESOURCE_DIR, "..", "frontend", "dist"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "dist"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "dist"),
]:
    if os.path.isdir(_p):
        DIST_DIR = os.path.abspath(_p)
        break


# ─────────────────────────────────────────────
# FastAPI 应用
# ─────────────────────────────────────────────
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from app.database import engine, Base, SessionLocal
from app.init_data import init_system_categories
from app.routers import messages, categories, stats, couple


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        init_system_categories(db)
    finally:
        db.close()
    yield


app = FastAPI(title="LoveNote - 情侣恋爱日记本", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(messages.router)
app.include_router(categories.router)
app.include_router(stats.router)
app.include_router(couple.router)

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "app": "LoveNote",
        "version": "2.0",
        "data_dir": DATA_DIR,
        "db_path": DB_PATH,
    }


# ── 静态文件服务 ─────────────────────────────
if DIST_DIR and os.path.isdir(DIST_DIR):
    @app.get("/")
    def index():
        return FileResponse(os.path.join(DIST_DIR, "index.html"))

    assets_dir = os.path.join(DIST_DIR, "assets")
    if os.path.isdir(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/favicon.ico")
    def favicon():
        return JSONResponse(status_code=204, content=None)

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str):
        if full_path.startswith("api/") or full_path.startswith("uploads/"):
            return JSONResponse({"detail": "Not found"}, status_code=404)
        index_path = os.path.join(DIST_DIR, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        return JSONResponse({"detail": "Not found"}, status_code=404)
else:
    @app.get("/")
    def dev_index():
        return {
            "app": "LoveNote",
            "mode": "development",
            "message": "Frontend dist not found. Run 'cd frontend && npm install && npm run build' first.",
            "data_dir": DATA_DIR,
        }


# ── 启动 ─────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", "8765"))
    host = os.environ.get("HOST", "127.0.0.1")
    uvicorn.run("main:app", host=host, port=port, reload=False, log_level="warning")
