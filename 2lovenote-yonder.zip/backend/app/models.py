from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, ForeignKey,
    Enum as SAEnum, JSON, Float
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from .database import Base


class ContentType(str, enum.Enum):
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    VIDEO = "video"
    STICKER = "sticker"


class UserRole(str, enum.Enum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class SummaryType(str, enum.Enum):
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"


class Couple(Base):
    __tablename__ = "couples"
    id = Column(Integer, primary_key=True, index=True)
    couple_name = Column(String(100), default="我们")
    together_date = Column(DateTime, nullable=True)
    access_password = Column(String(200), default="")
    onboarding_done = Column(Boolean, default=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    is_deleted = Column(Boolean, default=False)

    users = relationship("User", back_populates="couple")
    messages = relationship("Message", back_populates="couple")
    categories = relationship("Category", back_populates="couple")


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    couple_id = Column(Integer, ForeignKey("couples.id"))
    role = Column(SAEnum(UserRole), default=UserRole.OTHER)
    nickname = Column(String(50), default="")
    avatar_url = Column(String(500), default="")
    theme_color = Column(String(20), default="#ff6b9d")
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    couple = relationship("Couple", back_populates="users")
    messages = relationship("Message", back_populates="sender")


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True, index=True)
    couple_id = Column(Integer, ForeignKey("couples.id"), nullable=True)
    parent_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    name = Column(String(50), nullable=False)
    icon = Column(String(20), default="📁")
    color = Column(String(20), default="#ff6b9d")
    description = Column(String(200), default="")
    sort_order = Column(Integer, default=0)
    is_system = Column(Boolean, default=False)
    keywords = Column(JSON, default=list)
    created_at = Column(DateTime, server_default=func.now())

    couple = relationship("Couple", back_populates="categories")
    parent = relationship("Category", remote_side=[id])


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    couple_id = Column(Integer, ForeignKey("couples.id"))
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    sender_role = Column(SAEnum(UserRole), default=UserRole.OTHER)
    content_type = Column(SAEnum(ContentType), default=ContentType.TEXT)
    text_content = Column(Text, default="")
    main_category_id = Column(Integer, ForeignKey("categories.id"), nullable=True)
    ai_summary = Column(Text, default="")
    ai_processed = Column(Boolean, default=False)
    ai_processed_at = Column(DateTime, nullable=True)
    ai_confidence = Column(Float, default=0.0)
    location = Column(String(200), default="")
    extracted_nicknames = Column(JSON, default=list)
    voice_duration = Column(Float, nullable=True)
    video_duration = Column(Float, nullable=True)
    voice_transcribed = Column(Text, default="")
    is_edited = Column(Boolean, default=False)
    is_deleted = Column(Boolean, default=False)
    is_manual_category = Column(Boolean, default=False)
    created_at = Column(DateTime, server_default=func.now(), index=True)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    couple = relationship("Couple", back_populates="messages")
    sender = relationship("User", back_populates="messages")
    attachments = relationship("MessageAttachment", back_populates="message", cascade="all, delete-orphan")
    category = relationship("Category")


class MessageAttachment(Base):
    __tablename__ = "message_attachments"
    id = Column(Integer, primary_key=True, index=True)
    message_id = Column(Integer, ForeignKey("messages.id"))
    file_type = Column(String(20))
    file_url = Column(String(500))
    thumbnail_url = Column(String(500), default="")
    file_size = Column(Integer, default=0)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    duration = Column(Float, nullable=True)
    mime_type = Column(String(100), default="")
    created_at = Column(DateTime, server_default=func.now())

    message = relationship("Message", back_populates="attachments")


class AIProcessLog(Base):
    __tablename__ = "ai_process_logs"
    id = Column(Integer, primary_key=True, index=True)
    message_id = Column(Integer, ForeignKey("messages.id"))
    model_used = Column(String(100), default="")
    raw_response = Column(JSON, default=dict)
    processing_time_ms = Column(Integer, default=0)
    status = Column(String(20), default="pending")
    error_message = Column(Text, default="")
    created_at = Column(DateTime, server_default=func.now())
