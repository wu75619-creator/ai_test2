from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional

from ..database import get_db
from ..models import Couple, User, UserRole
from ..init_data import get_or_create_default_couple, get_or_create_users
from ..schemas import CoupleSetup, CoupleInfo

router = APIRouter(prefix="/api/couple", tags=["couple"])


class VerifyRequest(BaseModel):
    password: str


@router.post("/setup")
def setup_couple(body: CoupleSetup, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    couple.couple_name = body.couple_name or "我们"
    if body.together_date:
        try:
            couple.together_date = datetime.fromisoformat(body.together_date.replace("Z", "+00:00"))
        except Exception:
            pass
    if body.access_password:
        import hashlib
        couple.access_password = hashlib.sha256(body.access_password.encode()).hexdigest()
    else:
        couple.access_password = ""
    couple.onboarding_done = True
    male, female = get_or_create_users(db, couple, body.male_nickname or "他", body.female_nickname or "她")
    male.nickname = body.male_nickname or "他"
    female.nickname = body.female_nickname or "她"
    db.commit()
    return {"ok": True}


@router.get("/info")
def get_info(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    love_days = 0
    if couple.together_date:
        love_days = (datetime.utcnow() - couple.together_date).days
    male = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.MALE).first()
    female = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.FEMALE).first()
    return {
        "couple_name": couple.couple_name or "我们",
        "together_date": couple.together_date.isoformat() if couple.together_date else None,
        "onboarding_done": couple.onboarding_done,
        "love_days": love_days,
        "male_nickname": male.nickname if male else "他",
        "female_nickname": female.nickname if female else "她",
        "access_password_set": bool(couple.access_password),
    }


@router.post("/verify")
def verify_password(body: VerifyRequest, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    if not couple.access_password:
        return {"ok": True}
    import hashlib
    h = hashlib.sha256(body.password.encode()).hexdigest()
    if h == couple.access_password:
        return {"ok": True}
    raise HTTPException(401, "密码错误")


@router.post("/reset-onboarding")
def reset_onboarding(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    couple.onboarding_done = False
    db.commit()
    return {"ok": True}
