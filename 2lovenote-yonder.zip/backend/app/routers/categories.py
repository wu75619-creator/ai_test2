from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..database import get_db
from ..models import Category, Message, MessageAttachment, User, UserRole
from ..schemas import CategoryResponse, CategoryCreate, CategoryUpdate, MessageResponse
from ..init_data import get_or_create_default_couple, init_system_categories
from .messages import _build_response

router = APIRouter(prefix="/api/categories", tags=["categories"])


def _get_all_categories(db: Session, couple_id: int) -> List[Category]:
    sys_cats = db.query(Category).filter(Category.is_system == True).order_by(Category.sort_order).all()
    custom_cats = db.query(Category).filter(
        Category.is_system == False,
        (Category.couple_id == couple_id) | (Category.couple_id.is_(None))
    ).order_by(Category.sort_order, Category.id).all()
    return list(sys_cats) + list(custom_cats)


def _cat_to_response(cat: Category, msg_count: int = 0) -> dict:
    return {
        "id": cat.id,
        "name": cat.name,
        "icon": cat.icon or "📁",
        "color": cat.color or "#ff6b9d",
        "description": cat.description or "",
        "is_system": cat.is_system,
        "message_count": msg_count,
        "sort_order": cat.sort_order or 0,
    }


@router.get("", response_model=List[CategoryResponse])
def list_categories(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    init_system_categories(db)
    cats = _get_all_categories(db, couple.id)
    result = []
    for cat in cats:
        count = db.query(func.count(Message.id)).filter(
            Message.main_category_id == cat.id,
            Message.is_deleted == False
        ).scalar() or 0
        result.append(_cat_to_response(cat, count))
    return result


@router.post("", response_model=CategoryResponse)
def create_category(body: CategoryCreate, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    existing = db.query(Category).filter(
        Category.name == body.name,
        Category.couple_id == couple.id,
        Category.is_system == False
    ).first()
    if existing:
        raise HTTPException(400, "该分类名称已存在")
    max_order = db.query(func.max(Category.sort_order)).filter(
        (Category.couple_id == couple.id) | (Category.is_system == True)
    ).scalar() or 0
    cat = Category(
        couple_id=couple.id,
        name=body.name.strip(),
        icon=body.icon or "📁",
        color=body.color or "#ff6b9d",
        description=body.description or "",
        is_system=False,
        sort_order=(max_order + 1) if isinstance(max_order, int) else 1,
        keywords=[],
    )
    db.add(cat)
    db.commit()
    db.refresh(cat)
    return _cat_to_response(cat, 0)


@router.put("/{cat_id}", response_model=CategoryResponse)
def update_category(cat_id: int, body: CategoryUpdate, db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(404, "分类不存在")
    if cat.is_system:
        raise HTTPException(400, "系统分类不可修改")
    if body.name is not None:
        cat.name = body.name.strip()
    if body.icon is not None:
        cat.icon = body.icon
    if body.color is not None:
        cat.color = body.color
    if body.description is not None:
        cat.description = body.description
    db.commit()
    db.refresh(cat)
    count = db.query(func.count(Message.id)).filter(Message.main_category_id == cat.id).scalar() or 0
    return _cat_to_response(cat, count)


@router.delete("/{cat_id}")
def delete_category(cat_id: int, db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.id == cat_id).first()
    if not cat:
        raise HTTPException(404, "分类不存在")
    if cat.is_system:
        raise HTTPException(400, "系统分类不可删除")
    # Reassign messages to category 4 (趣味日常)
    db.query(Message).filter(Message.main_category_id == cat_id).update({"main_category_id": 4})
    db.delete(cat)
    db.commit()
    return {"ok": True}


@router.get("/name/{name}", response_model=List[MessageResponse])
def get_category_by_name(
    name: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db),
):
    couple = get_or_create_default_couple(db)
    cat = db.query(Category).filter(Category.name == name).first()
    if not cat:
        # Try custom categories
        cat = db.query(Category).filter(Category.name == name, Category.couple_id == couple.id).first()
    if not cat:
        return []
    q = db.query(Message).filter(
        Message.main_category_id == cat.id,
        Message.is_deleted == False,
    )
    if year:
        q = q.filter(func.strftime("%Y", Message.created_at) == str(year))
    if month:
        q = q.filter(func.strftime("%m", Message.created_at) == f"{month:02d}")
    msgs = q.order_by(Message.created_at.desc()).all()
    return [_build_response(m, db) for m in msgs]


@router.get("/{cat_id}/messages", response_model=List[MessageResponse])
def get_category_messages(
    cat_id: int,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db),
):
    q = db.query(Message).filter(
        Message.main_category_id == cat_id,
        Message.is_deleted == False,
    )
    if year:
        q = q.filter(func.strftime("%Y", Message.created_at) == str(year))
    if month:
        q = q.filter(func.strftime("%m", Message.created_at) == f"{month:02d}")
    msgs = q.order_by(Message.created_at.desc()).all()
    return [_build_response(m, db) for m in msgs]


@router.get("/stats/overview")
def category_stats(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    init_system_categories(db)
    total = db.query(func.count(Message.id)).filter(Message.is_deleted == False).scalar() or 0
    cats = _get_all_categories(db, couple.id)
    cat_list = []
    for c in cats:
        cnt = db.query(func.count(Message.id)).filter(
            Message.main_category_id == c.id, Message.is_deleted == False
        ).scalar() or 0
        cat_list.append({**_cat_to_response(c, cnt)})
    return {"total_messages": total, "categories": cat_list}
