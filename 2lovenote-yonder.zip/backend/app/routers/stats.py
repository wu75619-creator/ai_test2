from typing import List, Dict, Any
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, and_

from ..database import get_db
from ..models import Message, Category, Couple, User, UserRole
from ..init_data import get_or_create_default_couple

router = APIRouter(prefix="/api/stats", tags=["stats"])


def _get_week_bounds(dt: datetime) -> tuple:
    monday = (dt - timedelta(days=dt.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    sunday_end = monday + timedelta(days=6, hours=23, minutes=59, seconds=59)
    return monday, sunday_end


def _week_label(monday: datetime) -> str:
    sun = monday + timedelta(days=6)
    if monday.month == sun.month:
        return f"{monday.month}月{monday.day}日-{sun.day}日"
    return f"{monday.month}月{monday.day}日-{sun.month}月{sun.day}日"


def _get_couple_context(db: Session):
    couple = get_or_create_default_couple(db)
    love_days = 0
    if couple.together_date:
        love_days = (datetime.utcnow() - couple.together_date).days
    first_msg = db.query(func.min(Message.created_at)).filter(Message.is_deleted == False).scalar()
    if first_msg and not couple.together_date:
        love_days = (datetime.utcnow() - first_msg).days
    total_days = 0
    if first_msg:
        total_days = (datetime.utcnow() - first_msg).days + 1
    return couple, love_days, total_days, first_msg


@router.get("/overview")
def get_stats_overview(db: Session = Depends(get_db)) -> Dict[str, Any]:
    couple, love_days, total_days, first_msg = _get_couple_context(db)

    total_messages = db.query(func.count(Message.id)).filter(Message.is_deleted == False).scalar() or 0
    male_total = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.sender_role == UserRole.MALE
    ).scalar() or 0
    female_total = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.sender_role == UserRole.FEMALE
    ).scalar() or 0

    # Category distribution
    cat_counts = db.query(
        Message.main_category_id, func.count(Message.id)
    ).filter(Message.is_deleted == False).group_by(Message.main_category_id).all()
    cat_dist = []
    for cid, cnt in cat_counts:
        if cid:
            c = db.query(Category).filter(Category.id == cid).first()
            if c:
                cat_dist.append({
                    "id": c.id, "name": c.name, "icon": c.icon, "color": c.color,
                    "count": cnt,
                })
    cat_dist.sort(key=lambda x: -x["count"])

    # Hourly distribution (0-23)
    hourly = [0] * 24
    hour_rows = db.query(
        func.strftime("%H", Message.created_at), func.count(Message.id)
    ).filter(Message.is_deleted == False).group_by(func.strftime("%H", Message.created_at)).all()
    for h_str, cnt in hour_rows:
        h = int(h_str)
        hourly[h] = cnt

    # Weekly stats - last 8 weeks
    now = datetime.utcnow()
    weekly = []
    for i in range(8):
        monday, sunday_end = _get_week_bounds(now - timedelta(weeks=i))
        wk_ms = db.query(Message).filter(
            Message.is_deleted == False,
            Message.created_at >= monday,
            Message.created_at <= sunday_end,
        ).all()
        if not wk_ms and i > 4:
            continue
        m_count = sum(1 for m in wk_ms if m.sender_role == UserRole.MALE)
        f_count = sum(1 for m in wk_ms if m.sender_role == UserRole.FEMALE)
        cat_c = {}
        for m in wk_ms:
            if m.main_category_id:
                c = db.query(Category).filter(Category.id == m.main_category_id).first()
                cn = c.name if c else "未分类"
                cat_c[cn] = cat_c.get(cn, 0) + 1
        wk_hourly = {}
        for m in wk_ms:
            h = m.created_at.hour
            wk_hourly[h] = wk_hourly.get(h, 0) + 1
        most_active_h = max(wk_hourly, key=wk_hourly.get) if wk_hourly else 12
        days_span = min(7, (sunday_end - monday).days + 1)
        weekly.append({
            "week_label": _week_label(monday),
            "week_start": monday.strftime("%Y-%m-%d"),
            "total_messages": len(wk_ms),
            "male_count": m_count,
            "female_count": f_count,
            "category_counts": cat_c,
            "avg_daily": round(len(wk_ms) / max(days_span, 1), 1),
            "most_active_hour": most_active_h,
        })

    # Monthly stats - last 6 months
    monthly = []
    for i in range(6):
        dt = now.replace(day=1) - timedelta(days=1)
        for _ in range(i):
            dt = dt.replace(day=1) - timedelta(days=1)
        m_start = dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if m_start.month == 12:
            m_end = m_start.replace(year=m_start.year+1, month=1) - timedelta(seconds=1)
        else:
            m_end = m_start.replace(month=m_start.month+1) - timedelta(seconds=1)
        mo_ms = db.query(Message).filter(
            Message.is_deleted == False,
            Message.created_at >= m_start,
            Message.created_at <= m_end,
        ).all()
        if not mo_ms and i > 3:
            continue
        m_count = sum(1 for m in mo_ms if m.sender_role == UserRole.MALE)
        f_count = sum(1 for m in mo_ms if m.sender_role == UserRole.FEMALE)
        cat_c = {}
        daily_c = {}
        for m in mo_ms:
            if m.main_category_id:
                c = db.query(Category).filter(Category.id == m.main_category_id).first()
                cn = c.name if c else "未分类"
                cat_c[cn] = cat_c.get(cn, 0) + 1
            dk = m.created_at.strftime("%m-%d")
            daily_c[dk] = daily_c.get(dk, 0) + 1
        most_active_d = max(daily_c, key=daily_c.get) if daily_c else ""
        love_days_m = 0
        if couple.together_date:
            d_end = min(m_end, now)
            delta = (d_end - max(m_start, couple.together_date)).days
            love_days_m = max(0, delta)
        elif first_msg:
            love_days_m = max(0, (min(m_end, now) - max(m_start, first_msg)).days)
        monthly.append({
            "month_label": f"{m_start.year}年{m_start.month}月",
            "total_messages": len(mo_ms),
            "male_count": m_count,
            "female_count": f_count,
            "category_counts": cat_c,
            "daily_counts": daily_c,
            "most_active_day": most_active_d,
            "love_days_in_month": love_days_m,
        })

    return {
        "total_messages": total_messages,
        "total_days": total_days,
        "love_days": love_days,
        "male_total": male_total,
        "female_total": female_total,
        "weekly": weekly,
        "monthly": monthly,
        "category_distribution": cat_dist,
        "hourly_distribution": hourly,
    }


@router.get("/couple-info")
def get_couple_info(db: Session = Depends(get_db)):
    couple, love_days, total_days, first_msg = _get_couple_context(db)
    male = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.MALE).first()
    female = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.FEMALE).first()
    return {
        "couple_name": couple.couple_name or "我们",
        "together_date": couple.together_date.isoformat() if couple.together_date else None,
        "onboarding_done": couple.onboarding_done,
        "love_days": love_days,
        "male_nickname": male.nickname if male else "他",
        "female_nickname": female.nickname if female else "她",
        "access_password_set": bool(couple.access_password),
    }
