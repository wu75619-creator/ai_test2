import os
import json
import random
import re
import time
from typing import Optional, List, Dict
from sqlalchemy.orm import Session
from .models import Category, ContentType
from .init_data import SYSTEM_CATEGORIES

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

try:
    from PIL import Image
    import io
    import base64
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


SUMMARY_TEMPLATES = {
    1: ["又发现了好吃的！这就是幸福的味道～", "美食日记又添一笔，下次还要再来！", "和你一起吃饭，什么都特别香", "探店成功！果然听你的没错"],
    2: ["一起出门的日子总是特别开心！", "又留下了一段美好的回忆", "和你一起看世界，处处都是风景", "约会日最期待的就是见到你"],
    3: ["咔嚓！这个瞬间要永远保存", "每一张合影都是爱的证明", "我们的样子，就是幸福的样子", "镜头里全是你"],
    4: ["哈哈哈你怎么这么可爱！", "日常里的小确幸，笑到停不下来", "有你在身边，每天都好好笑", "有趣的灵魂找到了彼此"],
    5: ["被你甜到了！", "专属昵称是我们之间的秘密", "这声宝贝我收下了～", "甜甜的话只说给你听"],
    6: ["认真聊天的夜晚，感觉更近了", "谢谢你愿意和我说心里话", "能懂彼此，真的很好", "每一次深度交流都让我们更紧密"],
    7: ["吵过了就和好，感情更深厚了", "记录不开心是为了以后更珍惜", "雨后总会天晴的", "解决了这个问题，我们更懂彼此了"],
    8: ["语音里是你真实的声音，要好好保存", "听到你的声音就特别安心", "把此刻的声音保存下来", "语音里的温度不会消失"],
}
GENERIC_SUMMARIES = [
    "记录下这个有意义的瞬间", "今天也是爱你的一天", "又一个值得保存的片段", "日常的小美好", "和你在一起的时光"
]


NICKNAME_PATTERNS = [
    "宝贝", "宝宝", "亲爱的", "老公", "老婆", "傻瓜", "笨蛋", "小可爱",
    "baby", "baobei", "dear", "honey", "darling"
]


class AIService:
    def __init__(self):
        self.enabled = os.environ.get("AI_ENABLED", "false").lower() == "true"
        self.client = None
        self.model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        if self.enabled and HAS_OPENAI:
            api_key = os.environ.get("OPENAI_API_KEY", "")
            base_url = os.environ.get("OPENAI_BASE_URL", None)
            if api_key:
                self.client = OpenAI(api_key=api_key, base_url=base_url)

    def get_all_categories(self, db: Session) -> List[Category]:
        cats = db.query(Category).filter(Category.is_system == True).order_by(Category.sort_order).all()
        custom = db.query(Category).filter(Category.is_system == False).order_by(Category.sort_order, Category.id).all()
        return list(cats) + list(custom)

    def get_category_by_id(self, db: Session, cid: int) -> Optional[Category]:
        return db.query(Category).filter(Category.id == cid).first()

    def _extract_nicknames(self, text: str) -> List[str]:
        found = []
        for nick in NICKNAME_PATTERNS:
            if nick.lower() in text.lower():
                found.append(nick)
        return list(set(found))

    def _keyword_match(self, text: str, db: Session) -> Optional[Category]:
        if not text:
            return None
        cats = self.get_all_categories(db)
        best_cat = None
        best_score = 0
        text_lower = text.lower()
        for cat in cats:
            score = 0
            kws = cat.keywords or []
            for kw in kws:
                if kw.lower() in text_lower:
                    score += 1
            if score > best_score:
                best_score = score
                best_cat = cat
        return best_cat if best_score > 0 else None

    def _mock_classify(self, text_content: str, content_type: str, db: Session) -> Dict:
        cat_id = 4
        if content_type == ContentType.VOICE.value:
            cat_id = 8
        else:
            matched = self._keyword_match(text_content or "", db)
            if matched:
                cat_id = matched.id
        cat = self.get_category_by_id(db, cat_id)
        templates = SUMMARY_TEMPLATES.get(cat_id, GENERIC_SUMMARIES)
        summary = random.choice(templates) if text_content else random.choice(GENERIC_SUMMARIES)
        nicks = self._extract_nicknames(text_content or "")
        time.sleep(0.05)
        return {
            "category_id": cat_id,
            "summary": summary,
            "confidence": round(random.uniform(0.78, 0.96), 2),
            "nicknames": nicks,
            "tag_ids": [],
        }

    def _encode_image(self, path: str) -> Optional[str]:
        if not HAS_PIL:
            return None
        try:
            img = Image.open(path)
            img.thumbnail((1024, 1024))
            buf = io.BytesIO()
            img.convert("RGB").save(buf, format="JPEG", quality=82)
            return base64.b64encode(buf.getvalue()).decode()
        except Exception:
            return None

    def _llm_classify(self, text_content: str, content_type: str, image_paths: List[str], db: Session) -> Optional[Dict]:
        if not self.client:
            return None
        try:
            cats = self.get_all_categories(db)
            cat_desc = "\n".join([f"- {c.id}: {c.icon} {c.name}" for c in cats])
            sys_prompt = (
                "你是恋爱日记分类助手。根据情侣聊天内容，选择最合适的分类，生成温柔的1-2句总结。\n"
                f"可用分类：\n{cat_desc}\n"
                "请严格返回JSON格式：{\"category_id\": 数字, \"summary\": \"文案\", \"confidence\": 0.0-1.0, \"nicknames\": [\"昵称列表\"]}"
            )
            content_parts = []
            if text_content:
                content_parts.append({"type": "text", "text": f"[消息内容]: {text_content}"})
            else:
                content_parts.append({"type": "text", "text": "[无文字内容，仅图片/语音]"})
            for p in image_paths[:3]:
                b64 = self._encode_image(p)
                if b64:
                    content_parts.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user", "content": content_parts},
                ],
                response_format={"type": "json_object"},
                max_tokens=200,
                timeout=15,
            )
            raw = resp.choices[0].message.content
            result = json.loads(raw)
            return {
                "category_id": int(result.get("category_id", 4)),
                "summary": result.get("summary", "")[:100],
                "confidence": float(result.get("confidence", 0.8)),
                "nicknames": result.get("nicknames", []),
                "tag_ids": [],
            }
        except Exception as e:
            print(f"[AI] LLM error: {e}, falling back to mock")
            return None

    def process_message(self, text_content: str, content_type: str, image_paths: List[str], db: Session) -> Dict:
        t0 = time.time()
        result = None
        if content_type == ContentType.VOICE.value:
            cat8 = self.get_category_by_id(db, 8)
            result = {
                "category_id": 8,
                "summary": random.choice(SUMMARY_TEMPLATES[8]),
                "confidence": 0.99,
                "nicknames": self._extract_nicknames(text_content or ""),
                "tag_ids": [],
            }
        elif self.client and content_type != ContentType.VOICE.value:
            result = self._llm_classify(text_content, content_type, image_paths, db)
        if result is None:
            result = self._mock_classify(text_content, content_type, db)
        result["processing_time_ms"] = int((time.time() - t0) * 1000)
        return result


ai_service = AIService()
