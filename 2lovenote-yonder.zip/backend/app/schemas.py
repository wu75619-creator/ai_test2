from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from enum import Enum


class SenderRole(str, Enum):
    male = "male"
    female = "female"
    other = "other"


class ContentTypeEnum(str, Enum):
    text = "text"
    image = "image"
    voice = "voice"
    video = "video"
    sticker = "sticker"


class AttachmentInfo(BaseModel):
    id: int
    file_type: str
    file_url: str
    thumbnail_url: str = ""
    file_size: int = 0
    width: Optional[int] = None
    height: Optional[int] = None
    duration: Optional[float] = None
    mime_type: str = ""

    class Config:
        from_attributes = True


class MessageResponse(BaseModel):
    id: int
    sender_role: str
    sender_nickname: str = ""
    content_type: str
    text_content: str = ""
    ai_summary: str = ""
    main_category_id: Optional[int] = None
    main_category_name: str = ""
    main_category_icon: str = ""
    main_category_color: str = "#ff6b9d"
    ai_processed: bool = False
    is_manual_category: bool = False
    attachments: List[AttachmentInfo] = []
    voice_duration: Optional[float] = None
    video_duration: Optional[float] = None
    created_at: datetime

    class Config:
        from_attributes = True


class CategoryResponse(BaseModel):
    id: int
    name: str
    icon: str = "📁"
    color: str = "#ff6b9d"
    description: str = ""
    is_system: bool = False
    message_count: int = 0
    sort_order: int = 0

    class Config:
        from_attributes = True


class CategoryCreate(BaseModel):
    name: str
    icon: str = "📁"
    color: str = "#ff6b9d"
    description: str = ""


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    description: Optional[str] = None


class CoupleSetup(BaseModel):
    couple_name: str = "我们"
    together_date: Optional[str] = None
    access_password: str = ""
    male_nickname: str = "他"
    female_nickname: str = "她"


class CoupleInfo(BaseModel):
    couple_name: str
    together_date: Optional[datetime] = None
    onboarding_done: bool
    love_days: int = 0
    male_nickname: str = ""
    female_nickname: str = ""


class WeeklyStat(BaseModel):
    week_label: str
    week_start: str
    total_messages: int
    male_count: int
    female_count: int
    category_counts: dict
    avg_daily: float
    most_active_hour: int


class MonthlyStat(BaseModel):
    month_label: str
    total_messages: int
    male_count: int
    female_count: int
    category_counts: dict
    daily_counts: dict
    most_active_day: str
    love_days_in_month: int


class StatsOverview(BaseModel):
    total_messages: int
    total_days: int
    love_days: int
    male_total: int
    female_total: int
    weekly: List[WeeklyStat]
    monthly: List[MonthlyStat]
    category_distribution: List[dict]
    hourly_distribution: List[int]
