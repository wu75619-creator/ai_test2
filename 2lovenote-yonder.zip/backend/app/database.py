import os
import sys
import platform
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base


def _resolve_db_path() -> str:
    """解析数据库路径，优先级：
    1. 环境变量 LOVENOTE_DB_PATH（main.py 在 PyInstaller 模式下设置）
    2. 环境变量 DB_PATH（通用）
    3. PyInstaller 打包：用户数据目录
    4. 源码运行：backend/love_diary.db
    """
    p = os.environ.get("LOVENOTE_DB_PATH") or os.environ.get("DB_PATH")
    if p:
        return p
    if getattr(sys, 'frozen', False):
        system = platform.system()
        if system == "Windows":
            base = os.environ.get("APPDATA") or os.path.expanduser("~")
            p = os.path.join(base, "LoveNote", "love_diary.db")
        elif system == "Darwin":
            p = os.path.expanduser("~/Library/Application Support/LoveNote/love_diary.db")
        else:
            p = os.path.expanduser("~/.lovenote/love_diary.db")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        return p
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "love_diary.db")


DB_PATH = _resolve_db_path()
SQLALCHEMY_DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
