from sqlalchemy.orm import Session
from .models import Category, Couple, User, UserRole

SYSTEM_CATEGORIES = [
    {"id": 1, "name": "美食探店存档", "icon": "🍜", "color": "#ff9a56", "description": "一起吃过的美食", "sort_order": 1,
     "keywords": ["吃", "餐厅", "美食", "好吃", "外卖", "做饭", "菜", "饭", "火锅", "烧烤", "奶茶", "咖啡", "蛋糕", "甜品", "日料", "寿司", "三文鱼"]},
    {"id": 2, "name": "旅行&约会存档", "icon": "✈️", "color": "#56b3ff", "description": "一起去过的地方", "sort_order": 2,
     "keywords": ["旅行", "旅游", "出门", "约会", "出去玩", "景点", "公园", "电影", "逛街", "散步", "展览", "艺术展", "机场", "酒店", "海边", "山"]},
    {"id": 3, "name": "情侣合照存档", "icon": "📸", "color": "#a856ff", "description": "我们的合影", "sort_order": 3,
     "keywords": ["合照", "自拍", "拍照", "照片", "合影", "拍了", "大头贴", "摄影"]},
    {"id": 4, "name": "趣味日常存档", "icon": "😄", "color": "#56ffb3", "description": "搞笑有趣的日常", "sort_order": 4,
     "keywords": ["哈哈", "笑", "搞笑", "好玩", "有趣", "傻", "可爱", "逗", "笑死", "哈哈哈"]},
    {"id": 5, "name": "专属昵称存档", "icon": "💕", "color": "#ff5686", "description": "甜甜的昵称和表白", "sort_order": 5,
     "keywords": ["宝贝", "宝宝", "亲爱的", "老公", "老婆", "爱你", "想你", "么么", "心爱", "傻瓜", "笨蛋", "baby", "baobei", "dear", "heart"]},
    {"id": 6, "name": "深度谈心存档", "icon": "💬", "color": "#5677ff", "description": "认真聊天心里话", "sort_order": 6,
     "keywords": ["想", "感觉", "觉得", "希望", "未来", "心里话", "认真", "感受", "理解", "懂你", "压力", "心情", "emo", "难过", "开心", "幸福"]},
    {"id": 7, "name": "矛盾复盘存档", "icon": "🌧️", "color": "#9e9e9e", "description": "吵架和和好记录", "sort_order": 7,
     "keywords": ["生气", "吵架", "难过", "对不起", "抱歉", "错了", "原谅", "不开心", "委屈", "哭", "伤心", "冷战", "矛盾", "和好"]},
    {"id": 8, "name": "语音专属存档", "icon": "🎙️", "color": "#ff56b3", "description": "语音消息存档", "sort_order": 8,
     "keywords": []},
]


def init_system_categories(db: Session):
    count = db.query(Category).filter(Category.is_system == True).count()
    if count >= 8:
        return
    for cat_data in SYSTEM_CATEGORIES:
        existing = db.query(Category).filter(Category.id == cat_data["id"]).first()
        if not existing:
            cat = Category(
                id=cat_data["id"],
                couple_id=None,
                name=cat_data["name"],
                icon=cat_data["icon"],
                color=cat_data["color"],
                description=cat_data["description"],
                sort_order=cat_data["sort_order"],
                is_system=True,
                keywords=cat_data["keywords"],
            )
            db.add(cat)
    db.commit()


def get_or_create_default_couple(db: Session) -> Couple:
    couple = db.query(Couple).first()
    if not couple:
        couple = Couple(
            couple_name="我们",
            access_password="",
            onboarding_done=False,
        )
        db.add(couple)
        db.commit()
        db.refresh(couple)
    return couple


def get_or_create_users(db: Session, couple: Couple, male_nick: str = "他", female_nick: str = "她"):
    male = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.MALE).first()
    if not male:
        male = User(couple_id=couple.id, role=UserRole.MALE, nickname=male_nick, theme_color="#4a90e2", avatar_url="👨")
        db.add(male)
    female = db.query(User).filter(User.couple_id == couple.id, User.role == UserRole.FEMALE).first()
    if not female:
        female = User(couple_id=couple.id, role=UserRole.FEMALE, nickname=female_nick, theme_color="#ff6b9d", avatar_url="👩")
        db.add(female)
    db.commit()
    return male, female
