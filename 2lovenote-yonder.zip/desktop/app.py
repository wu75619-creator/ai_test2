"""
LoveNote 桌面端入口
──────────────────────────────────────────────
双击 LoveNote.exe 后执行：
  1. 在后台线程启动 FastAPI（uvicorn）监听 127.0.0.1:随机空闲端口
  2. 打开 pywebview 桌面窗口，加载前端页面
  3. 关闭窗口时自动终止服务器进程，释放端口

打包时由 PyInstaller 将本文件、后端代码、前端 dist 一起打包。
"""
import os
import sys
import threading
import time
import socket
import platform
import urllib.request
import urllib.error


def _find_free_port() -> int:
    """找一个空闲 TCP 端口，避免端口冲突"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ── 路径初始化（必须在 import main 之前完成）─────────────
def _setup_paths():
    """根据运行模式设置数据目录和资源目录环境变量"""
    if getattr(sys, "frozen", False):
        # PyInstaller 打包后，sys._MEIPASS 是临时解压目录
        base = sys._MEIPASS
        # 数据写入用户目录，而非临时目录
        system = platform.system()
        if system == "Windows":
            data_root = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "LoveNote")
        elif system == "Darwin":
            data_root = os.path.expanduser("~/Library/Application Support/LoveNote")
        else:
            data_root = os.path.expanduser("~/.lovenote")
        os.makedirs(data_root, exist_ok=True)
        os.makedirs(os.path.join(data_root, "uploads", "images"), exist_ok=True)
        os.makedirs(os.path.join(data_root, "uploads", "voices"), exist_ok=True)
        os.makedirs(os.path.join(data_root, "uploads", "videos"), exist_ok=True)
        os.environ["LOVENOTE_DATA_DIR"] = data_root
        os.environ["LOVENOTE_DB_PATH"] = os.path.join(data_root, "love_diary.db")
        os.environ["LOVENOTE_UPLOAD_DIR"] = os.path.join(data_root, "uploads")
        # 将后端资源目录加入 sys.path（_MEIPASS 下有 app/ 包和 dist/）
        if base not in sys.path:
            sys.path.insert(0, base)
        return base
    else:
        # 开发模式
        backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backend")
        if backend_dir not in sys.path:
            sys.path.insert(0, backend_dir)
        return backend_dir


RESOURCE_DIR = _setup_paths()


def _wait_for_server(port: int, timeout: float = 20.0) -> bool:
    """轮询等待 uvicorn 就绪"""
    url = f"http://127.0.0.1:{port}/api/health"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, ConnectionRefusedError, OSError):
            time.sleep(0.3)
    return False


class ServerThread(threading.Thread):
    """在后台线程中运行 uvicorn，支持优雅关闭"""

    def __init__(self, port: int):
        super().__init__(daemon=True)
        self.port = port
        self.server = None

    def run(self):
        import uvicorn
        # 每次重新 import 以保证 app 使用正确的 env 变量
        os.environ["PORT"] = str(self.port)
        os.environ["HOST"] = "127.0.0.1"
        import main  # noqa: W0611 – backend/main.py 创建 app 对象
        self.server = uvicorn.Server(
            uvicorn.Config(
                "main:app",
                host="127.0.0.1",
                port=self.port,
                log_level="error",
                access_log=False,
            )
        )
        self.server.run()

    def stop(self):
        if self.server:
            self.server.should_exit = True


def run_desktop():
    import webview

    port = _find_free_port()
    url = f"http://127.0.0.1:{port}/"

    server_thread = ServerThread(port)
    server_thread.start()

    if not _wait_for_server(port):
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("LoveNote", "服务启动失败，请检查端口是否被占用后重试。")
        sys.exit(1)

    # 创建窗口
    try:
        with open(os.path.join(RESOURCE_DIR, "dist", "index.html"), encoding="utf-8") as f:
            _ = f.read(1)
        window = webview.create_window(
            title="💕 LoveNote 恋爱日记本",
            url=url,
            width=480,
            height=820,
            min_size=(360, 600),
            resizable=True,
            text_select=True,
        )
        webview.start(debug=False)
    except Exception as e:
        # 若 dist 找不到，仍打开 API 地址
        window = webview.create_window(
            title="💕 LoveNote 恋爱日记本",
            url=url,
            width=480,
            height=820,
        )
        webview.start(debug=False)
    finally:
        server_thread.stop()
        time.sleep(0.5)


if __name__ == "__main__":
    run_desktop()
