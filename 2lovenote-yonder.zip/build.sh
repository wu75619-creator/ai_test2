#!/bin/bash
# LoveNote 桌面端构建脚本 (Linux / macOS)
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}══════════════════════════════════════════${NC}"
echo -e "${CYAN}  LoveNote 桌面端构建脚本 (Linux/macOS)${NC}"
echo -e "${CYAN}══════════════════════════════════════════${NC}"
echo ""

# ── 检查 Python ──────────────────────────
if ! command -v python3 &>/dev/null; then
    echo -e "${RED}[错误] 未检测到 python3，请先安装 Python 3.10+${NC}"
    exit 1
fi
PYVER=$(python3 --version)
echo -e "${GREEN}[检测]${NC} Python: $PYVER"

# ── 检查 Node.js ──────────────────────────
HAS_NODE=0
if command -v node &>/dev/null; then
    NODEVER=$(node --version)
    echo -e "${GREEN}[检测]${NC} Node.js: $NODEVER"
    HAS_NODE=1
else
    echo -e "${CYAN}[警告]${NC} 未检测到 Node.js，将跳过前端构建"
fi
echo ""

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

# ── 创建虚拟环境 ──────────────────────────
echo -e "${GREEN}[1/5]${NC} 创建 Python 虚拟环境..."
if [ ! -d "build_env" ]; then
    python3 -m venv build_env
fi
source build_env/bin/activate

# ── 安装依赖 ─────────────────────────────
echo -e "${GREEN}[2/5]${NC} 安装 Python 依赖..."
pip install --upgrade pip -q
pip install -r backend/requirements.txt -q
pip install pyinstaller pywebview -q

# Linux 需要额外的 GTK 依赖 for pywebview
if [ "$(uname)" = "Linux" ]; then
    echo -e "${CYAN}  [提示]${NC} Linux 下 pywebview 需要 GTK3，如运行失败请执行："
    echo "        sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0 libgirepository1.0-dev libcairo2-dev"
fi

# ── 构建前端 ─────────────────────────────
if [ "$HAS_NODE" -eq 1 ]; then
    echo -e "${GREEN}[3/5]${NC} 构建前端（Vue3）..."
    cd frontend
    if [ ! -d "node_modules" ]; then
        npm install
    fi
    npm run build
    cd "$PROJECT_DIR"
    rm -rf backend/dist
    cp -r frontend/dist backend/dist
else
    echo -e "${GREEN}[3/5]${NC} 跳过前端构建（使用已有 backend/dist）"
    if [ ! -f "backend/dist/index.html" ]; then
        echo -e "${RED}[错误] backend/dist/index.html 不存在，请先安装 Node.js 构建前端${NC}"
        exit 1
    fi
fi

# ── PyInstaller 打包 ─────────────────────
echo -e "${GREEN}[4/5]${NC} PyInstaller 打包中（首次需 1-3 分钟）..."
python3 -m PyInstaller LoveNote.spec --clean --noconfirm

# ── 清理 ─────────────────────────────────
echo -e "${GREEN}[5/5]${NC} 清理临时文件..."
rm -rf build

echo ""
echo -e "${CYAN}══════════════════════════════════════════${NC}"
echo -e "${GREEN}  构建完成！${NC}"
echo -e "  产物: dist/LoveNote/LoveNote"
if [ "$(uname)" = "Darwin" ]; then
    echo -e "  数据目录: ~/Library/Application Support/LoveNote/"
else
    echo -e "  数据目录: ~/.lovenote/"
fi
echo -e "${CYAN}══════════════════════════════════════════${NC}"
echo ""
echo "运行：./dist/LoveNote/LoveNote"
deactivate
