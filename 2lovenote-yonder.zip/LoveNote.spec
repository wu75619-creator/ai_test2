# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for LoveNote Desktop
打包命令：pyinstaller LoveNote.spec
产出：dist/LoveNote.exe
"""
import os
import sys

block_cipher = None

# 路径计算
SPEC_DIR = os.path.abspath(os.path.dirname(SPECPATH))
BACKEND_DIR = os.path.join(SPEC_DIR, 'backend')
FRONTEND_DIST = os.path.join(BACKEND_DIR, 'dist')
DESKTOP_DIR = os.path.join(SPEC_DIR, 'desktop')

a = Analysis(
    [os.path.join(DESKTOP_DIR, 'app.py')],
    pathex=[
        BACKEND_DIR,
        DESKTOP_DIR,
    ],
    binaries=[],
    datas=[
        # 前端构建产物（Vue dist）—— 打包后在 _MEIPASS/dist/
        (FRONTEND_DIST, 'dist'),
    ],
    hiddenimports=[
        'uvicorn.logging',
        'uvicorn.loops',
        'uvicorn.loops.auto',
        'uvicorn.protocols',
        'uvicorn.protocols.http',
        'uvicorn.protocols.http.auto',
        'uvicorn.protocols.websockets',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.lifespan',
        'uvicorn.lifespan.on',
        'app',
        'app.database',
        'app.models',
        'app.schemas',
        'app.init_data',
        'app.ai_service',
        'app.routers',
        'app.routers.messages',
        'app.routers.categories',
        'app.routers.stats',
        'app.routers.couple',
        'webview',
        'webview.platforms.winforms',
        'multipart',
        'multipart.multipart',
        'PIL.Image',
        'aiofiles',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib', 'numpy', 'pandas', 'scipy', 'tkinter.test',
        'unittest', 'pydoc', 'doctest', 'pytest',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LoveNote',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,          # 不显示黑色命令行窗口
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon=os.path.join(DESKTOP_DIR, 'icon.ico'),  # 如有图标文件取消注释
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LoveNote',
)
