# 💕 LoveNote - 情侣智能恋爱日记本

双人专属、对话式随手记录、AI 智能分类的情侣恋爱日记桌面应用。

支持三种使用方式：
- **Windows 桌面端**（双击 .exe 即用，无需任何配置）
- **本地源码运行**（Windows/Mac/Linux）
- **服务器部署**（手机/平板通过浏览器访问）

---

## 🖥️ 一、桌面端使用（推荐普通用户）

### 运行方式
双击 `LoveNote.exe` 即可启动。程序会自动打开一个独立桌面窗口，所有数据保存在本机用户目录，无需联网，无需安装任何依赖。

### 麦克风/摄像头权限说明
首次使用录音或录像功能时：

- **Windows 10/11**：系统会弹出权限请求对话框，点击"是"允许应用访问麦克风和摄像头即可。
  - 若未弹出，请前往 `设置 → 隐私和安全性 → 麦克风/摄像头 → 允许桌面应用访问`
  - Windows 可能会弹出"Windows 已保护你的电脑"提示（SmartScreen），点击"更多信息"→"仍要运行"即可
- **macOS**：首次录音时系统会弹出"LoveNote 想要访问麦克风"，点击"好"。若误点了拒绝，前往 `系统设置 → 隐私与安全性 → 麦克风` 重新授权。
- 语音消息在授权前无法录制，但文字/图片/视频文件上传功能不受影响。

### 数据存储位置
| 系统 | 数据库 & 媒体文件路径 |
|------|------|
| Windows | `%APPDATA%\LoveNote\` |
| macOS | `~/Library/Application Support/LoveNote/` |
| Linux | `~/.lovenote/` |

数据库（`love_diary.db`）和上传的图片/语音/视频均存储在此目录，删除程序不会删除数据，换机时复制此文件夹即可迁移。

---

## 🔨 二、从源码打包桌面端 .exe

### 2.1 打包所需环境

| 工具 | 版本要求 | 下载地址 |
|------|---------|---------|
| Python | 3.10 ~ 3.12 | https://www.python.org/downloads/ |
| Node.js | 18+ | https://nodejs.org/ |

> ⚠️ 安装 Python 时务必勾选 **"Add Python to PATH"**，否则 `build.bat` 找不到 Python。

### 2.2 一键打包（Windows）

在项目根目录双击运行：

```
build.bat
```

或打开 CMD/PowerShell 执行：
```cmd
build.bat
```

脚本自动完成以下步骤：
1. 创建 Python 虚拟环境 `build_env/`（自动隔离，不影响系统 Python）
2. 安装 FastAPI、Uvicorn、SQLAlchemy、Pillow、aiofiles 等后端依赖
3. 安装 PyInstaller（打包工具）和 pywebview（桌面窗口框架）
4. 执行 `npm install && npm run build` 构建前端 Vue3 产物
5. PyInstaller 打包后端 + 前端 dist + 桌面外壳为单个 .exe 程序
6. 产物输出到 `dist/LoveNote/LoveNote.exe`

### 2.3 一键打包（macOS / Linux）

```bash
chmod +x build.sh
./build.sh
```

> Linux 用户如运行 pywebview 报错，请先安装 GTK3 依赖：
> ```bash
> sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0 libgirepository1.0-dev libcairo2-dev
> ```

### 2.4 打包产物结构

```
dist/
└── LoveNote/
    ├── LoveNote.exe      ← 主程序，双击启动
    ├── *_internal/       ← 运行时依赖（随exe分发，勿删除）
    └── ...
```

将整个 `LoveNote/` 文件夹压缩为 zip 即可发给对方使用，双击 `LoveNote.exe` 启动。

---

## 💻 三、源码运行（开发者模式）

### 3.1 后端（FastAPI）

```bash
cd backend
pip install -r requirements.txt
python main.py
# 服务启动后访问 http://127.0.0.1:8765
```

源码模式下，数据存储在 `backend/love_diary.db`，上传文件在 `backend/uploads/`。

### 3.2 前端（Vite 热更新）

```bash
cd frontend
npm install
npm run dev
# 访问 http://localhost:5173（API 自动代理到 8765 端口）
```

### 3.3 前后端合一（生产模式预览）

```bash
cd frontend && npm install && npm run build
cd ../backend && python main.py
# 直接访问 http://127.0.0.1:8765，后端自动托管前端
```

---

## 🌐 四、部署为在线网页（手机/平板访问）

### Render.com（免费永久部署）
1. 将项目推送到 GitHub
2. 登录 [Render.com](https://render.com) → New → Web Service → 连接仓库
3. Build Command：
   ```
   pip install -r backend/requirements.txt && cd frontend && npm install && npm run build
   ```
4. Start Command：
   ```
   cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT
   ```
5. 部署完成获得 `https://xxx.onrender.com` 永久公网链接，手机浏览器直接访问

### Docker 部署
```bash
docker build -t lovenote .
docker run -d -p 8000:8000 -v ./lovenote-data:/app/backend lovenote
```

---

## ✨ 功能说明

### 核心功能
- 💬 **对话式记录**：文字、多图选择、浏览器麦克风录音（最长5分钟）、摄像头录像（最长2分钟）、本地音视频文件上传
- 🤖 **AI 智能分类**：自动归类到 8 大系统分类，生成温柔总结文案（本地关键词匹配无需 API Key；支持接入 OpenAI/GPT/DeepSeek/通义千问）
- 🏷️ **自定义分类**：自由创建/编辑/删除分类标签，支持 emoji 图标和主题颜色
- 📊 **统计面板**：相爱天数、24小时活跃度柱状图、分类分布、近8周周报、近6个月月报
- 🔒 **密码保护**：可选访问密码，防止他人误看
- 📱 **响应式设计**：手机/平板/电脑自适应

### 多媒体说明
- 图片：多选上传，点击大图预览，支持缩放
- 语音：浏览器实时录音，自定义波形播放条，显示录制时长
- 视频：摄像头实时录制预览，支持播放控件，显示视频时长
- 所有媒体文件以 UUID 文件名保存在本地，不会上传到任何第三方服务器

---

## ⚙️ AI 配置（可选）

在 `backend/` 目录创建 `.env` 文件接入真实 LLM：

```env
AI_ENABLED=true
OPENAI_API_KEY=sk-xxx
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
MAX_UPLOAD_SIZE=104857600
```

不配置时使用内置关键词模式，分类精确，零成本。

---

## 📁 项目结构

```
LoveNote/
├── build.bat              # Windows 一键打包脚本
├── build.sh               # macOS/Linux 一键打包脚本
├── LoveNote.spec          # PyInstaller 桌面端 spec
├── server.spec            # PyInstaller 纯服务端 spec（无窗口）
├── Dockerfile
├── render.yaml
├── README.md
├── desktop/
│   └── app.py             # 桌面外壳：后台线程起 uvicorn + pywebview 窗口
├── backend/
│   ├── main.py            # FastAPI 入口（适配 PyInstaller 路径）
│   ├── requirements.txt
│   ├── .env.example
│   ├── dist/              # 前端构建产物（打包时嵌入 exe）
│   └── app/
│       ├── database.py    # SQLite 路径自动适配用户目录
│       ├── models.py
│       ├── schemas.py
│       ├── init_data.py   # 8 大系统分类种子数据
│       ├── ai_service.py  # AI 分类服务（mock + LLM）
│       └── routers/
│           ├── messages.py    # 消息/多媒体上传 API
│           ├── categories.py  # 分类 CRUD
│           ├── stats.py       # 周/月统计
│           └── couple.py      # 情侣设置/密码验证
└── frontend/
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── views/         # 6 个页面
        ├── utils/recorder.js  # AudioRecorder + VideoRecorder
        ├── api/
        ├── stores/
        └── router/
```
