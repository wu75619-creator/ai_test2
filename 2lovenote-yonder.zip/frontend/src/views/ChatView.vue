<template>
  <div class="chat-page">
    <!-- Header -->
    <header class="chat-header">
      <div class="header-left">
        <span class="header-emo">💑</span>
        <div>
          <div class="header-title">{{ store.coupleName }}</div>
          <div class="header-sub">
            <span v-if="store.loveDays > 0">💕 已相爱 {{ store.loveDays }} 天</span>
            <span v-else>随手记录，自动沉淀</span>
          </div>
        </div>
      </div>
    </header>

    <!-- Messages -->
    <div ref="scrollRef" class="messages-area" @scroll="onScroll">
      <div v-if="loading" class="loading-hint">加载中...</div>
      <div v-if="!loading && messages.length === 0" class="empty-state">
        <div class="empty-emo">💌</div>
        <p>还没有消息，开始记录你们的第一条吧！</p>
      </div>
      <div
        v-for="(msg, i) in messages"
        :key="msg.id"
        class="msg-row"
        :class="msg.sender_role === 'female' ? 'female-row' : 'male-row'"
        :style="{ animationDelay: i * 30 + 'ms' }"
      >
        <div class="avatar" :class="msg.sender_role">
          {{ msg.sender_role === 'female' ? '👩' : '👨' }}
        </div>
        <div class="msg-content-wrap">
          <div class="sender-name">{{ msg.sender_nickname }}</div>
          <div class="bubble" :class="msg.sender_role">
            <!-- Images -->
            <div v-if="msg.attachments.filter(a=>a.file_type==='image').length" class="img-grid">
              <el-image
                v-for="(img, ji) in msg.attachments.filter(a=>a.file_type==='image')"
                :key="ji"
                :src="img.file_url"
                :preview-src-list="msg.attachments.filter(a=>a.file_type==='image').map(a=>a.file_url)"
                :initial-index="ji"
                fit="cover"
                class="msg-img"
                preview-teleported
              />
            </div>
            <!-- Video -->
            <div v-if="msg.attachments.find(a=>a.file_type==='video')">
              <video
                v-for="v in msg.attachments.filter(a=>a.file_type==='video')"
                :key="v.id" :src="v.file_url"
                controls playsinline preload="metadata"
                class="msg-video"
              />
            </div>
            <!-- Voice -->
            <div v-if="msg.attachments.find(a=>a.file_type==='voice')" class="voice-msg" @click="toggleVoice(msg)">
              <el-icon :size="20" class="voice-icon">
                <component :is="playingId === msg.id ? 'VideoPause' : 'Microphone'" />
              </el-icon>
              <div class="voice-bars">
                <div v-for="n in 14" :key="n"
                  class="vbar"
                  :class="{ active: playingId === msg.id }"
                  :style="{ height: getBarHeight(n, msg.voice_duration) + 'px', animationDelay: n * 60 + 'ms' }"
                />
              </div>
              <span class="voice-dur">{{ formatDur(msg.voice_duration || getVoiceDur(msg)) }}"</span>
            </div>
            <!-- Text -->
            <div v-if="msg.text_content" class="msg-text">{{ msg.text_content }}</div>
            <!-- AI badge -->
            <div v-if="msg.ai_processed && !msg.is_manual_category && msg.ai_summary" class="ai-summary">
              ✨ {{ msg.ai_summary }}
            </div>
            <div v-if="!msg.ai_processed" class="ai-loading">
              <el-icon class="is-loading"><Loading /></el-icon> AI归档中...
            </div>
          </div>
          <div class="bubble-meta">
            <span class="cat-tag" v-if="msg.main_category_name" :style="{ background: msg.main_category_color + '20', color: msg.main_category_color }">
              {{ msg.main_category_icon }} {{ msg.main_category_name }}
            </span>
            <span v-if="msg.is_manual_category" class="manual-badge">手动</span>
            <span class="msg-time">{{ formatTime(msg.created_at) }}</span>
          </div>
        </div>
      </div>
      <div ref="bottomRef" />
    </div>

    <!-- Input Area -->
    <div class="input-area">
      <!-- Options row -->
      <div class="options-row">
        <div class="opt-left">
          <el-switch
            v-model="isAiAuto"
            active-text="AI自动"
            inactive-text="手动分类"
            inline-prompt
            size="small"
          />
          <el-select
            v-if="!isAiAuto"
            v-model="manualCategory"
            placeholder="选择分类"
            size="small"
            style="width: 150px; margin-left: 8px;"
          >
            <el-option
              v-for="c in categories" :key="c.id"
              :label="c.icon + ' ' + c.name" :value="c.id"
            />
          </el-select>
        </div>
        <div class="sender-toggle">
          <el-radio-group v-model="senderRole" size="small">
            <el-radio-button value="male">👨 {{ store.maleNickname }}</el-radio-button>
            <el-radio-button value="female">👩 {{ store.femaleNickname }}</el-radio-button>
          </el-radio-group>
        </div>
      </div>

      <!-- Preview of selected media -->
      <div v-if="selectedImages.length" class="preview-row">
        <div v-for="(img, i) in selectedImages" :key="i" class="preview-thumb">
          <img :src="img.url" />
          <div class="thumb-remove" @click="removeImage(i)">×</div>
        </div>
      </div>
      <div v-if="selectedVideo" class="preview-row">
        <div class="preview-thumb video-thumb">
          <video :src="selectedVideo.url" controls style="width:120px;height:160px;object-fit:cover;border-radius:8px;" />
          <div class="thumb-remove" @click="selectedVideo=null">×</div>
        </div>
      </div>
      <div v-if="selectedVoice" class="preview-row">
        <div class="voice-preview">
          <el-icon><Microphone /></el-icon>
          <span>语音 {{ selectedVoice.duration }}"</span>
          <div class="thumb-remove" @click="selectedVoice=null">×</div>
        </div>
      </div>

      <!-- Input row -->
      <div class="input-row">
        <el-upload
          :show-file-list="false"
          accept="image/*"
          multiple
          :disabled="!!selectedVoice || isRecording || !!selectedVideo"
          :before-upload="onSelectImages"
        >
          <button class="icon-btn" :disabled="!!selectedVoice || isRecording || !!selectedVideo">
            <el-icon :size="22"><Picture /></el-icon>
          </button>
        </el-upload>
        <el-upload
          :show-file-list="false"
          accept="video/*"
          :disabled="!!selectedVoice || isRecording || selectedImages.length > 0"
          :before-upload="onSelectVideo"
        >
          <button class="icon-btn" :disabled="!!selectedVoice || isRecording || selectedImages.length > 0">
            <el-icon :size="22"><VideoCamera /></el-icon>
          </button>
        </el-upload>
        <button class="icon-btn record-video-btn" @click="startVideoRecord"
          :disabled="!!selectedVoice || selectedImages.length > 0 || !!selectedVideo || isRecording">
          <el-icon :size="22"><VideoCameraFilled /></el-icon>
        </button>
        <button
          class="icon-btn mic-btn"
          :class="{ recording: isRecording }"
          @mousedown.prevent="startAudioRecord"
          @touchstart.prevent="startAudioRecord"
          @mouseup.prevent="finishAudioRecord"
          @touchend.prevent="finishAudioRecord"
          @mouseleave.prevent="isRecording && finishAudioRecord()"
          :disabled="!!selectedVoice || selectedImages.length > 0 || !!selectedVideo || isVideoRecording"
        >
          <el-icon :size="22"><Microphone /></el-icon>
        </button>
        <el-input
          v-model="textContent"
          type="textarea"
          :rows="1"
          autosize
          placeholder="记录当下..."
          class="text-input"
          :disabled="isRecording"
          @keydown.enter.exact.prevent="doSend"
        />
        <button class="send-btn" @click="doSend" :disabled="!canSend || sending">
          <el-icon :size="20"><Promotion /></el-icon>
        </button>
      </div>
    </div>

    <!-- Audio Recording Overlay -->
    <div v-if="isRecording" class="rec-overlay" @click.stop>
      <div class="rec-pulse"></div>
      <div class="rec-content">
        <div class="rec-mic">🎙️</div>
        <div class="rec-timer">{{ formatRecTime(recTime) }}</div>
        <div class="rec-hint">松开发送，上滑取消</div>
        <div class="rec-wave">
          <div v-for="n in 20" :key="n" class="w-bar" :style="{ height: 10 + Math.random()*30 + 'px', animationDelay: n*50+'ms' }"></div>
        </div>
        <div class="rec-actions">
          <button class="rec-cancel" @click="cancelAudioRecord">
            <el-icon><Close /></el-icon> 取消
          </button>
          <button class="rec-confirm" @click="finishAudioRecord">
            <el-icon><Check /></el-icon> 发送
          </button>
        </div>
      </div>
    </div>

    <!-- Video Recording Overlay -->
    <div v-if="isVideoRecording" class="rec-overlay video-overlay" @click.stop>
      <video ref="videoPreviewEl" autoplay muted playsinline class="video-preview-el" />
      <div class="video-rec-timer">
        <div class="rec-dot"></div>
        {{ formatRecTime(recTime) }}
      </div>
      <div class="video-rec-actions">
        <button class="rec-cancel" @click="cancelVideoRecord">
          <el-icon :size="24"><Close /></el-icon>
        </button>
        <button class="video-stop-btn" @click="finishVideoRecord">
          <div class="stop-inner"></div>
        </button>
      </div>
      <div class="rec-hint-video">点击 ● 停止录制</div>
    </div>

    <!-- Hidden audio elements for voice playback -->
    <audio ref="audioPlayer" @ended="playingId=null" />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import dayjs from 'dayjs'
import { getMessages, sendMessage } from '../api/message'
import { getCategories } from '../api/category'
import { getCoupleInfo } from '../api/couple'
import { AudioRecorder, VideoRecorder, getMediaDuration } from '../utils/recorder'
import { useCoupleStore } from '../stores/couple'

const store = useCoupleStore()
const messages = ref([])
const categories = ref([])
const loading = ref(true)
const sending = ref(false)
const scrollRef = ref(null)
const bottomRef = ref(null)
const audioPlayer = ref(null)
const videoPreviewEl = ref(null)
const playingId = ref(null)

// Input state
const textContent = ref('')
const senderRole = ref('male')
const isAiAuto = ref(true)
const manualCategory = ref(null)
const selectedImages = ref([])
const selectedVideo = ref(null)
const selectedVoice = ref(null)

// Recording state
const audioRecorder = new AudioRecorder()
const videoRecorder = new VideoRecorder()
const isRecording = ref(false)
const isVideoRecording = ref(false)
const recTime = ref(0)
let recTimer = null

const canSend = computed(() => {
  if (sending.value) return false
  if (!isAiAuto.value && !manualCategory.value) return false
  return !!(textContent.value.trim() || selectedImages.value.length || selectedVoice.value || selectedVideo.value)
})

function formatTime(t) { return dayjs(t).format('HH:mm') }
function formatDur(s) { return s ? Math.round(s) : '?' }
function formatRecTime(s) {
  const m = Math.floor(s / 60)
  const sec = Math.floor(s % 60)
  return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
}
function getVoiceDur(msg) {
  const att = msg.attachments?.find(a => a.file_type === 'voice')
  return att?.duration || 0
}
function getBarHeight(n, dur) {
  const d = dur || 3
  const base = 6 + Math.sin(n * 0.8 + d) * 6
  return Math.max(4, Math.min(22, base + Math.random() * 6))
}

function scrollToBottom() {
  nextTick(() => {
    bottomRef.value?.scrollIntoView({ behavior: 'smooth' })
  })
}

async function loadMessages() {
  loading.value = true
  try {
    const [msgs, cats] = await Promise.all([
      getMessages('asc'),
      getCategories()
    ])
    messages.value = msgs
    categories.value = cats
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
    scrollToBottom()
  }
}

async function pollAI() {
  let attempts = 0
  while (attempts < 10) {
    await new Promise(r => setTimeout(r, 1500))
    attempts++
    const latest = await getMessages('asc')
    messages.value = latest
    const unprocessed = latest.filter(m => !m.ai_processed)
    if (unprocessed.length === 0) break
  }
}

// Image selection
async function onSelectImages(file) {
  if (!file) return false
  const url = URL.createObjectURL(file)
  selectedImages.value.push({ file, url })
  return false // prevent auto-upload
}
function removeImage(i) {
  URL.revokeObjectURL(selectedImages.value[i].url)
  selectedImages.value.splice(i, 1)
}

// Video selection
async function onSelectVideo(file) {
  if (!file) return false
  const url = URL.createObjectURL(file)
  const duration = await getMediaDuration(file)
  selectedVideo.value = { file, url, duration }
  return false
}

// Audio recording
async function startAudioRecord() {
  if (selectedVoice.value || isRecording.value) return
  try {
    isRecording.value = true
    recTime.value = 0
    await audioRecorder.start((t) => { recTime.value = t })
    recTimer = setInterval(() => {}, 100)
  } catch (e) {
    isRecording.value = false
    ElMessage.error('无法启动录音：' + (e.message || '请检查麦克风权限'))
  }
}
async function finishAudioRecord() {
  if (!isRecording.value) return
  clearInterval(recTimer)
  isRecording.value = false
  try {
    const result = await audioRecorder.stop()
    if (result && result.duration > 0.3) {
      selectedVoice.value = { file: result.file, duration: result.duration, url: URL.createObjectURL(result.file) }
    }
  } catch (e) {
    ElMessage.error('录音失败')
  }
}
function cancelAudioRecord() {
  clearInterval(recTimer)
  isRecording.value = false
  audioRecorder.cancel()
}

// Video recording
async function startVideoRecord() {
  try {
    isVideoRecording.value = true
    recTime.value = 0
    await nextTick()
    await videoRecorder.start(videoPreviewEl.value, (t) => { recTime.value = t })
  } catch (e) {
    isVideoRecording.value = false
    ElMessage.error('无法启动录像：' + (e.message || '请检查摄像头权限'))
  }
}
async function finishVideoRecord() {
  if (!isVideoRecording.value) return
  isVideoRecording.value = false
  try {
    const result = await videoRecorder.stop()
    if (result && result.duration > 0.5) {
      selectedVideo.value = {
        file: result.file,
        url: URL.createObjectURL(result.file),
        duration: result.duration,
      }
    }
  } catch (e) {
    ElMessage.error('录像失败')
  }
}
function cancelVideoRecord() {
  isVideoRecording.value = false
  videoRecorder.cancel()
}

// Send
async function doSend() {
  if (!canSend.value) return
  sending.value = true
  try {
    await sendMessage({
      sender_role: senderRole.value,
      text_content: textContent.value.trim(),
      is_ai_auto: isAiAuto.value,
      manual_category: !isAiAuto.value ? manualCategory.value : null,
      images: selectedImages.value.map(x => x.file),
      voice: selectedVoice.value?.file || null,
      voice_duration: selectedVoice.value?.duration ?? null,
      video: selectedVideo.value?.file || null,
      video_duration: selectedVideo.value?.duration ?? null,
    })
    textContent.value = ''
    selectedImages.value.forEach(x => URL.revokeObjectURL(x.url))
    selectedImages.value = []
    if (selectedVoice.value) URL.revokeObjectURL(selectedVoice.value.url)
    selectedVoice.value = null
    if (selectedVideo.value) URL.revokeObjectURL(selectedVideo.value.url)
    selectedVideo.value = null
    manualCategory.value = null
    await loadMessages()
    if (isAiAuto.value) pollAI()
    setTimeout(() => store.load(), 1000)
  } catch (e) {
    ElMessage.error('发送失败，请重试')
  } finally {
    sending.value = false
  }
}

// Voice playback
function toggleVoice(msg) {
  const att = msg.attachments?.find(a => a.file_type === 'voice')
  if (!att) return
  const player = audioPlayer.value
  if (playingId.value === msg.id) {
    player.pause()
    playingId.value = null
  } else {
    player.src = att.file_url
    player.play()
    playingId.value = msg.id
  }
}

function onScroll() {}

onMounted(async () => {
  await store.load()
  await loadMessages()
})
onUnmounted(() => {
  audioRecorder.cleanup()
  videoRecorder.cleanup()
})
</script>

<style scoped>
.chat-page { min-height: 100vh; display: flex; flex-direction: column; }
.chat-header {
  position: sticky; top: 0; z-index: 50;
  background: rgba(255,255,255,0.92);
  backdrop-filter: blur(12px);
  padding: 12px 16px;
  border-bottom: 1px solid var(--pink-100);
  display: flex; align-items: center;
}
.header-left { display: flex; align-items: center; gap: 10px; }
.header-emo { font-size: 28px; }
.header-title { font-size: 17px; font-weight: 700; color: var(--pink-600); }
.header-sub { font-size: 12px; color: #999; margin-top: 1px; }

.messages-area {
  flex: 1;
  overflow-y: auto;
  padding: 12px 12px 16px;
  -webkit-overflow-scrolling: touch;
}
.loading-hint, .empty-state { text-align: center; color: #bbb; padding: 40px 0; }
.empty-emo { font-size: 48px; margin-bottom: 8px; }

.msg-row {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
  animation: slideInLeft 0.3s ease both;
}
.msg-row.female-row { flex-direction: row-reverse; animation-name: slideInRight; }

.avatar {
  width: 36px; height: 36px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}
.avatar.male { background: var(--blue-100); }
.avatar.female { background: var(--pink-100); }

.msg-content-wrap { max-width: 72%; display: flex; flex-direction: column; gap: 3px; }
.msg-row.female-row .msg-content-wrap { align-items: flex-end; }

.sender-name { font-size: 11px; color: #aaa; padding: 0 4px; }

.bubble {
  padding: 10px 14px;
  border-radius: 18px;
  background: white;
  box-shadow: var(--shadow-sm);
  word-break: break-word;
  position: relative;
  min-width: 40px;
}
.bubble.male { background: white; border-bottom-left-radius: 4px; }
.bubble.female {
  background: linear-gradient(135deg, #ff9ec0, #ff6b9d);
  color: white;
  border-bottom-right-radius: 4px;
}
.bubble.female .msg-text { color: white; }

.img-grid { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 4px; }
.img-grid:has(:only-child) .msg-img { width: 200px; height: 200px; }
.msg-img { width: 90px; height: 90px; border-radius: 10px; object-fit: cover; }

.msg-video { max-width: 240px; border-radius: 12px; display: block; }

.voice-msg {
  display: flex; align-items: center; gap: 8px;
  min-width: 120px; cursor: pointer;
  padding: 4px 0;
}
.voice-icon { flex-shrink: 0; }
.bubble.female .voice-icon { color: white; }
.voice-bars { display: flex; align-items: center; gap: 2px; height: 24px; flex: 1; }
.vbar {
  width: 3px; background: #ccc; border-radius: 2px;
  transition: height 0.15s;
}
.vbar.active {
  animation: barPulse 0.6s ease-in-out infinite alternate;
  background: var(--pink-400);
}
.bubble.female .vbar { background: rgba(255,255,255,0.5); }
.bubble.female .vbar.active { background: white; }
@keyframes barPulse { from { height: 6px; } to { height: 20px; } }
.voice-dur { font-size: 12px; opacity: 0.7; min-width: 28px; }

.msg-text { font-size: 15px; line-height: 1.5; }

.ai-summary {
  margin-top: 6px;
  font-size: 12px;
  font-style: italic;
  opacity: 0.8;
  padding-top: 6px;
  border-top: 1px dashed rgba(0,0,0,0.08);
}
.bubble.female .ai-summary { border-top-color: rgba(255,255,255,0.25); }
.ai-loading {
  margin-top: 4px;
  font-size: 12px; opacity: 0.6;
  display: flex; align-items: center; gap: 4px;
}

.bubble-meta {
  display: flex; align-items: center; gap: 6px;
  font-size: 11px; color: #bbb; padding: 0 4px;
}
.cat-tag {
  font-size: 11px;
  padding: 2px 7px;
  border-radius: 8px;
  font-weight: 500;
}
.manual-badge {
  font-size: 10px;
  background: #f0f0f0;
  color: #999;
  padding: 1px 5px;
  border-radius: 6px;
}

/* Input area */
.input-area {
  background: rgba(255,255,255,0.96);
  backdrop-filter: blur(8px);
  border-top: 1px solid var(--pink-100);
  padding: 8px 10px;
  padding-bottom: calc(8px + env(safe-area-inset-bottom, 0px));
  position: sticky; bottom: 72px;
}
.options-row {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px; flex-wrap: wrap; gap: 6px;
}
.opt-left { display: flex; align-items: center; }

.preview-row { display: flex; gap: 6px; margin-bottom: 6px; flex-wrap: wrap; }
.preview-thumb { position: relative; width: 65px; height: 65px; border-radius: 8px; overflow: hidden; }
.preview-thumb img { width: 100%; height: 100%; object-fit: cover; }
.video-thumb { width: 100px; height: 130px; }
.thumb-remove {
  position: absolute; top: 2px; right: 2px;
  width: 20px; height: 20px; border-radius: 50%;
  background: rgba(0,0,0,0.55); color: white;
  display: flex; align-items: center; justify-content: center;
  font-size: 14px; cursor: pointer; line-height: 1;
}
.voice-preview {
  display: flex; align-items: center; gap: 8px;
  background: var(--pink-50); padding: 8px 12px;
  border-radius: 10px; font-size: 13px; color: var(--pink-600);
  position: relative; padding-right: 28px;
}
.voice-preview .thumb-remove { position: static; margin-left: auto; background: var(--pink-400); width: 18px; height: 18px; }

.input-row { display: flex; align-items: flex-end; gap: 6px; }
.icon-btn {
  width: 38px; height: 38px;
  border: none; background: var(--pink-50);
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  color: var(--pink-500);
  cursor: pointer; flex-shrink: 0;
  transition: all 0.15s;
}
.icon-btn:disabled { opacity: 0.35; cursor: not-allowed; }
.icon-btn:not(:disabled):active { transform: scale(0.9); background: var(--pink-100); }
.mic-btn.recording { background: #ff4444; color: white; animation: pulse 0.8s infinite; }
@keyframes pulse { 0%,100%{box-shadow:0 0 0 0 rgba(255,68,68,0.4)} 50%{box-shadow:0 0 0 8px rgba(255,68,68,0)} }

.text-input { flex: 1; }
.text-input :deep(.el-textarea__inner) {
  border-radius: 20px !important;
  border: 1px solid var(--pink-100) !important;
  padding: 9px 16px !important;
  font-size: 15px !important;
  min-height: 38px !important;
  max-height: 100px !important;
}

.send-btn {
  width: 38px; height: 38px;
  border: none; border-radius: 50%;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  color: white; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; transition: all 0.15s;
  box-shadow: 0 2px 8px rgba(255,107,157,0.3);
}
.send-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.send-btn:not(:disabled):active { transform: scale(0.9); }

/* Recording overlay */
.rec-overlay {
  position: fixed; inset: 0; z-index: 200;
  background: rgba(0,0,0,0.85);
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  color: white;
}
.rec-pulse {
  position: absolute;
  width: 200px; height: 200px;
  border-radius: 50%;
  background: rgba(255,68,68,0.2);
  animation: pulseRing 1.2s ease-out infinite;
}
@keyframes pulseRing { 0%{transform:scale(0.6);opacity:0.8} 100%{transform:scale(2);opacity:0} }
.rec-content { text-align: center; z-index: 1; }
.rec-mic { font-size: 64px; margin-bottom: 12px; }
.rec-timer { font-size: 48px; font-weight: 300; font-variant-numeric: tabular-nums; }
.rec-hint { font-size: 14px; opacity: 0.6; margin-top: 8px; }
.rec-wave { display: flex; align-items: center; gap: 3px; justify-content: center; margin: 24px 0; height: 50px; }
.w-bar { width: 4px; background: #ff6b9d; border-radius: 2px; animation: barWave 0.5s ease-in-out infinite alternate; }
@keyframes barWave { from { height: 10px; } to { height: 40px; } }
.rec-actions { display: flex; gap: 32px; margin-top: 20px; }
.rec-cancel, .rec-confirm {
  padding: 12px 24px; border-radius: 30px; border: none;
  font-size: 15px; cursor: pointer;
  display: flex; align-items: center; gap: 6px;
}
.rec-cancel { background: rgba(255,255,255,0.15); color: white; }
.rec-confirm { background: linear-gradient(135deg, #ff6b9d, #c878ff); color: white; }

/* Video recording */
.video-overlay { background: black; }
.video-preview-el {
  width: 100%; max-width: 400px;
  border-radius: 16px;
  aspect-ratio: 3/4; object-fit: cover;
}
.video-rec-timer {
  position: absolute; top: 60px; left: 50%; transform: translateX(-50%);
  display: flex; align-items: center; gap: 8px;
  font-size: 20px; font-variant-numeric: tabular-nums; color: white;
}
.rec-dot { width: 10px; height: 10px; border-radius: 50%; background: #ff3333; animation: blink 0.8s infinite; }
@keyframes blink { 50% { opacity: 0.3; } }
.video-rec-actions {
  display: flex; align-items: center; justify-content: center; gap: 48px;
  margin-top: 32px;
}
.video-stop-btn {
  width: 72px; height: 72px; border-radius: 50%;
  border: 4px solid white; background: transparent;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
}
.stop-inner { width: 28px; height: 28px; border-radius: 4px; background: #ff3333; }
.rec-hint-video { color: rgba(255,255,255,0.5); font-size: 13px; margin-top: 12px; }
</style>
