<template>
  <div class="cats-page">
    <header class="page-header">
      <h1>📂 分类相册</h1>
      <button class="add-btn" @click="showAddDialog = true">
        <el-icon :size="18"><Plus /></el-icon> 新建分类
      </button>
    </header>

    <div v-if="loading" class="loading-hint">加载中...</div>

    <div class="cats-grid">
      <div
        v-for="cat in categories"
        :key="cat.id"
        class="cat-card"
        @click="openCategory(cat)"
      >
        <div class="cat-icon-wrap" :style="{ background: cat.color + '22' }">
          <span class="cat-icon">{{ cat.icon }}</span>
        </div>
        <div class="cat-info">
          <div class="cat-name">
            {{ cat.name }}
            <span v-if="!cat.is_system" class="custom-tag">自定义</span>
          </div>
          <div class="cat-count">{{ cat.message_count }} 条记录</div>
        </div>
        <div class="cat-actions" @click.stop>
          <el-dropdown v-if="!cat.is_system" trigger="click" @command="cmd => handleCmd(cmd, cat)">
            <el-icon class="more-btn"><MoreFilled /></el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="edit"><el-icon><Edit /></el-icon> 编辑</el-dropdown-item>
                <el-dropdown-item command="delete" divided><el-icon><Delete /></el-icon> 删除</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <el-icon v-else class="sys-badge">🔒</el-icon>
        </div>
        <el-icon class="arrow"><ArrowRight /></el-icon>
      </div>

      <div v-if="!loading && categories.length === 0" class="empty-hint">
        <p>暂无分类</p>
      </div>
    </div>

    <!-- Add/Edit dialog -->
    <el-dialog v-model="showAddDialog" title="新建自定义分类" width="340px" :show-close="true" center>
      <div class="dialog-form">
        <div class="form-item">
          <label>分类名称</label>
          <el-input v-model="form.name" placeholder="如：养宠日常、装修日记" maxlength="10" />
        </div>
        <div class="form-item">
          <label>选择图标</label>
          <div class="icon-picker">
            <button
              v-for="ic in iconOptions" :key="ic"
              class="icon-opt" :class="{ active: form.icon === ic }"
              @click="form.icon = ic"
            >{{ ic }}</button>
          </div>
        </div>
        <div class="form-item">
          <label>主题颜色</label>
          <div class="color-picker">
            <button
              v-for="c in colorOptions" :key="c"
              class="color-opt" :class="{ active: form.color === c }"
              :style="{ background: c }"
              @click="form.color = c"
            />
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="saveCategory" :loading="saving">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getCategories, createCategory, updateCategory, deleteCategory } from '../api/category'
import { useCoupleStore } from '../stores/couple'

const router = useRouter()
const store = useCoupleStore()
const categories = ref([])
const loading = ref(true)
const showAddDialog = ref(false)
const saving = ref(false)
const editingId = ref(null)

const iconOptions = ['🏠', '🐱', '🐶', '🎮', '📚', '🎵', '🎨', '🏋️', '✈️', '🎂', '🌸', '⭐', '💼', '🎓', '🏥', '🛒', '🍳', '🧘']
const colorOptions = ['#ff6b9d', '#ff9a56', '#56b3ff', '#a856ff', '#56d99a', '#ffcc56', '#ff5656', '#5677ff']

const form = reactive({ name: '', icon: '🏠', color: '#ff6b9d' })

async function loadCats() {
  loading.value = true
  try {
    categories.value = await getCategories()
  } finally {
    loading.value = false
  }
}

function openCategory(cat) {
  router.push(`/category/${cat.id}`)
}

function handleCmd(cmd, cat) {
  if (cmd === 'edit') {
    editingId.value = cat.id
    form.name = cat.name
    form.icon = cat.icon
    form.color = cat.color
    showAddDialog.value = true
  } else if (cmd === 'delete') {
    ElMessageBox.confirm(`确认删除「${cat.name}」？该分类下的消息将移至"趣味日常存档"`, '删除确认', {
      confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning'
    }).then(async () => {
      await deleteCategory(cat.id)
      ElMessage.success('已删除')
      loadCats()
    }).catch(() => {})
  }
}

async function saveCategory() {
  if (!form.name.trim()) { ElMessage.warning('请输入分类名称'); return }
  saving.value = true
  try {
    if (editingId.value) {
      await updateCategory(editingId.value, { name: form.name.trim(), icon: form.icon, color: form.color })
      ElMessage.success('已更新')
    } else {
      await createCategory({ name: form.name.trim(), icon: form.icon, color: form.color })
      ElMessage.success('已创建')
    }
    showAddDialog.value = false
    editingId.value = null
    form.name = ''; form.icon = '🏠'; form.color = '#ff6b9d'
    loadCats()
  } catch (e) {
    ElMessage.error(e?.response?.data?.detail || '操作失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => { loadCats() })
</script>

<style scoped>
.cats-page { padding: 0 0 24px; }
.page-header {
  padding: 20px 16px 12px;
  display: flex; align-items: center; justify-content: space-between;
}
h1 { font-size: 22px; color: var(--pink-600); margin: 0; }
.add-btn {
  display: flex; align-items: center; gap: 4px;
  padding: 8px 14px; border-radius: 20px;
  border: none;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  color: white; font-size: 13px;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(255,107,157,0.3);
}
.loading-hint { text-align: center; color: #bbb; padding: 40px 0; }

.cats-grid { padding: 0 12px; display: flex; flex-direction: column; gap: 10px; max-height: calc(100vh - 180px); overflow-y: auto; }
.cat-card {
  display: flex; align-items: center; gap: 14px;
  background: white;
  border-radius: 16px;
  padding: 14px 16px;
  box-shadow: var(--shadow-sm);
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}
.cat-card:active { transform: scale(0.98); box-shadow: var(--shadow-md); }
.cat-icon-wrap {
  width: 52px; height: 52px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.cat-icon { font-size: 28px; }
.cat-info { flex: 1; min-width: 0; }
.cat-name {
  font-size: 16px; font-weight: 600; color: #333;
  display: flex; align-items: center; gap: 6px;
}
.custom-tag {
  font-size: 10px;
  background: var(--pink-50); color: var(--pink-500);
  padding: 1px 6px; border-radius: 6px;
  font-weight: 400;
}
.cat-count { font-size: 13px; color: #999; margin-top: 3px; }
.cat-actions { margin-right: 4px; }
.more-btn { color: #ccc; font-size: 20px; cursor: pointer; }
.more-btn:hover { color: var(--pink-500); }
.sys-badge { font-size: 14px; opacity: 0.4; }
.arrow { color: #ddd; font-size: 18px; }
.empty-hint { text-align: center; color: #bbb; padding: 60px 0; }

.dialog-form { display: flex; flex-direction: column; gap: 16px; }
.form-item label { display: block; font-size: 13px; color: #666; margin-bottom: 6px; }
.icon-picker { display: flex; flex-wrap: wrap; gap: 6px; }
.icon-opt {
  width: 40px; height: 40px; border-radius: 10px;
  border: 2px solid #f0f0f0; background: white;
  font-size: 22px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.icon-opt.active { border-color: var(--pink-500); background: var(--pink-50); }
.color-picker { display: flex; gap: 8px; }
.color-opt {
  width: 32px; height: 32px; border-radius: 50%;
  border: 3px solid transparent;
  cursor: pointer;
}
.color-opt.active { border-color: #333; }
</style>
