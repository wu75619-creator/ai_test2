<template>
  <div class="timeline-page">
    <header class="page-header">
      <h1>💕 恋爱时间轴</h1>
      <button class="stat-toggle" :class="{ active: showStats }" @click="showStats = !showStats">
        <el-icon :size="18"><DataAnalysis /></el-icon>
      </button>
    </header>

    <!-- Love Days Floating Card -->
    <div class="love-days-card" v-if="stats">
      <div class="ld-heart">💗</div>
      <div class="ld-info">
        <div class="ld-number">{{ stats.love_days }}</div>
        <div class="ld-label">相爱天数</div>
      </div>
      <div class="ld-divider"></div>
      <div class="ld-stats-mini">
        <div class="ld-stat-item">
          <div class="ld-sm-num">{{ stats.total_messages }}</div>
          <div class="ld-sm-label">条消息</div>
        </div>
        <div class="ld-stat-item">
          <div class="ld-sm-num">{{ stats.male_total }}</div>
          <div class="ld-sm-label">{{ store.maleNickname }}</div>
        </div>
        <div class="ld-stat-item">
          <div class="ld-sm-num">{{ stats.female_total }}</div>
          <div class="ld-sm-label">{{ store.femaleNickname }}</div>
        </div>
      </div>
    </div>

    <!-- Stats Panel (toggleable) -->
    <transition name="slide-up">
      <div v-if="showStats && stats" class="stats-panel">
        <div class="stats-section">
          <h3>📊 活跃度分布（24小时）</h3>
          <div class="hour-chart">
            <div
              v-for="(cnt, h) in stats.hourly_distribution"
              :key="h"
              class="hour-bar-wrap"
              @mouseenter="hoverHour = h; hoverHourCnt = cnt"
              @mouseleave="hoverHour = null"
            >
              <div class="hour-bar" :style="{ height: getHourBarH(cnt) + 'px' }" :class="{ peak: isPeakHour(h) }"></div>
              <span v-if="h % 4 === 0" class="hour-label">{{ h }}</span>
            </div>
          </div>
          <div v-if="hoverHour !== null" class="hour-tooltip">
            {{ hoverHour }}:00 - {{ hoverHourCnt }}条消息
          </div>
        </div>

        <div class="stats-section">
          <h3>🏷️ 分类统计</h3>
          <div class="cat-stats-list">
            <div v-for="c in stats.category_distribution.slice(0, 8)" :key="c.id" class="cat-stat-row">
              <span class="cs-icon">{{ c.icon }}</span>
              <span class="cs-name">{{ c.name }}</span>
              <div class="cs-bar-bg">
                <div class="cs-bar" :style="{ width: getCatBarW(c.count) + '%', background: c.color }"></div>
              </div>
              <span class="cs-count">{{ c.count }}</span>
            </div>
          </div>
        </div>

        <!-- Weekly stats -->
        <div class="stats-section">
          <h3>📅 周报 (近8周)</h3>
          <div class="week-list">
            <div v-for="(w, wi) in stats.weekly" :key="wi" class="week-card">
              <div class="week-head">
                <span class="week-label">{{ w.week_label }}</span>
                <span class="week-total">{{ w.total_messages }}条</span>
              </div>
              <div class="week-activity">
                <div class="wa-bar-wrap">
                  <div class="wa-bar male" :style="{ flex: w.male_count }"></div>
                  <div class="wa-bar female" :style="{ flex: w.female_count }"></div>
                </div>
                <span class="wa-avg">日均 {{ w.avg_daily }} 条</span>
              </div>
              <div class="week-detail">
                <span class="wd-male">👨 {{ w.male_count }}</span>
                <span class="wd-female">👩 {{ w.female_count }}</span>
                <span class="wd-hour">🕐 {{ w.most_active_hour }}:00 最活跃</span>
              </div>
              <div v-if="Object.keys(w.category_counts).length" class="week-cats">
                <span v-for="(cnt, cn) in Object.fromEntries(Object.entries(w.category_counts).slice(0,3))" :key="cn" class="wc-tag">
                  {{ cn }} {{ cnt }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <!-- Monthly stats -->
        <div class="stats-section">
          <h3>🗓️ 月报 (近6个月)</h3>
          <div class="month-list">
            <div v-for="(mo, mi) in stats.monthly" :key="mi" class="month-card">
              <div class="month-head">
                <span class="month-label">{{ mo.month_label }}</span>
                <span v-if="mo.love_days_in_month > 0" class="month-days">💕 {{ mo.love_days_in_month }}天</span>
              </div>
              <div class="month-stats-row">
                <div class="ms-stat">
                  <div class="ms-num">{{ mo.total_messages }}</div>
                  <div class="ms-lbl">消息</div>
                </div>
                <div class="ms-stat">
                  <div class="ms-num" style="color:var(--blue-600)">{{ mo.male_count }}</div>
                  <div class="ms-lbl">{{ store.maleNickname }}</div>
                </div>
                <div class="ms-stat">
                  <div class="ms-num" style="color:var(--pink-500)">{{ mo.female_count }}</div>
                  <div class="ms-lbl">{{ store.femaleNickname }}</div>
                </div>
              </div>
              <div v-if="Object.keys(mo.category_counts).length" class="month-cats">
                <span v-for="(cnt, cn) in Object.fromEntries(Object.entries(mo.category_counts).slice(0,4))" :key="cn" class="mc-tag">
                  {{ cn }} · {{ cnt }}
                </span>
              </div>
              <!-- Mini daily chart -->
              <div class="daily-chart">
                <div
                  v-for="(cnt, dk) in Object.entries(mo.daily_counts).slice(-14)"
                  :key="dk"
                  class="daily-bar"
                  :style="{ height: Math.min(40, cnt * 3 + 4) + 'px' }"
                  :title="dk[0] + ': ' + dk[1] + '条'"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <!-- Timeline -->
    <div v-if="loading" class="loading-hint">加载中...</div>

    <div v-if="!loading && groupedMessages.length === 0" class="empty-state">
      <div class="empty-emo">💌</div>
      <p>还没有消息，开始记录吧</p>
    </div>

    <el-timeline v-else class="tl-list">
      <el-timeline-item
        v-for="group in groupedMessages"
        :key="group.date"
        :timestamp="group.dateLabel"
        placement="top"
        type="primary"
        size="large"
      >
        <div class="tl-date-label">{{ group.dateLabel }}</div>
        <div v-for="msg in group.messages" :key="msg.id" class="tl-msg-card" :class="msg.sender_role">
          <div class="tl-msg-header">
            <span class="tl-avatar">{{ msg.sender_role === 'female' ? '👩' : '👨' }}</span>
            <span class="tl-name">{{ msg.sender_nickname }}</span>
            <span v-if="msg.main_category_icon" class="tl-cat-tag" :style="{ background: msg.main_category_color + '20', color: msg.main_category_color }">
              {{ msg.main_category_icon }} {{ msg.main_category_name }}
            </span>
          </div>
          <div v-if="msg.text_content" class="tl-text">{{ msg.text_content }}</div>
          <div v-if="getImages(msg).length" class="tl-images">
            <el-image
              v-for="(img, i) in getImages(msg)" :key="i"
              :src="img.file_url" fit="cover"
              :preview-src-list="getImages(msg).map(x=>x.file_url)"
              :initial-index="i" preview-teleported
              class="tl-img"
            />
          </div>
          <video
            v-for="v in getVideos(msg)" :key="v.id"
            :src="v.file_url" controls playsinline preload="metadata"
            class="tl-video"
          />
          <audio
            v-for="voc in getVoices(msg)" :key="voc.id"
            :src="voc.file_url" controls preload="metadata"
            class="tl-audio"
          />
          <div v-if="msg.ai_summary" class="tl-ai">✨ {{ msg.ai_summary }}</div>
          <div class="tl-time">{{ formatT(msg.created_at) }}</div>
        </div>
      </el-timeline-item>
    </el-timeline>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { getMessages } from '../api/message'
import { getStats } from '../api/stats'
import { useCoupleStore } from '../stores/couple'

const store = useCoupleStore()
const messages = ref([])
const stats = ref(null)
const loading = ref(true)
const showStats = ref(false)
const hoverHour = ref(null)
const hoverHourCnt = ref(0)

function getImages(m) { return m.attachments?.filter(a => a.file_type === 'image') || [] }
function getVideos(m) { return m.attachments?.filter(a => a.file_type === 'video') || [] }
function getVoices(m) { return m.attachments?.filter(a => a.file_type === 'voice') || [] }
function formatT(t) { return dayjs(t).format('HH:mm') }

const groupedMessages = computed(() => {
  const groups = {}
  for (const msg of [...messages.value].reverse()) {
    const d = dayjs(msg.created_at).format('YYYY-MM-DD')
    if (!groups[d]) groups[d] = []
    groups[d].push(msg)
  }
  const weekdays = ['周日','周一','周二','周三','周四','周五','周六']
  return Object.entries(groups).map(([date, msgs]) => {
    const dt = dayjs(date)
    let label = dt.format('M月D日') + ' ' + weekdays[dt.day()]
    const today = dayjs().startOf('day')
    if (dt.isSame(today, 'day')) label = '今天'
    else if (dt.isSame(today.subtract(1, 'day'), 'day')) label = '昨天'
    return { date, dateLabel: label, messages: msgs }
  })
})

const maxHourCnt = computed(() => Math.max(...(stats.value?.hourly_distribution || [1]), 1))
const maxCatCnt = computed(() => Math.max(...(stats.value?.category_distribution?.map(c=>c.count) || [1]), 1))

function getHourBarH(cnt) {
  return Math.max(2, (cnt / maxHourCnt.value) * 60)
}
function isPeakHour(h) {
  const mx = maxHourCnt.value
  return stats.value?.hourly_distribution[h] >= mx * 0.7 && mx > 0
}
function getCatBarW(cnt) {
  return Math.max(4, (cnt / maxCatCnt.value) * 100)
}

async function load() {
  loading.value = true
  try {
    const [msgs, st] = await Promise.all([getMessages('desc'), getStats()])
    messages.value = msgs
    stats.value = st
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  load()
  store.load()
})
</script>

<style scoped>
.timeline-page { padding-bottom: 24px; }
.page-header {
  padding: 20px 16px 8px;
  display: flex; align-items: center; justify-content: space-between;
}
h1 { font-size: 22px; color: var(--pink-600); margin: 0; }
.stat-toggle {
  width: 38px; height: 38px; border-radius: 50%;
  border: none; background: var(--pink-50);
  color: var(--pink-500); cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}
.stat-toggle.active { background: linear-gradient(135deg, #ff6b9d, #c878ff); color: white; }

/* Love Days Card */
.love-days-card {
  margin: 0 12px 12px;
  background: linear-gradient(135deg, #fff0f5, #fce4ec, #f3e8ff);
  border-radius: 18px;
  padding: 16px;
  display: flex; align-items: center; gap: 16px;
  box-shadow: var(--shadow-md);
  position: relative;
  overflow: hidden;
}
.love-days-card::before {
  content: '';
  position: absolute; right: -20px; top: -20px;
  width: 100px; height: 100px;
  background: radial-gradient(circle, rgba(255,107,157,0.15), transparent 70%);
  border-radius: 50%;
}
.ld-heart { font-size: 36px; animation: heartBeat 2s infinite; }
@keyframes heartBeat { 0%,100%{transform:scale(1)} 14%{transform:scale(1.3)} 28%{transform:scale(1)} }
.ld-info { text-align: center; }
.ld-number { font-size: 32px; font-weight: 800; color: var(--pink-600); line-height: 1; }
.ld-label { font-size: 11px; color: #999; margin-top: 2px; }
.ld-divider { width: 1px; height: 40px; background: rgba(255,107,157,0.2); }
.ld-stats-mini { display: flex; gap: 20px; flex: 1; justify-content: space-around; }
.ld-stat-item { text-align: center; }
.ld-sm-num { font-size: 18px; font-weight: 700; color: #333; }
.ld-sm-label { font-size: 11px; color: #999; margin-top: 2px; }

/* Stats Panel */
.stats-panel { padding: 0 12px; display: flex; flex-direction: column; gap: 14px; margin-bottom: 8px; }
.stats-section {
  background: white;
  border-radius: 16px;
  padding: 16px;
  box-shadow: var(--shadow-sm);
}
.stats-section h3 { font-size: 14px; color: #333; margin: 0 0 14px; font-weight: 600; }

.hour-chart {
  display: flex; align-items: flex-end;
  gap: 2px; height: 72px;
  border-bottom: 1px solid #f0f0f0;
  padding-bottom: 4px;
}
.hour-bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 2px; }
.hour-bar {
  width: 100%; border-radius: 2px 2px 0 0;
  background: var(--pink-200);
  min-height: 2px;
  transition: all 0.2s;
  cursor: pointer;
}
.hour-bar.peak { background: var(--pink-500); }
.hour-bar:hover { background: var(--pink-500); }
.hour-label { font-size: 9px; color: #ccc; }
.hour-tooltip {
  text-align: center; font-size: 12px; color: var(--pink-600);
  margin-top: 8px;
}

.cat-stats-list { display: flex; flex-direction: column; gap: 8px; }
.cat-stat-row { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.cs-icon { width: 20px; text-align: center; }
.cs-name { width: 80px; color: #555; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cs-bar-bg { flex: 1; height: 8px; background: #f5f5f5; border-radius: 4px; overflow: hidden; }
.cs-bar { height: 100%; border-radius: 4px; transition: width 0.5s; }
.cs-count { width: 28px; text-align: right; color: #888; font-size: 12px; font-weight: 600; }

/* Weekly */
.week-list { display: flex; flex-direction: column; gap: 10px; }
.week-card {
  background: var(--pink-50);
  border-radius: 12px; padding: 12px;
}
.week-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.week-label { font-size: 13px; font-weight: 600; color: #333; }
.week-total { font-size: 12px; color: var(--pink-500); font-weight: 600; }
.week-activity { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
.wa-bar-wrap { flex: 1; display: flex; height: 8px; border-radius: 4px; overflow: hidden; gap: 2px; }
.wa-bar { height: 100%; border-radius: 4px; min-width: 0; transition: flex 0.4s; }
.wa-bar.male { background: var(--blue-400); }
.wa-bar.female { background: var(--pink-400); }
.wa-avg { font-size: 11px; color: #999; white-space: nowrap; }
.week-detail { display: flex; gap: 12px; font-size: 11px; color: #888; margin-bottom: 6px; flex-wrap: wrap; }
.wd-male { color: var(--blue-600); }
.wd-female { color: var(--pink-500); }
.week-cats { display: flex; flex-wrap: wrap; gap: 4px; }
.wc-tag {
  font-size: 11px; background: white;
  padding: 2px 7px; border-radius: 8px; color: #666;
}

/* Monthly */
.month-list { display: flex; flex-direction: column; gap: 10px; }
.month-card {
  background: linear-gradient(135deg, #f8f9ff, #fff5f8);
  border-radius: 12px; padding: 12px;
}
.month-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.month-label { font-size: 14px; font-weight: 600; color: #333; }
.month-days { font-size: 12px; color: var(--pink-500); }
.month-stats-row { display: flex; gap: 8px; margin-bottom: 8px; }
.ms-stat {
  flex: 1; background: white; border-radius: 10px;
  padding: 8px; text-align: center;
}
.ms-num { font-size: 20px; font-weight: 700; color: #333; }
.ms-lbl { font-size: 11px; color: #999; }
.month-cats { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px; }
.mc-tag { font-size: 11px; background: white; padding: 2px 8px; border-radius: 8px; color: #666; }
.daily-chart {
  display: flex; align-items: flex-end;
  gap: 2px; height: 44px;
  border-top: 1px solid rgba(0,0,0,0.05);
  padding-top: 4px;
}
.daily-bar {
  flex: 1; background: var(--pink-300);
  border-radius: 2px 2px 0 0; min-height: 2px;
  transition: height 0.3s;
}

/* Timeline list */
.loading-hint, .empty-state { text-align: center; color: #bbb; padding: 40px 0; }
.empty-emo { font-size: 48px; margin-bottom: 8px; }
.tl-list { padding: 8px 12px; }
.tl-date-label {
  font-size: 13px; font-weight: 600; color: var(--pink-600);
  background: var(--pink-50);
  display: inline-block; padding: 3px 12px;
  border-radius: 12px; margin-bottom: 8px;
}

.tl-msg-card {
  background: white;
  border-radius: 14px;
  padding: 12px;
  margin-bottom: 8px;
  box-shadow: var(--shadow-sm);
  animation: fadeInUp 0.3s ease both;
}
.tl-msg-card.female { border-left: 3px solid var(--pink-500); }
.tl-msg-card.male { border-left: 3px solid var(--blue-400); }
.tl-msg-header { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.tl-avatar { font-size: 18px; }
.tl-name { font-size: 13px; font-weight: 600; color: #555; }
.tl-cat-tag {
  font-size: 11px;
  padding: 1px 7px; border-radius: 8px;
  font-weight: 500;
}
.tl-text { font-size: 14px; line-height: 1.6; color: #333; margin-bottom: 8px; }
.tl-images { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px; }
.tl-img { width: calc(50% - 2px); aspect-ratio: 1; border-radius: 8px; max-width: 180px; }
.tl-img:only-child { width: 200px; aspect-ratio: auto; max-height: 250px; }
.tl-video { max-width: 100%; border-radius: 10px; margin-bottom: 8px; max-height: 250px; }
.tl-audio { width: 100%; margin-bottom: 8px; }
.tl-ai {
  background: linear-gradient(135deg, #fff0f5, #f3e8ff);
  padding: 7px 10px; border-radius: 8px;
  font-size: 12px; color: var(--pink-600);
  font-style: italic; margin-bottom: 6px;
}
.tl-time { font-size: 11px; color: #ccc; }

:deep(.el-timeline-item__timestamp) {
  color: var(--pink-500) !important;
  font-size: 12px !important;
  font-weight: 500;
}
:deep(.el-timeline-item__node--normal) {
  background: var(--pink-400) !important;
}
</style>
