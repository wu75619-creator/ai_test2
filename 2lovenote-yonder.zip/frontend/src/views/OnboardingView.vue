<template>
  <div class="onboarding-wrap">
    <div class="deco-heart heart-1">💕</div>
    <div class="deco-heart heart-2">💗</div>
    <div class="deco-heart heart-3">💖</div>

    <div class="ob-card">
      <div class="ob-logo">💕</div>
      <h1 class="ob-title">欢迎来到 LoveNote</h1>
      <p class="ob-sub">两人专属的智能恋爱日记本</p>

      <div class="ob-form">
        <div class="form-group">
          <label>💑 情侣昵称</label>
          <el-input v-model="form.couple_name" placeholder="如：小明&小红 的小窝" size="large" />
        </div>

        <div class="form-row">
          <div class="form-group half">
            <label>👨 男主昵称</label>
            <el-input v-model="form.male_nickname" placeholder="他" size="large" />
          </div>
          <div class="form-group half">
            <label>👩 女主昵称</label>
            <el-input v-model="form.female_nickname" placeholder="她" size="large" />
          </div>
        </div>

        <div class="form-group">
          <label>📅 在一起的日子（选填）</label>
          <el-date-picker
            v-model="form.together_date"
            type="date"
            placeholder="选择你们在一起的日期"
            size="large"
            style="width:100%"
            format="YYYY-MM-DD"
            value-format="YYYY-MM-DD"
          />
        </div>

        <div class="form-group">
          <label>🔒 访问密码（选填，防止他人误看）</label>
          <el-input v-model="form.access_password" type="password" placeholder="设置后每次打开需输入" size="large" show-password />
        </div>
      </div>

      <button class="ob-btn" @click="submit" :disabled="loading">
        {{ loading ? '设置中...' : '✨ 开启我们的日记' }}
      </button>
      <p class="ob-tip">设置完成后，即可开始记录你们的每一个美好瞬间 ❤️</p>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { setupCouple } from '../api/couple'
import { useCoupleStore } from '../stores/couple'

const router = useRouter()
const store = useCoupleStore()
const loading = ref(false)

const form = reactive({
  couple_name: '我们的小窝',
  male_nickname: '他',
  female_nickname: '她',
  together_date: '',
  access_password: '',
})

async function submit() {
  if (!form.male_nickname.trim() || !form.female_nickname.trim()) {
    ElMessage.warning('请填写双方昵称')
    return
  }
  loading.value = true
  try {
    await setupCouple({
      couple_name: form.couple_name.trim(),
      male_nickname: form.male_nickname.trim(),
      female_nickname: form.female_nickname.trim(),
      together_date: form.together_date || null,
      access_password: form.access_password,
    })
    await store.load()
    store.setOnboardingDone(true)
    store.setVerified()
    ElMessage.success('设置完成！开始记录吧 💕')
    router.replace('/')
  } catch (e) {
    ElMessage.error('设置失败，请重试')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.onboarding-wrap {
  min-height: 100vh;
  background: linear-gradient(160deg, #fff5f8 0%, #ffe8f0 50%, #f3e8ff 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  position: relative;
  overflow: hidden;
}
.deco-heart {
  position: absolute;
  font-size: 40px;
  opacity: 0.3;
  animation: float 6s ease-in-out infinite;
}
.heart-1 { top: 10%; left: 10%; animation-delay: 0s; }
.heart-2 { top: 60%; right: 8%; font-size: 52px; animation-delay: 2s; }
.heart-3 { bottom: 15%; left: 15%; font-size: 32px; animation-delay: 4s; }
@keyframes float {
  0%,100% { transform: translateY(0) rotate(0deg); }
  50% { transform: translateY(-20px) rotate(10deg); }
}
.ob-card {
  background: rgba(255,255,255,0.96);
  border-radius: 24px;
  padding: 36px 28px;
  width: 100%;
  max-width: 420px;
  box-shadow: 0 12px 48px rgba(255,107,157,0.18);
  position: relative;
  z-index: 1;
}
.ob-logo {
  font-size: 56px;
  text-align: center;
  animation: heartBeat 2s ease-in-out infinite;
}
@keyframes heartBeat {
  0%,100% { transform: scale(1); }
  15% { transform: scale(1.15); }
  30% { transform: scale(1); }
  45% { transform: scale(1.1); }
}
.ob-title {
  text-align: center;
  font-size: 24px;
  font-weight: 700;
  color: var(--pink-600);
  margin: 8px 0 4px;
}
.ob-sub {
  text-align: center;
  color: #999;
  font-size: 14px;
  margin: 0 0 24px;
}
.ob-form { display: flex; flex-direction: column; gap: 16px; }
.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-group label { font-size: 13px; color: #666; font-weight: 500; }
.form-row { display: flex; gap: 12px; }
.half { flex: 1; }
.ob-btn {
  width: 100%;
  margin-top: 24px;
  padding: 14px;
  border: none;
  border-radius: 16px;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  color: white;
  font-size: 17px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 16px rgba(255,107,157,0.35);
}
.ob-btn:active { transform: scale(0.97); }
.ob-btn:disabled { opacity: 0.6; cursor: not-allowed; }
.ob-tip {
  text-align: center;
  font-size: 12px;
  color: #bbb;
  margin: 12px 0 0;
}
</style>
