<template>
  <div class="cat-page">
    <header class="cat-header">
      <button class="back-btn" @click="$router.back()">
        <el-icon :size="20"><ArrowLeft /></el-icon>
      </button>
      <div class="cat-title-wrap">
        <span class="cat-emo">{{ category?.icon || '📁' }}</span>
        <span class="cat-title-text">{{ category?.name || '分类' }}</span>
        <span class="cat-count-badge">{{ messages.length }} 条</span>
      </div>
    </header>

    <!-- Filter bar -->
    <div class="filter-bar">
      <el-radio-group v-model="filterMode" size="small" @change="loadMessages">
        <el-radio-button value="all">全部</el-radio-button>
        <el-radio-button value="year">按年</el-radio-button>
        <el-radio-button value="month">按月</el-radio-button>
      </el-radio-group>
      <el-date-picker
        v-if="filterMode !== 'all'"
        v-model="filterDate"
        :type="filterMode === 'year' ? 'year' : 'month'"
        :placeholder="filterMode === 'year' ? '选择年份' : '选择月份'"
        size="small"
        style="width: 130px; margin-left: 8px;"
        @change="loadMessages"
      />
    </div>

    <div v-if="loading" class="loading-hint">加载中...</div>

    <div class="cards-list">
      <div v-for="msg in messages" :key="msg.id" class="memo-card">
        <div class="card-header">
          <div class="card-avatar" :class="msg.sender_role">
            {{ msg.sender_role === 'female' ? '👩' : '👨' }}
          </div>
          <div>
            <div class="card-sender">{{ msg.sender_nickname }}</div>
            <div class="card-time">{{ formatTime(msg.created_at) }}</div>
          </div>
        </div>

        <div v-if="msg.text_content" class="card-text">{{ msg.text_content }}</div>

        <div v-if="getImages(msg).length" class="card-images">
          <el-image
            v-for="(img, i) in getImages(msg)" :key="i"
            :src="img.file_url" fit="cover"
            :preview-src-list="getImages(msg).map(x=>x.file_url)"
            :initial-index="i" preview-teleported
            class="card-img"
          />
        </div>

        <video
          v-for="v in getVideos(msg)" :key="v.id"
          :src="v.file_url" controls playsinline preload="metadata"
          class="card-video"
        />

        <audio
          v-for="voc in getVoices(msg)" :key="voc.id"
          :src="voc.file_url" controls preload="metadata"
          class="card-audio"
        />

        <div v-if="msg.ai_summary" class="ai-note">✨ {{ msg.ai_summary }}</div>
      </div>

      <div v-if="!loading && messages.length === 0" class="empty-state">
        <div class="empty-emo">📭</div>
        <p>这个分类还没有记录</p>
        <button @click="$router.push('/')" class="goto-chat">去记录一条</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { getCategories, getCategoryMessages } from '../api/category'

const route = useRoute()
const catId = computed(() => parseInt(route.params.id))
const category = ref(null)
const messages = ref([])
const loading = ref(true)
const filterMode = ref('all')
const filterDate = ref(null)

function formatTime(t) { return dayjs(t).format('YYYY年M月D日 HH:mm') }
function getImages(m) { return m.attachments?.filter(a => a.file_type === 'image') || [] }
function getVideos(m) { return m.attachments?.filter(a => a.file_type === 'video') || [] }
function getVoices(m) { return m.attachments?.filter(a => a.file_type === 'voice') || [] }

async function loadMessages() {
  loading.value = true
  try {
    let year = null, month = null
    if (filterDate.value) {
      if (filterMode.value === 'year') year = dayjs(filterDate.value).year()
      else { year = dayjs(filterDate.value).year(); month = dayjs(filterDate.value).month() + 1 }
    }
    messages.value = await getCategoryMessages(catId.value, year, month)
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  try {
    const allCats = await getCategories()
    category.value = allCats.find(c => c.id === catId.value)
  } catch (e) {}
  loadMessages()
})
</script>

<style scoped>
.cat-page { padding-bottom: 24px; }
.cat-header {
  position: sticky; top: 0; z-index: 50;
  background: rgba(255,255,255,0.95);
  backdrop-filter: blur(10px);
  padding: 14px 16px;
  display: flex; align-items: center; gap: 10px;
  border-bottom: 1px solid var(--pink-100);
}
.back-btn {
  width: 36px; height: 36px; border-radius: 50%;
  border: none; background: var(--pink-50);
  display: flex; align-items: center; justify-content: center;
  color: var(--pink-600); cursor: pointer;
}
.cat-title-wrap { display: flex; align-items: center; gap: 8px; flex: 1; }
.cat-emo { font-size: 24px; }
.cat-title-text { font-size: 18px; font-weight: 700; color: #333; }
.cat-count-badge {
  font-size: 12px; background: var(--pink-50); color: var(--pink-500);
  padding: 2px 8px; border-radius: 10px;
}

.filter-bar {
  padding: 10px 16px;
  display: flex; align-items: center;
  gap: 4px;
  background: rgba(255,255,255,0.6);
}

.loading-hint, .empty-state { text-align: center; color: #bbb; padding: 40px 0; }
.empty-emo { font-size: 48px; margin-bottom: 8px; }
.goto-chat {
  margin-top: 12px; padding: 10px 24px;
  border: none; border-radius: 20px;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  color: white; cursor: pointer; font-size: 14px;
}

.cards-list { padding: 12px; display: flex; flex-direction: column; gap: 12px; }
.memo-card {
  background: white;
  border-radius: 16px;
  padding: 14px;
  box-shadow: var(--shadow-sm);
  animation: fadeInUp 0.3s ease both;
}
.card-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.card-avatar {
  width: 36px; height: 36px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 20px;
}
.card-avatar.female { background: var(--pink-100); }
.card-avatar.male { background: var(--blue-100); }
.card-sender { font-size: 14px; font-weight: 600; color: #333; }
.card-time { font-size: 11px; color: #aaa; }

.card-text { font-size: 15px; color: #333; line-height: 1.6; margin-bottom: 10px; }
.card-images { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
.card-img {
  width: calc(50% - 3px); max-width: 200px;
  aspect-ratio: 1; border-radius: 10px;
}
.card-images:has(:only-child) .card-img { width: 100%; max-width: 300px; aspect-ratio: auto; max-height: 300px; }
.card-video { max-width: 100%; border-radius: 12px; margin-bottom: 8px; max-height: 300px; }
.card-audio { width: 100%; margin-bottom: 8px; }

.ai-note {
  background: linear-gradient(135deg, #fff0f5, #f3e8ff);
  padding: 8px 12px; border-radius: 10px;
  font-size: 13px; color: var(--pink-600);
  font-style: italic;
}
</style>
