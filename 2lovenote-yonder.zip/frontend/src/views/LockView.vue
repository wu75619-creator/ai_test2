<template>
  <div class="lock-wrap">
    <div class="lock-card">
      <div class="lock-icon">🔒</div>
      <h2>输入访问密码</h2>
      <p class="lock-sub">这是你们的专属日记本</p>
      <el-input
        v-model="password"
        type="password"
        placeholder="请输入密码"
        size="large"
        show-password
        @keyup.enter="unlock"
        style="margin: 20px 0 16px;"
      />
      <button class="lock-btn" @click="unlock" :disabled="loading">
        {{ loading ? '验证中...' : '💕 进入日记' }}
      </button>
      <p v-if="error" class="err-msg">密码错误，请重试</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { verifyPassword } from '../api/couple'
import { useCoupleStore } from '../stores/couple'

const router = useRouter()
const store = useCoupleStore()
const password = ref('')
const loading = ref(false)
const error = ref(false)

async function unlock() {
  if (!password.value) return
  loading.value = true
  error.value = false
  try {
    await verifyPassword(password.value)
    store.setVerified()
    router.replace('/')
  } catch (e) {
    error.value = true
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.lock-wrap {
  min-height: 100vh;
  background: linear-gradient(160deg, #fff5f8, #f3e8ff);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}
.lock-card {
  background: rgba(255,255,255,0.95);
  border-radius: 24px;
  padding: 40px 28px;
  width: 100%;
  max-width: 360px;
  text-align: center;
  box-shadow: 0 12px 48px rgba(255,107,157,0.15);
}
.lock-icon { font-size: 56px; margin-bottom: 12px; }
h2 { color: var(--pink-600); margin: 0 0 4px; font-size: 22px; }
.lock-sub { color: #999; font-size: 14px; margin: 0; }
.lock-btn {
  width: 100%;
  padding: 13px;
  border: none;
  border-radius: 14px;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  color: white;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.15s;
}
.lock-btn:active { transform: scale(0.97); }
.lock-btn:disabled { opacity: 0.6; }
.err-msg { color: #f56c6c; font-size: 13px; margin: 10px 0 0; }
</style>
