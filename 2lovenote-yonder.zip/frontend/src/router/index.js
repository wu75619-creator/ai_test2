import { createRouter, createWebHistory } from 'vue-router'
import { useCoupleStore } from '../stores/couple'

const routes = [
  { path: '/', name: 'Chat', component: () => import('../views/ChatView.vue') },
  { path: '/categories', name: 'Categories', component: () => import('../views/CategoriesView.vue') },
  { path: '/category/:id', name: 'Category', component: () => import('../views/CategoryView.vue'), props: true },
  { path: '/timeline', name: 'Timeline', component: () => import('../views/TimelineView.vue') },
  { path: '/onboarding', name: 'Onboarding', component: () => import('../views/OnboardingView.vue') },
  { path: '/lock', name: 'Lock', component: () => import('../views/LockView.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach(async (to, from, next) => {
  const store = useCoupleStore()
  if (!store.loaded) await store.load()
  // Lock screen
  if (to.name !== 'Lock' && to.name !== 'Onboarding' && store.accessPasswordSet && !store.verified) {
    return next({ name: 'Lock' })
  }
  // Onboarding
  if (to.name !== 'Onboarding' && to.name !== 'Lock' && !store.onboardingDone) {
    return next({ name: 'Onboarding' })
  }
  if (to.name === 'Onboarding' && store.onboardingDone) {
    return next({ name: 'Chat' })
  }
  if (to.name === 'Lock' && (!store.accessPasswordSet || store.verified)) {
    return next({ name: 'Chat' })
  }
  next()
})

export default router
