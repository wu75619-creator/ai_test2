import request from '../utils/request'

export function getCategories() {
  return request.get('/api/categories')
}

export function getCategoryMessages(catId, year, month) {
  const params = {}
  if (year) params.year = year
  if (month) params.month = month
  return request.get(`/api/categories/${catId}/messages`, { params })
}

export function getCategoryByName(name, year, month) {
  const params = {}
  if (year) params.year = year
  if (month) params.month = month
  return request.get(`/api/categories/name/${encodeURIComponent(name)}`, { params })
}

export function getCategoryStats() {
  return request.get('/api/categories/stats/overview')
}

export function createCategory(data) {
  return request.post('/api/categories', data)
}

export function updateCategory(catId, data) {
  return request.put(`/api/categories/${catId}`, data)
}

export function deleteCategory(catId) {
  return request.delete(`/api/categories/${catId}`)
}
