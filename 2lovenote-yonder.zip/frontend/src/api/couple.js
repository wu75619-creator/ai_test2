import request from '../utils/request'

export function getCoupleInfo() {
  return request.get('/api/couple/info')
}

export function setupCouple(data) {
  return request.post('/api/couple/setup', data)
}

export function verifyPassword(password) {
  return request.post('/api/couple/verify', { password })
}

export function resetOnboarding() {
  return request.post('/api/couple/reset-onboarding')
}
