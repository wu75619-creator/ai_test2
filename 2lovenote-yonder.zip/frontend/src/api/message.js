import request from '../utils/request'

export function getMessages(order = 'asc') {
  return request.get('/api/messages', { params: { order, limit: 1000 } })
}

export function sendMessage(data) {
  const fd = new FormData()
  fd.append('sender_role', data.sender_role || 'male')
  fd.append('is_ai_auto', data.is_ai_auto ? 'true' : 'false')
  if (data.text_content) fd.append('text_content', data.text_content)
  if (data.manual_category) fd.append('manual_category', data.manual_category)
  if (data.voice_duration != null) fd.append('voice_duration', data.voice_duration)
  if (data.video_duration != null) fd.append('video_duration', data.video_duration)
  if (data.images?.length) {
    data.images.forEach(f => fd.append('images', f))
  }
  if (data.voice) fd.append('voice', data.voice)
  if (data.video) fd.append('video', data.video)
  return request.post('/api/messages', fd, {
    timeout: 120000,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}
