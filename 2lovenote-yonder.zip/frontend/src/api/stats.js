import request from '../utils/request'

export function getStats() {
  return request.get('/api/stats/overview')
}

export function getCoupleInfo() {
  return request.get('/api/stats/couple-info')
}
