<template>
  <div class="app-container">
    <router-view v-slot="{ Component }">
      <transition name="fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>

    <!-- Bottom Nav -->
    <nav v-if="showNav" class="bottom-nav">
      <router-link to="/" class="nav-item" :class="{ active: $route.path === '/' }">
        <el-icon :size="22"><ChatDotRound /></el-icon>
        <span>聊天记录</span>
      </router-link>
      <router-link to="/categories" class="nav-item center-btn" :class="{ active: $route.path.includes('categor') }">
        <div class="center-circle">
          <el-icon :size="26"><FolderOpened /></el-icon>
        </div>
        <span>分类相册</span>
      </router-link>
      <router-link to="/timeline" class="nav-item" :class="{ active: $route.path === '/timeline' }">
        <el-icon :size="22"><Clock /></el-icon>
        <span>时间轴</span>
      </router-link>
    </nav>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const showNav = computed(() => !['Onboarding', 'Lock'].includes(route.name))
</script>

<style scoped>
.app-container {
  max-width: 768px;
  margin: 0 auto;
  min-height: 100vh;
  position: relative;
  padding-bottom: 80px;
}
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  max-width: 768px;
  height: 72px;
  background: rgba(255,255,255,0.96);
  backdrop-filter: blur(12px);
  border-top: 1px solid var(--pink-100);
  display: flex;
  align-items: center;
  justify-content: space-around;
  padding: 0 8px;
  padding-bottom: env(safe-area-inset-bottom, 0);
  z-index: 100;
  box-shadow: 0 -4px 20px rgba(255,107,157,0.08);
}
.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  color: #aaa;
  text-decoration: none;
  font-size: 11px;
  flex: 1;
  transition: color 0.2s;
  padding-top: 4px;
}
.nav-item.active { color: var(--pink-500); }
.center-btn { position: relative; }
.center-circle {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff6b9d, #c878ff);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-top: -20px;
  box-shadow: 0 4px 16px rgba(255,107,157,0.4);
  transition: transform 0.2s;
}
.center-btn:active .center-circle { transform: scale(0.92); }
.center-btn span { margin-top: 2px; }
.nav-item:not(.center-btn) .el-icon { transition: transform 0.2s; }
.nav-item.active:not(.center-btn) .el-icon { transform: scale(1.15); }
</style>
