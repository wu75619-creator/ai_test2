/**
 * Enhanced Media Recorder utility
 * Supports both audio and video recording with proper duration tracking
 */

function _pickMime(types) {
  for (const t of types) {
    if (MediaRecorder.isTypeSupported(t)) return t
  }
  return ''
}

export class AudioRecorder {
  constructor() {
    this.mediaRecorder = null
    this.stream = null
    this.chunks = []
    this.startTime = 0
    this.duration = 0
    this.maxSeconds = 300
    this.timer = null
    this.tickCallback = null
  }

  static isSupported() {
    return !!(navigator.mediaDevices?.getUserMedia && window.MediaRecorder)
  }

  _getExt(mime) {
    if (mime.includes('webm')) return 'webm'
    if (mime.includes('ogg')) return 'ogg'
    if (mime.includes('mp4')) return 'm4a'
    if (mime.includes('wav')) return 'wav'
    return 'webm'
  }

  async start(onTick) {
    if (!AudioRecorder.isSupported()) throw new Error('浏览器不支持录音功能')
    this.chunks = []
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    })
    const mime = _pickMime([
      'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'
    ])
    this.mediaRecorder = new MediaRecorder(this.stream, mime ? { mimeType: mime } : undefined)
    this.mediaRecorder.ondataavailable = e => { if (e.data?.size) this.chunks.push(e.data) }
    this.mediaRecorder.start(1000)
    this.startTime = Date.now()
    this.tickCallback = onTick
    if (onTick) {
      this.timer = setInterval(() => {
        const elapsed = (Date.now() - this.startTime) / 1000
        onTick(Math.min(elapsed, this.maxSeconds))
        if (elapsed >= this.maxSeconds) this.stop()
      }, 100)
    }
  }

  stop() {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) return resolve(null)
      if (this.timer) { clearInterval(this.timer); this.timer = null }
      this.duration = (Date.now() - this.startTime) / 1000
      this.mediaRecorder.onstop = () => {
        const mime = this.mediaRecorder.mimeType || 'audio/webm'
        const ext = this._getExt(mime)
        const file = new File(this.chunks, `recording_${Date.now()}.${ext}`, { type: mime })
        this.cleanup()
        resolve({ file, duration: Math.round(this.duration * 10) / 10 })
      }
      try { this.mediaRecorder.stop() } catch (e) { reject(e) }
    })
  }

  cancel() {
    if (this.timer) { clearInterval(this.timer); this.timer = null }
    if (this.mediaRecorder?.state !== 'inactive') {
      try { this.mediaRecorder.stop() } catch (e) {}
    }
    this.cleanup()
  }

  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop())
      this.stream = null
    }
    this.mediaRecorder = null
    this.chunks = []
  }
}


export class VideoRecorder {
  constructor() {
    this.mediaRecorder = null
    this.stream = null
    this.chunks = []
    this.startTime = 0
    this.duration = 0
    this.maxSeconds = 120
    this.timer = null
    this.preview = null
  }

  static isSupported() {
    return !!(navigator.mediaDevices?.getUserMedia && window.MediaRecorder)
  }

  _getExt(mime) {
    if (mime.includes('webm')) return 'webm'
    if (mime.includes('mp4')) return 'mp4'
    if (mime.includes('quicktime')) return 'mov'
    return 'webm'
  }

  async start(videoEl, onTick) {
    if (!VideoRecorder.isSupported()) throw new Error('浏览器不支持视频录制')
    this.chunks = []
    this.stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 1280 } },
      audio: { echoCancellation: true, noiseSuppression: true }
    })
    if (videoEl) {
      videoEl.srcObject = this.stream
      videoEl.muted = true
      try { await videoEl.play() } catch (e) {}
      this.preview = videoEl
    }
    const mime = _pickMime([
      'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'
    ])
    this.mediaRecorder = new MediaRecorder(this.stream, mime ? { mimeType: mime } : undefined)
    this.mediaRecorder.ondataavailable = e => { if (e.data?.size) this.chunks.push(e.data) }
    this.mediaRecorder.start(1000)
    this.startTime = Date.now()
    if (onTick) {
      this.timer = setInterval(() => {
        const elapsed = (Date.now() - this.startTime) / 1000
        onTick(Math.min(elapsed, this.maxSeconds))
        if (elapsed >= this.maxSeconds) this.stop()
      }, 100)
    }
  }

  stop() {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) return resolve(null)
      if (this.timer) { clearInterval(this.timer); this.timer = null }
      this.duration = (Date.now() - this.startTime) / 1000
      this.mediaRecorder.onstop = () => {
        const mime = this.mediaRecorder.mimeType || 'video/webm'
        const ext = this._getExt(mime)
        const file = new File(this.chunks, `video_${Date.now()}.${ext}`, { type: mime })
        const duration = Math.round(this.duration * 10) / 10
        this.cleanup()
        resolve({ file, duration })
      }
      try { this.mediaRecorder.stop() } catch (e) { reject(e) }
    })
  }

  cancel() {
    if (this.timer) { clearInterval(this.timer); this.timer = null }
    if (this.mediaRecorder?.state !== 'inactive') {
      try { this.mediaRecorder.stop() } catch (e) {}
    }
    this.cleanup()
  }

  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop())
      this.stream = null
    }
    if (this.preview) {
      this.preview.srcObject = null
      this.preview = null
    }
    this.mediaRecorder = null
    this.chunks = []
  }
}


/**
 * Get media file duration (for uploaded files, not recorded ones)
 */
export function getMediaDuration(file) {
  return new Promise((resolve) => {
    const type = file.type || ''
    if (!type.startsWith('audio/') && !type.startsWith('video/')) return resolve(null)
    const el = document.createElement(type.startsWith('video/') ? 'video' : 'audio')
    el.preload = 'metadata'
    el.muted = true
    const url = URL.createObjectURL(file)
    el.src = url
    el.onloadedmetadata = () => {
      resolve(el.duration || null)
      URL.revokeObjectURL(url)
    }
    el.onerror = () => { resolve(null); URL.revokeObjectURL(url) }
    setTimeout(() => { resolve(null); URL.revokeObjectURL(url) }, 5000)
  })
}
