import axios from 'axios'
import { ElMessage } from 'element-plus'

const service = axios.create({
  baseURL: '',
  timeout: 30000,
})

service.interceptors.response.use(
  response => response.data,
  error => {
    const msg = error?.response?.data?.detail || error.message || '请求失败'
    if (error?.response?.status !== 401) {
      ElMessage.error(typeof msg === 'string' ? msg : '网络错误，请稍后再试')
    }
    return Promise.reject(error)
  }
)

export default service
