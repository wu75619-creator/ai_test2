import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getCoupleInfo as apiGetCoupleInfo } from '../api/couple'

export const useCoupleStore = defineStore('couple', () => {
  const coupleName = ref('我们')
  const maleNickname = ref('他')
  const femaleNickname = ref('她')
  const togetherDate = ref(null)
  const onboardingDone = ref(false)
  const loveDays = ref(0)
  const accessPasswordSet = ref(false)
  const verified = ref(false)
  const loaded = ref(false)

  async function load() {
    try {
      const info = await apiGetCoupleInfo()
      coupleName.value = info.couple_name || '我们'
      maleNickname.value = info.male_nickname || '他'
      femaleNickname.value = info.female_nickname || '她'
      togetherDate.value = info.together_date
      onboardingDone.value = info.onboarding_done
      loveDays.value = info.love_days || 0
      accessPasswordSet.value = info.access_password_set
      if (!info.access_password_set) verified.value = true
      loaded.value = true
      return info
    } catch (e) {
      loaded.value = true
      return null
    }
  }

  function setVerified() { verified.value = true }
  function setOnboardingDone(val) { onboardingDone.value = val }

  return {
    coupleName, maleNickname, femaleNickname, togetherDate,
    onboardingDone, loveDays, accessPasswordSet, verified, loaded,
    load, setVerified, setOnboardingDone,
  }
})
