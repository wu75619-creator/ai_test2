# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for standalone LoveNote server (无桌面外壳)
打包命令：pyinstaller server.spec
产出：dist/server/server.exe（运行后在 127.0.0.1:8765 提供 HTTP 服务）
"""
import os

block_cipher = None
SPEC_DIR = os.path.abspath(os.path.dirname(SPECPATH))
BACKEND_DIR = os.path.join(SPEC_DIR, 'backend')

a = Analysis(
    [os.path.join(BACKEND_DIR, 'main.py')],
    pathex=[BACKEND_DIR],
    binaries=[],
    datas=[
        (os.path.join(BACKEND_DIR, 'dist'), 'dist'),
    ],
    hiddenimports=[
        'uvicorn.logging',
        'uvicorn.loops',
        'uvicorn.loops.auto',
        'uvicorn.protocols',
        'uvicorn.protocols.http',
        'uvicorn.protocols.http.auto',
        'uvicorn.protocols.websockets',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.lifespan',
        'uvicorn.lifespan.on',
        'app',
        'app.database',
        'app.models',
        'app.schemas',
        'app.init_data',
        'app.ai_service',
        'app.routers',
        'app.routers.messages',
        'app.routers.categories',
        'app.routers.stats',
        'app.routers.couple',
        'multipart',
        'PIL.Image',
        'aiofiles',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'numpy', 'pandas', 'scipy', 'pytest'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='server',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='server',
)
