@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ══════════════════════════════════════════
echo   LoveNote 桌面端构建脚本 (Windows)
echo ══════════════════════════════════════════
echo.

:: ── 检查 Python ──────────────────────────
where python >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.10+
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [检测] Python 版本：%PYVER%

:: ── 检查 Node.js ──────────────────────────
where node >nul 2>&1
set HAS_NODE=0
if not errorlevel 1 set HAS_NODE=1

if "%HAS_NODE%"=="0" (
    echo [警告] 未检测到 Node.js，将跳过前端构建，直接使用 backend/dist
    echo        如需重新构建前端，请安装 Node.js 18+：https://nodejs.org/
) else (
    for /f "tokens=*" %%v in ('node --version 2^>^&1') do set NODEVER=%%v
    echo [检测] Node.js 版本：!NODEVER!
)
echo.

:: ── 创建构建虚拟环境 ──────────────────────
echo [1/6] 创建 Python 虚拟环境...
if not exist "build_env" (
    python -m venv build_env
    if errorlevel 1 (
        echo [错误] 创建虚拟环境失败
        pause
        exit /b 1
    )
)
call build_env\Scripts\activate.bat

:: ── 安装 Python 依赖 ─────────────────────
echo [2/6] 安装 Python 依赖（含 PyInstaller 和 pywebview）...
python -m pip install --upgrade pip -q
pip install -r backend\requirements.txt -q
pip install pyinstaller pywebview -q
if errorlevel 1 (
    echo [错误] Python 依赖安装失败
    pause
    exit /b 1
)

:: ── 构建前端 ─────────────────────────────
if "%HAS_NODE%"=="1" (
    echo [3/6] 构建前端（Vue3）...
    cd frontend
    if not exist "node_modules" (
        call npm install
    )
    call npm run build
    cd ..
    if errorlevel 1 (
        echo [错误] 前端构建失败
        pause
        exit /b 1
    )
    :: 将 dist 复制到 backend\dist（PyInstaller 从这里打包）
    if exist "backend\dist" rmdir /s /q "backend\dist"
    xcopy /e /i /q frontend\dist backend\dist >nul
    echo        前端构建完成。
) else (
    echo [3/6] 跳过前端构建（使用 backend/dist 内已有产物）
    if not exist "backend\dist\index.html" (
        echo [错误] backend/dist/index.html 不存在，请先用 Node.js 构建前端
        pause
        exit /b 1
    )
)

:: ── PyInstaller 打包 ─────────────────────
echo [4/6] PyInstaller 打包桌面应用（首次打包需要 1-3 分钟，请耐心等待）...
python -m PyInstaller LoveNote.spec --clean --noconfirm
if errorlevel 1 (
    echo [错误] PyInstaller 打包失败
    pause
    exit /b 1
)

:: ── 清理 ─────────────────────────────────
echo [5/6] 清理临时文件...
if exist "build" rmdir /s /q "build"
if exist "LoveNote.spec.bak" del /q "LoveNote.spec.bak"

:: ── 输出结果 ─────────────────────────────
echo [6/6] 构建完成！
echo.
echo ══════════════════════════════════════════
echo   产物位置：dist\LoveNote\LoveNote.exe
echo   数据目录：%%APPDATA%%\LoveNote\
echo ══════════════════════════════════════════
echo.
echo 双击 dist\LoveNote\LoveNote.exe 即可运行。
echo.
deactivate
pause
