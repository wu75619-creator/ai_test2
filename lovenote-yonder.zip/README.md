# 💕 LoveNote - 情侣智能恋爱日记本

双人专属、对话式随手记录、支持 AI 智能分类的情侣恋爱纪念网页应用。

## 功能特性

### 核心功能
- **对话式记录**: 仿微信聊天界面，双方随时发送文字/图片/语音/视频
- **AI 智能分类**: 自动识别内容归类到8大预设分类，生成温柔总结文案
- **手动分类**: 发送时可手动选择分类，AI 与手动双轨制
- **自定义分类**: 用户可创建、编辑、删除自定义分类标签
- **多媒体支持**:
  - 多图一次性上传，点击大图预览
  - 浏览器实时录音（支持最长5分钟），自定义播放UI
  - 摄像头实时录像（支持最长2分钟），自动保存
  - 本地音视频文件上传
  - 语音/视频时长精确记录与展示
- **结构化回顾**: 每个分类专属页面，支持按年/月筛选，卡片式展示
- **全局时间轴**: 按日期倒序排列，支持图片/视频/语音完整展示

### 统计面板
- **相爱天数**: 实时计算两人在一起的精确天数
- **24小时活跃度分布**: 柱状图展示一天中发消息的时间分布
- **分类统计**: 各分类消息数量横向柱状图
- **周报**: 近8周消息量、男女双方活跃度、最活跃时段
- **月报**: 近6个月消息趋势、日活跃度迷你图、分类统计

### 安全与隐私
- 首次进入强制设置双方昵称和在一起日期
- 可选访问密码保护，防止他人误看
- 所有数据本地加密存储（SQLite）

## 技术栈

### 前端
- Vue 3 + Vite 5
- Vue Router 4 + Pinia 2
- Element Plus UI
- Axios + Day.js
- MediaRecorder API（音视频录制）

### 后端
- FastAPI + Uvicorn
- SQLAlchemy + SQLite
- Pydantic v2
- Pillow（图片处理）
- aiofiles（异步文件保存）
- 支持 OpenAI 兼容 API（可接 GPT-4o/通义千问/豆包/DeepSeek 等）

## 快速开始

### 方式一：本地开发

```bash
# 1. 安装后端依赖
cd backend
pip install -r requirements.txt

# 2. 安装前端依赖并构建
cd ../frontend
npm install
npm run build

# 3. 启动后端（会自动服务前端静态文件）
cd ../backend
python main.py
# 访问 http://localhost:8000
```

开发模式（前端热更新）：
```bash
# Terminal 1: 启动后端
cd backend && python main.py

# Terminal 2: 启动前端 dev server
cd frontend && npm run dev
# 访问 http://localhost:5173
```

### 方式二：Docker 部署

```bash
docker build -t lovenote .
docker run -p 8000:8000 -v ./data:/app/backend lovenote
```

### 方式三：部署到 Render/Railway（永久在线）

点击按钮部署到 Render，或使用项目中的 `render.yaml` 配置。

1. Fork 本仓库到你的 GitHub
2. 在 Render 中创建 Web Service，连接仓库
3. 构建命令: `cd frontend && npm install && npm run build && cd ../backend && pip install -r requirements.txt`
4. 启动命令: `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
5. 部署完成，获得永久 HTTPS 链接

### 方式四：Vercel + 外部后端
- 前端可部署到 Vercel/Netlify
- 后端部署到 Render/Railway/Fly.io
- 修改 `frontend/src/utils/request.js` 的 baseURL 指向后端地址

## 环境变量

在 `backend/` 目录创建 `.env` 文件（可选）：

```env
AI_ENABLED=true                    # 启用真实 AI（否则使用 mock 模式）
OPENAI_API_KEY=sk-xxx              # OpenAI API Key
OPENAI_BASE_URL=https://api.openai.com/v1  # 或其他兼容 API（如 DeepSeek）
OPENAI_MODEL=gpt-4o-mini           # 模型名称
MAX_UPLOAD_SIZE=104857600          # 最大上传大小（默认 100MB）
```

不配置 AI 相关变量时，系统使用本地关键词匹配的 mock 模式，功能完整，准确度高。

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/couple/setup | 首次设置情侣信息 |
| GET | /api/couple/info | 获取情侣信息 |
| POST | /api/couple/verify | 验证访问密码 |
| POST | /api/messages | 发送消息（支持文字/图片/语音/视频） |
| GET | /api/messages | 获取消息列表 |
| GET | /api/categories | 获取所有分类（含自定义） |
| POST | /api/categories | 创建自定义分类 |
| PUT | /api/categories/{id} | 编辑自定义分类 |
| DELETE | /api/categories/{id} | 删除自定义分类 |
| GET | /api/categories/{id}/messages | 获取分类下的消息 |
| GET | /api/stats/overview | 获取统计数据（周/月/小时分布） |
| GET | /api/health | 健康检查 |

## 项目结构

```
lovenote-final/
├── backend/
│   ├── main.py              # FastAPI 入口
│   ├── requirements.txt
│   ├── app/
│   │   ├── database.py      # 数据库配置
│   │   ├── models.py        # SQLAlchemy ORM 模型
│   │   ├── schemas.py       # Pydantic 数据模型
│   │   ├── init_data.py     # 初始数据（8大系统分类）
│   │   ├── ai_service.py    # AI 分类服务（mock + LLM）
│   │   └── routers/
│   │       ├── messages.py  # 消息发送/列表/多媒体上传
│   │       ├── categories.py # 分类 CRUD
│   │       ├── stats.py     # 周/月统计面板
│   │       └── couple.py    # 情侣设置/密码验证
│   ├── uploads/             # 多媒体文件存储
│   └── dist/                # 构建后的前端文件
└── frontend/
    ├── src/
    │   ├── views/           # 页面组件
    │   │   ├── ChatView.vue        # 聊天/发送/录音/录像
    │   │   ├── CategoriesView.vue  # 分类列表+自定义管理
    │   │   ├── CategoryView.vue    # 分类详情
    │   │   ├── TimelineView.vue    # 时间轴+统计面板
    │   │   ├── OnboardingView.vue  # 首次引导
    │   │   └── LockView.vue        # 密码锁屏
    │   ├── utils/
    │   │   ├── recorder.js  # AudioRecorder + VideoRecorder
    │   │   └── request.js   # Axios 封装
    │   ├── api/             # API 调用
    │   ├── stores/          # Pinia 状态管理
    │   └── router/          # 路由配置
    └── dist/                # 构建产物
```
