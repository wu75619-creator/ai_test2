import os
import uuid
import aiofiles
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, UploadFile, File, Form, BackgroundTasks, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from PIL import Image
import io

from ..database import get_db
from ..models import (
    Message, MessageAttachment, ContentType, UserRole,
    Category, AIProcessLog, Couple, User
)
from ..schemas import MessageResponse, AttachmentInfo
from ..init_data import get_or_create_default_couple, get_or_create_users
from ..ai_service import ai_service

router = APIRouter(prefix="/api/messages", tags=["messages"])

UPLOAD_BASE = os.path.join(os.path.dirname(__file__), "..", "..", "uploads")
IMG_DIR = os.path.join(UPLOAD_BASE, "images")
VOICE_DIR = os.path.join(UPLOAD_BASE, "voices")
VIDEO_DIR = os.path.join(UPLOAD_BASE, "videos")

for d in [IMG_DIR, VOICE_DIR, VIDEO_DIR]:
    os.makedirs(d, exist_ok=True)


def _guess_ext(content_type: str, original: str = "") -> str:
    if not content_type and original:
        return os.path.splitext(original)[1].lstrip(".") or "bin"
    map_ct = {
        "image/jpeg": "jpg", "image/jpg": "jpg", "image/png": "png",
        "image/gif": "gif", "image/webp": "webp", "image/heic": "heic",
        "audio/webm": "webm", "audio/ogg": "ogg", "audio/mp4": "m4a",
        "audio/mpeg": "mp3", "audio/wav": "wav", "audio/mp3": "mp3",
        "video/webm": "webm", "video/mp4": "mp4", "video/quicktime": "mov",
        "video/x-matroska": "mkv", "video/ogg": "ogv",
    }
    return map_ct.get(content_type, "bin")


async def _save_upload(file: UploadFile, dest_dir: str) -> tuple:
    """Save uploaded file, returns (url_rel_path, size_bytes, width_or_None, height_or_None, ext, mime)"""
    original = file.filename or ""
    mime = file.content_type or ""
    ext = _guess_ext(mime, original)
    fname = f"{uuid.uuid4().hex}.{ext}"
    fpath = os.path.join(dest_dir, fname)
    size = 0
    width = height = None
    is_img = dest_dir == IMG_DIR
    img_data = b""
    MAX = int(os.environ.get("MAX_UPLOAD_SIZE", str(100 * 1024 * 1024)))
    async with aiofiles.open(fpath, "wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX:
                await f.close()
                os.remove(fpath)
                raise HTTPException(413, f"文件超过 {MAX//1024//1024}MB 限制")
            if is_img and len(img_data) < 20 * 1024 * 1024:
                img_data += chunk
            await f.write(chunk)
    if is_img and img_data:
        try:
            im = Image.open(io.BytesIO(img_data))
            width, height = im.size
        except Exception:
            pass
    url_map = {IMG_DIR: "/uploads/images", VOICE_DIR: "/uploads/voices", VIDEO_DIR: "/uploads/videos"}
    return f"{url_map[dest_dir]}/{fname}", size, width, height, ext, mime


def _build_response(msg: Message, db: Session) -> dict:
    sender_nick = ""
    if msg.sender_id:
        u = db.query(User).filter(User.id == msg.sender_id).first()
        if u:
            sender_nick = u.nickname
    if not sender_nick:
        sender_nick = "他" if msg.sender_role == UserRole.MALE else "她"
    cat_name, cat_icon, cat_color = "", "", "#ff6b9d"
    if msg.main_category_id:
        c = db.query(Category).filter(Category.id == msg.main_category_id).first()
        if c:
            cat_name, cat_icon, cat_color = c.name, c.icon, c.color
    attachments = []
    for att in msg.attachments:
        attachments.append({
            "id": att.id,
            "file_type": att.file_type,
            "file_url": att.file_url,
            "thumbnail_url": att.thumbnail_url,
            "file_size": att.file_size,
            "width": att.width,
            "height": att.height,
            "duration": att.duration,
            "mime_type": att.mime_type,
        })
    return {
        "id": msg.id,
        "sender_role": msg.sender_role.value if hasattr(msg.sender_role, 'value') else str(msg.sender_role),
        "sender_nickname": sender_nick,
        "content_type": msg.content_type.value if hasattr(msg.content_type, 'value') else str(msg.content_type),
        "text_content": msg.text_content or "",
        "ai_summary": msg.ai_summary or "",
        "main_category_id": msg.main_category_id,
        "main_category_name": cat_name,
        "main_category_icon": cat_icon,
        "main_category_color": cat_color,
        "ai_processed": msg.ai_processed,
        "is_manual_category": msg.is_manual_category,
        "attachments": attachments,
        "voice_duration": msg.voice_duration,
        "video_duration": msg.video_duration,
        "created_at": msg.created_at,
    }


def _process_ai_classification(msg_id: int, text: str, content_type: str, img_paths: List[str]):
    from ..database import SessionLocal
    db = SessionLocal()
    try:
        abs_paths = []
        for p in img_paths:
            clean = p.replace("/uploads/", "")
            full = os.path.join(UPLOAD_BASE, clean)
            if os.path.exists(full):
                abs_paths.append(full)
        result = ai_service.process_message(text, content_type, abs_paths, db)
        msg = db.query(Message).filter(Message.id == msg_id).first()
        if msg:
            msg.main_category_id = result["category_id"]
            msg.ai_summary = result.get("summary", "")
            msg.ai_confidence = result.get("confidence", 0.0)
            msg.extracted_nicknames = result.get("nicknames", [])
            msg.ai_processed = True
            msg.ai_processed_at = datetime.utcnow()
            log = AIProcessLog(
                message_id=msg_id,
                model_used=ai_service.model,
                raw_response=result,
                processing_time_ms=result.get("processing_time_ms", 0),
                status="success",
            )
            db.add(log)
            db.commit()
    except Exception as e:
        db.rollback()
        try:
            log = AIProcessLog(message_id=msg_id, status="error", error_message=str(e)[:500])
            db.add(log)
            msg = db.query(Message).filter(Message.id == msg_id).first()
            if msg:
                msg.ai_processed = True
                msg.ai_summary = "[AI处理失败]"
            db.commit()
        except Exception:
            pass
    finally:
        db.close()


@router.post("", response_model=MessageResponse)
async def send_message(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    sender_role: str = Form("male"),
    text_content: str = Form(""),
    is_ai_auto: bool = Form(True),
    manual_category: Optional[int] = Form(None),
    voice_duration: Optional[float] = Form(None),
    video_duration: Optional[float] = Form(None),
    images: List[UploadFile] = File(default=[]),
    voice: Optional[UploadFile] = File(None),
    video: Optional[UploadFile] = File(None),
):
    couple = get_or_create_default_couple(db)
    get_or_create_users(db, couple)
    role = UserRole.FEMALE if sender_role == "female" else UserRole.MALE
    user = db.query(User).filter(User.couple_id == couple.id, User.role == role).first()
    if not user:
        get_or_create_users(db, couple)
        user = db.query(User).filter(User.couple_id == couple.id, User.role == role).first()

    # Determine content type
    has_img = bool(images and any(i.filename for i in images))
    has_voice = bool(voice and voice.filename)
    has_video = bool(video and video.filename)
    has_text = bool(text_content.strip())

    if not has_img and not has_voice and not has_video and not has_text:
        raise HTTPException(400, "消息内容不能为空")

    if has_voice:
        ctype = ContentType.VOICE
    elif has_video:
        ctype = ContentType.VIDEO
    elif has_img:
        ctype = ContentType.IMAGE
    else:
        ctype = ContentType.TEXT

    # Create message
    msg = Message(
        couple_id=couple.id,
        sender_id=user.id if user else None,
        sender_role=role,
        content_type=ctype,
        text_content=text_content.strip(),
        voice_duration=voice_duration if has_voice else None,
        video_duration=video_duration if has_video else None,
    )

    if not is_ai_auto and manual_category:
        msg.main_category_id = int(manual_category)
        msg.is_manual_category = True
        msg.ai_processed = True
        msg.ai_summary = ""

    db.add(msg)
    db.flush()

    img_paths_for_ai = []
    # Save images
    if has_img:
        for img in images:
            if img.filename:
                url, size, w, h, ext, mime = await _save_upload(img, IMG_DIR)
                att = MessageAttachment(
                    message_id=msg.id, file_type="image", file_url=url,
                    file_size=size, width=w, height=h, mime_type=mime,
                )
                db.add(att)
                img_paths_for_ai.append(url)
    # Save voice
    if has_voice:
        url, size, w, h, ext, mime = await _save_upload(voice, VOICE_DIR)
        att = MessageAttachment(
            message_id=msg.id, file_type="voice", file_url=url,
            file_size=size, duration=voice_duration, mime_type=mime or "audio/webm",
        )
        db.add(att)
        msg.voice_duration = voice_duration
    # Save video
    if has_video:
        url, size, w, h, ext, mime = await _save_upload(video, VIDEO_DIR)
        att = MessageAttachment(
            message_id=msg.id, file_type="video", file_url=url,
            file_size=size, duration=video_duration, mime_type=mime or "video/mp4",
        )
        db.add(att)
        msg.video_duration = video_duration

    db.commit()
    db.refresh(msg)

    if is_ai_auto and not msg.is_manual_category:
        background_tasks.add_task(
            _process_ai_classification, msg.id, text_content, ctype.value, img_paths_for_ai
        )

    return _build_response(msg, db)


@router.get("", response_model=List[MessageResponse])
def list_messages(
    limit: int = 500,
    offset: int = 0,
    order: str = "asc",
    db: Session = Depends(get_db),
):
    q = db.query(Message).filter(Message.is_deleted == False)
    if order == "desc":
        q = q.order_by(Message.created_at.desc())
    else:
        q = q.order_by(Message.created_at.asc())
    msgs = q.offset(offset).limit(limit).all()
    return [_build_response(m, db) for m in msgs]


@router.get("/recent", response_model=List[MessageResponse])
def recent_messages(limit: int = 20, db: Session = Depends(get_db)):
    msgs = db.query(Message).filter(Message.is_deleted == False)\
        .order_by(Message.created_at.desc()).limit(limit).all()
    return [_build_response(m, db) for m in reversed(msgs)]
