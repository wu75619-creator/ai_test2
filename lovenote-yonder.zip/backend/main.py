import os
import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# Add parent to path
sys.path.insert(0, os.path.dirname(__file__))

from app.database import engine, Base, SessionLocal
from app.init_data import init_system_categories
from app.routers import messages, categories, stats, couple


UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
# Check multiple possible dist locations
_here = os.path.dirname(os.path.abspath(__file__))
DIST_DIR = None
for _p in [
    os.path.join(_here, "..", "frontend", "dist"),
    os.path.join(_here, "dist"),
    os.path.join(os.path.dirname(_here), "frontend", "dist"),
]:
    if os.path.isdir(_p):
        DIST_DIR = os.path.abspath(_p)
        break

os.makedirs(os.path.join(UPLOAD_DIR, "images"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "voices"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "videos"), exist_ok=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        init_system_categories(db)
    finally:
        db.close()
    yield


app = FastAPI(title="LoveNote - 情侣恋爱日记本", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(messages.router)
app.include_router(categories.router)
app.include_router(stats.router)
app.include_router(couple.router)

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


@app.get("/api/health")
def health():
    return {"status": "ok", "app": "LoveNote", "version": "2.0"}


# Serve frontend static files if dist exists (production mode)
if DIST_DIR and os.path.isdir(DIST_DIR):
    @app.get("/")
    def index():
        return FileResponse(os.path.join(DIST_DIR, "index.html"))

    assets_dir = os.path.join(DIST_DIR, "assets")
    if os.path.isdir(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str):
        if full_path.startswith("api/") or full_path.startswith("uploads/"):
            return {"detail": "Not found"}
        index_path = os.path.join(DIST_DIR, "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        return {"detail": "Not found"}
else:
    @app.get("/")
    def dev_index():
        return {
            "app": "LoveNote",
            "mode": "development",
            "message": "Frontend dist not found. Run 'cd frontend && npm run build' first, or run 'npm run dev' for development mode.",
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.environ.get("PORT", "8000")), reload=False)
