# 情侣智能随手恋爱日记本

一款双人专属、对话式随手记录、AI 自动分类归档的恋爱纪念网页应用。

## 核心数据库表结构设计
### 1. users 用户表
存储情侣双方账号信息
| 字段 | 类型 | 说明 |
|------|------|------|
| user_id | TEXT | 主键，用户唯一ID |
| username | TEXT | 登录账号，唯一 |
| password_hash | TEXT | 加密存储的密码 |
| role | TEXT | 角色：`male`/`female`（男主/女主） |
| nickname | TEXT | 用户昵称 |
| avatar_url | TEXT | 头像地址 |
| access_password | TEXT | 全局访问密码（防止他人误进） |
| last_login_at | TIMESTAMP | 最后登录时间 |
| created_at/updated_at | TIMESTAMP | 记录创建/更新时间 |

### 2. categories 分类归档表
预设8大核心分类，支持后续扩展
| 字段 | 类型 | 说明 |
|------|------|------|
| category_id | TEXT | 主键，分类唯一ID |
| category_key | TEXT | 分类唯一标识，如`food`/`travel` |
| category_name | TEXT | 分类显示名称 |
| description | TEXT | 分类描述 |
| sort_order | INTEGER | 排序权重，控制前端展示顺序 |
| is_system | BOOLEAN | 是否为系统预设分类 |
| created_at | TIMESTAMP | 记录创建时间 |

**预设8大分类**：
美食探店、旅行约会、情侣合照、趣味日常、专属昵称、深度谈心、矛盾复盘、语音存档

### 3. messages 消息记录表（核心业务表）
存储所有用户发送的内容，支持全媒介类型
| 字段 | 类型 | 说明 |
|------|------|------|
| message_id | TEXT | 主键，消息唯一ID |
| sender_id | TEXT | 发送人ID，关联users表 |
| content_type | TEXT | 内容类型：`text`/`image`/`audio` |
| content | TEXT | 文字内容（图片/语音类型存AI转写文本） |
| media_urls | TEXT | JSON数组，存储图片/语音文件路径 |
| audio_duration | INTEGER | 语音时长（秒，仅音频类型） |
| send_time | TIMESTAMP | 发送时间，支撑全局时间轴排序 |
| main_category_id | TEXT | 主分类ID，关联categories表（单条内容唯一主分类） |
| sub_tags | TEXT | JSON数组，存储子标签（如["奶茶","网红店"]） |
| ai_summary | TEXT | AI生成的1-2句温柔小结 |
| ai_confidence | FLOAT | AI分类置信度（0-1） |
| status | TEXT | 处理状态：`pending`(待分类)/`processed`(已分类)/`deleted`(已删除) |
| created_at/updated_at | TIMESTAMP | 记录创建/更新时间 |

### 4. message_category_relations 消息分类关联表
支持一条内容关联主分类+附属分类（如合照同时归入旅行分类）
| 字段 | 类型 | 说明 |
|------|------|------|
| relation_id | TEXT | 主键，关联唯一ID |
| message_id | TEXT | 消息ID，关联messages表 |
| category_id | TEXT | 分类ID，关联categories表 |
| relation_type | TEXT | 关联类型：`main`(主分类)/`related`(附属分类) |
| created_at | TIMESTAMP | 记录创建时间 |

---

## 项目启动指南

### 环境要求
- Node.js >= 18.0.0
- Python >= 3.10
- SQLite 3 (无需额外部署，系统自带)

### 后端启动（FastAPI）
```bash
cd backend
# 安装依赖
pip install -r requirements.txt
# 初始化数据库（可选，会自动创建并导入预设分类）
python init_db.py
# 启动服务，默认运行在 http://localhost:8000
uvicorn main:app --reload
```

### 前端启动（Vue3 + Vite）
```bash
cd frontend
# 安装依赖
npm install
# 启动开发服务，默认运行在 http://localhost:5173
npm run dev
```

### 生产部署
- 前端：打包后部署到Vercel/阿里云OSS等静态资源平台
- 后端：部署到阿里云ECS/腾讯云轻量服务器
- 文件存储：使用阿里云OSS/MinIO存储图片、语音文件
