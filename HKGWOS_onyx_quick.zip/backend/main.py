from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import json
import os
from passlib.context import CryptContext
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 导入数据模型和AI服务
from models import Base, User, Message, Category, MessageCategoryRelation
from services.ai_service import classify_content, get_all_categories

# 数据库配置
SQLALCHEMY_DATABASE_URL = "sqlite:///./diary.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 密码加密工具
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 上传文件配置
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}
ALLOWED_AUDIO_TYPES = {"audio/mpeg", "audio/wav", "audio/ogg", "audio/webm", "audio/x-m4a", "audio/mp4"}

# 初始化FastAPI应用
app = FastAPI(title="情侣恋爱日记本API", version="1.2.0")

# 挂载静态文件目录，支持通过URL访问上传的文件
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# 配置CORS：允许所有源跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 数据库依赖注入
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 应用启动时自动建表 + 初始化默认数据
@app.on_event("startup")
async def startup_event():
    # 自动创建所有数据库表
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    # 初始化默认测试用户（男主、女主）
    default_users = [
        {
            "user_id": "user_male",
            "username": "male_user",
            "role": "male",
            "nickname": "男主",
            "password": "***"
        },
        {
            "user_id": "user_female",
            "username": "female_user",
            "role": "female",
            "nickname": "女主",
            "password": "***"
        }
    ]
    
    for user_data in default_users:
        existing_user = db.query(User).filter(User.user_id == user_data["user_id"]).first()
        if not existing_user:
            user = User(
                user_id=user_data["user_id"],
                username=user_data["username"],
                password_hash=pwd_context.hash(user_data["password"]),
                role=user_data["role"],
                nickname=user_data["nickname"]
            )
            db.add(user)
    
    # 初始化默认分类
    default_categories = [
        {"category_id": "cat_food", "category_key": "food", "category_name": "美食探店", "description": "记录一起打卡的美食、奶茶、探店经历", "sort_order": 1},
        {"category_id": "cat_travel", "category_key": "travel", "category_name": "旅行约会", "description": "记录旅行、逛街、约会的所有回忆", "sort_order": 2},
        {"category_id": "cat_photo", "category_key": "photo", "category_name": "情侣合照", "description": "所有双人同框的合照、自拍专属相册", "sort_order": 3},
        {"category_id": "cat_daily", "category_key": "daily", "category_name": "趣味日常", "description": "搞笑对话、互怼日常、可爱碎片记录", "sort_order": 4},
        {"category_id": "cat_nickname", "category_key": "nickname", "category_name": "专属昵称", "description": "专属称呼、私密梗、情侣暗号汇总", "sort_order": 5},
        {"category_id": "cat_emotion", "category_key": "emotion", "category_name": "深度谈心", "description": "走心交流、情绪倾诉、未来规划记录", "sort_order": 6},
        {"category_id": "cat_conflict", "category_key": "conflict", "category_name": "矛盾复盘", "description": "矛盾记录、反思、和解、成长约定", "sort_order": 7},
        {"category_id": "cat_voice", "category_key": "voice", "category_name": "语音存档", "description": "所有语音消息单独归档，可随时回放", "sort_order": 8}
    ]
    
    for cat_data in default_categories:
        existing_cat = db.query(Category).filter(Category.category_id == cat_data["category_id"]).first()
        if not existing_cat:
            cat = Category(**cat_data, is_system=True)
            db.add(cat)
    
    db.commit()
    db.close()

# ------------------------------
# 辅助函数
# ------------------------------
def save_upload_file(upload_file: UploadFile, content_type: str) -> str:
    """保存上传的文件到uploads目录，返回访问URL"""
    # 校验文件类型
    if content_type.startswith("image/") and upload_file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail=f"不支持的图片类型：{upload_file.content_type}，仅支持JPG/PNG/GIF/WEBP")
    if content_type.startswith("audio/") and upload_file.content_type not in ALLOWED_AUDIO_TYPES:
        raise HTTPException(status_code=400, detail=f"不支持的音频类型：{upload_file.content_type}，仅支持MP3/WAV/OGG/M4A")
    
    # 生成唯一文件名
    file_ext = os.path.splitext(upload_file.filename)[1] or (".jpg" if content_type == "image" else ".mp3")
    file_name = f"{uuid.uuid4()}{file_ext}"
    file_path = os.path.join(UPLOAD_DIR, file_name)
    
    # 保存文件
    with open(file_path, "wb") as buffer:
        buffer.write(upload_file.file.read())
    
    # 返回可访问的URL（本地开发用，生产环境替换为CDN地址）
    return f"http://localhost:8000/uploads/{file_name}"

# ------------------------------
# Pydantic 数据模型定义
# ------------------------------
class MessageResponse(BaseModel):
    """消息响应模型"""
    message_id: str
    sender_id: str
    sender_role: str  # 返回中文 男主/女主
    sender_nickname: str
    content_type: str
    content: Optional[str]
    media_urls: List[str]
    audio_duration: Optional[int]
    send_time: datetime
    main_category_id: Optional[str]
    main_category_name: Optional[str]
    sub_tags: List[str]
    ai_summary: Optional[str]
    ai_confidence: float
    status: str
    
    class Config:
        orm_mode = True

class CategoryResponse(BaseModel):
    """分类响应模型"""
    category_id: str
    category_key: str
    category_name: str
    description: Optional[str]
    message_count: Optional[int] = 0

# ------------------------------
# 核心API接口
# ------------------------------
@app.post("/api/messages", response_model=MessageResponse, status_code=status.HTTP_201_CREATED)
async def create_message(
    sender_role: str = Form(...),
    content: Optional[str] = Form(None),
    content_type: str = Form("text"),
    is_ai_auto: bool = Form(True),
    manual_category: Optional[str] = Form(None),
    audio_duration: Optional[int] = Form(None),
    files: List[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    """
    发送聊天消息接口（支持多媒体文件、自动/手动分类双模式）
    - sender_role: 发送人角色，"男主" / "女主"
    - content: 文本内容
    - content_type: 内容类型，text/image/audio
    - is_ai_auto: 是否启用AI自动分类，默认true
    - manual_category: 手动选择的分类key（如food/travel），is_ai_auto为false时必填
    - audio_duration: 语音时长（秒），仅音频类型
    - files: 上传的图片/语音文件
    """
    # 角色映射：中文入参 -> 数据库存储值
    role_map = {"男主": "male", "女主": "female"}
    if sender_role not in role_map:
        raise HTTPException(status_code=400, detail="sender_role 只能是 '男主' 或 '女主'")
    
    db_role = role_map[sender_role]
    sender = db.query(User).filter(User.role == db_role).first()
    if not sender:
        raise HTTPException(status_code=404, detail="发送用户不存在")
    
    # 内容校验
    if content_type == "text" and not content:
        raise HTTPException(status_code=400, detail="文本内容不能为空")
    if content_type in ["image", "audio"] and not files:
        raise HTTPException(status_code=400, detail=f"{content_type}类型必须上传文件")
    
    # 处理文件上传
    media_urls = []
    if files and len(files) > 0:
        for file in files:
            file_url = save_upload_file(file, content_type)
            media_urls.append(file_url)
    
    # 手动分类模式校验
    if not is_ai_auto and not manual_category:
        raise HTTPException(status_code=400, detail="手动分类模式下必须选择分类")
    
    # 生成唯一消息ID
    message_id = str(uuid.uuid4())
    
    # 处理JSON字段
    media_urls_json = json.dumps(media_urls)
    
    # 分类逻辑处理
    category_id = None
    sub_tags = []
    ai_summary = None
    confidence = 0.0
    
    if is_ai_auto:
        # AI自动分类模式
        category_id, sub_tags, ai_summary, confidence = await classify_content(
            content=content or "",
            content_type=content_type,
            media_urls=media_urls
        )
    else:
        # 手动分类模式
        category = db.query(Category).filter(Category.category_key == manual_category).first()
        if not category:
            raise HTTPException(status_code=400, detail="选择的分类不存在")
        category_id = category.category_id
        ai_summary = "用户手动选择分类"
    
    # 创建消息对象
    db_message = Message(
        message_id=message_id,
        sender_id=sender.user_id,
        content_type=content_type,
        content=content,
        media_urls=media_urls_json,
        audio_duration=audio_duration,
        main_category_id=category_id,
        sub_tags=json.dumps(sub_tags),
        ai_summary=ai_summary,
        ai_confidence=confidence,
        status="processed"
    )
    
    # 创建分类关联关系
    relation = MessageCategoryRelation(
        relation_id=str(uuid.uuid4()),
        message_id=message_id,
        category_id=category_id,
        relation_type="main"
    )
    
    db.add(db_message)
    db.add(relation)
    db.commit()
    db.refresh(db_message)
    
    # 获取分类名称
    category = db.query(Category).filter(Category.category_id == category_id).first()
    category_name = category.category_name if category else None
    
    # 组装响应数据
    response = MessageResponse(
        message_id=db_message.message_id,
        sender_id=db_message.sender_id,
        sender_role=sender_role,
        sender_nickname=sender.nickname,
        content_type=db_message.content_type,
        content=db_message.content,
        media_urls=json.loads(db_message.media_urls) if db_message.media_urls else [],
        audio_duration=db_message.audio_duration,
        send_time=db_message.send_time,
        main_category_id=db_message.main_category_id,
        main_category_name=category_name,
        sub_tags=json.loads(db_message.sub_tags) if db_message.sub_tags else [],
        ai_summary=db_message.ai_summary,
        ai_confidence=db_message.ai_confidence,
        status=db_message.status
    )
    
    return response

@app.get("/api/messages", response_model=List[MessageResponse])
def get_all_messages(
    year: Optional[int] = None,
    month: Optional[int] = None,
    category_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    获取所有历史消息，按发送时间正序排列（支撑全局时间轴）
    支持按年、月、分类ID筛选
    """
    query = db.query(Message).filter(Message.status == "processed")
    
    # 按年筛选
    if year:
        query = query.filter(
            Message.send_time >= datetime(year, 1, 1),
            Message.send_time < datetime(year + 1, 1, 1)
        )
    
    # 按月筛选
    if month and year:
        query = query.filter(
            Message.send_time >= datetime(year, month, 1),
            Message.send_time < datetime(year, month + 1, 1) if month < 12 else datetime(year + 1, 1, 1)
        )
    
    # 按分类筛选
    if category_id:
        query = query.join(MessageCategoryRelation).filter(
            MessageCategoryRelation.category_id == category_id
        )
    
    messages = query.order_by(Message.send_time.asc()).all()
    result = []
    
    # 角色反向映射：数据库存储值 -> 中文返回
    role_reverse_map = {"male": "男主", "female": "女主"}
    for msg in messages:
        sender = db.query(User).filter(User.user_id == msg.sender_id).first()
        category = db.query(Category).filter(Category.category_id == msg.main_category_id).first()
        result.append(MessageResponse(
            message_id=msg.message_id,
            sender_id=msg.sender_id,
            sender_role=role_reverse_map.get(sender.role, "未知") if sender else "未知",
            sender_nickname=sender.nickname if sender else "未知",
            content_type=msg.content_type,
            content=msg.content,
            media_urls=json.loads(msg.media_urls) if msg.media_urls else [],
            audio_duration=msg.audio_duration,
            send_time=msg.send_time,
            main_category_id=msg.main_category_id,
            main_category_name=category.category_name if category else None,
            sub_tags=json.loads(msg.sub_tags) if msg.sub_tags else [],
            ai_summary=msg.ai_summary,
            ai_confidence=msg.ai_confidence,
            status=msg.status
        ))
    
    return result

@app.get("/api/categories", response_model=List[CategoryResponse])
def get_categories(db: Session = Depends(get_db)):
    """获取所有分类列表，包含每个分类的消息数量"""
    categories = get_all_categories(db)
    result = []
    
    for cat in categories:
        # 统计该分类下的消息数量
        count = db.query(MessageCategoryRelation).filter(
            MessageCategoryRelation.category_id == cat["category_id"],
            MessageCategoryRelation.relation_type == "main"
        ).count()
        
        result.append(CategoryResponse(
            **cat,
            message_count=count
        ))
    
    return result

@app.get("/api/categories/{category_name}", response_model=List[MessageResponse])
def get_category_messages(
    category_name: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    """按分类名称获取该分类下的所有消息，支持按年/月筛选"""
    # 查找分类
    category = db.query(Category).filter(Category.category_key == category_name).first()
    if not category:
        raise HTTPException(status_code=404, detail="分类不存在")
    
    # 查询该分类下的所有消息
    query = db.query(Message).join(MessageCategoryRelation).filter(
        MessageCategoryRelation.category_id == category.category_id,
        Message.status == "processed"
    )
    
    # 按年筛选
    if year:
        query = query.filter(
            Message.send_time >= datetime(year, 1, 1),
            Message.send_time < datetime(year + 1, 1, 1)
        )
    
    # 按月筛选
    if month and year:
        query = query.filter(
            Message.send_time >= datetime(year, month, 1),
            Message.send_time < datetime(year, month + 1, 1) if month < 12 else datetime(year + 1, 1, 1)
        )
    
    messages = query.order_by(Message.send_time.asc()).all()
    result = []
    
    # 角色反向映射：数据库存储值 -> 中文返回
    role_reverse_map = {"male": "男主", "female": "女主"}
    for msg in messages:
        sender = db.query(User).filter(User.user_id == msg.sender_id).first()
        result.append(MessageResponse(
            message_id=msg.message_id,
            sender_id=msg.sender_id,
            sender_role=role_reverse_map.get(sender.role, "未知") if sender else "未知",
            sender_nickname=sender.nickname if sender else "未知",
            content_type=msg.content_type,
            content=msg.content,
            media_urls=json.loads(msg.media_urls) if msg.media_urls else [],
            audio_duration=msg.audio_duration,
            send_time=msg.send_time,
            main_category_id=msg.main_category_id,
            main_category_name=category.category_name,
            sub_tags=json.loads(msg.sub_tags) if msg.sub_tags else [],
            ai_summary=msg.ai_summary,
            ai_confidence=msg.ai_confidence,
            status=msg.status
        ))
    
    return result

# 健康检查接口
@app.get("/health")
def health_check():
    return {"status": "ok", "timestamp": datetime.now()}
