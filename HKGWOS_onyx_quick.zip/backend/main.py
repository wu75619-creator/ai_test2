from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import json
from passlib.context import CryptContext

# 导入数据模型
from models import Base, User, Message, Category

# 数据库配置
SQLALCHEMY_DATABASE_URL = "sqlite:///./diary.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 密码加密工具
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# 初始化FastAPI应用
app = FastAPI(title="情侣恋爱日记本API", version="1.0.0")

# 配置CORS：允许所有源跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 数据库依赖注入
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 应用启动时自动建表 + 初始化默认数据
@app.on_event("startup")
async def startup_event():
    # 自动创建所有数据库表
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    # 初始化默认测试用户（男主、女主）
    default_users = [
        {
            "user_id": "user_male",
            "username": "male_user",
            "role": "male",
            "nickname": "男主",
            "password": "123456"
        },
        {
            "user_id": "user_female",
            "username": "female_user",
            "role": "female",
            "nickname": "女主",
            "password": "123456"
        }
    ]
    
    for user_data in default_users:
        existing_user = db.query(User).filter(User.user_id == user_data["user_id"]).first()
        if not existing_user:
            user = User(
                user_id=user_data["user_id"],
                username=user_data["username"],
                password_hash=pwd_context.hash(user_data["password"]),
                role=user_data["role"],
                nickname=user_data["nickname"]
            )
            db.add(user)
    
    db.commit()
    db.close()

# ------------------------------
# Pydantic 数据模型定义
# ------------------------------
class MessageCreate(BaseModel):
    """发送消息请求模型"""
    sender_role: str  # 仅支持 "男主" / "女主"
    content: str
    content_type: Optional[str] = "text"  # 内容类型：text/image/audio
    media_urls: Optional[List[str]] = None  # 媒体文件URL列表（图片/语音）
    audio_duration: Optional[int] = None  # 语音时长（秒，仅音频类型）

class MessageResponse(BaseModel):
    """消息响应模型"""
    message_id: str
    sender_id: str
    sender_role: str  # 返回中文 男主/女主
    sender_nickname: str
    content_type: str
    content: Optional[str]
    media_urls: List[str]
    audio_duration: Optional[int]
    send_time: datetime
    main_category_id: Optional[str]
    sub_tags: List[str]
    ai_summary: Optional[str]
    ai_confidence: float
    status: str
    
    class Config:
        orm_mode = True

# ------------------------------
# 核心API接口
# ------------------------------
@app.post("/api/messages", response_model=MessageResponse, status_code=status.HTTP_201_CREATED)
def create_message(message: MessageCreate, db: Session = Depends(get_db)):
    """发送聊天消息接口"""
    # 角色映射：中文入参 -> 数据库存储值
    role_map = {"男主": "male", "女主": "female"}
    if message.sender_role not in role_map:
        raise HTTPException(status_code=400, detail="sender_role 只能是 '男主' 或 '女主'")
    
    db_role = role_map[message.sender_role]
    sender = db.query(User).filter(User.role == db_role).first()
    if not sender:
        raise HTTPException(status_code=404, detail="发送用户不存在")
    
    # 生成唯一消息ID
    message_id = str(uuid.uuid4())
    
    # 处理JSON字段（SQLite不支持原生JSON类型，用字符串存储）
    media_urls_json = json.dumps(message.media_urls) if message.media_urls else "[]"
    
    # 创建消息对象
    db_message = Message(
        message_id=message_id,
        sender_id=sender.user_id,
        content_type=message.content_type,
        content=message.content,
        media_urls=media_urls_json,
        audio_duration=message.audio_duration,
        status="pending"  # 初始状态为待分类，等待AI处理
    )
    
    # ==============================================
    # TODO: 接入AI分类打标逻辑
    # 后续这里将异步调用多模态AI接口，自动更新以下字段：
    # - main_category_id: 主分类ID（关联categories表）
    # - sub_tags: 子标签数组（JSON字符串存储）
    # - ai_summary: AI生成的1-2句温柔小结
    # - ai_confidence: 分类置信度（0-1）
    # - status: 处理完成后更新为 "processed"
    # ==============================================
    
    db.add(db_message)
    db.commit()
    db.refresh(db_message)
    
    # 组装响应数据，将JSON字符串转回数组
    response = MessageResponse(
        message_id=db_message.message_id,
        sender_id=db_message.sender_id,
        sender_role=message.sender_role,
        sender_nickname=sender.nickname,
        content_type=db_message.content_type,
        content=db_message.content,
        media_urls=json.loads(db_message.media_urls) if db_message.media_urls else [],
        audio_duration=db_message.audio_duration,
        send_time=db_message.send_time,
        main_category_id=db_message.main_category_id,
        sub_tags=json.loads(db_message.sub_tags) if db_message.sub_tags else [],
        ai_summary=db_message.ai_summary,
        ai_confidence=db_message.ai_confidence,
        status=db_message.status
    )
    
    return response

@app.get("/api/messages", response_model=List[MessageResponse])
def get_all_messages(db: Session = Depends(get_db)):
    """获取所有历史消息，按发送时间正序排列（支撑全局时间轴）"""
    messages = db.query(Message).order_by(Message.send_time.asc()).all()
    result = []
    
    # 角色反向映射：数据库存储值 -> 中文返回
    role_reverse_map = {"male": "男主", "female": "女主"}
    for msg in messages:
        sender = db.query(User).filter(User.user_id == msg.sender_id).first()
        result.append(MessageResponse(
            message_id=msg.message_id,
            sender_id=msg.sender_id,
            sender_role=role_reverse_map.get(sender.role, "未知") if sender else "未知",
            sender_nickname=sender.nickname if sender else "未知",
            content_type=msg.content_type,
            content=msg.content,
            media_urls=json.loads(msg.media_urls) if msg.media_urls else [],
            audio_duration=msg.audio_duration,
            send_time=msg.send_time,
            main_category_id=msg.main_category_id,
            sub_tags=json.loads(msg.sub_tags) if msg.sub_tags else [],
            ai_summary=msg.ai_summary,
            ai_confidence=msg.ai_confidence,
            status=msg.status
        ))
    
    return result

# 健康检查接口
@app.get("/health")
def health_check():
    return {"status": "ok", "timestamp": datetime.now()}
