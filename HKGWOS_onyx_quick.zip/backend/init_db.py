"""
数据库初始化脚本
"""
import sqlite3
import os

def init_database():
    db_path = os.path.join(os.path.dirname(__file__), "diary.db")
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    
    # 读取schema文件
    with open(schema_path, "r", encoding="utf-8") as f:
        schema_sql = f.read()
    
    # 执行初始化
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.executescript(schema_sql)
    conn.commit()
    conn.close()
    
    print(f"数据库初始化完成，文件位置：{db_path}")

if __name__ == "__main__":
    init_database()
