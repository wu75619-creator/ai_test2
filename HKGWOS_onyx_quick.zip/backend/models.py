"""
SQLAlchemy 数据模型定义
"""
from sqlalchemy import Column, String, Text, Integer, Float, Boolean, TIMESTAMP, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    
    user_id = Column(String, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, nullable=False)  # 'male' / 'female'
    nickname = Column(String, nullable=False)
    avatar_url = Column(String)
    access_password = Column(String)
    last_login_at = Column(TIMESTAMP)
    created_at = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    messages = relationship("Message", back_populates="sender")
    
    __table_args__ = (
        CheckConstraint("role IN ('male', 'female')", name="check_user_role"),
    )

class Category(Base):
    __tablename__ = "categories"
    
    category_id = Column(String, primary_key=True)
    category_key = Column(String, unique=True, nullable=False)
    category_name = Column(String, nullable=False)
    description = Column(Text)
    sort_order = Column(Integer, default=0, nullable=False)
    is_system = Column(Boolean, default=True, nullable=False)
    created_at = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)

class Message(Base):
    __tablename__ = "messages"
    
    message_id = Column(String, primary_key=True)
    sender_id = Column(String, ForeignKey("users.user_id"), nullable=False)
    content_type = Column(String, nullable=False)  # 'text' / 'image' / 'audio'
    content = Column(Text)
    media_urls = Column(String, default="[]")  # JSON array
    audio_duration = Column(Integer)
    send_time = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)
    main_category_id = Column(String, ForeignKey("categories.category_id"))
    sub_tags = Column(String, default="[]")  # JSON array
    ai_summary = Column(Text)
    ai_confidence = Column(Float, default=0.0)
    status = Column(String, default="pending", nullable=False)  # 'pending' / 'processed' / 'deleted'
    created_at = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)
    updated_at = Column(TIMESTAMP, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    sender = relationship("User", back_populates="messages")
    main_category = relationship("Category")
    category_relations = relationship("MessageCategoryRelation", back_populates="message")
    
    __table_args__ = (
        CheckConstraint("content_type IN ('text', 'image', 'audio')", name="check_content_type"),
        CheckConstraint("status IN ('pending', 'processed', 'deleted')", name="check_message_status"),
    )

class MessageCategoryRelation(Base):
    __tablename__ = "message_category_relations"
    
    relation_id = Column(String, primary_key=True)
    message_id = Column(String, ForeignKey("messages.message_id", ondelete="CASCADE"), nullable=False)
    category_id = Column(String, ForeignKey("categories.category_id"), nullable=False)
    relation_type = Column(String, nullable=False)  # 'main' / 'related'
    created_at = Column(TIMESTAMP, default=datetime.utcnow, nullable=False)
    
    message = relationship("Message", back_populates="category_relations")
    category = relationship("Category")
    
    __table_args__ = (
        UniqueConstraint("message_id", "category_id", name="uq_message_category"),
        CheckConstraint("relation_type IN ('main', 'related')", name="check_relation_type"),
    )
