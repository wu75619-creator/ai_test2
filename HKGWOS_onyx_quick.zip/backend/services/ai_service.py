"""
AI分类服务模块
支持通过环境变量AI_ENABLED开关切换真实API调用和Mock模式
"""
import os
import json
import random
from typing import List, Dict, Tuple
from sqlalchemy.orm import Session
from models import Category
from openai import OpenAI
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 八大分类的Mock配置
MOCK_CATEGORIES = [
    {
        "id": "cat_food",
        "key": "food",
        "name": "美食探店",
        "tags_pool": ["火锅", "奶茶", "探店", "烧烤", "甜品", "日料", "咖啡", "蛋糕"],
        "summary_templates": [
            "今天和宝贝一起打卡了{tag}，幸福满满~",
            "和你一起吃的{tag}，连空气都是甜的✨",
            "干饭人干饭魂，和你一起吃什么都香",
            "又发现了一家好吃的{tag}店，下次还要和你一起来"
        ]
    },
    {
        "id": "cat_travel",
        "key": "travel",
        "name": "旅行约会",
        "tags_pool": ["逛街", "约会", "旅行", "看电影", "逛公园", "看展", "爬山", "海边"],
        "summary_templates": [
            "和你一起去{tag}，风景都变得更美了",
            "今天的{tag}之旅，有你在身边超开心",
            "每一次和你的{tag}，都是最珍贵的回忆",
            "牵着你的手{tag}，就是最浪漫的事"
        ]
    },
    {
        "id": "cat_photo",
        "key": "photo",
        "name": "情侣合照",
        "tags_pool": ["合照", "自拍", "同框", "合影", "全家福", "情侣照"],
        "summary_templates": [
            "和宝贝的合照，每一张都要好好珍藏",
            "定格和你在一起的美好瞬间💑",
            "我们的第N张合照，越来越有夫妻相啦",
            "你笑起来的样子，是我见过最美的风景"
        ]
    },
    {
        "id": "cat_daily",
        "key": "daily",
        "name": "趣味日常",
        "tags_pool": ["搞笑", "互怼", "可爱", "沙雕", "日常", "碎碎念", "梗"],
        "summary_templates": [
            "今天也是被你可爱到的一天🥰",
            "和你在一起的日常，每天都有新笑点",
            "平平淡淡的日常，因为有你变得闪闪发光",
            "我们的小日常，就是最幸福的样子"
        ]
    },
    {
        "id": "cat_nickname",
        "key": "nickname",
        "name": "专属昵称",
        "tags_pool": ["昵称", "称呼", "暗号", "外号", "专属梗"],
        "summary_templates": [
            "属于我们的专属昵称，只有我们懂的小秘密",
            "你给我起的外号，我都偷偷记下来啦",
            "我们的专属暗号，是爱情的密码呀",
            "每次你叫我昵称的时候，心都化了"
        ]
    },
    {
        "id": "cat_emotion",
        "key": "emotion",
        "name": "深度谈心",
        "tags_pool": ["谈心", "未来", "规划", "情绪", "爱意", "告白", "心里话"],
        "summary_templates": [
            "和你聊了很多心里话，越来越爱你了",
            "我们的未来，要一起走下去呀",
            "谢谢你愿意听我讲所有的开心和不开心",
            "被你理解和爱着的感觉，真好"
        ]
    },
    {
        "id": "cat_conflict",
        "key": "conflict",
        "name": "矛盾复盘",
        "tags_pool": ["吵架", "矛盾", "反思", "和解", "约定", "道歉"],
        "summary_templates": [
            "今天的小矛盾，让我们更了解彼此了",
            "吵架没关系，只要最后还是我们就好",
            "我们约定好，以后再也不冷战了好不好",
            "一起解决问题的我们，会越来越默契的"
        ]
    },
    {
        "id": "cat_voice",
        "key": "voice",
        "name": "语音存档",
        "tags_pool": ["语音", "唱歌", "晚安", "告白", "碎碎念"],
        "summary_templates": [
            "你的声音，是我听过最好听的声音",
            "存下你的语音，想你的时候就拿出来听",
            "睡前听你的声音，连梦都是甜的",
            "你说的每一句话，我都想好好珍藏"
        ]
    }
]

# 是否启用真实AI API（通过环境变量控制，默认关闭使用Mock）
AI_ENABLED = os.getenv("AI_ENABLED", "false").lower() == "true"
# OpenAI配置
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

# 初始化OpenAI客户端
if AI_ENABLED and OPENAI_API_KEY:
    client = OpenAI(
        api_key=OPENAI_API_KEY,
        base_url=OPENAI_BASE_URL
    )
else:
    client = None


def get_all_categories(db: Session) -> List[Dict]:
    """获取所有分类列表"""
    categories = db.query(Category).order_by(Category.sort_order.asc()).all()
    return [
        {
            "category_id": cat.category_id,
            "category_key": cat.category_key,
            "category_name": cat.category_name,
            "description": cat.description
        }
        for cat in categories
    ]


def _mock_classify_content(content: str, content_type: str) -> Tuple[str, List[str], str, float]:
    """
    Mock分类逻辑：随机匹配八大分类，生成标签和小结
    返回：(主分类ID, 子标签列表, AI小结, 置信度)
    """
    # 语音类型优先归入语音存档分类
    if content_type == "audio":
        category = MOCK_CATEGORIES[-1]
    else:
        # 随机选择一个分类
        category = random.choice(MOCK_CATEGORIES)
    
    # 随机生成1-3个子标签
    tag_count = random.randint(1, 3)
    tags = random.sample(category["tags_pool"], min(tag_count, len(category["tags_pool"])))
    
    # 生成小结
    summary_template = random.choice(category["summary_templates"])
    primary_tag = tags[0] if tags else category["name"]
    summary = summary_template.format(tag=primary_tag)
    
    # 随机置信度 0.75 ~ 0.98
    confidence = round(random.uniform(0.75, 0.98), 2)
    
    return category["id"], tags, summary, confidence


async def _ai_classify_content(content: str, content_type: str, media_urls: List[str] = None) -> Tuple[str, List[str], str, float]:
    """
    真实OpenAI分类逻辑
    返回：(主分类ID, 子标签列表, AI小结, 置信度)
    """
    if not client:
        raise ValueError("OpenAI客户端未初始化，请检查API_KEY配置")
    
    # 构造分类描述
    categories_desc = "\n".join([
        f"- {cat['key']}: {cat['name']}，标签示例：{', '.join(cat['tags_pool'])}"
        for cat in MOCK_CATEGORIES
    ])
    
    # 构造用户内容描述
    content_desc = f"文本内容：{content}" if content else ""
    if content_type == "image" and media_urls:
        content_desc += f"\n图片数量：{len(media_urls)}张"
    elif content_type == "audio":
        content_desc += "\n语音消息"
    
    # 构造提示词
    prompt = f"""
你是一个专业的恋爱日记分类专家，请根据情侣发送的内容，自动匹配最合适的分类。

分类列表（只能从下面选一个）：
{categories_desc}

用户发送内容：
{content_desc}

请严格按照以下JSON格式返回结果，不要有其他额外内容：
{{
    "category_key": "分类的key，必须是上面列出的8个key之一",
    "tags": ["子标签1", "子标签2", "子标签3"],
    "summary": "1-2句温柔风格的小结，符合恋爱日记的甜蜜氛围，不要太长",
    "confidence": 0.95 // 分类置信度，0-1之间的浮点数
}}
"""
    
    # 调用OpenAI API
    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": "你是一个专业的恋爱日记分类助手，擅长识别情侣对话的场景，输出结果必须严格是JSON格式，不要有任何解释性文字。"},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        response_format={"type": "json_object"}
    )
    
    # 解析返回结果
    ai_content = response.choices[0].message.content
    data = json.loads(ai_content)
    
    # 查找分类ID
    category_key = data["category_key"]
    category = next((cat for cat in MOCK_CATEGORIES if cat["key"] == category_key), MOCK_CATEGORIES[0])
    
    return (
        category["id"],
        data["tags"],
        data["summary"],
        data["confidence"]
    )


async def classify_content(content: str, content_type: str, media_urls: List[str] = None) -> Tuple[str, List[str], str, float]:
    """
    统一分类入口：根据AI_ENABLED开关自动选择Mock或真实API
    """
    if AI_ENABLED and client:
        try:
            return await _ai_classify_content(content, content_type, media_urls)
        except Exception as e:
            print(f"AI分类失败，降级为Mock模式：{str(e)}")
            # 真实API调用失败时降级为Mock
            return _mock_classify_content(content, content_type)
    else:
        # Mock模式
        return _mock_classify_content(content, content_type)
