-- 情侣智能随手恋爱日记本 数据库schema (SQLite 3)
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- 1. 用户表：存储情侣双方账号信息
CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('male', 'female')),
    nickname TEXT NOT NULL,
    avatar_url TEXT,
    access_password TEXT,
    last_login_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. 分类归档表：预设8大核心分类
CREATE TABLE IF NOT EXISTS categories (
    category_id TEXT PRIMARY KEY,
    category_key TEXT NOT NULL UNIQUE,
    category_name TEXT NOT NULL,
    description TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_system INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 初始化8大预设分类
INSERT OR IGNORE INTO categories (category_id, category_key, category_name, description, sort_order) VALUES
('cat_food', 'food', '美食探店存档', '记录一起打卡的美食、奶茶、探店经历', 1),
('cat_travel', 'travel', '旅行&外出约会存档', '记录旅行、逛街、约会的所有回忆', 2),
('cat_photo', 'photo', '情侣合照存档', '所有双人同框的合照、自拍专属相册', 3),
('cat_daily', 'daily', '趣味日常存档', '搞笑对话、互怼日常、可爱碎片记录', 4),
('cat_nickname', 'nickname', '专属昵称&特殊代号存档', '专属称呼、私密梗、情侣暗号汇总', 5),
('cat_emotion', 'emotion', '深度谈心&情感对话存档', '走心交流、情绪倾诉、未来规划记录', 6),
('cat_conflict', 'conflict', '矛盾&吵架复盘存档', '矛盾记录、反思、和解、成长约定', 7),
('cat_voice', 'voice', '语音专属存档库', '所有语音消息单独归档，可随时回放', 8);

-- 3. 消息记录表：核心业务表
CREATE TABLE IF NOT EXISTS messages (
    message_id TEXT PRIMARY KEY,
    sender_id TEXT NOT NULL REFERENCES users(user_id),
    content_type TEXT NOT NULL CHECK (content_type IN ('text', 'image', 'audio')),
    content TEXT,
    media_urls TEXT DEFAULT '[]', -- JSON数组，存储图片/语音文件路径
    audio_duration INTEGER, -- 语音时长（秒）
    send_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    main_category_id TEXT REFERENCES categories(category_id),
    sub_tags TEXT DEFAULT '[]', -- JSON数组，存储子标签
    ai_summary TEXT,
    ai_confidence REAL DEFAULT 0.0,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processed', 'deleted')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. 消息分类关联表：支持一条内容关联主分类+附属分类
CREATE TABLE IF NOT EXISTS message_category_relations (
    relation_id TEXT PRIMARY KEY,
    message_id TEXT NOT NULL REFERENCES messages(message_id) ON DELETE CASCADE,
    category_id TEXT NOT NULL REFERENCES categories(category_id),
    relation_type TEXT NOT NULL CHECK (relation_type IN ('main', 'related')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, category_id)
);

-- 索引优化
CREATE INDEX IF NOT EXISTS idx_messages_send_time ON messages(send_time DESC);
CREATE INDEX IF NOT EXISTS idx_messages_main_category ON messages(main_category_id);
CREATE INDEX IF NOT EXISTS idx_relations_message ON message_category_relations(message_id);
CREATE INDEX IF NOT EXISTS idx_relations_category ON message_category_relations(category_id);
