import request from './request'

/**
 * 获取所有分类列表
 * @returns {Promise<Array>} 分类列表
 */
export function getCategories() {
  return request({
    url: '/api/categories',
    method: 'get'
  })
}

/**
 * 按分类名称获取分类下的消息
 * @param {string} categoryName 分类唯一标识（如food/travel）
 * @param {Object} [params] 筛选参数
 * @param {number} [params.year] 年份
 * @param {number} [params.month] 月份
 * @returns {Promise<Array>} 消息列表
 */
export function getCategoryMessages(categoryName, params = {}) {
  return request({
    url: `/api/categories/${categoryName}`,
    method: 'get',
    params
  })
}
