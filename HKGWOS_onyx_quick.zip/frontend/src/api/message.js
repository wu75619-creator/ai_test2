import request from './request'

/**
 * 获取所有历史消息
 * @returns {Promise<Array>} 消息列表
 */
export function getMessages(params = {}) {
  return request({
    url: '/api/messages',
    method: 'get',
    params
  })
}

/**
 * 发送新消息
 * @param {FormData} data 消息数据，包含以下字段：
 * - sender_role: 发送人角色："男主" / "女主"
 * - content_type: 内容类型：text/image/audio
 * - is_ai_auto: 是否自动分类，布尔值
 * - manual_category: 手动分类的key（可选）
 * - content: 文本内容（可选）
 * - audio_duration: 语音时长（秒，可选）
 * - files: 文件数组（可选）
 * @returns {Promise<Object>} 新创建的消息
 */
export function sendMessage(data) {
  return request({
    url: '/api/messages',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}
