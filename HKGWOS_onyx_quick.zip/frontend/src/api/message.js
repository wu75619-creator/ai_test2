import request from './request'

/**
 * 获取所有历史消息
 * @returns {Promise<Array>} 消息列表
 */
export function getMessages() {
  return request({
    url: '/api/messages',
    method: 'get'
  })
}

/**
 * 发送新消息
 * @param {Object} data 消息数据
 * @param {string} data.sender_role 发送人角色："男主" / "女主"
 * @param {string} data.content 消息内容
 * @param {string} [data.content_type="text"] 内容类型：text/image/audio
 * @param {Array<string>} [data.media_urls] 媒体文件URL列表
 * @param {number} [data.audio_duration] 语音时长（秒）
 * @returns {Promise<Object>} 新创建的消息
 */
export function sendMessage(data) {
  return request({
    url: '/api/messages',
    method: 'post',
    data
  })
}
