import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import './style.css'
import App from './App.vue'
import ChatView from './views/ChatView.vue'
import CategoryView from './views/CategoryView.vue'
import TimelineView from './views/TimelineView.vue'

// 路由配置
const routes = [
  {
    path: '/',
    name: 'Chat',
    component: ChatView,
    meta: { title: '聊天记录' }
  },
  {
    path: '/category',
    name: 'Category',
    component: CategoryView,
    meta: { title: '分类相册' }
  },
  {
    path: '/timeline',
    name: 'Timeline',
    component: TimelineView,
    meta: { title: '恋爱时间轴' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

const app = createApp(App)
app.use(router)
app.use(ElementPlus)

// 注册所有Element Plus图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.mount('#app')
