<script setup>
import { RouterView, useRouter, useRoute } from 'vue-router'
import { ChatDotRound, Folder, Clock } from '@element-plus/icons-vue'
import { ref } from 'vue'

const router = useRouter()
const route = useRoute()
const activeTab = ref(route.path)

// 切换Tab
const handleTabClick = (path) => {
  activeTab.value = path
  router.push(path)
}

// 监听路由变化，更新Tab状态
router.afterEach((to) => {
  activeTab.value = to.path
})
</script>

<template>
  <div class="app-container">
    <RouterView />
    
    <!-- 底部导航栏 -->
    <div class="bottom-nav">
      <div
        class="nav-item"
        :class="{ active: activeTab === '/' }"
        @click="handleTabClick('/')"
      >
        <el-icon class="nav-icon"><ChatDotRound /></el-icon>
        <span class="nav-text">聊天记录</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: activeTab === '/category' }"
        @click="handleTabClick('/category')"
      >
        <el-icon class="nav-icon"><Folder /></el-icon>
        <span class="nav-text">分类相册</span>
      </div>
      <div
        class="nav-item"
        :class="{ active: activeTab === '/timeline' }"
        @click="handleTabClick('/timeline')"
      >
        <el-icon class="nav-icon"><Clock /></el-icon>
        <span class="nav-text">恋爱时间轴</span>
      </div>
    </div>
  </div>
</template>

<style>
.app-container {
  min-height: 100vh;
  padding-bottom: 70px;
}

/* 底部导航栏 */
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  max-width: 800px;
  margin: 0 auto;
  height: 60px;
  background-color: var(--bg-card);
  border-top: 1px solid var(--el-color-primary-light-8);
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 0 20px;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.03);
  z-index: 1000;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  color: var(--text-light);
  transition: all 0.3s ease;
  padding: 8px 16px;
  border-radius: 12px;
}

.nav-item.active {
  color: var(--el-color-primary);
  background-color: var(--el-color-primary-light-9);
}

.nav-icon {
  font-size: 20px;
}

.nav-text {
  font-size: 12px;
  font-weight: 500;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .bottom-nav {
    padding: 0 calc(12px + env(safe-area-inset-right)) calc(8px + env(safe-area-inset-bottom)) calc(12px + env(safe-area-inset-left));
  }
}
</style>
