<template>
  <div class="timeline-container">
    <!-- 页面头部 -->
    <div class="page-header">
      <h1 class="page-title">💑 恋爱时间轴</h1>
      <p class="page-subtitle">一起走过的点点滴滴，都在这里 ✨</p>
    </div>

    <!-- 时间筛选器 -->
    <div class="filter-bar">
      <el-date-picker
        v-model="dateRange"
        type="year"
        placeholder="选择年份筛选"
        format="YYYY"
        value-format="YYYY"
        @change="loadMessages"
        clearable
        class="date-picker"
      />
      <span class="stats-text">共 {{ messages.length }} 条记录</span>
    </div>

    <!-- 时间轴内容 -->
    <div class="timeline-content" v-loading="loading">
      <el-timeline>
        <el-timeline-item
          v-for="(group, date) in groupedMessages"
          :key="date"
          :timestamp="date"
          placement="top"
          color="#ff85a2"
          size="large"
        >
          <div class="date-group">
            <!-- 该日期下的所有消息 -->
            <div
              v-for="message in group"
              :key="message.message_id"
              class="timeline-message"
            >
              <!-- 发送人信息 -->
              <div class="message-sender">
                <div class="avatar" :class="message.sender_role === '男主' ? 'avatar-male' : 'avatar-female'">
                  {{ message.sender_role === '男主' ? '👦' : '👧' }}
                </div>
                <div class="sender-text">
                  <div class="nickname">{{ message.sender_nickname }}</div>
                  <div class="time">{{ formatTime(message.send_time) }}</div>
                </div>
              </div>

              <!-- 消息内容 -->
              <div class="message-content">
                <!-- 文字内容 -->
                <div v-if="message.content_type === 'text'" class="text-content">
                  {{ message.content }}
                </div>

                <!-- 图片内容 -->
                <div v-else-if="message.content_type === 'image'" class="image-content">
                  <el-image
                    v-for="(url, index) in message.media_urls"
                    :key="index"
                    :src="url"
                    fit="cover"
                    class="timeline-image"
                    :preview-src-list="message.media_urls"
                  />
                </div>

                <!-- 语音内容 -->
                <div v-else-if="message.content_type === 'audio'" class="audio-content">
                  <el-icon class="audio-icon"><Microphone /></el-icon>
                  <span>{{ message.audio_duration }}''</span>
                  <audio :src="message.media_urls[0]" controls preload="none"></audio>
                </div>

                <!-- AI标签和小结 -->
                <div class="ai-info">
                  <div class="ai-tags" v-if="message.main_category_name || message.sub_tags?.length > 0">
                    <el-tag v-if="message.main_category_name" size="small" type="primary" class="category-tag">
                      {{ message.main_category_name }}
                    </el-tag>
                    <el-tag v-for="tag in message.sub_tags" :key="tag" size="small" class="sub-tag">
                      #{{ tag }}
                    </el-tag>
                  </div>
                  <div v-if="message.ai_summary" class="ai-summary">
                    💡 {{ message.ai_summary }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-timeline-item>
      </el-timeline>

      <!-- 空状态 -->
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div class="empty-icon">⏳</div>
        <p class="empty-text">还没有时间线记录哦，快去聊天页面发送第一条吧~</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Microphone } from '@element-plus/icons-vue'
import { getMessages } from '../api/message'

// 消息列表
const messages = ref([])
// 日期范围
const dateRange = ref('')
// 加载状态
const loading = ref(false)

// 按日期分组的消息
const groupedMessages = computed(() => {
  const groups = {}
  messages.value.forEach(msg => {
    const date = new Date(msg.send_time)
    const dateStr = `${date.getFullYear()}年${(date.getMonth() + 1).toString().padStart(2, '0')}月${date.getDate().toString().padStart(2, '0')}日`
    if (!groups[dateStr]) {
      groups[dateStr] = []
    }
    groups[dateStr].push(msg)
  })
  return groups
})

// 格式化时间（时分）
const formatTime = (timeStr) => {
  const date = new Date(timeStr)
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  return `${hours}:${minutes}`
}

// 加载消息
const loadMessages = async () => {
  loading.value = true
  try {
    const params = {}
    if (dateRange.value) {
      params.year = parseInt(dateRange.value)
    }
    
    const res = await getMessages(params)
    // 按时间倒序排列，最新的在上面
    messages.value = res.reverse()
  } catch (error) {
    console.error('加载时间线失败:', error)
    ElMessage.error('加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.timeline-container {
  max-width: 800px;
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-color);
  padding-bottom: 80px;
}

/* 页面头部 */
.page-header {
  padding: 20px;
  text-align: center;
  background: linear-gradient(135deg, var(--el-color-primary-light-8) 0%, var(--bg-color) 100%);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.page-title {
  font-size: 24px;
  color: var(--el-color-primary-dark-2);
  margin-bottom: 4px;
  font-weight: 600;
}

.page-subtitle {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 筛选栏 */
.filter-bar {
  padding: 16px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: var(--bg-card);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.date-picker {
  width: 150px;
}

.stats-text {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 时间轴内容 */
.timeline-content {
  flex: 1;
  padding: 30px 20px;
  padding-left: 40px;
}

:deep(.el-timeline-item__timestamp) {
  color: var(--el-color-primary-dark-2);
  font-weight: 500;
  font-size: 14px;
  background-color: var(--el-color-primary-light-9);
  padding: 4px 12px;
  border-radius: 12px;
  margin-bottom: 12px;
}

:deep(.el-timeline-item__node--large) {
  width: 14px;
  height: 14px;
  left: -7px;
}

:deep(.el-timeline-item__wrapper) {
  padding-left: 24px;
}

/* 日期分组 */
.date-group {
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-bottom: 24px;
}

/* 时间轴消息 */
.timeline-message {
  background-color: var(--bg-card);
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  border: 1px solid var(--el-color-primary-light-8);
}

/* 发送人信息 */
.message-sender {
  display: flex;
  gap: 8px;
  align-items: center;
  margin-bottom: 12px;
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
}

.avatar-male {
  background-color: var(--bubble-male);
}

.avatar-female {
  background-color: var(--bubble-female);
}

.sender-text {
  display: flex;
  flex-direction: column;
}

.nickname {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-primary);
}

.time {
  font-size: 12px;
  color: var(--text-light);
}

/* 消息内容 */
.message-content {
  margin-left: 44px;
}

.text-content {
  font-size: 14px;
  line-height: 1.6;
  color: var(--text-primary);
  background-color: var(--el-color-primary-light-9);
  padding: 12px;
  border-radius: 8px;
}

.image-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 8px;
}

.timeline-image {
  border-radius: 8px;
  width: 100%;
  height: 100px;
}

.audio-content {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px;
  background-color: var(--el-color-primary-light-9);
  border-radius: 8px;
}

.audio-icon {
  font-size: 18px;
  color: var(--el-color-primary);
}

.audio-content audio {
  flex: 1;
  height: 24px;
  margin-left: 8px;
}

/* AI信息 */
.ai-info {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid var(--el-color-primary-light-8);
}

.ai-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 8px;
}

.category-tag {
  background-color: var(--el-color-primary-light-7);
  border-color: var(--el-color-primary);
  color: var(--el-color-primary-dark-2);
}

.sub-tag {
  background-color: transparent;
  border-color: var(--el-color-primary-light-3);
  color: var(--el-color-primary);
}

.ai-summary {
  font-size: 13px;
  color: var(--text-secondary);
  font-style: italic;
  background-color: rgba(255, 133, 162, 0.08);
  padding: 8px 12px;
  border-radius: 6px;
  border-left: 3px solid var(--el-color-primary);
}

/* 空状态 */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-light);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 16px;
}

.empty-text {
  font-size: 14px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .timeline-content {
    padding-left: 30px;
  }
  
  .message-content {
    margin-left: 0;
    margin-top: 8px;
  }
  
  .image-content {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
