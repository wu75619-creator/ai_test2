<template>
  <div class="chat-container">
    <!-- 聊天头部 -->
    <div class="chat-header">
      <h1 class="chat-title">💑 我们的恋爱日记本</h1>
      <p class="chat-subtitle">随手记录每一个甜蜜瞬间 ✨</p>
    </div>

    <!-- 消息列表区域 -->
    <div class="message-list" ref="messageListRef">
      <div
        v-for="message in messages"
        :key="message.message_id"
        class="message-item"
        :class="message.sender_role === '男主' ? 'message-male' : 'message-female'"
      >
        <!-- 头像 -->
        <div class="avatar" :class="message.sender_role === '男主' ? 'avatar-male' : 'avatar-female'">
          {{ message.sender_role === '男主' ? '👦' : '👧' }}
        </div>

        <!-- 消息内容区域 -->
        <div class="message-content">
          <div class="message-meta">
            <span class="sender-nickname">{{ message.sender_nickname }}</span>
            <span class="send-time">{{ formatTime(message.send_time) }}</span>
          </div>
          <div class="message-bubble">
            <!-- 文字消息 -->
            <div v-if="message.content_type === 'text'" class="text-content">
              {{ message.content }}
            </div>

            <!-- 图片消息 -->
            <div v-else-if="message.content_type === 'image'" class="image-content">
              <el-image
                v-for="(url, index) in message.media_urls"
                :key="index"
                :src="url"
                fit="cover"
                class="message-image"
                :preview-src-list="message.media_urls"
              />
            </div>

            <!-- 语音消息 -->
            <div v-else-if="message.content_type === 'audio'" class="audio-content">
              <el-icon class="audio-icon"><Microphone /></el-icon>
              <span>{{ message.audio_duration }}''</span>
              <audio :src="message.media_urls[0]" controls preload="none"></audio>
            </div>

            <!-- AI分类标签 -->
            <div v-if="message.main_category_id || message.sub_tags?.length > 0" class="ai-tags">
              <el-tag v-if="message.main_category_id" size="small" type="primary" class="category-tag">
                {{ getCategoryName(message.main_category_id) }}
              </el-tag>
              <el-tag v-for="tag in message.sub_tags" :key="tag" size="small" class="sub-tag">
                #{{ tag }}
              </el-tag>
            </div>

            <!-- AI小结 -->
            <div v-if="message.ai_summary" class="ai-summary">
              💡 {{ message.ai_summary }}
            </div>
          </div>
        </div>
      </div>

      <!-- 空状态 -->
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div class="empty-icon">💬</div>
        <p class="empty-text">还没有消息哦，快来发送第一条甜蜜记录吧~</p>
      </div>
    </div>

    <!-- 底部输入区域 -->
    <div class="input-area">
      <div class="role-selector">
        <el-radio-group v-model="currentRole" size="small">
          <el-radio-button label="男主">👦 男主</el-radio-button>
          <el-radio-button label="女主">👧 女主</el-radio-button>
        </el-radio-group>
      </div>
      <div class="input-wrapper">
        <el-input
          v-model="inputContent"
          type="textarea"
          :rows="2"
          placeholder="说点什么吧~ 记录你们的甜蜜瞬间 ✨"
          @keydown.enter.exact.prevent="handleSend"
          class="message-input"
        />
        <el-button
          type="primary"
          :loading="sending"
          @click="handleSend"
          class="send-button"
          :disabled="!inputContent.trim()"
        >
          发送
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { Microphone } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'

// 消息列表
const messages = ref([])
// 加载状态
const loading = ref(false)
// 发送状态
const sending = ref(false)
// 输入内容
const inputContent = ref('')
// 当前发送角色（可切换，默认女主）
const currentRole = ref('女主')
// 消息列表DOM引用
const messageListRef = ref(null)

// 分类名称映射（后续可以替换为接口获取）
const categoryMap = {
  'cat_food': '美食探店',
  'cat_travel': '旅行约会',
  'cat_photo': '情侣合照',
  'cat_daily': '趣味日常',
  'cat_nickname': '专属昵称',
  'cat_emotion': '深度谈心',
  'cat_conflict': '矛盾复盘',
  'cat_voice': '语音存档'
}

// 获取分类名称
const getCategoryName = (categoryId) => {
  return categoryMap[categoryId] || '未分类'
}

// 格式化时间
const formatTime = (timeStr) => {
  const date = new Date(timeStr)
  const now = new Date()
  const isToday = date.toDateString() === now.toDateString()
  
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  
  if (isToday) {
    return `${hours}:${minutes}`
  } else {
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    return `${month}-${day} ${hours}:${minutes}`
  }
}

// 滚动到底部
const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}

// 加载历史消息
const loadMessages = async () => {
  loading.value = true
  try {
    const res = await getMessages()
    messages.value = res
    scrollToBottom()
  } catch (error) {
    console.error('加载历史消息失败:', error)
  } finally {
    loading.value = false
  }
}

// 发送消息
const handleSend = async () => {
  const content = inputContent.value.trim()
  if (!content || sending.value) return

  sending.value = true
  try {
    await sendMessage({
      sender_role: currentRole.value,
      content: content,
      content_type: 'text'
    })
    
    // 清空输入框
    inputContent.value = ''
    // 重新加载消息（后续可以优化为本地追加，减少请求）
    await loadMessages()
    ElMessage.success('发送成功')
  } catch (error) {
    console.error('发送消息失败:', error)
  } finally {
    sending.value = false
  }
}

// 页面加载时获取历史消息
onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.chat-container {
  max-width: 800px;
  margin: 0 auto;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-color);
  border-left: 1px solid var(--el-color-primary-light-8);
  border-right: 1px solid var(--el-color-primary-light-8);
}

/* 头部样式 */
.chat-header {
  padding: 20px;
  text-align: center;
  background: linear-gradient(135deg, var(--el-color-primary-light-8) 0%, var(--bg-color) 100%);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.chat-title {
  font-size: 24px;
  color: var(--el-color-primary-dark-2);
  margin-bottom: 4px;
  font-weight: 600;
}

.chat-subtitle {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 消息列表样式 */
.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background-color: var(--bg-color);
}

.message-item {
  display: flex;
  margin-bottom: 20px;
  gap: 12px;
}

/* 男主消息：左侧对齐 */
.message-male {
  flex-direction: row;
}

.message-male .message-content {
  align-items: flex-start;
}

.message-male .message-bubble {
  background-color: var(--bubble-male);
  color: var(--text-male);
  border-bottom-left-radius: 4px;
}

/* 女主消息：右侧对齐 */
.message-female {
  flex-direction: row-reverse;
}

.message-female .message-content {
  align-items: flex-end;
}

.message-female .message-bubble {
  background-color: var(--bubble-female);
  color: var(--text-female);
  border-bottom-right-radius: 4px;
}

.message-female .message-meta {
  flex-direction: row-reverse;
}

/* 头像样式 */
.avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.avatar-male {
  background-color: var(--bubble-male);
}

.avatar-female {
  background-color: var(--bubble-female);
}

/* 消息内容样式 */
.message-content {
  display: flex;
  flex-direction: column;
  max-width: 70%;
}

.message-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 4px;
  font-size: 12px;
  color: var(--text-light);
}

.sender-nickname {
  font-weight: 500;
}

.message-bubble {
  padding: 12px 16px;
  border-radius: 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  line-height: 1.5;
  word-break: break-word;
}

/* 图片消息样式 */
.image-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 8px;
}

.message-image {
  border-radius: 8px;
  width: 100%;
  height: 120px;
}

/* 语音消息样式 */
.audio-content {
  display: flex;
  align-items: center;
  gap: 8px;
}

.audio-icon {
  font-size: 18px;
}

.audio-content audio {
  height: 24px;
  margin-left: 8px;
}

/* AI标签样式 */
.ai-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.category-tag {
  background-color: var(--el-color-primary-light-7);
  border-color: var(--el-color-primary);
  color: var(--el-color-primary-dark-2);
}

.sub-tag {
  background-color: transparent;
  border-color: var(--el-color-primary-light-3);
  color: var(--el-color-primary);
}

/* AI小结样式 */
.ai-summary {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
  font-size: 13px;
  color: var(--text-secondary);
  font-style: italic;
}

/* 空状态样式 */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-light);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 16px;
}

.empty-text {
  font-size: 14px;
}

/* 底部输入区域样式 */
.input-area {
  padding: 16px 20px;
  background-color: var(--bg-card);
  border-top: 1px solid var(--el-color-primary-light-8);
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.03);
}

.role-selector {
  margin-bottom: 12px;
}

.input-wrapper {
  display: flex;
  gap: 12px;
  align-items: flex-end;
}

.message-input {
  flex: 1;
}

.send-button {
  height: 40px;
  padding: 0 24px;
  border-radius: 20px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .chat-container {
    border: none;
  }
  
  .message-content {
    max-width: 75%;
  }
  
  .input-area {
    padding: 12px 16px;
    padding-bottom: calc(12px + env(safe-area-inset-bottom));
  }
  
  .send-button {
    padding: 0 16px;
  }
}
</style>
