<template>
  <div class="chat-container">
    <!-- 聊天头部 -->
    <div class="chat-header">
      <h1 class="chat-title">💑 我们的恋爱日记本</h1>
      <p class="chat-subtitle">随手记录每一个甜蜜瞬间 ✨</p>
    </div>

    <!-- 消息列表区域 -->
    <div class="message-list" ref="messageListRef">
      <div
        v-for="message in messages"
        :key="message.message_id"
        class="message-item"
        :class="message.sender_role === '男主' ? 'message-male' : 'message-female'"
      >
        <!-- 头像 -->
        <div class="avatar" :class="message.sender_role === '男主' ? 'avatar-male' : 'avatar-female'">
          {{ message.sender_role === '男主' ? '👦' : '👧' }}
        </div>

        <!-- 消息内容区域 -->
        <div class="message-content">
          <div class="message-meta">
            <span class="sender-nickname">{{ message.sender_nickname }}</span>
            <span class="send-time">{{ formatTime(message.send_time) }}</span>
          </div>
          <div class="message-bubble">
            <!-- 文字消息 -->
            <div v-if="message.content_type === 'text'" class="text-content">
              {{ message.content }}
            </div>

            <!-- 图片消息 -->
            <div v-else-if="message.content_type === 'image'" class="image-content">
              <el-image
                v-for="(url, index) in message.media_urls"
                :key="index"
                :src="url"
                fit="cover"
                class="message-image"
                :preview-src-list="message.media_urls"
              />
              <div v-if="message.content" class="image-caption">{{ message.content }}</div>
            </div>

            <!-- 语音消息 -->
            <div v-else-if="message.content_type === 'audio'" class="audio-content">
              <div class="audio-info">
                <el-icon class="audio-icon"><Microphone /></el-icon>
                <span>{{ message.audio_duration }}''</span>
              </div>
              <audio :src="message.media_urls[0]" controls preload="none"></audio>
            </div>

            <!-- 分类标签和小结 -->
            <div v-if="message.main_category_name || message.sub_tags?.length > 0 || message.ai_summary" class="ai-info">
              <div class="ai-tags">
                <el-tag v-if="message.main_category_name" size="small" type="primary" class="category-tag">
                  {{ message.main_category_name }}
                </el-tag>
                <el-tag v-for="tag in message.sub_tags" :key="tag" size="small" class="sub-tag">
                  #{{ tag }}
                </el-tag>
              </div>
              <div v-if="message.ai_summary" class="ai-summary">
                💡 {{ message.ai_summary }}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 空状态 -->
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div class="empty-icon">💬</div>
        <p class="empty-text">还没有消息哦，快来发送第一条甜蜜记录吧~</p>
      </div>
    </div>

    <!-- 底部输入区域 -->
    <div class="input-area">
      <!-- 分类模式控制 -->
      <div class="category-control">
        <div class="ai-switch-wrapper">
          <el-switch v-model="isAiAuto" active-text="AI自动分类" inactive-text="手动分类" />
        </div>
        <el-select
          v-if="!isAiAuto"
          v-model="selectedCategory"
          placeholder="请选择分类"
          size="small"
          class="category-select"
        >
          <el-option
            v-for="cat in categories"
            :key="cat.category_id"
            :label="cat.category_name"
            :value="cat.category_key"
          />
        </el-select>
      </div>

      <!-- 功能按钮栏 -->
      <div class="function-bar">
        <input
          ref="imageInputRef"
          type="file"
          accept="image/*"
          multiple
          @change="handleImageSelect"
          style="display: none;"
        />
        <el-button
          type="text"
          icon="Picture"
          @click="imageInputRef.click()"
          :disabled="recording"
          class="func-btn"
        >
          图片
        </el-button>
        
        <el-button
          type="text"
          :icon="recording ? 'VideoPause' : 'Microphone'"
          @click="handleRecordToggle"
          :class="recording ? 'recording-btn' : 'func-btn'"
        >
          {{ recording ? '停止录音' : '语音' }}
        </el-button>

        <!-- 已选文件预览 -->
        <div v-if="selectedFiles.length > 0" class="selected-files">
          <span class="file-count">已选{{ selectedFiles.length }}个文件</span>
          <el-button type="text" size="small" @click="clearFiles">清除</el-button>
        </div>
      </div>

      <div class="input-wrapper">
        <el-input
          v-model="inputContent"
          type="textarea"
          :rows="2"
          placeholder="说点什么吧~ 记录你们的甜蜜瞬间 ✨"
          @keydown.enter.exact.prevent="handleSend"
          class="message-input"
          :disabled="recording"
        />
        <el-button
          type="primary"
          :loading="sending"
          @click="handleSend"
          class="send-button"
          :disabled="!canSend"
        >
          发送
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { Microphone, Picture, VideoPause } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'
import { getCategories } from '../api/category'

// 消息列表
const messages = ref([])
// 分类列表
const categories = ref([])
// 加载状态
const loading = ref(false)
// 发送状态
const sending = ref(false)
// 输入内容
const inputContent = ref('')
// 当前发送角色（可切换，默认女主）
const currentRole = ref('女主')
// 消息列表DOM引用
const messageListRef = ref(null)
// 图片输入DOM引用
const imageInputRef = ref(null)

// AI自动分类开关，默认开启
const isAiAuto = ref(true)
// 手动选择的分类
const selectedCategory = ref('')

// 上传文件相关
const selectedFiles = ref([])
const currentContentType = ref('text')
const audioDuration = ref(0)

// 录音相关
const recording = ref(false)
let mediaRecorder = null
let audioChunks = []
let recordStartTime = 0

// 是否可以发送
const canSend = computed(() => {
  if (sending.value || recording.value) return false
  if (currentContentType.value === 'text' && !inputContent.value.trim()) return false
  if (currentContentType.value !== 'text' && selectedFiles.value.length === 0) return false
  if (!isAiAuto.value && !selectedCategory.value) return false
  return true
})

// 格式化时间
const formatTime = (timeStr) => {
  const date = new Date(timeStr)
  const now = new Date()
  const isToday = date.toDateString() === now.toDateString()
  
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  
  if (isToday) {
    return `${hours}:${minutes}`
  } else {
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    return `${month}-${day} ${hours}:${minutes}`
  }
}

// 滚动到底部
const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}

// 加载分类列表
const loadCategories = async () => {
  try {
    const res = await getCategories()
    categories.value = res
  } catch (error) {
    console.error('加载分类列表失败:', error)
  }
}

// 加载历史消息
const loadMessages = async () => {
  loading.value = true
  try {
    const res = await getMessages()
    messages.value = res
    scrollToBottom()
  } catch (error) {
    console.error('加载历史消息失败:', error)
  } finally {
    loading.value = false
  }
}

// 处理图片选择
const handleImageSelect = (e) => {
  const files = Array.from(e.target.files)
  if (files.length === 0) return
  
  selectedFiles.value = files
  currentContentType.value = 'image'
  audioDuration.value = 0
  ElMessage.success(`已选择${files.length}张图片`)
}

// 清除已选文件
const clearFiles = () => {
  selectedFiles.value = []
  currentContentType.value = 'text'
  audioDuration.value = 0
  imageInputRef.value.value = ''
}

// 切换录音状态
const handleRecordToggle = async () => {
  if (!recording.value) {
    // 开始录音
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      mediaRecorder = new MediaRecorder(stream)
      audioChunks = []
      recordStartTime = Date.now()
      
      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunks.push(e.data)
        }
      }
      
      mediaRecorder.onstop = () => {
        // 录音结束，生成音频文件
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' })
        const audioFile = new File([audioBlob], `recording_${Date.now()}.webm`, { type: 'audio/webm' })
        selectedFiles.value = [audioFile]
        currentContentType.value = 'audio'
        audioDuration.value = Math.round((Date.now() - recordStartTime) / 1000)
        ElMessage.success(`录音完成，时长${audioDuration.value}秒`)
        
        // 停止所有音频轨道
        stream.getTracks().forEach(track => track.stop())
      }
      
      mediaRecorder.start()
      recording.value = true
      ElMessage.success('开始录音，点击按钮停止')
    } catch (error) {
      console.error('录音失败:', error)
      ElMessage.error('无法访问麦克风，请检查权限设置')
    }
  } else {
    // 停止录音
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop()
    }
    recording.value = false
  }
}

// 发送消息
const handleSend = async () => {
  if (!canSend.value) {
    if (!isAiAuto.value && !selectedCategory.value) {
      ElMessage.warning('手动分类模式下请选择分类')
    }
    return
  }

  sending.value = true
  try {
    // 构造FormData
    const formData = new FormData()
    formData.append('sender_role', currentRole.value)
    formData.append('content_type', currentContentType.value)
    formData.append('is_ai_auto', isAiAuto.value)
    
    if (inputContent.value.trim()) {
      formData.append('content', inputContent.value.trim())
    }
    
    if (!isAiAuto.value && selectedCategory.value) {
      formData.append('manual_category', selectedCategory.value)
    }
    
    if (currentContentType.value === 'audio' && audioDuration.value > 0) {
      formData.append('audio_duration', audioDuration.value)
    }
    
    // 添加文件
    selectedFiles.value.forEach(file => {
      formData.append('files', file)
    })
    
    await sendMessage(formData)
    
    // 清空表单
    inputContent.value = ''
    clearFiles()
    selectedCategory.value = ''
    
    // 重新加载消息
    await loadMessages()
    ElMessage.success('发送成功')
  } catch (error) {
    console.error('发送消息失败:', error)
  } finally {
    sending.value = false
  }
}

// 页面加载时初始化
onMounted(() => {
  loadCategories()
  loadMessages()
})
</script>

<style scoped>
.chat-container {
  max-width: 800px;
  margin: 0 auto;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-color);
  border-left: 1px solid var(--el-color-primary-light-8);
  border-right: 1px solid var(--el-color-primary-light-8);
}

/* 头部样式 */
.chat-header {
  padding: 20px;
  text-align: center;
  background: linear-gradient(135deg, var(--el-color-primary-light-8) 0%, var(--bg-color) 100%);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.chat-title {
  font-size: 24px;
  color: var(--el-color-primary-dark-2);
  margin-bottom: 4px;
  font-weight: 600;
}

.chat-subtitle {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 消息列表样式 */
.message-list {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background-color: var(--bg-color);
}

.message-item {
  display: flex;
  margin-bottom: 20px;
  gap: 12px;
}

/* 男主消息：左侧对齐 */
.message-male {
  flex-direction: row;
}

.message-male .message-content {
  align-items: flex-start;
}

.message-male .message-bubble {
  background-color: var(--bubble-male);
  color: var(--text-male);
  border-bottom-left-radius: 4px;
}

/* 女主消息：右侧对齐 */
.message-female {
  flex-direction: row-reverse;
}

.message-female .message-content {
  align-items: flex-end;
}

.message-female .message-bubble {
  background-color: var(--bubble-female);
  color: var(--text-female);
  border-bottom-right-radius: 4px;
}

.message-female .message-meta {
  flex-direction: row-reverse;
}

/* 头像样式 */
.avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.avatar-male {
  background-color: var(--bubble-male);
}

.avatar-female {
  background-color: var(--bubble-female);
}

/* 消息内容样式 */
.message-content {
  display: flex;
  flex-direction: column;
  max-width: 75%;
}

.message-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 4px;
  font-size: 12px;
  color: var(--text-light);
}

.sender-nickname {
  font-weight: 500;
}

.message-bubble {
  padding: 12px 16px;
  border-radius: 18px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  line-height: 1.5;
  word-break: break-word;
}

/* 图片消息样式 */
.image-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 8px;
  margin-bottom: 8px;
}

.message-image {
  border-radius: 8px;
  width: 100%;
  height: 120px;
}

.image-caption {
  font-size: 14px;
  margin-top: 4px;
}

/* 语音消息样式 */
.audio-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 180px;
}

.audio-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.audio-icon {
  font-size: 18px;
}

.audio-content audio {
  width: 100%;
  height: 28px;
}

/* AI信息样式 */
.ai-info {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.ai-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 6px;
}

.category-tag {
  background-color: var(--el-color-primary-light-7);
  border-color: var(--el-color-primary);
  color: var(--el-color-primary-dark-2);
}

.sub-tag {
  background-color: transparent;
  border-color: var(--el-color-primary-light-3);
  color: var(--el-color-primary);
}

.ai-summary {
  font-size: 13px;
  color: var(--text-secondary);
  font-style: italic;
}

/* 空状态样式 */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-light);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 16px;
}

.empty-text {
  font-size: 14px;
}

/* 底部输入区域样式 */
.input-area {
  padding: 16px 20px;
  background-color: var(--bg-card);
  border-top: 1px solid var(--el-color-primary-light-8);
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.03);
}

/* 分类控制 */
.category-control {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.ai-switch-wrapper {
  flex-shrink: 0;
}

.category-select {
  flex: 1;
  min-width: 150px;
}

/* 功能按钮栏 */
.function-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.func-btn {
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 4px;
}

.recording-btn {
  color: var(--el-color-danger);
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% { opacity: 1; }
  50% { opacity: 0.6; }
  100% { opacity: 1; }
}

.selected-files {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: var(--text-secondary);
  background-color: var(--el-color-primary-light-9);
  padding: 4px 8px;
  border-radius: 4px;
}

.file-count {
  margin-right: 4px;
}

/* 输入框区域 */
.input-wrapper {
  display: flex;
  gap: 12px;
  align-items: flex-end;
}

.message-input {
  flex: 1;
}

.send-button {
  height: 40px;
  padding: 0 24px;
  border-radius: 20px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .chat-container {
    border: none;
  }
  
  .message-content {
    max-width: 80%;
  }
  
  .input-area {
    padding: 12px 16px;
    padding-bottom: calc(12px + env(safe-area-inset-bottom));
  }
  
  .send-button {
    padding: 0 16px;
  }
  
  .category-select {
    min-width: 120px;
  }
}
</style>
