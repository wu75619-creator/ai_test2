<template>
  <div class="category-container">
    <!-- 页面头部 -->
    <div class="page-header">
      <h1 class="page-title">💑 分类相册</h1>
      <p class="page-subtitle">所有甜蜜瞬间都在这里归档 ✨</p>
    </div>

    <!-- 分类Tab栏 -->
    <div class="category-tabs">
      <el-scrollbar>
        <div class="tabs-wrapper">
          <div
            v-for="category in categories"
            :key="category.category_id"
            class="category-tab"
            :class="{ active: currentCategoryKey === category.category_key }"
            @click="handleCategoryChange(category)"
          >
            <div class="tab-name">{{ category.category_name }}</div>
            <div class="tab-count">{{ category.message_count }}条</div>
          </div>
        </div>
      </el-scrollbar>
    </div>

    <!-- 时间筛选器 -->
    <div class="filter-bar">
      <el-date-picker
        v-model="dateRange"
        type="month"
        placeholder="选择年月筛选"
        format="YYYY-MM"
        value-format="YYYY-MM"
        @change="handleDateChange"
        clearable
        class="date-picker"
      />
      <el-button type="primary" text @click="loadMessages">刷新</el-button>
    </div>

    <!-- 消息卡片列表 -->
    <div class="message-list" v-loading="loading">
      <div
        v-for="message in messages"
        :key="message.message_id"
        class="message-card"
      >
        <!-- 卡片头部 -->
        <div class="card-header">
          <div class="sender-info">
            <div class="avatar" :class="message.sender_role === '男主' ? 'avatar-male' : 'avatar-female'">
              {{ message.sender_role === '男主' ? '👦' : '👧' }}
            </div>
            <div class="info-text">
              <div class="nickname">{{ message.sender_nickname }}</div>
              <div class="send-time">{{ formatTime(message.send_time) }}</div>
            </div>
          </div>
          <div class="ai-tags">
            <el-tag v-if="message.main_category_name" size="small" type="primary" class="category-tag">
              {{ message.main_category_name }}
            </el-tag>
            <el-tag v-for="tag in message.sub_tags" :key="tag" size="small" class="sub-tag">
              #{{ tag }}
            </el-tag>
          </div>
        </div>

        <!-- 卡片内容 -->
        <div class="card-content">
          <!-- 文字内容 -->
          <div v-if="message.content_type === 'text'" class="text-content">
            {{ message.content }}
          </div>

          <!-- 图片内容 -->
          <div v-else-if="message.content_type === 'image'" class="image-content">
            <el-image
              v-for="(url, index) in message.media_urls"
              :key="index"
              :src="url"
              fit="cover"
              class="card-image"
              :preview-src-list="message.media_urls"
            />
          </div>

          <!-- 语音内容 -->
          <div v-else-if="message.content_type === 'audio'" class="audio-content">
            <el-icon class="audio-icon"><Microphone /></el-icon>
            <span>{{ message.audio_duration }}''</span>
            <audio :src="message.media_urls[0]" controls preload="none"></audio>
          </div>
        </div>

        <!-- AI小结 -->
        <div v-if="message.ai_summary" class="ai-summary">
          💡 {{ message.ai_summary }}
        </div>
      </div>

      <!-- 空状态 -->
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div class="empty-icon">📸</div>
        <p class="empty-text">这个分类下还没有记录哦，快去聊天页面发送第一条吧~</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Microphone } from '@element-plus/icons-vue'
import { getCategories, getCategoryMessages } from '../api/category'

// 分类列表
const categories = ref([])
// 当前选中的分类Key
const currentCategoryKey = ref('food')
// 日期范围
const dateRange = ref('')
// 消息列表
const messages = ref([])
// 加载状态
const loading = ref(false)

// 格式化时间
const formatTime = (timeStr) => {
  const date = new Date(timeStr)
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  return `${year}-${month}-${day} ${hours}:${minutes}`
}

// 加载分类列表
const loadCategories = async () => {
  try {
    const res = await getCategories()
    categories.value = res
    if (res.length > 0) {
      currentCategoryKey.value = res[0].category_key
      await loadMessages()
    }
  } catch (error) {
    console.error('加载分类列表失败:', error)
  }
}

// 加载分类下的消息
const loadMessages = async () => {
  loading.value = true
  try {
    const params = {}
    if (dateRange.value) {
      const [year, month] = dateRange.value.split('-')
      params.year = parseInt(year)
      params.month = parseInt(month)
    }
    
    const res = await getCategoryMessages(currentCategoryKey.value, params)
    messages.value = res
  } catch (error) {
    console.error('加载分类消息失败:', error)
    ElMessage.error('加载失败，请稍后重试')
  } finally {
    loading.value = false
  }
}

// 切换分类
const handleCategoryChange = (category) => {
  currentCategoryKey.value = category.category_key
  loadMessages()
}

// 日期变化
const handleDateChange = () => {
  loadMessages()
}

onMounted(() => {
  loadCategories()
})
</script>

<style scoped>
.category-container {
  max-width: 800px;
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-color);
  padding-bottom: 80px;
}

/* 页面头部 */
.page-header {
  padding: 20px;
  text-align: center;
  background: linear-gradient(135deg, var(--el-color-primary-light-8) 0%, var(--bg-color) 100%);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.page-title {
  font-size: 24px;
  color: var(--el-color-primary-dark-2);
  margin-bottom: 4px;
  font-weight: 600;
}

.page-subtitle {
  font-size: 14px;
  color: var(--text-secondary);
}

/* 分类Tab栏 */
.category-tabs {
  padding: 16px 0;
  border-bottom: 1px solid var(--el-color-primary-light-8);
  background-color: var(--bg-card);
}

.tabs-wrapper {
  display: flex;
  gap: 12px;
  padding: 0 20px;
  white-space: nowrap;
}

.category-tab {
  padding: 8px 16px;
  border-radius: 20px;
  background-color: var(--el-color-primary-light-9);
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 0.3s ease;
  text-align: center;
  min-width: 80px;
}

.category-tab:hover {
  background-color: var(--el-color-primary-light-8);
}

.category-tab.active {
  background-color: var(--el-color-primary);
  color: white;
  border-color: var(--el-color-primary);
}

.tab-name {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 2px;
}

.tab-count {
  font-size: 12px;
  opacity: 0.8;
}

/* 筛选栏 */
.filter-bar {
  padding: 16px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: var(--bg-card);
  border-bottom: 1px solid var(--el-color-primary-light-8);
}

.date-picker {
  width: 180px;
}

/* 消息列表 */
.message-list {
  flex: 1;
  padding: 20px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}

.message-card {
  background-color: var(--bg-card);
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.05);
  border: 1px solid var(--el-color-primary-light-8);
  transition: all 0.3s ease;
}

.message-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(255, 133, 162, 0.15);
}

/* 卡片头部 */
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 12px;
}

.sender-info {
  display: flex;
  gap: 8px;
  align-items: center;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}

.avatar-male {
  background-color: var(--bubble-male);
}

.avatar-female {
  background-color: var(--bubble-female);
}

.info-text {
  display: flex;
  flex-direction: column;
}

.nickname {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-primary);
}

.send-time {
  font-size: 12px;
  color: var(--text-light);
}

.ai-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  justify-content: flex-end;
  max-width: 50%;
}

.category-tag {
  background-color: var(--el-color-primary-light-7);
  border-color: var(--el-color-primary);
  color: var(--el-color-primary-dark-2);
}

.sub-tag {
  background-color: transparent;
  border-color: var(--el-color-primary-light-3);
  color: var(--el-color-primary);
}

/* 卡片内容 */
.card-content {
  margin-bottom: 12px;
}

.text-content {
  font-size: 14px;
  line-height: 1.6;
  color: var(--text-primary);
  background-color: var(--el-color-primary-light-9);
  padding: 12px;
  border-radius: 8px;
}

.image-content {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 8px;
}

.card-image {
  border-radius: 8px;
  width: 100%;
  height: 100px;
}

.audio-content {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px;
  background-color: var(--el-color-primary-light-9);
  border-radius: 8px;
}

.audio-icon {
  font-size: 18px;
  color: var(--el-color-primary);
}

.audio-content audio {
  flex: 1;
  height: 24px;
  margin-left: 8px;
}

/* AI小结 */
.ai-summary {
  padding: 10px 12px;
  background-color: rgba(255, 133, 162, 0.08);
  border-radius: 8px;
  font-size: 13px;
  color: var(--text-secondary);
  font-style: italic;
  border-left: 3px solid var(--el-color-primary);
}

/* 空状态 */
.empty-state {
  grid-column: 1 / -1;
  text-align: center;
  padding: 60px 20px;
  color: var(--text-light);
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 16px;
}

.empty-text {
  font-size: 14px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .message-list {
    grid-template-columns: 1fr;
  }
  
  .ai-tags {
    max-width: 40%;
  }
}
</style>
