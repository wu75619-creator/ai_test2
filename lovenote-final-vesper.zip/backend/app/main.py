from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import asc, desc, func, extract
from datetime import datetime, date, timedelta
from typing import Optional, List
import os
import uuid
import json
import aiofiles
from pathlib import Path

from .database import get_db
from .models import User, Message, Category, AppSetting
from .init_db import init_database
from .services.ai_service import process_message_content

# ========== App Init ==========
init_database()

app = FastAPI(
    title="💕 情侣智能随手恋爱日记本 API",
    description="对话式记录 + AI自动归档 + 多媒体支持",
    version="3.0.0"
)

# CORS
cors_origins_str = os.getenv("CORS_ORIGINS", "*")
cors_origins = cors_origins_str.split(",") if cors_origins_str != "*" else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Upload dir
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")

# Static frontend (for production)
FRONTEND_DIST = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "frontend", "dist"))
if os.path.isdir(FRONTEND_DIST):
    if os.path.isdir(os.path.join(FRONTEND_DIST, "assets")):
        app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_DIST, "assets")), name="assets")


# ========== Helpers ==========
ALLOWED_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic'}
ALLOWED_VIDEO_EXTS = {'.mp4', '.webm', '.mov', '.avi', '.mkv', '.3gp'}
ALLOWED_AUDIO_EXTS = {'.webm', '.ogg', '.mp3', '.wav', '.m4a', '.aac', '.amr'}
MAX_FILE_SIZE = 200 * 1024 * 1024  # 200MB


def get_setting(db: Session) -> AppSetting:
    s = db.query(AppSetting).first()
    if not s:
        s = AppSetting(setup_completed=False)
        db.add(s)
        db.commit()
        db.refresh(s)
    return s


def serialize_msg(msg: Message, user: User = None, cat: Category = None) -> dict:
    return {
        "id": msg.id,
        "sender_id": msg.sender_id,
        "sender_role": user.role if user else "unknown",
        "sender_nickname": user.nickname if user else "未知",
        "sender_color": user.theme_color if user else "#ff6b9d",
        "message_type": msg.message_type,
        "text_content": msg.text_content or "",
        "media_urls": msg.media_urls or [],
        "voice_url": msg.voice_url,
        "voice_duration": msg.voice_duration,
        "video_url": msg.video_url,
        "video_duration": msg.video_duration,
        "tags": msg.tags or [],
        "ai_summary": msg.ai_summary,
        "ai_confidence": msg.ai_confidence,
        "category_code": cat.code if cat else None,
        "category_name": cat.name if cat else None,
        "category_icon": cat.icon if cat else None,
        "category_color": cat.color if cat else None,
        "sent_at": msg.sent_at.isoformat() if msg.sent_at else None,
        "ai_processed": msg.ai_processed
    }


def _save_upload(file: UploadFile, allowed_exts: set) -> tuple:
    """Save uploaded file, returns (url_path, file_size, ext)"""
    if not file.filename:
        return None, 0, ""
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in allowed_exts:
        # Try to infer from content-type
        ct = (file.content_type or "").lower()
        if ct.startswith("image/"):
            ext = ".jpg"
        elif ct.startswith("video/"):
            ext = ".mp4"
        elif ct.startswith("audio/"):
            ext = ".webm"
        else:
            ext = ".bin"
    filename = f"{uuid.uuid4()}{ext}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    content = file.file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="文件过大，最大200MB")
    with open(file_path, 'wb') as f:
        f.write(content)
    return f"/uploads/{filename}", len(content), ext


# ========== Health ==========
@app.get("/api/health", tags=["系统"])
async def health_check():
    return {"status": "ok", "message": "恋爱日记本API运行中 💕", "time": datetime.utcnow().isoformat()}


# ========== Settings / Onboarding ==========
@app.get("/api/settings", tags=["设置"])
async def get_app_settings(db: Session = Depends(get_db)):
    s = get_setting(db)
    # Sync nicknames to User table
    male = db.query(User).filter(User.role == "male").first()
    female = db.query(User).filter(User.role == "female").first()
    if male and s.male_nickname and male.nickname != s.male_nickname:
        male.nickname = s.male_nickname
    if female and s.female_nickname and female.nickname != s.female_nickname:
        female.nickname = s.female_nickname
    db.commit()

    return {
        "setup_completed": s.setup_completed,
        "male_nickname": s.male_nickname,
        "female_nickname": s.female_nickname,
        "love_start_date": s.love_start_date.isoformat() if s.love_start_date else None,
        "couple_title": s.couple_title,
        "has_password": bool(s.access_password),
        "male_color": male.theme_color if male else "#54a0ff",
        "female_color": female.theme_color if female else "#ff6b9d",
    }


@app.post("/api/settings", tags=["设置"])
async def update_settings(
    setup_completed: Optional[bool] = Form(None),
    male_nickname: Optional[str] = Form(None),
    female_nickname: Optional[str] = Form(None),
    love_start_date: Optional[str] = Form(None),
    access_password: Optional[str] = Form(None),
    couple_title: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    s = get_setting(db)
    if setup_completed is not None:
        s.setup_completed = setup_completed
    if male_nickname is not None:
        s.male_nickname = male_nickname.strip()
        male = db.query(User).filter(User.role == "male").first()
        if male:
            male.nickname = male_nickname.strip()
    if female_nickname is not None:
        s.female_nickname = female_nickname.strip()
        female = db.query(User).filter(User.role == "female").first()
        if female:
            female.nickname = female_nickname.strip()
    if love_start_date is not None:
        s.love_start_date = date.fromisoformat(love_start_date) if love_start_date else None
    if access_password is not None:
        s.access_password = access_password
    if couple_title is not None:
        s.couple_title = couple_title.strip()
    db.commit()
    db.refresh(s)
    return {"status": "ok", "setup_completed": s.setup_completed}


@app.post("/api/auth/verify", tags=["设置"])
async def verify_password(password: str = Form(...), db: Session = Depends(get_db)):
    s = get_setting(db)
    if not s.access_password:
        return {"ok": True}
    return {"ok": password == s.access_password}


@app.get("/api/auth/password", tags=["设置"])
async def check_password_required(db: Session = Depends(get_db)):
    s = get_setting(db)
    return {"required": bool(s.access_password)}


# ========== Categories ==========
@app.get("/api/categories", tags=["分类"])
async def get_categories(db: Session = Depends(get_db)):
    cats = db.query(Category).order_by(Category.is_system.desc(), Category.sort_order, Category.created_at).all()
    return [
        {"id": c.id, "code": c.code, "name": c.name, "icon": c.icon,
         "color": c.color, "description": c.description, "is_system": c.is_system}
        for c in cats
    ]


CUSTOM_COLORS = ["#ff9f43", "#54a0ff", "#ff6b9d", "#feca57", "#5f27cd",
                 "#00d2d3", "#10ac84", "#ee5253", "#ff9ff3", "#54a0ff"]
CUSTOM_ICONS = ["💕", "🌸", "🎀", "🏠", "🐱", "🎵", "📚", "🎮", "🍰", "🌙",
                "⭐", "🎁", "🌈", "🍀", "🦋", "🎨", "🏃", "🛍️", "🎂", "💝"]


@app.post("/api/categories", tags=["分类"])
async def create_custom_category(
    name: str = Form(...),
    icon: Optional[str] = Form(None),
    color: Optional[str] = Form(None),
    description: Optional[str] = Form(""),
    db: Session = Depends(get_db)
):
    name = name.strip()
    if not name or len(name) > 20:
        raise HTTPException(status_code=400, detail="分类名称1-20个字符")
    # Generate unique code
    code = f"custom_{uuid.uuid4().hex[:8]}"
    if not icon:
        icon = CUSTOM_ICONS[hash(name) % len(CUSTOM_ICONS)]
    if not color:
        color = CUSTOM_COLORS[hash(name + "c") % len(CUSTOM_COLORS)]
    # Get next sort_order
    max_order = db.query(func.max(Category.sort_order)).scalar() or 8
    cat = Category(
        code=code, name=name, icon=icon, color=color,
        description=description or "自定义分类",
        sort_order=max_order + 1, is_system=False,
        created_at=datetime.utcnow()
    )
    db.add(cat)
    db.commit()
    db.refresh(cat)
    return {"id": cat.id, "code": cat.code, "name": cat.name, "icon": cat.icon,
            "color": cat.color, "description": cat.description, "is_system": False}


@app.delete("/api/categories/{code}", tags=["分类"])
async def delete_category(code: str, db: Session = Depends(get_db)):
    cat = db.query(Category).filter(Category.code == code).first()
    if not cat:
        raise HTTPException(status_code=404, detail="分类不存在")
    if cat.is_system:
        raise HTTPException(status_code=403, detail="系统预置分类不可删除")
    # Reassign messages to daily_fun
    daily = db.query(Category).filter(Category.code == "daily_fun").first()
    if daily:
        db.query(Message).filter(Message.main_category_id == cat.id).update(
            {"main_category_id": daily.id}
        )
    db.delete(cat)
    db.commit()
    return {"status": "ok"}


@app.put("/api/categories/{code}", tags=["分类"])
async def update_category(
    code: str,
    name: Optional[str] = Form(None),
    icon: Optional[str] = Form(None),
    color: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    cat = db.query(Category).filter(Category.code == code).first()
    if not cat:
        raise HTTPException(status_code=404, detail="分类不存在")
    if name:
        cat.name = name.strip()
    if icon:
        cat.icon = icon
    if color:
        cat.color = color
    db.commit()
    return {"status": "ok"}


# ========== Messages ==========
@app.post("/api/messages", tags=["消息"])
async def create_message(
    sender_role: str = Form(...),
    text_content: Optional[str] = Form(""),
    is_ai_auto: bool = Form(True),
    manual_category: Optional[str] = Form(None),
    voice_duration: Optional[int] = Form(None),
    video_duration: Optional[int] = Form(None),
    images: List[UploadFile] = File(None),
    voice: Optional[UploadFile] = File(None),
    video: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db)
):
    if sender_role not in ("male", "female"):
        raise HTTPException(status_code=400, detail="sender_role必须是male或female")

    sender = db.query(User).filter(User.role == sender_role).first()
    if not sender:
        raise HTTPException(status_code=404, detail=f"未找到{sender_role}用户")

    if not is_ai_auto and not manual_category:
        raise HTTPException(status_code=400, detail="手动分类模式必须选择分类")

    message_type = "text"
    media_urls = []
    voice_url = None
    video_url = None
    v_duration = voice_duration
    vid_duration = video_duration
    media_size = 0
    saved_image_paths = []

    # Process images
    if images:
        for f in images:
            if not f.filename:
                continue
            ext = os.path.splitext(f.filename)[1].lower()
            # Skip videos accidentally sent in images field
            if ext in ALLOWED_VIDEO_EXTS and not video:
                url, sz, _ = _save_upload(f, ALLOWED_VIDEO_EXTS)
                if url:
                    video_url = url
                    media_size += sz
                    message_type = "video"
                continue
            url, sz, ext_saved = _save_upload(f, ALLOWED_IMAGE_EXTS)
            if url:
                media_urls.append(url)
                media_size += sz
                if message_type not in ("video", "voice"):
                    message_type = "image"
                saved_image_paths.append(os.path.join(UPLOAD_DIR, os.path.basename(url)))

    # Process video (dedicated field)
    if video and video.filename:
        url, sz, _ = _save_upload(video, ALLOWED_VIDEO_EXTS)
        if url:
            video_url = url
            media_size += sz
            message_type = "video"

    # Process voice
    if voice and voice.filename:
        url, sz, _ = _save_upload(voice, ALLOWED_AUDIO_EXTS)
        if url:
            voice_url = url
            media_size += sz
            message_type = "voice"

    now = datetime.utcnow()

    # AI classification
    ai_result = process_message_content(
        text_content=text_content or "",
        message_type=message_type,
        image_paths=saved_image_paths,
        manual_category=manual_category if not is_ai_auto else None,
        db=db
    )

    main_cat = db.query(Category).filter(Category.code == ai_result["main_category_code"]).first()
    main_cat_id = main_cat.id if main_cat else None

    # Voice messages always get the voice category
    if message_type == "voice":
        voice_cat = db.query(Category).filter(Category.code == "voice").first()
        if voice_cat:
            main_cat_id = voice_cat.id
            ai_result["main_category_code"] = "voice"
            ai_result["main_category_name"] = voice_cat.name

    msg = Message(
        sender_id=sender.id,
        message_type=message_type,
        text_content=text_content or "",
        media_urls=media_urls if media_urls else None,
        voice_url=voice_url,
        voice_duration=v_duration if v_duration else (5 if voice_url else None),
        video_url=video_url,
        video_duration=vid_duration,
        media_size=media_size,
        sent_at=now,
        hour_of_day=now.hour,
        main_category_id=main_cat_id,
        tags=ai_result["tags"],
        ai_summary=ai_result["ai_summary"],
        ai_confidence=ai_result["confidence"],
        ai_processed=True,
        ai_processed_at=now,
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)

    return serialize_msg(msg, sender, main_cat)


@app.get("/api/messages", tags=["消息"])
async def get_messages(
    limit: Optional[int] = None,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    query = db.query(Message).filter(Message.is_deleted == False).order_by(asc(Message.sent_at))
    if limit:
        query = query.offset(offset).limit(limit)
    messages = query.all()

    user_map = {u.id: u for u in db.query(User).all()}
    cat_map = {c.id: c for c in db.query(Category).all()}

    return [serialize_msg(m, user_map.get(m.sender_id), cat_map.get(m.main_category_id)) for m in messages]


@app.delete("/api/messages/{msg_id}", tags=["消息"])
async def delete_message(msg_id: str, db: Session = Depends(get_db)):
    msg = db.query(Message).filter(Message.id == msg_id).first()
    if not msg:
        raise HTTPException(status_code=404, detail="消息不存在")
    msg.is_deleted = True
    db.commit()
    return {"status": "ok"}


@app.get("/api/categories/{category_code}/messages", tags=["分类"])
async def get_category_messages(
    category_code: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    cat = db.query(Category).filter(Category.code == category_code).first()
    if not cat:
        raise HTTPException(status_code=404, detail=f"分类 {category_code} 不存在")

    query = db.query(Message).filter(
        Message.is_deleted == False,
        Message.main_category_id == cat.id
    )
    if year:
        query = query.filter(extract('year', Message.sent_at) == year)
    if month:
        query = query.filter(extract('month', Message.sent_at) == month)

    messages = query.order_by(desc(Message.sent_at)).all()
    user_map = {u.id: u for u in db.query(User).all()}
    return [serialize_msg(m, user_map.get(m.sender_id), cat) for m in messages]


# ========== Statistics ==========
@app.get("/api/stats/overview", tags=["统计"])
async def get_stats_overview(db: Session = Depends(get_db)):
    s = get_setting(db)
    now = datetime.utcnow().date()

    # Love days
    love_days = None
    if s.love_start_date:
        love_days = (now - s.love_start_date).days + 1

    # Total counts
    total_msgs = db.query(func.count(Message.id)).filter(Message.is_deleted == False).scalar() or 0
    male_id = db.query(User.id).filter(User.role == "male").first()
    female_id = db.query(User.id).filter(User.role == "female").first()
    male_id = male_id[0] if male_id else None
    female_id = female_id[0] if female_id else None

    male_count = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.sender_id == male_id
    ).scalar() or 0 if male_id else 0
    female_count = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.sender_id == female_id
    ).scalar() or 0 if female_id else 0

    # Media counts
    img_count = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.message_type == "image"
    ).scalar() or 0
    voice_count = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.message_type == "voice"
    ).scalar() or 0
    video_count = db.query(func.count(Message.id)).filter(
        Message.is_deleted == False, Message.message_type == "video"
    ).scalar() or 0

    # Categories count
    cat_counts = {}
    cats = db.query(Category).all()
    for c in cats:
        cnt = db.query(func.count(Message.id)).filter(
            Message.is_deleted == False, Message.main_category_id == c.id
        ).scalar() or 0
        cat_counts[c.code] = {"name": c.name, "icon": c.icon, "count": cnt, "color": c.color}

    return {
        "love_days": love_days,
        "love_start_date": s.love_start_date.isoformat() if s.love_start_date else None,
        "total_messages": total_msgs,
        "male_count": male_count,
        "female_count": female_count,
        "image_count": img_count,
        "voice_count": voice_count,
        "video_count": video_count,
        "male_nickname": s.male_nickname,
        "female_nickname": s.female_nickname,
        "categories": cat_counts,
        "couple_title": s.couple_title,
    }


def _get_period_stats(db: Session, start_dt: datetime, end_dt: datetime) -> dict:
    """Get stats for a time period"""
    msgs = db.query(Message).filter(
        Message.is_deleted == False,
        Message.sent_at >= start_dt,
        Message.sent_at < end_dt
    ).all()

    male = db.query(User).filter(User.role == "male").first()
    female = db.query(User).filter(User.role == "female").first()
    male_id = male.id if male else None
    female_id = female.id if female else None

    male_msgs = [m for m in msgs if m.sender_id == male_id]
    female_msgs = [m for m in msgs if m.sender_id == female_id]

    # Hour distribution
    hour_dist = [0] * 24
    for m in msgs:
        h = m.sent_at.hour if m.sent_at else 12
        hour_dist[h] += 1

    # Peak hour
    peak_hour = hour_dist.index(max(hour_dist)) if msgs else 12

    # Category distribution
    cat_map = {c.id: c for c in db.query(Category).all()}
    cat_dist = {}
    for m in msgs:
        code = cat_map.get(m.main_category_id).code if cat_map.get(m.main_category_id) else "other"
        cat_dist[code] = cat_dist.get(code, 0) + 1

    # Day-by-day
    day_stats = {}
    for m in msgs:
        d = m.sent_at.date().isoformat()
        if d not in day_stats:
            day_stats[d] = {"total": 0, "male": 0, "female": 0}
        day_stats[d]["total"] += 1
        if m.sender_id == male_id:
            day_stats[d]["male"] += 1
        else:
            day_stats[d]["female"] += 1

    # Type distribution
    type_dist = {}
    for m in msgs:
        t = m.message_type
        type_dist[t] = type_dist.get(t, 0) + 1

    return {
        "total": len(msgs),
        "male_count": len(male_msgs),
        "female_count": len(female_msgs),
        "hour_distribution": hour_dist,
        "peak_hour": peak_hour,
        "peak_label": _format_hour_label(peak_hour),
        "category_distribution": cat_dist,
        "day_stats": day_stats,
        "type_distribution": type_dist,
    }


def _format_hour_label(h: int) -> str:
    if 0 <= h < 6:
        return f"凌晨{h}点"
    elif 6 <= h < 12:
        return f"上午{h}点"
    elif h == 12:
        return "中午12点"
    elif 13 <= h < 18:
        return f"下午{h-12}点"
    else:
        return f"晚上{h-12}点"


@app.get("/api/stats/weekly", tags=["统计"])
async def get_weekly_stats(db: Session = Depends(get_db)):
    today = datetime.utcnow().date()
    # Start from Monday
    start = today - timedelta(days=today.weekday())
    start_dt = datetime.combine(start, datetime.min.time())
    end_dt = start_dt + timedelta(days=7)
    stats = _get_period_stats(db, start_dt, end_dt)
    stats["period_start"] = start.isoformat()
    stats["period_end"] = (start + timedelta(days=6)).isoformat()
    stats["period_label"] = f"{start.month}月{start.day}日 - {start.month}月{start.day+6}日"
    return stats


@app.get("/api/stats/monthly", tags=["统计"])
async def get_monthly_stats(
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    today = datetime.utcnow().date()
    y = year or today.year
    m = month or today.month
    start = date(y, m, 1)
    if m == 12:
        end = date(y + 1, 1, 1)
    else:
        end = date(y, m + 1, 1)
    start_dt = datetime.combine(start, datetime.min.time())
    end_dt = datetime.combine(end, datetime.min.time())
    stats = _get_period_stats(db, start_dt, end_dt)
    stats["period_start"] = start.isoformat()
    stats["period_end"] = (end - timedelta(days=1)).isoformat()
    stats["period_label"] = f"{y}年{m}月"
    return stats


# ========== Serve Frontend (SPA fallback) ==========
@app.get("/{full_path:path}", include_in_schema=False)
async def serve_frontend(full_path: str):
    # Never serve SPA for API routes
    if full_path.startswith("api/") or full_path == "api" or full_path.startswith("uploads/"):
        raise HTTPException(status_code=404, detail="Not found")
    index_path = os.path.join(FRONTEND_DIST, "index.html") if os.path.isdir(FRONTEND_DIST) else None
    if index_path and os.path.exists(index_path):
        file_path = os.path.join(FRONTEND_DIST, full_path)
        if full_path and os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(index_path)
    return {"message": "API running. Docs at /docs", "status": "ok"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    host = os.getenv("HOST", "0.0.0.0")
    uvicorn.run(app, host=host, port=port)
