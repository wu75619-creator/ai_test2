# 💕 情侣智能随手恋爱日记本

对话式随手记录、AI 自动分类归档的双人专属恋爱记忆存档工具。

## ✨ 核心功能

- 💬 **聊天式记录** - 仿微信聊天界面，支持文字、图片、语音、视频随手发送
- 🤖 **AI智能分类** - AI自动识别内容归档到8大预设分类，支持手动选择
- 📂 **自定义分类** - 用户可创建/删除自定义分类标签
- 📊 **恋爱统计** - 周度/月度活跃度统计、时间段分布、分类分布可视化
- 💝 **恋爱天数** - 悬浮卡片实时显示在一起的天数
- 🎤 **语音录制** - 内置实时录音，波形可视化，可播放进度拖拽
- 🎬 **视频录制** - 支持手机摄像头直接录制短视频
- 🔒 **密码保护** - 可设置访问密码保护隐私
- 📱 **全端适配** - 手机/平板/电脑完美响应式布局

## 🛠 技术栈

| 层级 | 技术 |
|------|------|
| 前端 | Vue 3 + TypeScript + Vite + Element Plus |
| 后端 | Python FastAPI + SQLAlchemy |
| 数据库 | SQLite（零配置部署）|
| AI | Mock模式（默认）/ OpenAI GPT-4o（可选）|

## 🚀 快速开始

### 方式一：本地运行

```bash
# 1. 克隆项目后安装依赖
cd backend && pip3 install -r requirements.txt
cd ../frontend && npm install

# 2. 构建前端
cd frontend && npx vite build

# 3. 启动后端（同时托管前端静态文件）
cd ../backend && python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

浏览器打开 http://localhost:8000 即可使用。

### 方式二：一键启动脚本

```bash
chmod +x start.sh
./start.sh
```

### 方式三：Docker 部署

```bash
docker build -t lovenote .
docker run -d -p 8000:8000 -v $(pwd)/data:/app/backend lovenote
```

## 🌐 永久在线部署

### Render（推荐，免费）

1. Fork本项目到你的GitHub
2. 在Render.com创建新的Web Service
3. 连接你的GitHub仓库
4. 选择Docker环境，或使用以下配置：
   - **Build Command**: `pip install -r backend/requirements.txt && cd frontend && npm install && npx vite build`
   - **Start Command**: `cd backend && uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. 添加Disk（1GB即可）挂载到 `/app/backend` 保存数据库和上传文件

### Railway / Fly.io

支持通过 `Dockerfile` 直接部署，或使用 `Procfile`。

### Vercel（前端） + 独立后端

如需将前端部署到Vercel：
1. 修改 `frontend/vite.config.ts` 中的代理目标为你的后端URL
2. 修改 `frontend/src/utils/request.ts` 中的 `API_BASE` 为你的后端地址
3. `cd frontend && npx vite build` 后将dist部署到Vercel
4. 后端单独部署到Render/Railway

## ⚙️ 环境变量

在 `backend/.env` 文件中配置：

```env
# AI模式（默认Mock，无需API Key）
AI_MOCK=true

# 真实AI（AI_MOCK=false时需要）
OPENAI_API_KEY=sk-xxx
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini

# 端口和主机
PORT=8000
HOST=0.0.0.0

# 数据库
DATABASE_URL=sqlite:///./love_diary.db

# 访问密码（可选，留空则不启用）
ACCESS_PASSWORD=
```

## 📱 使用说明

1. **首次进入**：填写双方昵称和在一起的日期，可选设密码
2. **记录内容**：点击底部聊天页，可发送文字/图片/语音/视频
3. **AI分类**：默认AI自动归档，也可关闭AI手动选择分类
4. **查看相册**：点击底部"相册"按分类浏览所有记录，支持新建自定义分类
5. **查看统计**：点击"时光"查看恋爱时间轴和周/月统计数据
6. **修改设置**：点击右上角设置图标修改昵称/日期/密码

## 📊 API接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/health | 健康检查 |
| GET | /api/settings | 获取设置 |
| POST | /api/settings | 更新设置（引导/昵称/日期/密码）|
| GET | /api/auth/password | 检查是否需要密码 |
| POST | /api/auth/verify | 验证密码 |
| GET | /api/categories | 获取所有分类 |
| POST | /api/categories | 创建自定义分类 |
| DELETE | /api/categories/{code} | 删除自定义分类 |
| GET | /api/messages | 获取所有消息 |
| POST | /api/messages | 发送消息（支持文字/图片/语音/视频）|
| GET | /api/categories/{code}/messages | 按分类获取消息 |
| GET | /api/stats/overview | 总览统计（恋爱天数等）|
| GET | /api/stats/weekly | 周统计 |
| GET | /api/stats/monthly | 月统计 |

## 🔒 隐私说明

- 所有数据存储在你自己的服务器/数据库中
- 支持设置访问密码
- 图片/语音/视频文件存储在本地uploads目录
- AI模式默认本地Mock，不上传任何数据到外部API
