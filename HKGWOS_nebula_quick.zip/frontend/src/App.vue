<template>
  <router-view />
</template>

<script setup>
// 根组件：仅渲染路由视图，业务由 ChatView.vue 承载
</script>

<style>
#app {
  width: 100%;
  height: 100%;
}
</style>
