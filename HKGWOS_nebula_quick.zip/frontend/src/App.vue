<template>
  <div class="app-shell">
    <!-- 主内容区 -->
    <main class="app-main">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>

    <!-- 底部导航栏（移动端 TabBar） -->
    <nav class="tab-bar">
      <router-link
        v-for="r in routes"
        :key="r.path"
        :to="r.path"
        class="tab-item"
        :class="{ active: $route.path === r.path }"
      >
        <el-icon class="tab-icon"><component :is="iconMap[r.meta.icon]" /></el-icon>
        <span class="tab-label">{{ r.meta.title }}</span>
      </router-link>
    </nav>
  </div>
</template>

<script setup>
import { routes } from './router'
import { ChatDotRound, PictureFilled, Clock } from '@element-plus/icons-vue'

const iconMap = {
  ChatDotRound,
  PictureFilled,
  Clock
}
</script>

<style>
/* 全局重置 */
html, body, #app {
  height: 100%;
  margin: 0;
  padding: 0;
  overflow: hidden;
}

.app-shell {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 720px;
  margin: 0 auto;
  background: var(--theme-cream);
  box-shadow: var(--theme-soft-shadow);
  position: relative;
}

.app-main {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
}

/* 路由切换动画 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* 底部导航 */
.tab-bar {
  display: flex;
  justify-content: space-around;
  align-items: center;
  height: 60px;
  background: #fff;
  border-top: 1px solid #ffe0ec;
  box-shadow: 0 -2px 12px rgba(255, 143, 171, 0.08);
  flex-shrink: 0;
}
.tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  text-decoration: none;
  color: #b08898;
  font-size: 11px;
  padding: 6px 16px;
  border-radius: 12px;
  transition: all 0.2s ease;
}
.tab-item:hover {
  color: var(--el-color-primary);
  background: var(--el-color-primary-light-9);
}
.tab-item.active {
  color: var(--el-color-primary);
}
.tab-item.active .tab-icon {
  transform: scale(1.15);
}
.tab-icon {
  font-size: 22px;
  transition: transform 0.2s ease;
}
.tab-label {
  font-size: 11px;
  font-weight: 500;
}
</style>
