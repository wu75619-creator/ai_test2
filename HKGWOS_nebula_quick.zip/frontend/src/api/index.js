import axios from 'axios'
import { ElMessage } from 'element-plus'

// 后端 API 基础地址（开发环境默认连本地 FastAPI 8000 端口）
const BASE_URL = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

const http = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' }
})

// 响应拦截：统一错误提示
http.interceptors.response.use(
  (res) => res,
  (err) => {
    const msg = err?.response?.data?.detail || err.message || '请求失败'
    ElMessage.error(`接口错误：${msg}`)
    return Promise.reject(err)
  }
)

/**
 * 获取全部历史消息（正序时间轴）
 */
export function fetchMessages(params = {}) {
  return http.get('/api/messages', { params }).then((r) => r.data)
}

/**
 * 发送一条消息
 * @param {Object} payload { sender_role: 'MALE'|'FEMALE', text_content: string }
 */
export function createMessage(payload) {
  return http.post('/api/messages', payload).then((r) => r.data)
}

export default http
