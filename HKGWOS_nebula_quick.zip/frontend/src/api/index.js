import axios from 'axios'
import { ElMessage } from 'element-plus'

const BASE_URL = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

const http = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,  // 上传大文件需要更长超时
})

http.interceptors.response.use(
  (res) => res,
  (err) => {
    const msg = err?.response?.data?.detail || err.message || '请求失败'
    ElMessage.error(`接口错误：${msg}`)
    return Promise.reject(err)
  }
)

/** 拉取历史消息（聊天页，正序） */
export function fetchMessages(params = {}) {
  return http.get('/api/messages', { params: { order: 'asc', ...params } }).then((r) => r.data)
}

/** 拉取时间轴消息（倒序） */
export function fetchTimelineMessages(params = {}) {
  return http.get('/api/messages', { params: { order: 'desc', limit: 500, ...params } }).then((r) => r.data)
}

/**
 * 发送消息（multipart/form-data）
 * @param {Object} opts
 * @param {string} opts.sender_role  MALE/FEMALE
 * @param {string} [opts.text_content]
 * @param {File[]} [opts.images]
 * @param {boolean} opts.is_ai_auto
 * @param {string} [opts.manual_category]
 */
export function createMessage(opts) {
  const fd = new FormData()
  fd.append('sender_role', opts.sender_role)
  if (opts.text_content) fd.append('text_content', opts.text_content)
  fd.append('is_ai_auto', String(opts.is_ai_auto))
  if (!opts.is_ai_auto && opts.manual_category) {
    fd.append('manual_category', opts.manual_category)
  }
  if (opts.images && opts.images.length > 0) {
    opts.images.forEach((f) => fd.append('images', f))
  }
  return http.post('/api/messages', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }).then((r) => r.data)
}

/** 获取分类统计 */
export function fetchCategories() {
  return http.get('/api/categories').then((r) => r.data)
}

/** 按分类拉取记录 */
export function fetchCategoryMessages(category, params = {}) {
  return http.get(`/api/categories/${category}`, { params }).then((r) => r.data)
}

export default http
