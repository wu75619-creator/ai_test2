import { createRouter, createWebHistory } from 'vue-router'
import ChatView from '../views/ChatView.vue'
import CategoryView from '../views/CategoryView.vue'
import TimelineView from '../views/TimelineView.vue'

export const routes = [
  { path: '/', name: 'Chat', component: ChatView, meta: { title: '聊天', icon: 'ChatDotRound' } },
  { path: '/category', name: 'Category', component: CategoryView, meta: { title: '分类相册', icon: 'PictureFilled' } },
  { path: '/timeline', name: 'Timeline', component: TimelineView, meta: { title: '恋爱时间轴', icon: 'Clock' } }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.meta?.title) {
    document.title = `${to.meta.title} · 情侣智能随手恋爱日记本`
  }
  next()
})

export default router
