<template>
  <div class="timeline-page">
    <!-- 顶部栏 -->
    <header class="page-header">
      <div class="title">
        <span class="icon">⏳</span>
        <span>恋爱时间轴</span>
      </div>
      <div class="subtitle">完整还原我们的恋爱全过程 💗</div>
    </header>

    <!-- 排序切换 -->
    <div class="toolbar">
      <el-radio-group v-model="sortOrder" size="small" @change="loadMessages">
        <el-radio-button label="desc">最新在前</el-radio-button>
        <el-radio-button label="asc">最早在前</el-radio-button>
      </el-radio-group>
      <span class="total-tip">共 {{ messages.length }} 条记录</span>
    </div>

    <!-- 时间轴主体 -->
    <main class="timeline-wrap" v-loading="loading">
      <div v-if="!loading && messages.length === 0" class="empty-tip">
        <span>还没有任何记录，去聊天页发第一条吧～</span>
      </div>

      <el-timeline v-else>
        <el-timeline-item
          v-for="(msg, idx) in messages"
          :key="msg.id"
          :timestamp="formatFull(msg.created_at)"
          :type="timelineType(msg.sender_role)"
          :hollow="msg.manual_override"
        >
          <template #dot>
            <div class="dot" :class="msg.sender_role === 'MALE' ? 'dot-male' : 'dot-female'">
              {{ msg.sender_role === 'MALE' ? '♂' : '♀' }}
            </div>
          </template>

          <div class="timeline-card">
            <div class="card-header">
              <div class="avatar" :class="msg.sender_role === 'MALE' ? 'male' : 'female'">
                {{ msg.sender_role === 'MALE' ? '男主' : '女主' }}
              </div>
              <el-tag
                v-if="msg.main_category"
                size="small"
                type="warning"
                effect="light"
              >
                🏷️ {{ categoryLabel(msg.main_category) }}
              </el-tag>
            </div>
            <div class="card-content">{{ msg.text_content }}</div>
            <div v-if="msg.ai_summary" class="ai-summary">
              <span class="ai-icon">💭</span>
              <span>{{ msg.ai_summary }}</span>
            </div>
            <div v-if="msg.sub_tags && msg.sub_tags.length > 0" class="sub-tags">
              <el-tag
                v-for="tag in msg.sub_tags"
                :key="tag"
                size="small"
                effect="plain"
              >
                #{{ tag }}
              </el-tag>
            </div>
          </div>
        </el-timeline-item>
      </el-timeline>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { fetchTimelineMessages } from '../api'

const messages = ref([])
const loading = ref(false)
const sortOrder = ref('desc')

const LABELS = {
  FOOD: '美食探店',
  TRAVEL_DATE: '旅行约会',
  COUPLE_PHOTO: '情侣合照',
  FUN_DAILY: '趣味日常',
  NICKNAME: '专属昵称',
  DEEP_TALK: '深度谈心',
  CONFLICT: '矛盾复盘',
  VOICE_ONLY: '语音专属'
}
const categoryLabel = (c) => LABELS[c] || c
const timelineType = (role) => (role === 'MALE' ? 'primary' : 'danger')

function formatFull(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

async function loadMessages() {
  loading.value = true
  try {
    const list = await fetchTimelineMessages({ order: sortOrder.value })
    messages.value = list
  } catch (e) {
    console.error('加载时间轴失败', e)
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.timeline-page {
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background: var(--theme-bg-gradient);
}

.page-header {
  padding: 16px 16px 12px;
  background: #fff;
  border-bottom: 1px solid #ffe0ec;
  position: sticky;
  top: 0;
  z-index: 10;
}
.title {
  font-size: 18px;
  font-weight: 600;
  color: #c2185b;
  display: flex;
  align-items: center;
  gap: 6px;
}
.title .icon {
  font-size: 20px;
}
.subtitle {
  font-size: 12px;
  color: #b08898;
  margin-top: 4px;
}

.toolbar {
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  background: #fff8fa;
  border-bottom: 1px solid #ffe0ec;
}
.total-tip {
  margin-left: auto;
  font-size: 12px;
  color: #b08898;
}

.timeline-wrap {
  padding: 20px 16px 100px;
}
.empty-tip {
  text-align: center;
  color: #c0a0b0;
  padding: 60px 20px;
}

/* 自定义圆点 */
.dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  color: #fff;
  font-weight: bold;
}
.dot-male {
  background: linear-gradient(135deg, #64b5f6, #1e88e5);
}
.dot-female {
  background: linear-gradient(135deg, #ff8fab, #ff5c8a);
}

.timeline-card {
  background: #fff;
  border-radius: 14px;
  padding: 14px 16px;
  box-shadow: 0 3px 12px rgba(255, 143, 171, 0.1);
  margin-bottom: 6px;
  transition: transform 0.2s ease;
}
.timeline-card:hover {
  transform: translateX(4px);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}
.avatar {
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
}
.avatar.male {
  background: linear-gradient(135deg, #64b5f6, #1e88e5);
}
.avatar.female {
  background: linear-gradient(135deg, #ff8fab, #ff5c8a);
}

.card-content {
  font-size: 14px;
  line-height: 1.6;
  color: #4a4a4a;
  background: #fff5f8;
  padding: 10px 12px;
  border-radius: 10px;
  margin-bottom: 10px;
}

.ai-summary {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  font-size: 12px;
  color: #9e7a8a;
  font-style: italic;
  padding: 8px 10px;
  background: #fff0f3;
  border-radius: 8px;
  border-left: 3px solid #ffc8dd;
  margin-bottom: 8px;
}
.ai-icon {
  flex-shrink: 0;
}

.sub-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
</style>
