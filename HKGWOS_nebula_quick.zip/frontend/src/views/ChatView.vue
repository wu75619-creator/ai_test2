<template>
  <div class="chat-page">
    <!-- 顶部栏 -->
    <header class="chat-header">
      <div class="title">
        <span class="heart">💗</span>
        <span>情侣智能恋爱日记本</span>
      </div>
      <div class="role-switch">
        <el-radio-group v-model="myRole" size="small">
          <el-radio-button label="MALE">男主</el-radio-button>
          <el-radio-button label="FEMALE">女主</el-radio-button>
        </el-radio-group>
      </div>
    </header>

    <!-- 消息流 -->
    <main class="chat-body" ref="chatBodyRef">
      <div v-if="loading" class="empty-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        <span>加载中…</span>
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <span>还没有消息，发条甜言蜜语吧～</span>
      </div>

      <div
        v-for="msg in messages"
        :key="msg.id"
        class="msg-row"
        :class="isMe(msg) ? 'msg-me' : 'msg-other'"
      >
        <!-- 头像 -->
        <div class="avatar" :class="roleClass(msg.sender_role)">
          {{ roleLabel(msg.sender_role) }}
        </div>

        <!-- 气泡 -->
        <div class="bubble-wrap">
          <div class="meta">
            <span class="nickname">{{ roleLabel(msg.sender_role) }}</span>
            <span class="time">{{ formatTime(msg.created_at) }}</span>
          </div>
          <div class="bubble" :class="`bubble-${roleClass(msg.sender_role)}`">
            {{ msg.text_content }}
          </div>
          <!-- AI 分类徽标（异步填充后显示） -->
          <div v-if="msg.main_category" class="ai-tag">
            <el-tag size="small" type="warning" effect="light">
              🏷️ {{ categoryLabel(msg.main_category) }}
            </el-tag>
            <span v-if="msg.ai_summary" class="ai-summary">💭 {{ msg.ai_summary }}</span>
          </div>
        </div>
      </div>
    </main>

    <!-- 底部输入区 -->
    <footer class="chat-footer">
      <el-input
        v-model="inputText"
        type="textarea"
        :autosize="{ minRows: 1, maxRows: 4 }"
        placeholder="随手记一句，AI 会自动帮你归档～"
        @keydown.enter.exact.prevent="onSend"
        :disabled="sending"
      />
      <el-button
        type="primary"
        class="send-btn"
        :loading="sending"
        @click="onSend"
      >
        发送
      </el-button>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, watch } from 'vue'
import { Loading } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { fetchMessages, createMessage } from '../api'

// ============ 状态 ============
const messages = ref([])
const loading = ref(false)
const sending = ref(false)
const inputText = ref('')
const myRole = ref('FEMALE') // 默认以女主身份发送，可切换
const chatBodyRef = ref(null)

// ============ 八大主分类中文映射 ============
const CATEGORY_MAP = {
  FOOD: '美食探店',
  TRAVEL_DATE: '旅行约会',
  COUPLE_PHOTO: '情侣合照',
  FUN_DAILY: '趣味日常',
  NICKNAME: '专属昵称',
  DEEP_TALK: '深度谈心',
  CONFLICT: '矛盾复盘',
  VOICE_ONLY: '语音专属'
}

// ============ 工具函数 ============
const isMe = (msg) => msg.sender_role === myRole.value
const roleLabel = (r) => (r === 'MALE' ? '男主' : r === 'FEMALE' ? '女主' : r)
const roleClass = (r) => (r === 'MALE' ? 'male' : 'female')
const categoryLabel = (c) => CATEGORY_MAP[c] || c

function formatTime(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const pad = (n) => String(n).padStart(2, '0')
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function scrollToBottom() {
  nextTick(() => {
    if (chatBodyRef.value) {
      chatBodyRef.value.scrollTop = chatBodyRef.value.scrollHeight
    }
  })
}

// ============ 拉取历史 ============
async function loadMessages() {
  loading.value = true
  try {
    const list = await fetchMessages()
    messages.value = list
    scrollToBottom()
  } catch (e) {
    console.error('拉取历史失败', e)
  } finally {
    loading.value = false
  }
}

// ============ 发送消息 ============
async function onSend() {
  const text = inputText.value.trim()
  if (!text) {
    ElMessage.warning('请输入内容')
    return
  }
  sending.value = true
  try {
    await createMessage({
      sender_role: myRole.value,
      text_content: text
    })
    inputText.value = ''
    await loadMessages()
  } catch (e) {
    console.error('发送失败', e)
  } finally {
    sending.value = false
  }
}

// ============ 生命周期 ============
onMounted(() => {
  loadMessages()
})

// 消息更新后自动滚到底部
watch(messages, () => scrollToBottom(), { deep: true })
</script>

<style scoped>
.chat-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-width: 720px;
  margin: 0 auto;
  background: var(--theme-cream);
  box-shadow: var(--theme-soft-shadow);
}

/* ── 顶部栏 ── */
.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: linear-gradient(135deg, #ffc8dd 0%, #ffb3c6 100%);
  color: #fff;
  box-shadow: 0 2px 8px rgba(255, 143, 171, 0.2);
}
.title {
  font-size: 16px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 6px;
}
.heart {
  font-size: 18px;
  animation: heartbeat 1.6s ease-in-out infinite;
}
@keyframes heartbeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}

/* ── 消息流 ── */
.chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 16px 12px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.empty-tip {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c0a0b0;
  gap: 8px;
}

/* 消息行 */
.msg-row {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.msg-me {
  flex-direction: row-reverse;
}

/* 头像 */
.avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  flex-shrink: 0;
}
.avatar.male {
  background: linear-gradient(135deg, #64b5f6, #1e88e5);
}
.avatar.female {
  background: linear-gradient(135deg, #ff8fab, #ff5c8a);
}

/* 气泡 */
.bubble-wrap {
  max-width: 70%;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.msg-me .bubble-wrap {
  align-items: flex-end;
}

.meta {
  font-size: 11px;
  color: #b08898;
  display: flex;
  gap: 8px;
}

.bubble {
  padding: 10px 14px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
}
.bubble-male {
  background: var(--theme-male-bg);
  color: var(--theme-male-text);
  border-bottom-left-radius: 4px;
}
.bubble-female {
  background: var(--theme-female-bg);
  color: var(--theme-female-text);
  border-bottom-right-radius: 4px;
}

/* AI 徽标 */
.ai-tag {
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
}
.ai-summary {
  font-size: 11px;
  color: #9e7a8a;
  font-style: italic;
}

/* ── 底部输入区 ── */
.chat-footer {
  display: flex;
  gap: 8px;
  padding: 12px;
  background: #fff;
  border-top: 1px solid #ffe0ec;
}
.send-btn {
  flex-shrink: 0;
  height: 100%;
  min-height: 40px;
}
</style>
