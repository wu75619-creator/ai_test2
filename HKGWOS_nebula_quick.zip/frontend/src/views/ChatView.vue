<template>
  <div class="chat-page">
    <!-- 顶部栏 -->
    <header class="chat-header">
      <div class="title">
        <span class="heart">💗</span>
        <span>情侣智能恋爱日记本</span>
      </div>
      <div class="role-switch">
        <el-radio-group v-model="myRole" size="small">
          <el-radio-button label="MALE">男主</el-radio-button>
          <el-radio-button label="FEMALE">女主</el-radio-button>
        </el-radio-group>
      </div>
    </header>

    <!-- 消息流 -->
    <main class="chat-body" ref="chatBodyRef">
      <div v-if="loading" class="empty-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        <span>加载中…</span>
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <span>还没有消息，发条甜言蜜语吧～</span>
      </div>

      <div
        v-for="msg in messages"
        :key="msg.id"
        class="msg-row"
        :class="isMe(msg) ? 'msg-me' : 'msg-other'"
      >
        <div class="avatar" :class="roleClass(msg.sender_role)">
          {{ roleLabel(msg.sender_role) }}
        </div>

        <div class="bubble-wrap">
          <div class="meta">
            <span class="nickname">{{ roleLabel(msg.sender_role) }}</span>
            <span class="time">{{ formatTime(msg.created_at) }}</span>
          </div>

          <!-- 图片气泡 -->
          <div v-if="msg.media_urls && msg.media_urls.length > 0" class="media-grid">
            <img
              v-for="(url, i) in msg.media_urls"
              :key="i"
              :src="resolveUrl(url)"
              class="msg-img"
              @click="previewImage(resolveUrl(url))"
            />
          </div>

          <!-- 文字气泡 -->
          <div v-if="msg.text_content" class="bubble" :class="`bubble-${roleClass(msg.sender_role)}`">
            {{ msg.text_content }}
          </div>

          <!-- AI/手动分类徽标 -->
          <div class="tag-row">
            <el-tag
              v-if="msg.main_category"
              size="small"
              :type="msg.manual_override ? 'info' : 'warning'"
              effect="light"
            >
              🏷️ {{ categoryLabel(msg.main_category) }}
              <span v-if="msg.manual_override" class="manual-mark">手动</span>
            </el-tag>
            <span v-if="msg.ai_summary" class="ai-summary">💭 {{ msg.ai_summary }}</span>
          </div>
        </div>
      </div>
    </main>

    <!-- 底部输入区 -->
    <footer class="chat-footer">
      <!-- 工具栏 -->
      <div class="toolbar">
        <div class="tool-left">
          <!-- 上传图片按钮 -->
          <el-upload
            :show-file-list="false"
            :before-upload="onImageSelected"
            accept="image/*"
            multiple
          >
            <el-button size="small" :icon="PictureFilled" circle />
          </el-upload>

          <!-- 录制语音按钮（占位） -->
          <el-button size="small" :icon="Microphone" circle @click="onVoiceClick" />
        </div>

        <div class="tool-right">
          <!-- AI 自动分类开关 -->
          <span class="switch-label">AI 自动</span>
          <el-switch v-model="isAiAuto" size="small" />

          <!-- 手动分类选择器（关闭 AI 时显示） -->
          <el-select
            v-if="!isAiAuto"
            v-model="manualCategory"
            size="small"
            placeholder="选择分类"
            class="manual-select"
          >
            <el-option
              v-for="cat in categoryOptions"
              :key="cat.value"
              :label="cat.label"
              :value="cat.value"
            />
          </el-select>
        </div>
      </div>

      <!-- 已选图片预览 -->
      <div v-if="selectedImages.length > 0" class="selected-images">
        <div v-for="(img, i) in selectedImages" :key="i" class="img-thumb">
          <img :src="URL.createObjectURL(img)" />
          <el-icon class="remove-icon" @click="removeImage(i)"><Close /></el-icon>
        </div>
      </div>

      <!-- 输入框 + 发送 -->
      <div class="input-row">
        <el-input
          v-model="inputText"
          type="textarea"
          :autosize="{ minRows: 1, maxRows: 4 }"
          placeholder="随手记一句，AI 会自动帮你归档～"
          @keydown.enter.exact.prevent="onSend"
          :disabled="sending"
        />
        <el-button
          type="primary"
          class="send-btn"
          :loading="sending"
          @click="onSend"
        >
          发送
        </el-button>
      </div>
    </footer>

    <!-- 图片预览弹窗 -->
    <el-dialog v-model="previewVisible" width="80%" center>
      <img :src="previewSrc" class="preview-img" />
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, watch } from 'vue'
import { Loading, PictureFilled, Microphone, Close } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { fetchMessages, createMessage } from '../api'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

// ============ 状态 ============
const messages = ref([])
const loading = ref(false)
const sending = ref(false)
const inputText = ref('')
const myRole = ref('FEMALE')
const chatBodyRef = ref(null)

// 双模式
const isAiAuto = ref(true)
const manualCategory = ref('')
const categoryOptions = [
  { value: 'FOOD', label: '🍜 美食探店' },
  { value: 'TRAVEL_DATE', label: '🌸 旅行约会' },
  { value: 'COUPLE_PHOTO', label: '💑 情侣合照' },
  { value: 'FUN_DAILY', label: '😆 趣味日常' },
  { value: 'NICKNAME', label: '🤫 专属昵称' },
  { value: 'DEEP_TALK', label: '💕 深度谈心' },
  { value: 'CONFLICT', label: '🌱 矛盾复盘' },
  { value: 'VOICE_ONLY', label: '🎵 语音专属' },
]

// 图片
const selectedImages = ref([])

// 预览
const previewVisible = ref(false)
const previewSrc = ref('')

// ============ 工具 ============
const CATEGORY_LABELS = {
  FOOD: '美食探店', TRAVEL_DATE: '旅行约会', COUPLE_PHOTO: '情侣合照',
  FUN_DAILY: '趣味日常', NICKNAME: '专属昵称', DEEP_TALK: '深度谈心',
  CONFLICT: '矛盾复盘', VOICE_ONLY: '语音专属',
}
const categoryLabel = (c) => CATEGORY_LABELS[c] || c
const isMe = (msg) => msg.sender_role === myRole.value
const roleLabel = (r) => (r === 'MALE' ? '男主' : r === 'FEMALE' ? '女主' : r)
const roleClass = (r) => (r === 'MALE' ? 'male' : 'female')

function formatTime(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const pad = (n) => String(n).padStart(2, '0')
  return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function resolveUrl(url) {
  if (!url) return ''
  if (url.startsWith('http')) return url
  return `${API_BASE}${url}`
}

function scrollToBottom() {
  nextTick(() => {
    if (chatBodyRef.value) {
      chatBodyRef.value.scrollTop = chatBodyRef.value.scrollHeight
    }
  })
}

// ============ 图片处理 ============
function onImageSelected(file) {
  selectedImages.value.push(file)
  return false // 阻止自动上传
}

function removeImage(i) {
  selectedImages.value.splice(i, 1)
}

function previewImage(src) {
  previewSrc.value = src
  previewVisible.value = true
}

// ============ 语音（占位） ============
function onVoiceClick() {
  ElMessage.info('语音功能开发中…')
}

// ============ 拉取历史 ============
async function loadMessages() {
  loading.value = true
  try {
    const list = await fetchMessages()
    messages.value = list
    scrollToBottom()
  } catch (e) {
    console.error(e)
  } finally {
    loading.value = false
  }
}

// ============ 发送消息 ============
async function onSend() {
  const text = inputText.value.trim()
  const hasImages = selectedImages.value.length > 0

  if (!text && !hasImages) {
    ElMessage.warning('请输入内容或选择图片')
    return
  }

  // 手动模式校验
  if (!isAiAuto.value && !manualCategory.value) {
    ElMessage.warning('请先选择分类')
    return
  }

  sending.value = true
  try {
    await createMessage({
      sender_role: myRole.value,
      text_content: text || undefined,
      images: hasImages ? [...selectedImages.value] : undefined,
      is_ai_auto: isAiAuto.value,
      manual_category: !isAiAuto.value ? manualCategory.value : undefined,
    })

    // 清空
    inputText.value = ''
    selectedImages.value = []
    await loadMessages()
  } catch (e) {
    console.error(e)
  } finally {
    sending.value = false
  }
}

// ============ 生命周期 ============
onMounted(() => {
  loadMessages()
})

watch(messages, () => scrollToBottom(), { deep: true })
</script>

<style scoped>
.chat-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--theme-cream);
}

.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: linear-gradient(135deg, #ffc8dd 0%, #ffb3c6 100%);
  color: #fff;
  box-shadow: 0 2px 8px rgba(255, 143, 171, 0.2);
}
.title {
  font-size: 16px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 6px;
}
.heart {
  font-size: 18px;
  animation: heartbeat 1.6s ease-in-out infinite;
}
@keyframes heartbeat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.15); }
}

.chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 16px 12px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.empty-tip {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c0a0b0;
  gap: 8px;
}

.msg-row {
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.msg-me {
  flex-direction: row-reverse;
}

.avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  flex-shrink: 0;
}
.avatar.male {
  background: linear-gradient(135deg, #64b5f6, #1e88e5);
}
.avatar.female {
  background: linear-gradient(135deg, #ff8fab, #ff5c8a);
}

.bubble-wrap {
  max-width: 75%;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.msg-me .bubble-wrap {
  align-items: flex-end;
}

.meta {
  font-size: 11px;
  color: #b08898;
  display: flex;
  gap: 8px;
}

.media-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 6px;
  margin-bottom: 6px;
}
.msg-img {
  width: 100%;
  border-radius: 12px;
  cursor: pointer;
  transition: transform 0.2s;
}
.msg-img:hover {
  transform: scale(1.02);
}

.bubble {
  padding: 10px 14px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.5;
  word-break: break-word;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
}
.bubble-male {
  background: var(--theme-male-bg);
  color: var(--theme-male-text);
  border-bottom-left-radius: 4px;
}
.bubble-female {
  background: var(--theme-female-bg);
  color: var(--theme-female-text);
  border-bottom-right-radius: 4px;
}

.tag-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
  margin-top: 4px;
}
.manual-mark {
  font-size: 10px;
  margin-left: 4px;
  opacity: 0.7;
}
.ai-summary {
  font-size: 11px;
  color: #9e7a8a;
  font-style: italic;
}

/* 底部输入区 */
.chat-footer {
  background: #fff;
  border-top: 1px solid #ffe0ec;
  padding: 10px 12px;
}
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}
.tool-left {
  display: flex;
  gap: 8px;
}
.tool-right {
  display: flex;
  align-items: center;
  gap: 8px;
}
.switch-label {
  font-size: 12px;
  color: #b08898;
}
.manual-select {
  width: 140px;
}

.selected-images {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 8px;
}
.img-thumb {
  position: relative;
  width: 60px;
  height: 60px;
  border-radius: 8px;
  overflow: hidden;
}
.img-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.remove-icon {
  position: absolute;
  top: 2px;
  right: 2px;
  background: rgba(0,0,0,0.5);
  color: #fff;
  border-radius: 50%;
  padding: 2px;
  cursor: pointer;
  font-size: 12px;
}

.input-row {
  display: flex;
  gap: 8px;
}
.send-btn {
  flex-shrink: 0;
  height: 100%;
  min-height: 40px;
}

.preview-img {
  width: 100%;
  border-radius: 12px;
}
</style>
