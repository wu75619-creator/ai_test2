<template>
  <div class="category-page">
    <!-- 顶部栏 -->
    <header class="page-header">
      <div class="title">
        <span class="icon">📸</span>
        <span>分类相册</span>
      </div>
      <el-radio-group v-model="currentCategory" size="small" @change="onCategoryChange">
        <el-radio-button
          v-for="cat in categoryList"
          :key="cat.category"
          :label="cat.category"
        >
          {{ cat.label }}
          <span v-if="cat.count > 0" class="cat-count">{{ cat.count }}</span>
        </el-radio-button>
      </el-radio-group>
    </header>

    <!-- 时间筛选器 -->
    <div class="filter-bar">
      <el-date-picker
        v-model="dateRange"
        type="daterange"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        value-format="YYYY-MM-DD"
        size="small"
        style="width: 280px"
        @change="onDateChange"
      />
      <el-button size="small" @click="resetFilter" :disabled="!dateRange">
        重置
      </el-button>
      <span class="total-tip">共 {{ messages.length }} 条记录</span>
    </div>

    <!-- 主体：瀑布流卡片 -->
    <main class="card-grid" v-loading="loading">
      <div v-if="!loading && messages.length === 0" class="empty-tip">
        <span>该分类下暂无记录，去聊天页发一条试试～</span>
      </div>

      <div v-for="msg in messages" :key="msg.id" class="card">
        <!-- 卡片头部 -->
        <div class="card-header">
          <div class="avatar" :class="msg.sender_role === 'MALE' ? 'male' : 'female'">
            {{ msg.sender_role === 'MALE' ? '男' : '女' }}
          </div>
          <div class="meta">
            <span class="nickname">{{ msg.sender_role === 'MALE' ? '男主' : '女主' }}</span>
            <span class="time">{{ formatDate(msg.created_at) }}</span>
          </div>
          <el-tag size="small" type="warning" effect="light" class="cat-tag">
            🏷️ {{ categoryLabel(msg.main_category) }}
          </el-tag>
        </div>

        <!-- 内容 -->
        <div class="card-content">{{ msg.text_content }}</div>

        <!-- AI 小结 -->
        <div v-if="msg.ai_summary" class="ai-summary">
          <span class="ai-icon">💭</span>
          <span>{{ msg.ai_summary }}</span>
        </div>

        <!-- 子标签 -->
        <div v-if="msg.sub_tags && msg.sub_tags.length > 0" class="sub-tags">
          <el-tag
            v-for="tag in msg.sub_tags"
            :key="tag"
            size="small"
            effect="plain"
            class="sub-tag"
          >
            #{{ tag }}
          </el-tag>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { fetchCategories, fetchCategoryMessages } from '../api'

const categoryList = ref([])
const currentCategory = ref('FOOD')
const dateRange = ref(null)
const messages = ref([])
const loading = ref(false)

const LABELS = {
  FOOD: '美食探店',
  TRAVEL_DATE: '旅行约会',
  COUPLE_PHOTO: '情侣合照',
  FUN_DAILY: '趣味日常',
  NICKNAME: '专属昵称',
  DEEP_TALK: '深度谈心',
  CONFLICT: '矛盾复盘',
  VOICE_ONLY: '语音专属'
}
const categoryLabel = (c) => LABELS[c] || c

function formatDate(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const pad = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

async function loadCategories() {
  try {
    categoryList.value = await fetchCategories()
    if (categoryList.value.length > 0) {
      currentCategory.value = categoryList.value[0].category
    }
  } catch (e) {
    console.error('加载分类失败', e)
  }
}

async function loadMessages() {
  loading.value = true
  try {
    const params = {}
    if (dateRange.value && dateRange.value.length === 2) {
      params.start_date = dateRange.value[0]
      params.end_date = dateRange.value[1]
    }
    const list = await fetchCategoryMessages(currentCategory.value, params)
    messages.value = list
  } catch (e) {
    console.error('加载消息失败', e)
  } finally {
    loading.value = false
  }
}

function onCategoryChange() {
  dateRange.value = null
  loadMessages()
}

function onDateChange() {
  loadMessages()
}

function resetFilter() {
  dateRange.value = null
  loadMessages()
}

onMounted(() => {
  loadCategories()
  loadMessages()
})
</script>

<style scoped>
.category-page {
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background: var(--theme-bg-gradient);
}

.page-header {
  padding: 16px 16px 12px;
  background: #fff;
  border-bottom: 1px solid #ffe0ec;
  position: sticky;
  top: 0;
  z-index: 10;
}
.title {
  font-size: 18px;
  font-weight: 600;
  color: #c2185b;
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 10px;
}
.title .icon {
  font-size: 20px;
}
.cat-count {
  margin-left: 4px;
  font-size: 10px;
  opacity: 0.8;
}

.filter-bar {
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff8fa;
  border-bottom: 1px solid #ffe0ec;
}
.total-tip {
  margin-left: auto;
  font-size: 12px;
  color: #b08898;
}

.card-grid {
  padding: 16px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 16px;
}
.empty-tip {
  grid-column: 1 / -1;
  text-align: center;
  color: #c0a0b0;
  padding: 60px 20px;
}

.card {
  background: #fff;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 4px 16px rgba(255, 143, 171, 0.1);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 24px rgba(255, 143, 171, 0.18);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: #fff;
  flex-shrink: 0;
}
.avatar.male {
  background: linear-gradient(135deg, #64b5f6, #1e88e5);
}
.avatar.female {
  background: linear-gradient(135deg, #ff8fab, #ff5c8a);
}
.meta {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.nickname {
  font-size: 13px;
  font-weight: 600;
  color: #4a4a4a;
}
.time {
  font-size: 11px;
  color: #b08898;
}
.cat-tag {
  flex-shrink: 0;
}

.card-content {
  font-size: 14px;
  line-height: 1.6;
  color: #4a4a4a;
  background: #fff5f8;
  padding: 10px 12px;
  border-radius: 10px;
  margin-bottom: 10px;
}

.ai-summary {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  font-size: 12px;
  color: #9e7a8a;
  font-style: italic;
  padding: 8px 10px;
  background: #fff0f3;
  border-radius: 8px;
  border-left: 3px solid #ffc8dd;
}
.ai-icon {
  flex-shrink: 0;
}

.sub-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}
.sub-tag {
  font-size: 11px;
}
</style>
