# 情侣智能随手恋爱日记本

> 双人专属 · 对话式随手记录 · AI 自动分类归档

---

## 一、项目结构

```
.
├── README.md
├── frontend/          # Vue3 + Vite 前端（待初始化）
└── backend/
    ├── main.py        # FastAPI 入口
    ├── models.py      # SQLAlchemy 数据模型
    ├── schema.sql     # SQLite 原生 DDL（与 models.py 对齐）
    └── requirements.txt
```

---

## 二、核心表结构（8 张表）

| 表名 | 用途 | 关键字段 |
|---|---|---|
| `couples` | 情侣对（最小独立空间） | `id`, `couple_name`, `anniversary`, `access_password`(bcrypt) |
| `users` | 用户（仅 `MALE` / `FEMALE` 两种角色） | `id`, `couple_id`, `role`, `nickname`, `avatar_url` |
| `media_assets` | 媒体资源（图片 / 语音，文件存 `uploads/`） | `id`, `couple_id`, `uploader_id`, `media_type`, `file_path`, `mime_type`, `size_bytes`, `width`, `height`, `duration_ms`, `asr_text` |
| `messages` | **消息记录（核心）** | `id`, `couple_id`, `sender_id`, `msg_type`(TEXT/IMAGE/VOICE/STICKER), `text_content`, `media_asset_ids`(逗号分隔), **`main_category`**(8 大主分类), **`sub_tags`**(JSON 数组), **`related_categories`**(JSON 数组), **`ai_summary`**, `ai_confidence`, `ai_model_version`, `manual_category`, `manual_override`, `occurred_at`, `created_at` |
| `category_archives` | 分类归档快照（按 DAY/MONTH/YEAR 聚合） | `id`, `couple_id`, `main_category`, `period_type`, `period_start`, `period_end`, `message_ids`, `message_count`, `cover_asset_id`, `ai_period_summary` |
| `nickname_dict` | 昵称 & 专属梗词典（PRD 4.3.3） | `id`, `couple_id`, `nickname`, `meaning`, `source_msg_id`, `created_by` |
| `conflict_reviews` | 矛盾复盘专区（PRD 4.3.3） | `id`, `couple_id`, `title`, `cause`, `both_views`(JSON), `resolution`, `agreement`, `source_msg_ids` |
| `ai_classification_jobs` | AI 分类任务队列（可重试、可观测） | `id`, `couple_id`, `message_id`, `status`, `attempts`, `last_error` |

### 关键设计点

- **八大主分类枚举**：`FOOD` / `TRAVEL_DATE` / `COUPLE_PHOTO` / `FUN_DAILY` / `NICKNAME` / `DEEP_TALK` / `CONFLICT` / `VOICE_ONLY`
- **单条消息 = 唯一主分类 + 多子标签 + 关联分类**（PRD 4.2.2）：分别由 `main_category`、`sub_tags`、`related_categories` 字段承载
- **全局时间轴** = `messages` 按 `couple_id + created_at DESC` 排序（索引 `idx_msg_couple_time`）
- **分类页快速聚合** = 直接查 `category_archives`（已按月/年预聚合）
- **AI 异步处理**：消息先入库 → 入队 `ai_classification_jobs` → Worker 异步消费 → 回写 AI 字段
- **人工修正**：`manual_override=1` + `manual_category` 覆盖 AI 结果（PRD 6.2）

---

## 三、启动命令

### 后端（Python 3.10+）

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 方式 1：直接运行（自动建表）
python main.py

# 方式 2：uvicorn 启动（推荐开发）
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

- API 文档：http://localhost:8000/docs
- 数据库：`backend/love_diary.db`（SQLite 自动创建）
- 媒体上传目录：`backend/uploads/`（运行时自动创建）

### 前端（Vue3 + Vite）

```bash
cd frontend
# 待初始化（下一步）
npm install
npm run dev
```

---

## 四、下一步开发计划

1. **第 2 步**：前端 Vite 项目初始化 + 路由 + Pinia + Element Plus 主题
2. **第 3 步**：后端鉴权（JWT + 情侣对密码登录）+ 上传接口
3. **第 4 步**：聊天页 WebSocket 实时推送 + 聊天气泡渲染
4. **第 5 步**：AI 分类 Worker + AIService 封装（LLM + 视觉 + ASR）
5. **第 6 步**：分类归档页 + 全局时间轴页
6. **第 7 步**：昵称词典 + 矛盾复盘等特色板块
