"""
SQLAlchemy 数据模型（核心：User / Message）
其他表（Couple / MediaAsset / CategoryArchive / NicknameDict /
ConflictReview / AIClassificationJob）的完整定义见 schema.sql，
后续按需补全 ORM 映射。
"""
import uuid
from datetime import datetime, date
from sqlalchemy import (
    create_engine, Column, String, Text, Integer, Float,
    Boolean, Date, DateTime, ForeignKey, CheckConstraint,
    Index, event,
)
from sqlalchemy.orm import (
    declarative_base, relationship, sessionmaker, Mapped, mapped_column
)
from sqlalchemy.sql import func

# ── 数据库连接（SQLite 单文件） ──────────────────────────────
SQLALCHEMY_DATABASE_URL = "sqlite:///./love_diary.db"
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def uuid_str() -> str:
    return str(uuid.uuid4())


# ── 自动更新 updated_at（before_update 全局钩子） ────────────
@event.listens_for(Base, "before_update", propagate=True)
def _touch_updated_at(mapper, connection, target):
    if hasattr(target, "updated_at"):
        target.updated_at = datetime.utcnow()


# ============================================================
# User 用户表（仅两种角色：MALE 男主 / FEMALE 女主）
# ============================================================
class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    couple_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("couples.id", ondelete="CASCADE"),
        nullable=False,
    )
    role: Mapped[str] = mapped_column(String(16), nullable=False)  # MALE / FEMALE
    nickname: Mapped[str] = mapped_column(String(64), nullable=False)
    avatar_url: Mapped[str | None] = mapped_column(Text)
    login_token: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        CheckConstraint("role IN ('MALE','FEMALE')", name="ck_user_role"),
        Index("idx_users_couple", "couple_id"),
    )

    # 与 Couple 的关系（Couple 模型在 schema.sql 已完整定义）
    # couple = relationship("Couple", back_populates="users")
    sent_messages = relationship(
        "Message", back_populates="sender", foreign_keys="Message.sender_id"
    )


# ============================================================
# Message 消息记录表（核心）
# 已预留 AI 分类与 AI 小结字段，支持文本/图片/语音/表情包
# ============================================================
class Message(Base):
    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_str)
    couple_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("couples.id", ondelete="CASCADE"),
        nullable=False,
    )
    sender_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id"), nullable=False
    )
    # 内容类型：TEXT / IMAGE / VOICE / STICKER
    msg_type: Mapped[str] = mapped_column(String(16), nullable=False, default="TEXT")
    text_content: Mapped[str | None] = mapped_column(Text)
    # 关联多媒体（逗号分隔的 media_assets.id），多图/语音场景使用
    media_asset_ids: Mapped[str] = mapped_column(Text, default="")

    # ============ AI 自动处理字段（PRD 4.2.2） ============
    # 主分类（8 大分类之一）：FOOD / TRAVEL_DATE / COUPLE_PHOTO /
    # FUN_DAILY / NICKNAME / DEEP_TALK / CONFLICT / VOICE_ONLY
    main_category: Mapped[str | None] = mapped_column(String(32))
    # 子标签，JSON 数组字符串，如 ["奶茶","探店","甜"]
    sub_tags: Mapped[str] = mapped_column(Text, default="[]")
    # 关联分类，JSON 数组字符串
    related_categories: Mapped[str] = mapped_column(Text, default="[]")
    # AI 生成的 1-2 句温柔小结
    ai_summary: Mapped[str | None] = mapped_column(Text)
    # 分类置信度 0~1
    ai_confidence: Mapped[float | None] = mapped_column(Float)
    # 模型版本，便于回溯
    ai_model_version: Mapped[str | None] = mapped_column(String(32))

    # 人工修正（PRD 6.2 特殊场景可手动微调分类）
    manual_category: Mapped[str | None] = mapped_column(String(32))
    manual_override: Mapped[bool] = mapped_column(Boolean, default=False)

    # 时间绑定（PRD 4.2.2 自动时间绑定）
    occurred_at: Mapped[date] = mapped_column(Date, server_default=func.current_date())
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        CheckConstraint(
            "msg_type IN ('TEXT','IMAGE','VOICE','STICKER')",
            name="ck_msg_type",
        ),
        Index("idx_msg_couple_time", "couple_id", "created_at"),
        Index("idx_msg_couple_cat", "couple_id", "main_category", "created_at"),
        Index("idx_msg_couple_date", "couple_id", "occurred_at"),
    )

    sender = relationship("User", back_populates="sent_messages", foreign_keys=[sender_id])
    # couple = relationship("Couple", back_populates="messages")


# ============================================================
# 建表入口
# ============================================================
def init_db():
    """创建所有已映射的表；其它表（couples / media_assets / ...）
    可通过执行 schema.sql 补齐，未来扩展模型后此函数会自动包含。"""
    Base.metadata.create_all(bind=engine)


if __name__ == "__main__":
    init_db()
    print("✅ 数据库表已创建/更新 → love_diary.db")
