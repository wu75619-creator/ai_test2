"""
AI 分类服务 v2
- 支持真实 OpenAI 兼容接口（多模态：文本 + 图片）
- 通过 AI_USE_MOCK 环境变量开关降级为 Mock
- 输入：文本 + 图片路径（可选），输出：分类 + 子标签 + 小结
"""
import os
import json
import base64
import random
from typing import Optional, List

from dotenv import load_dotenv
load_dotenv()

# ============================================================
# 八大主分类
# ============================================================
CATEGORIES = [
    "FOOD",
    "TRAVEL_DATE",
    "COUPLE_PHOTO",
    "FUN_DAILY",
    "NICKNAME",
    "DEEP_TALK",
    "CONFLICT",
    "VOICE_ONLY",
]

CATEGORY_LABELS = {
    "FOOD": "美食探店",
    "TRAVEL_DATE": "旅行约会",
    "COUPLE_PHOTO": "情侣合照",
    "FUN_DAILY": "趣味日常",
    "NICKNAME": "专属昵称",
    "DEEP_TALK": "深度谈心",
    "CONFLICT": "矛盾复盘",
    "VOICE_ONLY": "语音专属",
}

# 关键词触发映射
CATEGORY_KEYWORDS = {
    "FOOD": ["吃", "美食", "餐厅", "奶茶", "咖啡", "探店", "好吃", "料理", "烧烤", "火锅", "日料"],
    "TRAVEL_DATE": ["约会", "出门", "旅行", "景点", "逛街", "公园", "电影", "出行", "游玩"],
    "COUPLE_PHOTO": ["合照", "自拍", "拍照", "同框", "合影"],
    "FUN_DAILY": ["搞笑", "段子", "哈哈", "可爱", "梗", "互怼", "开心"],
    "NICKNAME": ["昵称", "宝贝", "亲爱的", "老公", "老婆", "外号"],
    "DEEP_TALK": ["爱你", "未来", "心事", "感动", "谈心", "三观", "规划", "喜欢"],
    "CONFLICT": ["吵架", "生气", "矛盾", "对不起", "原谅", "和解", "反思", "道歉"],
    "VOICE_ONLY": ["语音", "录音", "听听"],
}

SUMMARY_TEMPLATES = {
    "FOOD": ["和你一起吃这顿饭，连空气都是甜的 🍬", "今日美食打卡，和宝贝一起干饭的小幸福 🍜"],
    "TRAVEL_DATE": ["和你走过的每一条街，都是最美的风景 🌸", "今天的约会满分，牵着你的手就是全世界 💑"],
    "COUPLE_PHOTO": ["我们的同框，是时光最温柔的定格 📸", "一张合照，锁住此刻的心动 💖"],
    "FUN_DAILY": ["和你在一起的日常，连空气都在笑 😆", "今天的小确幸，是你给的小甜饼 🍪"],
    "NICKNAME": ["这个昵称，专属于我们的小秘密 🤫", "一句称呼，藏着我所有的温柔 💗"],
    "DEEP_TALK": ["今晚的心里话，是我想和你走一辈子的证据 💕", "和你深谈的每一句，都刻在心里 📝"],
    "CONFLICT": ["吵架不可怕，因为我们愿意一起变好 🌱", "今天的和解，是感情更坚固的一块砖 🧱"],
    "VOICE_ONLY": ["你的声音，是我百听不厌的情歌 🎵", "这条语音，我要循环一整晚 🌙"],
}

SUB_TAG_POOL = {
    "FOOD": ["奶茶", "探店", "甜", "火锅", "日料", "咖啡", "好吃"],
    "TRAVEL_DATE": ["约会", "逛街", "电影", "公园", "旅行", "打卡"],
    "COUPLE_PHOTO": ["合照", "自拍", "同框", "情侣照"],
    "FUN_DAILY": ["搞笑", "段子", "日常", "可爱", "沙雕"],
    "NICKNAME": ["昵称", "暗号", "专属"],
    "DEEP_TALK": ["走心", "未来", "爱意", "三观"],
    "CONFLICT": ["吵架", "和解", "反思", "约定"],
    "VOICE_ONLY": ["语音", "录音", "告白"],
}


def is_mock_mode() -> bool:
    return os.getenv("AI_USE_MOCK", "1") == "1"


def _keyword_classify(text: str) -> Optional[str]:
    text = (text or "").lower()
    for cat, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                return cat
    return None


def _mock_result(text: str) -> dict:
    cat = _keyword_classify(text) or random.choice(CATEGORIES)
    pool = SUB_TAG_POOL.get(cat, [])
    sub_tags = random.sample(pool, k=min(len(pool), random.randint(1, 3))) if pool else []
    related = [random.choice([c for c in CATEGORIES if c != cat])] if random.random() < 0.2 else []
    summary = random.choice(SUMMARY_TEMPLATES.get(cat, ["今天也和你在一起，真好 💗"]))
    return {
        "main_category": cat,
        "sub_tags": sub_tags,
        "related_categories": related,
        "ai_summary": summary,
        "ai_confidence": round(random.uniform(0.85, 0.98), 4),
        "ai_model_version": "mock-2.0",
    }


def _encode_image(image_path: str) -> str:
    """本地图片转 base64 data URL"""
    import mimetypes
    mime, _ = mimetypes.guess_type(image_path)
    mime = mime or "image/jpeg"
    with open(image_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def _call_openai(text: str, image_paths: List[str]) -> dict:
    """调用 OpenAI 兼容接口（支持多模态）"""
    from openai import OpenAI

    api_key = os.getenv("LLM_API_KEY")
    base_url = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    model = os.getenv("LLM_MODEL", "gpt-4o-mini")

    if not api_key:
        print("⚠️  未配置 LLM_API_KEY，降级到 Mock")
        return _mock_result(text)

    client = OpenAI(api_key=api_key, base_url=base_url)

    # 构造 messages
    system_prompt = (
        "你是一个情侣恋爱日记本的 AI 分类助手。"
        "请根据用户发送的文本和/或图片，判断最匹配的分类，"
        "并生成一句温柔的小结。严格返回 JSON，不要其他内容。\n"
        f"可选分类：{json.dumps(CATEGORY_LABELS, ensure_ascii=False)}\n"
        '返回格式：{"main_category":"FOOD","sub_tags":["奶茶"],"ai_summary":"和你一起喝奶茶真好 🍬","ai_confidence":0.95}'
    )

    user_content = [{"type": "text", "text": text or "（无文字，仅图片）"}]

    # 附加图片（仅前 3 张）
    for p in image_paths[:3]:
        try:
            user_content.append({
                "type": "image_url",
                "image_url": {"url": _encode_image(p)},
            })
        except Exception as e:
            print(f"⚠️  图片读取失败 {p}: {e}")

    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            response_format={"type": "json_object"},
            temperature=0.3,
            max_tokens=300,
        )
        raw = resp.choices[0].message.content
        data = json.loads(raw)

        # 校验 main_category 合法性
        cat = data.get("main_category", "FUN_DAILY")
        if cat not in CATEGORIES:
            cat = _keyword_classify(text) or "FUN_DAILY"

        return {
            "main_category": cat,
            "sub_tags": data.get("sub_tags", []),
            "related_categories": data.get("related_categories", []),
            "ai_summary": data.get("ai_summary", ""),
            "ai_confidence": float(data.get("ai_confidence", 0.9)),
            "ai_model_version": f"{model}",
        }
    except Exception as e:
        print(f"❌ OpenAI 调用失败: {e}")
        return _mock_result(text)


def classify_message(
    text: str,
    image_paths: Optional[List[str]] = None,
) -> dict:
    """
    主入口：对消息进行 AI 分类
    Args:
        text: 文本内容
        image_paths: 本地图片路径列表（可选）
    Returns:
        {main_category, sub_tags, related_categories, ai_summary, ai_confidence, ai_model_version}
    """
    if is_mock_mode():
        return _mock_result(text)
    return _call_openai(text, image_paths or [])
