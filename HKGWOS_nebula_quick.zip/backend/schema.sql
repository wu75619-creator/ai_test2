-- ============================================================
-- 情侣智能随手恋爱日记本 - 数据库 DDL (SQLite 兼容)
-- 后端：Python 3 + FastAPI + SQLite
-- ============================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ============================================================
-- 1. 情侣对表（最小独立空间：一对情侣 = 一个私密日记本）
-- ============================================================
CREATE TABLE IF NOT EXISTS couples (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_name     TEXT,                             -- "小明 & 小红"
    anniversary     TEXT,                             -- 在一起日期 YYYY-MM-DD
    access_password TEXT NOT NULL,                    -- bcrypt 访问密码（PRD 6.1）
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- 2. 用户表（仅两种角色：男主 MALE / 女主 FEMALE）
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_id       TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    role            TEXT NOT NULL CHECK (role IN ('MALE','FEMALE')),
    nickname        TEXT NOT NULL,                    -- 显示昵称
    avatar_url      TEXT,
    login_token     TEXT,                             -- 登录凭证 hash
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (couple_id, role)
);
CREATE INDEX IF NOT EXISTS idx_users_couple ON users(couple_id);

-- ============================================================
-- 3. 媒体资源表（图片、语音统一存储，文件本体存本地 uploads/）
-- ============================================================
CREATE TABLE IF NOT EXISTS media_assets (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_id       TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    uploader_id     TEXT NOT NULL REFERENCES users(id),
    media_type      TEXT NOT NULL CHECK (media_type IN ('IMAGE','VOICE')),
    file_path       TEXT NOT NULL,                    -- 本地相对路径 uploads/xxx
    mime_type       TEXT NOT NULL,
    size_bytes      INTEGER NOT NULL,
    width           INTEGER,                          -- 图片宽
    height          INTEGER,                          -- 图片高
    duration_ms     INTEGER,                          -- 语音时长
    asr_text        TEXT,                             -- 语音转文字结果
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_media_couple_created ON media_assets(couple_id, created_at DESC);

-- ============================================================
-- 4. 消息记录表（核心：一条消息 = 一次对话记录）
-- ============================================================
CREATE TABLE IF NOT EXISTS messages (
    id                  TEXT PRIMARY KEY,             -- UUID
    couple_id           TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    sender_id           TEXT NOT NULL REFERENCES users(id),
    msg_type            TEXT NOT NULL CHECK (msg_type IN ('TEXT','IMAGE','VOICE','STICKER')),

    -- 文字内容 / 图片配文 / 语音 ASR 回填
    text_content        TEXT,

    -- 关联多媒体（多图一次上传，PRD 4.1.2），用逗号分隔的 UUID 列表
    media_asset_ids     TEXT DEFAULT '',              -- "uuid1,uuid2,..."

    -- ============ AI 自动处理结果（PRD 4.2.2 关键字段） ============
    -- 八大主分类：FOOD / TRAVEL_DATE / COUPLE_PHOTO / FUN_DAILY /
    --            NICKNAME / DEEP_TALK / CONFLICT / VOICE_ONLY
    main_category       TEXT,                         -- 唯一主分类
    -- 子标签，JSON 数组字符串，如 '["奶茶","探店","甜"]'
    sub_tags            TEXT DEFAULT '[]',
    -- 关联分类，JSON 数组字符串
    related_categories  TEXT DEFAULT '[]',
    -- AI 1-2 句温柔小结
    ai_summary          TEXT,
    -- 分类置信度 0~1
    ai_confidence       REAL,
    -- 模型版本，便于回溯
    ai_model_version    TEXT,

    -- 人工修正（PRD 6.2 手动微调分类）
    manual_category     TEXT,                         -- 人工覆盖主分类
    manual_override     INTEGER NOT NULL DEFAULT 0,  -- 0/1 是否已人工修正

    -- 时间绑定（PRD 4.2.2）
    occurred_at         TEXT NOT NULL DEFAULT (date('now')),  -- 归属日期 YYYY-MM-DD
    created_at          TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_msg_couple_time    ON messages(couple_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_msg_couple_cat     ON messages(couple_id, main_category, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_msg_couple_date    ON messages(couple_id, occurred_at DESC);

-- ============================================================
-- 5. 分类归档快照表（PRD 4.3 八大分类专属页面，按日/月/年聚合）
-- ============================================================
CREATE TABLE IF NOT EXISTS category_archives (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_id       TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    main_category   TEXT NOT NULL,
    period_type     TEXT NOT NULL CHECK (period_type IN ('DAY','MONTH','YEAR')),
    period_start    TEXT NOT NULL,                    -- 周期起点 YYYY-MM-DD
    period_end      TEXT NOT NULL,                    -- 周期终点（含）
    message_ids     TEXT NOT NULL DEFAULT '',         -- 逗号分隔的 messages.id
    message_count   INTEGER NOT NULL DEFAULT 0,
    cover_asset_id  TEXT REFERENCES media_assets(id), -- 封面
    ai_period_summary TEXT,                           -- AI 月度/年度小结（PRD 4.3.3）
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (couple_id, main_category, period_type, period_start)
);
CREATE INDEX IF NOT EXISTS idx_archive_couple_cat ON category_archives(couple_id, main_category, period_start DESC);

-- ============================================================
-- 6. 昵称 & 专属梗词典（PRD 4.3.3 专属特色板块）
-- ============================================================
CREATE TABLE IF NOT EXISTS nickname_dict (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_id       TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    nickname        TEXT NOT NULL,
    meaning         TEXT,                             -- 含义 / 出处
    source_msg_id   TEXT REFERENCES messages(id),     -- 首次出现的消息
    created_by      TEXT NOT NULL REFERENCES users(id),
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_nick_couple ON nickname_dict(couple_id);

-- ============================================================
-- 7. 矛盾复盘专区（PRD 4.3.3 吵架复盘成长手册）
-- ============================================================
CREATE TABLE IF NOT EXISTS conflict_reviews (
    id              TEXT PRIMARY KEY,                 -- UUID
    couple_id       TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    title           TEXT,
    cause           TEXT,                             -- 矛盾起因
    both_views      TEXT DEFAULT '{}',                -- JSON: {"MALE":"...","FEMALE":"..."}
    resolution      TEXT,                             -- 和解过程
    agreement       TEXT,                             -- 改进约定
    source_msg_ids  TEXT DEFAULT '',                  -- 逗号分隔
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============================================================
-- 8. AI 分类任务队列（可观测、可重试）
-- ============================================================
CREATE TABLE IF NOT EXISTS ai_classification_jobs (
    id            TEXT PRIMARY KEY,                   -- UUID
    couple_id     TEXT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    message_id    TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    status        TEXT NOT NULL DEFAULT 'PENDING'
                  CHECK (status IN ('PENDING','RUNNING','SUCCESS','FAILED','MANUAL_FIX')),
    attempts      INTEGER NOT NULL DEFAULT 0,
    last_error    TEXT,
    started_at    TEXT,
    finished_at   TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_aijob_status ON ai_classification_jobs(status, created_at);

-- ============================================================
-- 触发器：自动更新 updated_at（SQLite 用触发器替代 PG 函数）
-- ============================================================
CREATE TRIGGER IF NOT EXISTS trg_couples_updated
AFTER UPDATE ON couples
FOR EACH ROW BEGIN
    UPDATE couples SET updated_at = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_messages_updated
AFTER UPDATE ON messages
FOR EACH ROW BEGIN
    UPDATE messages SET updated_at = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_archives_updated
AFTER UPDATE ON category_archives
FOR EACH ROW BEGIN
    UPDATE category_archives SET updated_at = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS trg_conflict_updated
AFTER UPDATE ON conflict_reviews
FOR EACH ROW BEGIN
    UPDATE conflict_reviews SET updated_at = datetime('now') WHERE id = NEW.id;
END;
