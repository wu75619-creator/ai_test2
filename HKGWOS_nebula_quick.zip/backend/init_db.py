"""
数据库初始化工具
- 启动时通过 schema.sql 创建完整的 8 张表（含外键依赖）
- 或直接用 SQLAlchemy create_all 增量创建新增表
"""
import sqlite3
import os
from models import Base, engine

DB_PATH = os.path.join(os.path.dirname(__file__), "love_diary.db")
SCHEMA_PATH = os.path.join(os.path.dirname(__file__), "schema.sql")


def init_db_full():
    """通过 schema.sql 创建完整数据库（首次运行使用）"""
    print(f"📂 初始化数据库: {DB_PATH}")
    if os.path.exists(DB_PATH):
        print("⚠️  数据库已存在，跳过完整初始化（如需重置请删除 love_diary.db）")
        return

    conn = sqlite3.connect(DB_PATH)
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()
    print("✅ 通过 schema.sql 完整建表完成（8 张表）")


def init_db_orm():
    """通过 ORM 增量建表（模型新增字段/表时使用）"""
    Base.metadata.create_all(bind=engine)
    print("✅ ORM 增量建表完成")


if __name__ == "__main__":
    init_db_full()
    # init_db_orm()
