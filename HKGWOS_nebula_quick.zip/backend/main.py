"""
情侣智能随手恋爱日记本 - 后端入口
启动：uvicorn main:app --reload --host 0.0.0.0 --port 8000
Swagger 文档：http://localhost:8000/docs
"""
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List

from models import SessionLocal, engine, Base, User, Message
from init_db import init_db_full


# ============================================================
# 启动时自动建表
# ============================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 开发阶段：先通过 schema.sql 创建完整 8 张表（含外键依赖）
    # 后续 ORM 新增字段/表可调用 Base.metadata.create_all 增量同步
    init_db_full()
    print("✅ 数据库表已就绪")
    yield


app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    description="双人专属·对话式随手记录·AI 自动分类归档",
    version="0.1.0",
    lifespan=lifespan,
)

# ============================================================
# CORS：允许所有源跨域（开发期；生产按需收紧）
# ============================================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# 依赖注入：数据库 Session
# ============================================================
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================================================
# Pydantic 请求/响应模型
# ============================================================
from pydantic import BaseModel, Field


class MessageCreate(BaseModel):
    """前端发送消息的请求体"""
    sender_role: str = Field(..., description="发送人角色：MALE 男主 / FEMALE 女主")
    text_content: str = Field(..., description="文本内容")
    couple_id: str | None = Field(default=None, description="情侣对 ID（可选，未传则使用默认对）")


class MessageOut(BaseModel):
    """返回给前端的消息体"""
    id: str
    couple_id: str
    sender_id: str | None
    sender_role: str
    msg_type: str
    text_content: str | None
    main_category: str | None
    sub_tags: str | None
    ai_summary: str | None
    ai_confidence: float | None
    manual_override: bool
    occurred_at: str | None
    created_at: str

    class Config:
        from_attributes = True


# ============================================================
# 根路由 & 健康检查
# ============================================================
@app.get("/", tags=["系统"])
def root():
    return {
        "service": "love-diary-api",
        "version": "0.1.0",
        "docs": "/docs",
        "status": "ok",
    }


@app.get("/health", tags=["系统"])
def health():
    return {"status": "healthy", "time": datetime.utcnow().isoformat()}


# ============================================================
# 核心 API：消息
# ============================================================
DEFAULT_COUPLE_ID = "00000000-0000-0000-0000-000000000001"


def _ensure_default_couple_and_users(db: Session) -> dict[str, str]:
    """确保默认情侣对 + 男主/女主用户存在，返回 {MALE: user_id, FEMALE: user_id}"""
    from models import Couple
    import uuid

    couple = db.query(Couple).filter(Couple.id == DEFAULT_COUPLE_ID).first()
    if not couple:
        couple = Couple(
            id=DEFAULT_COUPLE_ID,
            couple_name="默认情侣",
            access_password="$2b$12$placeholder_hash_value",
        )
        db.add(couple)
        db.commit()

    user_map: dict[str, str] = {}
    for role in ("MALE", "FEMALE"):
        user = (
            db.query(User)
            .filter(User.couple_id == DEFAULT_COUPLE_ID, User.role == role)
            .first()
        )
        if not user:
            user = User(
                id=str(uuid.uuid4()),
                couple_id=DEFAULT_COUPLE_ID,
                role=role,
                nickname="男主" if role == "MALE" else "女主",
            )
            db.add(user)
            db.commit()
            db.refresh(user)
        user_map[role] = user.id
    return user_map


@app.post("/api/messages", response_model=MessageOut, status_code=201, tags=["消息"])
def create_message(payload: MessageCreate, db: Session = Depends(get_db)):
    """
    创建一条聊天消息
    - 接收发送人角色（MALE/FEMALE）+ 文本内容
    - 立即入库，AI 分类字段暂留空（异步填充）
    """
    if payload.sender_role not in ("MALE", "FEMALE"):
        raise HTTPException(status_code=400, detail="sender_role 必须为 MALE 或 FEMALE")

    couple_id = payload.couple_id or DEFAULT_COUPLE_ID

    # 确保默认情侣对 + 男女主用户存在
    user_map = _ensure_default_couple_and_users(db)
    sender_id = user_map[payload.sender_role]

    # ============================================================
    # TODO: 接入 AI 分类打标逻辑
    #   1. 调用 AIService 对 text_content 进行场景识别
    #   2. 输出：main_category / sub_tags / related_categories / ai_summary / ai_confidence
    #   3. 同步写入 ai_classification_jobs 任务队列，支持重试与可观测
    #   4. 若是 NICKNAME 类，触发 nickname_dict 抽取
    # 当前实现：AI 字段先留空，由后续 Worker 异步回写
    # ============================================================
    msg = Message(
        couple_id=couple_id,
        sender_id=sender_id,
        msg_type="TEXT",
        text_content=payload.text_content,
        # AI 字段暂留空，等待 Worker 异步填充
        main_category=None,
        sub_tags="[]",
        related_categories="[]",
        ai_summary=None,
        ai_confidence=None,
        manual_override=False,
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)

    return MessageOut(
        id=msg.id,
        couple_id=msg.couple_id,
        sender_id=msg.sender_id,
        sender_role=payload.sender_role,
        msg_type=msg.msg_type,
        text_content=msg.text_content,
        main_category=msg.main_category,
        sub_tags=msg.sub_tags,
        ai_summary=msg.ai_summary,
        ai_confidence=msg.ai_confidence,
        manual_override=msg.manual_override,
        occurred_at=str(msg.occurred_at) if msg.occurred_at else None,
        created_at=msg.created_at.isoformat() if msg.created_at else "",
    )


@app.get("/api/messages", response_model=List[MessageOut], tags=["消息"])
def list_messages(
    couple_id: str | None = None,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    """
    按时间正序返回历史消息（全局时间轴）
    - couple_id：可选，未传则返回默认情侣对的消息
    - limit：返回条数上限，默认 100
    """
    cid = couple_id or DEFAULT_COUPLE_ID

    rows = (
        db.query(Message, User.role)
        .outerjoin(User, User.id == Message.sender_id)
        .filter(Message.couple_id == cid)
        .order_by(Message.created_at.asc())
        .limit(limit)
        .all()
    )

    result: List[MessageOut] = []
    for msg, role in rows:
        result.append(
            MessageOut(
                id=msg.id,
                couple_id=msg.couple_id,
                sender_id=msg.sender_id,
                sender_role=role or "UNKNOWN",
                msg_type=msg.msg_type,
                text_content=msg.text_content,
                main_category=msg.main_category,
                sub_tags=msg.sub_tags,
                ai_summary=msg.ai_summary,
                ai_confidence=msg.ai_confidence,
                manual_override=msg.manual_override,
                occurred_at=str(msg.occurred_at) if msg.occurred_at else None,
                created_at=msg.created_at.isoformat() if msg.created_at else "",
            )
        )
    return result


# ============================================================
# 启动入口
# ============================================================
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
