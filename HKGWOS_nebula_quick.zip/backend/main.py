"""
情侣智能随手恋爱日记本 - 后端入口 v3
- 支持 multipart/form-data 上传（文字 + 图片 + 语音）
- 静态文件代理 uploads/ 目录
- AI 自动/手动 双模式分类
"""
import os
import json
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, Query, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from sqlalchemy.orm import Session
from sqlalchemy import func
from dotenv import load_dotenv

from models import SessionLocal, User, Message, MediaAsset
from init_db import init_db_full
from ai_service import classify_message, CATEGORIES, CATEGORY_LABELS

load_dotenv()

# ============================================================
# 目录与启动
# ============================================================
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db_full()
    print(f"✅ 数据库就绪，上传目录：{UPLOAD_DIR}")
    yield


app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 静态文件代理 /uploads → 本地 uploads 目录
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")


# ============================================================
# 依赖注入
# ============================================================
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ============================================================
# Pydantic 响应模型
# ============================================================
from pydantic import BaseModel


class MessageOut(BaseModel):
    id: str
    couple_id: str
    sender_id: Optional[str] = None
    sender_role: str
    msg_type: str
    text_content: Optional[str] = None
    media_urls: List[str] = []
    main_category: Optional[str] = None
    sub_tags: Optional[List[str]] = None
    related_categories: Optional[List[str]] = None
    ai_summary: Optional[str] = None
    ai_confidence: Optional[float] = None
    manual_override: bool = False
    occurred_at: Optional[str] = None
    created_at: str

    class Config:
        from_attributes = True


class CategoryStat(BaseModel):
    category: str
    label: str
    count: int


# ============================================================
# 工具
# ============================================================
DEFAULT_COUPLE_ID = "00000000-0000-0000-0000-000000000001"


def _ensure_default_couple_and_users(db: Session) -> dict:
    from models import Couple
    couple = db.query(Couple).filter(Couple.id == DEFAULT_COUPLE_ID).first()
    if not couple:
        couple = Couple(
            id=DEFAULT_COUPLE_ID,
            couple_name="默认情侣",
            access_password="$2b$12$placeholder_hash_value",
        )
        db.add(couple)
        db.commit()

    user_map = {}
    for role in ("MALE", "FEMALE"):
        user = (
            db.query(User)
            .filter(User.couple_id == DEFAULT_COUPLE_ID, User.role == role)
            .first()
        )
        if not user:
            user = User(
                id=str(uuid.uuid4()),
                couple_id=DEFAULT_COUPLE_ID,
                role=role,
                nickname="男主" if role == "MALE" else "女主",
            )
            db.add(user)
            db.commit()
            db.refresh(user)
        user_map[role] = user.id
    return user_map


def _save_upload(file: UploadFile, media_type: str) -> Optional[MediaAsset]:
    """保存上传文件到 uploads 目录，返回 MediaAsset 对象（不入库）"""
    if not file or not file.filename:
        return None

    ext = os.path.splitext(file.filename)[1].lower()
    if not ext:
        ext = ".jpg" if media_type == "IMAGE" else ".mp3"

    date_prefix = datetime.now().strftime("%Y%m%d")
    filename = f"{date_prefix}_{uuid.uuid4().hex[:8]}{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)

    content = file.file.read()
    with open(filepath, "wb") as f:
        f.write(content)

    asset = MediaAsset(
        id=str(uuid.uuid4()),
        couple_id=DEFAULT_COUPLE_ID,
        uploader_id="",  # 后面补
        media_type=media_type,
        file_path=f"uploads/{filename}",
        mime_type=file.content_type or "application/octet-stream",
        size_bytes=len(content),
    )

    # 图片：提取宽高
    if media_type == "IMAGE":
        try:
            from PIL import Image
            import io
            img = Image.open(io.BytesIO(content))
            asset.width, asset.height = img.size
        except Exception:
            pass

    # 语音：留空 duration_ms（后续可加 mutagen）
    return asset


def _row_to_out(msg, role: str, media_urls: List[str]) -> MessageOut:
    return MessageOut(
        id=msg.id,
        couple_id=msg.couple_id,
        sender_id=msg.sender_id,
        sender_role=role or "UNKNOWN",
        msg_type=msg.msg_type,
        text_content=msg.text_content,
        media_urls=media_urls,
        main_category=msg.main_category,
        sub_tags=json.loads(msg.sub_tags) if msg.sub_tags else [],
        related_categories=json.loads(msg.related_categories) if msg.related_categories else [],
        ai_summary=msg.ai_summary,
        ai_confidence=msg.ai_confidence,
        manual_override=bool(msg.manual_override),
        occurred_at=str(msg.occurred_at) if msg.occurred_at else None,
        created_at=msg.created_at.isoformat() if msg.created_at else "",
    )


def _load_media_urls(db: Session, msg: Message) -> List[str]:
    """根据消息的 media_asset_ids 加载媒体 URL 列表"""
    if not msg.media_asset_ids:
        return []
    ids = [i.strip() for i in msg.media_asset_ids.split(",") if i.strip()]
    if not ids:
        return []
    assets = db.query(MediaAsset).filter(MediaAsset.id.in_(ids)).all()
    base = os.getenv("UPLOAD_BASE_URL", "")
    return [f"{base}/{a.file_path}" if base else f"/{a.file_path}" for a in assets]


# ============================================================
# 根路由 & 健康检查
# ============================================================
@app.get("/", tags=["系统"])
def root():
    return {
        "service": "love-diary-api",
        "version": "0.3.0",
        "docs": "/docs",
        "ai_mock_mode": os.getenv("AI_USE_MOCK", "1") == "1",
    }


@app.get("/health", tags=["系统"])
def health():
    return {"status": "healthy", "time": datetime.utcnow().isoformat()}


# ============================================================
# 消息 API（multipart/form-data）
# ============================================================
@app.post("/api/messages", response_model=MessageOut, status_code=201, tags=["消息"])
async def create_message(
    sender_role: str = Form(..., description="MALE 男主 / FEMALE 女主"),
    text_content: Optional[str] = Form(None, description="文本内容"),
    is_ai_auto: bool = Form(True, description="是否 AI 自动分类"),
    manual_category: Optional[str] = Form(None, description="手动分类（is_ai_auto=false 时必填）"),
    images: List[UploadFile] = File(default=[], description="图片文件"),
    db: Session = Depends(get_db),
):
    """
    创建消息（支持文字 + 图片 + 语音）
    - is_ai_auto=true：调用 AI 分类
    - is_ai_auto=false：使用 manual_category，跳过 AI
    """
    if sender_role not in ("MALE", "FEMALE"):
        raise HTTPException(status_code=400, detail="sender_role 必须为 MALE 或 FEMALE")

    if not is_ai_auto and not manual_category:
        raise HTTPException(status_code=400, detail="手动模式下必须提供 manual_category")

    if manual_category and manual_category not in CATEGORIES:
        raise HTTPException(status_code=400, detail=f"无效分类：{manual_category}，可选：{CATEGORIES}")

    if not text_content and not images:
        raise HTTPException(status_code=400, detail="文本和图片不能同时为空")

    couple_id = DEFAULT_COUPLE_ID
    user_map = _ensure_default_couple_and_users(db)
    sender_id = user_map[sender_role]

    # 保存上传的图片
    saved_assets = []
    image_paths = []  # 供 AI 调用使用的本地路径
    for img in images:
        asset = _save_upload(img, "IMAGE")
        if asset:
            asset.uploader_id = sender_id
            db.add(asset)
            db.flush()  # 获取 ID
            saved_assets.append(asset)
            image_paths.append(os.path.join(UPLOAD_DIR, os.path.basename(asset.file_path)))

    # 确定消息类型
    if images and text_content:
        msg_type = "IMAGE"  # 混合类型按图片算
    elif images:
        msg_type = "IMAGE"
    else:
        msg_type = "TEXT"

    # 分类逻辑
    if is_ai_auto:
        ai_result = classify_message(text_content or "", image_paths)
        main_category = ai_result["main_category"]
        sub_tags = ai_result["sub_tags"]
        related_categories = ai_result["related_categories"]
        ai_summary = ai_result["ai_summary"]
        ai_confidence = ai_result["ai_confidence"]
        ai_model_version = ai_result["ai_model_version"]
        manual_override = False
    else:
        # 手动模式：直接用前端传的分类，AI 字段留空
        main_category = manual_category
        sub_tags = []
        related_categories = []
        ai_summary = None
        ai_confidence = None
        ai_model_version = "manual"
        manual_override = True

    # 入库消息
    media_ids_str = ",".join([a.id for a in saved_assets]) if saved_assets else ""
    msg = Message(
        couple_id=couple_id,
        sender_id=sender_id,
        msg_type=msg_type,
        text_content=text_content,
        media_asset_ids=media_ids_str,
        main_category=main_category,
        sub_tags=json.dumps(sub_tags, ensure_ascii=False),
        related_categories=json.dumps(related_categories, ensure_ascii=False),
        ai_summary=ai_summary,
        ai_confidence=ai_confidence,
        ai_model_version=ai_model_version,
        manual_override=manual_override,
    )
    db.add(msg)
    db.commit()
    db.refresh(msg)

    media_urls = _load_media_urls(db, msg)
    return _row_to_out(msg, sender_role, media_urls)


@app.get("/api/messages", response_model=List[MessageOut], tags=["消息"])
def list_messages(
    couple_id: Optional[str] = None,
    category: Optional[str] = Query(None),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    order: str = Query("asc"),
    limit: int = Query(500, ge=1, le=2000),
    db: Session = Depends(get_db),
):
    """获取消息列表（时间轴/聊天页/分类页通用）"""
    cid = couple_id or DEFAULT_COUPLE_ID
    q = (
        db.query(Message, User.role)
        .outerjoin(User, User.id == Message.sender_id)
        .filter(Message.couple_id == cid)
    )

    if category:
        if category not in CATEGORIES:
            raise HTTPException(status_code=400, detail=f"无效分类：{category}")
        q = q.filter(Message.main_category == category)
    if start_date:
        q = q.filter(Message.occurred_at >= start_date)
    if end_date:
        q = q.filter(Message.occurred_at <= end_date)

    q = q.order_by(Message.created_at.desc() if order == "desc" else Message.created_at.asc())
    rows = q.limit(limit).all()

    result = []
    for msg, role in rows:
        media_urls = _load_media_urls(db, msg)
        result.append(_row_to_out(msg, role, media_urls))
    return result


# ============================================================
# 分类 API
# ============================================================
@app.get("/api/categories", response_model=List[CategoryStat], tags=["分类"])
def list_categories(db: Session = Depends(get_db)):
    rows = (
        db.query(Message.main_category, func.count(Message.id))
        .filter(Message.main_category.isnot(None))
        .group_by(Message.main_category)
        .all()
    )
    result = []
    found = set()
    for cat, cnt in rows:
        result.append(CategoryStat(category=cat, label=CATEGORY_LABELS.get(cat, cat), count=cnt))
        found.add(cat)
    for cat in CATEGORIES:
        if cat not in found:
            result.append(CategoryStat(category=cat, label=CATEGORY_LABELS[cat], count=0))
    return result


@app.get("/api/categories/{category_name}", response_model=List[MessageOut], tags=["分类"])
def get_category_messages(
    category_name: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = Query(200, ge=1, le=1000),
    db: Session = Depends(get_db),
):
    if category_name not in CATEGORIES:
        raise HTTPException(status_code=400, detail=f"无效分类：{category_name}")

    q = (
        db.query(Message, User.role)
        .outerjoin(User, User.id == Message.sender_id)
        .filter(Message.main_category == category_name)
    )
    if start_date:
        q = q.filter(Message.occurred_at >= start_date)
    if end_date:
        q = q.filter(Message.occurred_at <= end_date)

    rows = q.order_by(Message.created_at.desc()).limit(limit).all()
    result = []
    for msg, role in rows:
        media_urls = _load_media_urls(db, msg)
        result.append(_row_to_out(msg, role, media_urls))
    return result


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
