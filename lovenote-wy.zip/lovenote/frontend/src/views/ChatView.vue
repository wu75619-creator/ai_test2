<template>
  <div class="chat-page">
    <!-- 顶部标题栏 -->
    <div class="chat-header">
      <div class="header-title">💑 我们的恋爱日记本</div>
      <div class="header-subtitle">随手记录，AI自动归档，珍藏每一份甜蜜</div>
    </div>

    <!-- 消息列表区域 -->
    <div class="chat-messages" ref="messageListRef">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载消息中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💌</div>
        <div>还没有消息，发第一条消息开始记录我们的故事吧～</div>
        <div class="empty-hint">支持文字、图片、语音、视频录制，AI自动分类归档</div>
      </div>
      <template v-else>
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="message-item"
          :class="msg.sender_role === '女主' ? 'message-female' : 'message-male'"
        >
          <div class="avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
            {{ msg.sender_role === '女主' ? '👩' : '👨' }}
          </div>
          <div class="message-body">
            <div class="sender-name">{{ msg.sender_nickname }}</div>

            <div class="bubble" :class="msg.sender_role === '女主' ? 'bubble-female' : 'bubble-male'">
              <!-- 图片 -->
              <div v-if="getImageAttachments(msg).length > 0" class="images-wrap">
                <div :class="['image-grid', `grid-${Math.min(getImageAttachments(msg).length, 4)}`]">
                  <el-image
                    v-for="(att, idx) in getImageAttachments(msg)"
                    :key="idx"
                    :src="att.file_url"
                    :preview-src-list="getImageAttachments(msg).map(a => a.file_url)"
                    :initial-index="idx"
                    fit="cover"
                    class="msg-image"
                    preview-teleported
                    hide-on-click-modal
                  />
                </div>
              </div>

              <!-- 视频 -->
              <div v-for="(att, idx) in getVideoAttachments(msg)" :key="'v'+idx" class="video-wrap">
                <video :src="att.file_url" controls playsinline preload="metadata" class="msg-video"></video>
              </div>

              <!-- 语音 -->
              <div v-for="(att, idx) in getVoiceAttachments(msg)" :key="'voice'+idx" class="voice-msg" @click="toggleVoice(att.file_url)">
                <div class="voice-icon">
                  <el-icon :class="{'playing': currentPlayingVoice === att.file_url}">
                    <VideoPause v-if="currentPlayingVoice === att.file_url" />
                    <VideoPlay v-else />
                  </el-icon>
                </div>
                <div class="voice-wave">
                  <div class="wave-bar" v-for="n in 12" :key="n" :style="{height: `${12 + Math.random()*12}px`}"></div>
                </div>
                <span class="voice-duration">{{ formatDuration(att.duration || msg.voice_duration) }}</span>
                <audio ref="voiceAudios" :src="att.file_url" @ended="onVoiceEnded"></audio>
              </div>

              <!-- 文字 -->
              <div v-if="msg.text_content" class="text-content">{{ msg.text_content }}</div>

              <!-- AI小结 -->
              <div v-if="msg.ai_summary && msg.ai_processed && !msg.is_manual_category" class="ai-summary">
                <span class="ai-tag">✨ AI小结</span>
                {{ msg.ai_summary }}
              </div>

              <!-- 分类标签 -->
              <div v-if="msg.main_category_name" class="category-tag" :style="msg.main_category_color ? {borderColor: msg.main_category_color+'40', color: msg.main_category_color} : {}">
                {{ msg.main_category_icon }} {{ msg.main_category_name }}
                <span v-if="msg.is_manual_category" class="manual-badge">手动</span>
              </div>
              <div v-else-if="!msg.ai_processed" class="processing-tag">
                <el-icon class="is-loading"><Loading /></el-icon> AI归档中...
              </div>
            </div>

            <div class="message-time">{{ formatTime(msg.created_at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- 音频录音遮罩 -->
    <div v-if="isRecording" class="recording-overlay" @click.stop>
      <div class="recording-panel">
        <div class="recording-indicator">
          <div class="recording-pulse"></div>
          <el-icon class="mic-icon"><Microphone /></el-icon>
        </div>
        <div class="recording-time">{{ recordingDuration }}s</div>
        <div class="recording-hint">松开发送 · 点击按钮取消或确认</div>
        <div class="recording-actions">
          <el-button type="danger" circle @click="cancelRecording" size="large">
            <el-icon><Close /></el-icon>
          </el-button>
          <el-button type="primary" circle @click="finishRecording" size="large">
            <el-icon><Check /></el-icon>
          </el-button>
        </div>
      </div>
    </div>

    <!-- 视频录制遮罩 -->
    <div v-if="isVideoRecording" class="recording-overlay" @click.stop>
      <div class="video-recording-panel">
        <div class="video-rec-header">
          <span class="video-rec-badge">
            <span class="rec-dot"></span> 录制中 {{ videoDuration }}s
          </span>
        </div>
        <video ref="videoPreviewEl" class="video-preview-cam" autoplay muted playsinline></video>
        <div class="video-rec-actions">
          <el-button type="danger" circle size="large" @click="cancelVideoRecording">
            <el-icon><Close /></el-icon>
          </el-button>
          <el-button type="success" circle size="large" @click="finishVideoRecording">
            <el-icon><Check /></el-icon>
          </el-button>
        </div>
        <div class="recording-hint">点击绿色按钮完成录制，红色按钮取消</div>
      </div>
    </div>

    <!-- 底部输入区域 -->
    <div class="chat-input-area">
      <div class="input-options">
        <div class="ai-switch">
          <el-switch v-model="isAiAuto" size="small" active-color="#ff6b9d" />
          <span class="switch-label">AI自动分类</span>
        </div>
        <el-select
          v-if="!isAiAuto"
          v-model="selectedCategory"
          placeholder="选择分类"
          size="small"
          class="category-select"
        >
          <el-option-group v-for="group in categoryGroups" :key="group.label" :label="group.label">
            <el-option
              v-for="cat in group.options"
              :key="cat.id"
              :label="`${cat.icon} ${cat.name}`"
              :value="cat.name"
            />
          </el-option-group>
        </el-select>
      </div>

      <!-- 预览选中的图片 -->
      <div v-if="selectedImages.length > 0" class="preview-images">
        <div v-for="(img, idx) in selectedImages" :key="idx" class="preview-img-item">
          <img :src="img.preview" />
          <el-icon class="remove-btn" @click="removeImage(idx)"><Close /></el-icon>
        </div>
      </div>

      <!-- 视频预览 -->
      <div v-if="selectedVideo" class="video-preview">
        <video :src="selectedVideo.preview" controls class="preview-video"></video>
        <div class="vid-info">
          <span>视频 {{ selectedVideo.duration }}s</span>
          <el-icon class="remove-btn" @click="selectedVideo = null"><Close /></el-icon>
        </div>
      </div>

      <!-- 语音预览 -->
      <div v-if="selectedVoice" class="voice-preview">
        <div class="voice-rec-info">
          <el-icon><Microphone /></el-icon>
          <span>语音 {{ selectedVoice.duration }}s</span>
        </div>
        <audio :src="selectedVoice.preview" controls class="preview-voice"></audio>
        <el-icon class="remove-voice" @click="clearVoice"><Close /></el-icon>
      </div>

      <div class="input-wrapper">
        <div class="func-btns">
          <el-upload
            :show-file-list="false"
            accept="image/*"
            multiple
            :before-upload="handleImageSelect"
            class="upload-btn"
          >
            <el-button circle size="small" :icon="Picture" :disabled="!!selectedVoice || isRecording || isVideoRecording || !!selectedVideo" />
          </el-upload>

          <el-upload
            :show-file-list="false"
            accept="video/*"
            :before-upload="handleVideoFileSelect"
            class="upload-btn"
          >
            <el-button circle size="small" :disabled="!!selectedVoice || isRecording || isVideoRecording || selectedImages.length > 0">
              <el-icon><Film /></el-icon>
            </el-button>
          </el-upload>

          <!-- 视频录制按钮 -->
          <el-button
            circle
            size="small"
            :class="{'recording-btn': isVideoRecording}"
            :disabled="selectedImages.length > 0 || !!selectedVideo || !!selectedVoice || !!inputText.trim() || isRecording"
            @click="startVideoRecording"
          >
            <el-icon><VideoCamera /></el-icon>
          </el-button>

          <!-- 语音录制按钮 -->
          <el-button
            circle
            size="small"
            :class="{'recording-btn': isRecording}"
            :disabled="selectedImages.length > 0 || !!selectedVideo || !!selectedVoice || !!inputText.trim() || isVideoRecording"
            @mousedown.prevent="startRecording"
            @touchstart.prevent="startRecording"
          >
            <el-icon><Microphone /></el-icon>
          </el-button>
        </div>

        <el-input
          v-model="inputText"
          type="textarea"
          :rows="1"
          autosize
          placeholder="说点什么吧～ 支持文字/图片/语音/视频"
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
          class="msg-input"
          :disabled="isRecording || isVideoRecording"
        />

        <el-button
          type="primary"
          class="send-btn"
          @click="handleSend"
          :loading="sending"
          :disabled="!canSend"
        >
          发送 💕
        </el-button>
      </div>

      <div class="role-tip">
        发送身份：
        <el-radio-group v-model="currentSender" size="small">
          <el-radio-button label="男主">👨 男主</el-radio-button>
          <el-radio-button label="女主">👩 女主</el-radio-button>
        </el-radio-group>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, nextTick, onBeforeUnmount } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { Loading, Picture, Microphone, Close, Check, VideoPlay, VideoPause, Film, VideoCamera } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'
import { getCategories } from '../api/category'
import { AudioRecorder } from '../utils/recorder'
import { VideoRecorder } from '../utils/videoRecorder'

const messageListRef = ref(null)
const voiceAudios = ref([])
const videoPreviewEl = ref(null)
const loading = ref(false)
const sending = ref(false)
const messages = ref([])
const inputText = ref('')
const currentSender = ref('女主')
const isAiAuto = ref(true)
const selectedCategory = ref('')
const categories = ref([])

const selectedImages = ref([])
const selectedVideo = ref(null)
const selectedVoice = ref(null)

// Audio recording
const recorder = ref(null)
const isRecording = ref(false)
const recordingDuration = ref(0)
const recordingTimer = ref(null)

// Video recording
const videoRecorder = ref(null)
const isVideoRecording = ref(false)
const videoDuration = ref(0)
const videoTimer = ref(null)

// Voice playback
const currentPlayingVoice = ref(null)
const currentAudio = ref(null)

const canSend = computed(() => {
  if (sending.value || isRecording.value || isVideoRecording.value) return false
  const hasContent = inputText.value.trim() || selectedImages.value.length > 0 || selectedVideo.value || selectedVoice.value
  if (!hasContent) return false
  if (!isAiAuto.value && !selectedCategory.value) return false
  return true
})

const categoryGroups = computed(() => {
  const system = categories.value.filter(c => c.is_system)
  const custom = categories.value.filter(c => c.is_custom)
  const groups = [{ label: '系统分类', options: system }]
  if (custom.length > 0) groups.push({ label: '我的分类', options: custom })
  return groups
})

const getImageAttachments = (msg) => (msg.attachments || []).filter(a => a.file_type === 'image')
const getVideoAttachments = (msg) => (msg.attachments || []).filter(a => a.file_type === 'video')
const getVoiceAttachments = (msg) => (msg.attachments || []).filter(a => a.file_type === 'voice')

const formatTime = (time) => dayjs(time).format('MM-DD HH:mm')
const formatDuration = (seconds) => {
  if (!seconds || seconds <= 0) return '1"'
  return `${seconds}"`
}

const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}

const loadCategories = async () => {
  try {
    const res = await getCategories()
    if (res && res.length > 0) categories.value = res
  } catch (e) { /* ignore */ }
}

const loadMessages = async () => {
  loading.value = true
  try {
    const res = await getMessages('asc')
    messages.value = res
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  } finally {
    loading.value = false
  }
}

// Image selection
const handleImageSelect = (file) => {
  if (selectedVoice.value || selectedVideo.value) {
    ElMessage.warning('请先发送或移除已选媒体')
    return false
  }
  const preview = URL.createObjectURL(file)
  selectedImages.value.push({ file, preview })
  return false
}

const removeImage = (idx) => selectedImages.value.splice(idx, 1)

// Video file selection (from gallery)
const handleVideoFileSelect = (file) => {
  if (selectedVoice.value || isRecording.value) {
    ElMessage.warning('请先完成当前操作')
    return false
  }
  if (selectedImages.value.length > 0) {
    ElMessage.warning('请先发送或移除已选图片')
    return false
  }
  if (selectedVideo.value) {
    ElMessage.warning('一次只能发送一个视频')
    return false
  }
  const videoUrl = URL.createObjectURL(file)
  const tempVideo = document.createElement('video')
  tempVideo.preload = 'metadata'
  tempVideo.onloadedmetadata = () => {
    selectedVideo.value = {
      file,
      preview: videoUrl,
      duration: Math.round(tempVideo.duration) || 0
    }
  }
  tempVideo.src = videoUrl
  return false
}

// ========== Audio Recording ==========
const startRecording = async () => {
  if (!AudioRecorder.isSupported()) {
    ElMessage.error('当前浏览器不支持录音，请使用Chrome/Edge等现代浏览器')
    return
  }
  try {
    recorder.value = new AudioRecorder()
    await recorder.value.start()
    isRecording.value = true
    recordingDuration.value = 0
    recordingTimer.value = setInterval(() => {
      recordingDuration.value++
      if (recordingDuration.value >= 60) finishRecording()
    }, 1000)
  } catch (err) {
    if (err.name === 'NotAllowedError') ElMessage.error('麦克风权限被拒绝')
    else if (err.name === 'NotFoundError') ElMessage.error('未检测到麦克风设备')
    else ElMessage.error(`录音启动失败: ${err.message}`)
  }
}

const finishRecording = async () => {
  if (!recorder.value) return
  try {
    const { file, duration } = await recorder.value.stop()
    clearInterval(recordingTimer.value)
    isRecording.value = false
    const actualDur = duration > 0 ? duration : recordingDuration.value
    selectedVoice.value = {
      file,
      preview: URL.createObjectURL(file),
      duration: actualDur
    }
    if (!isAiAuto.value) selectedCategory.value = '语音专属存档'
    recorder.value = null
  } catch (err) {
    ElMessage.error('录音失败')
    cancelRecording()
  }
}

const cancelRecording = () => {
  if (recorder.value) recorder.value.cancel()
  clearInterval(recordingTimer.value)
  isRecording.value = false
  recorder.value = null
}

const clearVoice = () => {
  selectedVoice.value = null
}

// ========== Video Recording ==========
const startVideoRecording = async () => {
  if (!VideoRecorder.isSupported()) {
    ElMessage.error('当前浏览器不支持视频录制')
    return
  }
  try {
    videoRecorder.value = new VideoRecorder()
    isVideoRecording.value = true
    videoDuration.value = 0
    await nextTick()
    await videoRecorder.value.start(videoPreviewEl.value)
    videoTimer.value = setInterval(() => {
      videoDuration.value++
      if (videoDuration.value >= 120) finishVideoRecording()
    }, 1000)
  } catch (err) {
    isVideoRecording.value = false
    if (err.name === 'NotAllowedError') ElMessage.error('摄像头/麦克风权限被拒绝')
    else if (err.name === 'NotFoundError') ElMessage.error('未检测到摄像头设备')
    else ElMessage.error(`视频录制启动失败: ${err.message}`)
    if (videoRecorder.value) videoRecorder.value.cleanup()
    videoRecorder.value = null
  }
}

const finishVideoRecording = async () => {
  if (!videoRecorder.value) return
  try {
    const { file, duration } = await videoRecorder.value.stop()
    clearInterval(videoTimer.value)
    isVideoRecording.value = false
    selectedVideo.value = {
      file,
      preview: URL.createObjectURL(file),
      duration: duration > 0 ? duration : videoDuration.value
    }
    videoRecorder.value = null
  } catch (err) {
    ElMessage.error('视频录制失败')
    cancelVideoRecording()
  }
}

const cancelVideoRecording = () => {
  if (videoRecorder.value) videoRecorder.value.cancel()
  clearInterval(videoTimer.value)
  isVideoRecording.value = false
  videoRecorder.value = null
}

// ========== Voice Playback ==========
const onVoiceEnded = () => {
  currentPlayingVoice.value = null
  currentAudio.value = null
}

const toggleVoice = (url) => {
  if (currentAudio.value) {
    currentAudio.value.pause()
    if (currentPlayingVoice.value === url) {
      currentPlayingVoice.value = null
      currentAudio.value = null
      return
    }
  }
  const audios = voiceAudios.value
  for (const audio of audios) {
    if (audio && audio.src && audio.src.endsWith(url)) {
      audio.play()
      currentAudio.value = audio
      currentPlayingVoice.value = url
      break
    }
  }
}

// ========== Send ==========
const handleSend = async () => {
  if (!canSend.value) {
    if (!isAiAuto.value && !selectedCategory.value) ElMessage.warning('请先选择分类')
    return
  }
  sending.value = true
  try {
    await sendMessage({
      sender_role: currentSender.value,
      text_content: inputText.value.trim() || null,
      is_ai_auto: isAiAuto.value,
      manual_category: isAiAuto.value ? null : selectedCategory.value,
      voice_duration: selectedVoice.value?.duration || null,
      video_duration: selectedVideo.value?.duration || null,
      images: selectedImages.value.map(i => i.file),
      voice: selectedVoice.value?.file || null,
      video: selectedVideo.value?.file || null
    })

    inputText.value = ''
    selectedImages.value = []
    selectedVideo.value = null
    selectedVoice.value = null

    await loadMessages()

    if (isAiAuto.value) {
      ElMessage.success('发送成功，AI正在自动归档 ✨')
      let refreshCount = 0
      const refreshTimer = setInterval(async () => {
        await loadMessages()
        refreshCount++
        if (refreshCount >= 8) clearInterval(refreshTimer)
      }, 2000)
    } else {
      ElMessage.success('发送成功 💌')
    }
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '发送失败，请检查后端服务')
  } finally {
    sending.value = false
  }
}

onBeforeUnmount(() => {
  if (recorder.value) recorder.value.cleanup()
  if (videoRecorder.value) videoRecorder.value.cleanup()
  if (recordingTimer.value) clearInterval(recordingTimer.value)
  if (videoTimer.value) clearInterval(videoTimer.value)
})

onMounted(() => {
  loadCategories()
  loadMessages()
})
</script>

<style scoped>
.chat-page {
  width: 100%; height: 100%;
  display: flex; flex-direction: column;
  background: var(--bg-color); position: relative;
}
.chat-header {
  padding: 14px 16px 10px; text-align: center;
  background: white; border-bottom: 1px solid var(--border-color); flex-shrink: 0;
}
.header-title { font-size: 17px; font-weight: 600; color: var(--el-color-primary); margin-bottom: 2px; }
.header-subtitle { font-size: 11px; color: var(--text-secondary); }
.chat-messages {
  flex: 1; overflow-y: auto; padding: 12px;
  display: flex; flex-direction: column; gap: 14px; -webkit-overflow-scrolling: touch;
}
.loading-tip, .empty-tip { text-align: center; color: var(--text-secondary); padding: 40px 0; font-size: 14px; }
.empty-icon { font-size: 48px; margin-bottom: 12px; }
.empty-hint { font-size: 12px; margin-top: 8px; opacity: 0.7; }
.message-item { display: flex; gap: 8px; max-width: 85%; }
.message-male { align-self: flex-start; }
.message-female { align-self: flex-end; flex-direction: row-reverse; }
.avatar {
  width: 36px; height: 36px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0;
}
.avatar-male { background: var(--male-bubble-bg); }
.avatar-female { background: var(--female-bubble-bg); }
.message-body { display: flex; flex-direction: column; gap: 3px; min-width: 0; }
.message-female .message-body { align-items: flex-end; }
.sender-name { font-size: 11px; color: var(--text-secondary); padding: 0 4px; }
.bubble {
  padding: 8px 10px; border-radius: 14px; font-size: 14px; line-height: 1.6;
  word-break: break-all; max-width: 100%; overflow: hidden;
}
.bubble-male { background: white; color: var(--text-primary); border-bottom-left-radius: 4px; border: 1px solid var(--border-color); }
.bubble-female { background: var(--female-bubble-bg); color: var(--female-bubble-text); border-bottom-right-radius: 4px; }
.images-wrap { margin-bottom: 6px; border-radius: 8px; overflow: hidden; }
.image-grid { display: grid; gap: 3px; border-radius: 8px; overflow: hidden; }
.grid-1 { grid-template-columns: 1fr; max-width: 220px; }
.grid-2 { grid-template-columns: 1fr 1fr; max-width: 220px; }
.grid-3 { grid-template-columns: 1fr 1fr; max-width: 220px; }
.grid-4 { grid-template-columns: 1fr 1fr; max-width: 220px; }
.msg-image { width: 100%; min-height: 80px; max-height: 250px; border-radius: 6px; cursor: pointer; background: #f5f5f5; }
.grid-1 .msg-image { max-height: 300px; }
.video-wrap { margin-bottom: 6px; border-radius: 8px; overflow: hidden; }
.msg-video { max-width: 240px; max-height: 300px; border-radius: 8px; display: block; }
.voice-msg {
  display: flex; align-items: center; gap: 8px; min-width: 120px; padding: 8px 12px;
  background: rgba(255,255,255,0.6); border-radius: 20px; cursor: pointer; margin-bottom: 4px; user-select: none;
}
.bubble-male .voice-msg { background: var(--el-color-primary-light-9); }
.voice-icon {
  width: 28px; height: 28px; border-radius: 50%; background: var(--el-color-primary); color: white;
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.voice-icon .playing { animation: pulse 1s infinite; }
@keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.1)} }
.voice-wave { flex:1; display:flex; align-items:center; gap:2px; height:24px; overflow:hidden; }
.wave-bar { width: 2px; background: var(--el-color-primary); border-radius: 1px; opacity: 0.6; }
.voice-duration { font-size: 12px; color: var(--text-secondary); flex-shrink: 0; }
.text-content { margin: 4px 0; }
.ai-summary {
  margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(0,0,0,0.08);
  font-size: 12px; opacity: 0.9; font-style: italic; line-height: 1.5;
}
.ai-tag { font-weight: 500; margin-right: 4px; font-style: normal; color: var(--el-color-primary); }
.bubble-female .ai-summary { border-top-color: rgba(255,255,255,0.5); }
.category-tag {
  margin-top: 6px; display: inline-flex; align-items: center; gap: 4px; font-size: 11px;
  padding: 2px 8px; border-radius: 10px; background: rgba(255,255,255,0.7);
  border: 1px solid var(--el-color-primary-light-5);
}
.bubble-male .category-tag { background: var(--el-color-primary-light-9); }
.manual-badge { font-size: 9px; background: #e6f7ff; color: #1890ff; padding: 0 4px; border-radius: 4px; margin-left: 2px; }
.processing-tag { margin-top: 6px; font-size: 11px; color: var(--text-secondary); display: flex; align-items: center; gap: 3px; }
.message-time { font-size: 10px; color: var(--text-secondary); padding: 0 4px; }

/* Recording overlay */
.recording-overlay {
  position: fixed; top:0; left:0; right:0; bottom:0; background: rgba(0,0,0,0.6);
  z-index: 1000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px);
}
.recording-panel {
  background: white; border-radius: 24px; padding: 40px 30px 30px;
  text-align: center; box-shadow: 0 20px 60px rgba(0,0,0,0.3); width: 280px;
}
.recording-indicator { position: relative; width: 100px; height: 100px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; }
.recording-pulse {
  position: absolute; width: 100%; height: 100%; border-radius: 50%;
  background: rgba(255,107,157,0.3); animation: recordingPulse 1.5s infinite;
}
@keyframes recordingPulse { 0%{transform:scale(1);opacity:.7} 100%{transform:scale(1.5);opacity:0} }
.mic-icon {
  font-size: 40px; color: white; background: linear-gradient(135deg, #ff6b9d, #ff4081);
  width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center; z-index: 1;
}
.recording-time { font-size: 36px; font-weight: 700; color: var(--el-color-primary); margin-bottom: 8px; font-variant-numeric: tabular-nums; }
.recording-hint { font-size: 13px; color: var(--text-secondary); margin-bottom: 24px; }
.recording-actions { display: flex; justify-content: center; gap: 30px; }

/* Video recording panel */
.video-recording-panel {
  background: #1a1a1a; border-radius: 20px; padding: 20px; width: 320px; max-width: 90vw;
  display: flex; flex-direction: column; align-items: center; gap: 16px;
}
.video-rec-header { display: flex; justify-content: center; }
.video-rec-badge {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(255,0,0,0.2); color: #ff4444; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 600;
}
.rec-dot { width: 8px; height: 8px; border-radius: 50%; background: #ff4444; animation: pulse 1s infinite; }
.video-preview-cam { width: 100%; max-height: 320px; border-radius: 12px; background: #000; object-fit: cover; }
.video-rec-actions { display: flex; gap: 40px; }
.video-rec-actions .el-button { width: 56px; height: 56px; }

/* Input area */
.chat-input-area { background: white; padding: 10px 12px 16px; border-top: 1px solid var(--border-color); flex-shrink: 0; }
.input-options { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; flex-wrap: wrap; }
.ai-switch { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--text-secondary); }
.category-select { flex: 1; min-width: 180px; }
.preview-images { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
.preview-img-item { position: relative; width: 65px; height: 65px; border-radius: 8px; overflow: hidden; }
.preview-img-item img { width: 100%; height: 100%; object-fit: cover; }
.remove-btn, .remove-voice {
  position: absolute; top: 2px; right: 2px; background: rgba(0,0,0,0.6); color: white;
  border-radius: 50%; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; font-size: 12px; cursor: pointer; z-index: 2;
}
.video-preview { position: relative; margin-bottom: 8px; border-radius: 8px; overflow: hidden; display: inline-flex; flex-direction: column; }
.preview-video { max-height: 120px; border-radius: 8px; }
.vid-info { display: flex; align-items: center; justify-content: space-between; padding: 4px 8px; background: rgba(0,0,0,0.05); font-size: 12px; }
.voice-preview { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; padding: 8px; background: var(--bg-cream); border-radius: 8px; position: relative; }
.voice-rec-info { display: flex; align-items: center; gap: 4px; font-size: 12px; color: var(--el-color-primary); white-space: nowrap; }
.preview-voice { flex: 1; height: 32px; }
.remove-voice { position: static; }

.input-wrapper { display: flex; gap: 8px; align-items: flex-end; }
.func-btns { display: flex; gap: 4px; padding-bottom: 4px; flex-wrap: wrap; }
.upload-btn :deep(.el-button) { color: var(--text-secondary); border-color: var(--border-color); background: white; }
.recording-btn { background: var(--el-color-danger) !important; border-color: var(--el-color-danger) !important; color: white !important; animation: pulse 1s infinite; }
.msg-input { flex: 1; }
.msg-input :deep(.el-textarea__inner) {
  border-radius: 20px; border-color: var(--border-color); background: var(--bg-cream);
  padding: 8px 16px; resize: none; max-height: 100px;
}
.msg-input :deep(.el-textarea__inner:focus) { border-color: var(--el-color-primary); }
.send-btn { border-radius: 20px !important; height: 36px; padding: 0 16px; flex-shrink: 0; }
.role-tip { margin-top: 8px; font-size: 11px; color: var(--text-secondary); display: flex; align-items: center; gap: 6px; }
.role-tip :deep(.el-radio-button__inner) { padding: 3px 10px; font-size: 11px; }
</style>
