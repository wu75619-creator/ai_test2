<template>
  <div class="timeline-page">
    <div class="page-header">
      <h1>💕 恋爱时间轴</h1>
      <p>每一条记录，都是我们相爱的证据</p>
    </div>

    <!-- 核心统计面板 -->
    <div class="stats-dashboard" v-loading="loading">
      <div class="stats-hero">
        <div class="hero-item">
          <div class="hero-num">{{ stats.total_days || 0 }}</div>
          <div class="hero-label">天陪伴</div>
        </div>
        <div class="heart-divider">💕</div>
        <div class="hero-item">
          <div class="hero-num">{{ stats.total_messages || 0 }}</div>
          <div class="hero-label">条甜蜜记录</div>
        </div>
        <div class="heart-divider">💬</div>
        <div class="hero-item">
          <div class="hero-num">{{ stats.streak_days || 0 }}</div>
          <div class="hero-label">天连续记录</div>
        </div>
      </div>

      <div class="stats-details">
        <div class="detail-row"><span class="detail-label">📅 活跃天数</span><span class="detail-val">{{ stats.active_days || 0 }} 天</span></div>
        <div class="detail-row"><span class="detail-label">📊 日均消息</span><span class="detail-val">{{ stats.avg_daily_messages || 0 }} 条</span></div>
        <div class="detail-row"><span class="detail-label">📆 活跃周数</span><span class="detail-val">{{ stats.active_weeks || 0 }} 周</span></div>
        <div class="detail-row"><span class="detail-label">🗓️ 活跃月数</span><span class="detail-val">{{ stats.active_months || 0 }} 个月</span></div>
      </div>

      <div class="sender-bar" v-if="stats.total_messages > 0">
        <div class="sender-label">发送比例</div>
        <div class="bar-container">
          <div class="bar-male" :style="{width: malePct + '%'}"><span v-if="malePct > 15">👨 {{ malePct }}%</span></div>
          <div class="bar-female" :style="{width: femalePct + '%'}"><span v-if="femalePct > 15">👩 {{ femalePct }}%</span></div>
        </div>
      </div>

      <div class="chart-toggle">
        <el-radio-group v-model="chartMode" size="small" fill="#ff6b9d">
          <el-radio-button label="weekly">周度统计</el-radio-button>
          <el-radio-button label="monthly">月度统计</el-radio-button>
        </el-radio-group>
      </div>

      <div class="chart-area">
        <div class="chart-bars" v-if="chartData.length > 0">
          <div class="bar-item" v-for="(item, idx) in chartData" :key="idx">
            <div class="bar-stacked" :title="`男主:${item.male_count} 女主:${item.female_count}`">
              <div class="bar-male-part" :style="{height: getBarH(item.male_count) + 'px'}"></div>
              <div class="bar-female-part" :style="{height: getBarH(item.female_count) + 'px'}"></div>
            </div>
            <div class="bar-tick">{{ item.shortLabel }}</div>
            <div class="bar-count">{{ item.message_count || '' }}</div>
          </div>
        </div>
        <div v-else class="chart-empty">暂无数据</div>
      </div>

      <div v-if="stats.category_distribution && stats.category_distribution.length > 0" class="cat-dist-section">
        <div class="section-label">🏷️ 分类分布</div>
        <div class="cat-bars">
          <div v-for="cat in stats.category_distribution.slice(0, 8)" :key="cat.name" class="cat-bar-row">
            <span class="cat-bar-icon">{{ cat.icon }}</span>
            <span class="cat-bar-name">{{ cat.name }}</span>
            <div class="cat-bar-track">
              <div class="cat-bar-fill" :style="{width: cat.percentage + '%', background: cat.color}"></div>
            </div>
            <span class="cat-bar-pct">{{ cat.count }}条</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 时间轴消息列表 -->
    <div class="timeline-container" v-loading="messagesLoading">
      <div v-if="groupedMessages.length === 0 && !messagesLoading" class="empty-state">
        <div style="font-size:48px;margin-bottom:12px">📖</div>
        <div>还没有任何记录，去聊天页留下第一条回忆吧～</div>
        <el-button type="primary" link @click="$router.push('/')">去聊天</el-button>
      </div>
      <el-timeline v-else>
        <div v-for="group in groupedMessages" :key="group.date">
          <div class="date-marker"><span class="date-text">{{ formatDateLabel(group.date) }}</span></div>
          <el-timeline-item
            v-for="msg in group.messages" :key="msg.id"
            :timestamp="formatTime(msg.created_at)"
            :color="msg.sender_role==='女主'?'#ff6b9d':'#4a90e2'" placement="top">
            <div class="timeline-card">
              <div class="card-sender">
                <span class="sender-avatar" :class="msg.sender_role==='女主'?'avatar-female':'avatar-male'">{{ msg.sender_role==='女主'?'👩':'👨' }}</span>
                <span class="sender-name">{{ msg.sender_nickname }}</span>
                <el-tag v-if="msg.main_category_icon" size="small" effect="plain" round class="cat-tag"
                  :style="msg.main_category_color ? {color: msg.main_category_color, borderColor: msg.main_category_color+'40'} : {}">
                  {{ msg.main_category_icon }} {{ msg.main_category_name }}
                </el-tag>
              </div>
              <div v-if="msg.attachments && msg.attachments.length > 0" class="card-images">
                <el-image v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='image')" :key="idx" :src="att.file_url"
                  :preview-src-list="msg.attachments.filter(a=>a.file_type==='image').map(a=>a.file_url)" fit="cover" class="tl-img" preview-teleported />
                <video v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='video')" :key="'vid'+idx" :src="att.file_url" controls playsinline class="tl-video"></video>
                <audio v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='voice')" :key="'v'+idx" :src="att.file_url" controls class="tl-voice"></audio>
              </div>
              <div v-if="msg.text_content" class="card-text">{{ msg.text_content }}</div>
              <div v-if="msg.ai_summary" class="ai-note"><span>✨ AI小结：</span>{{ msg.ai_summary }}</div>
            </div>
          </el-timeline-item>
        </div>
      </el-timeline>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { getMessages } from '../api/message'
import { getStatsDashboard } from '../api/category'

const loading = ref(false)
const messagesLoading = ref(false)
const messages = ref([])
const stats = ref({})
const chartMode = ref('weekly')

const malePct = computed(() => {
  const total = (stats.value.sender_distribution?.男主 || 0) + (stats.value.sender_distribution?.女主 || 0)
  return total > 0 ? Math.round((stats.value.sender_distribution?.男主 || 0) / total * 100) : 50
})
const femalePct = computed(() => 100 - malePct.value)

const chartData = computed(() => {
  if (chartMode.value === 'weekly') {
    return (stats.value.weekly_stats || []).map(w => ({ ...w, shortLabel: w.week_label.split('-')[0] }))
  }
  return (stats.value.monthly_stats || []).map(m => ({ ...m, shortLabel: `${m.month}月` }))
})

const maxBarVal = computed(() => Math.max(...chartData.value.map(d => d.message_count), 1))

const getBarH = (val) => {
  if (!val) return 2
  return Math.max(2, (val / maxBarVal.value) * 80)
}

const groupedMessages = computed(() => {
  const groups = {}
  const sorted = [...messages.value].sort((a,b) => dayjs(b.created_at).valueOf() - dayjs(a.created_at).valueOf())
  sorted.forEach(msg => {
    const date = dayjs(msg.created_at).format('YYYY-MM-DD')
    if (!groups[date]) groups[date] = []
    groups[date].push(msg)
  })
  return Object.keys(groups).map(date => ({ date, messages: groups[date] }))
})

const formatTime = (t) => dayjs(t).format('HH:mm')
const formatDateLabel = (date) => {
  const today = dayjs().format('YYYY-MM-DD')
  const yesterday = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
  if (date === today) return '今天'
  if (date === yesterday) return '昨天'
  return dayjs(date).format('M月D日 ') + ['日','一','二','三','四','五','六'][dayjs(date).day()]
}

const loadStats = async () => {
  loading.value = true
  try { stats.value = await getStatsDashboard() } catch(e) { console.error(e) } finally { loading.value = false }
}
const loadMessages = async () => {
  messagesLoading.value = true
  try { messages.value = await getMessages('desc') } catch(e) { ElMessage.error('加载时间轴失败') } finally { messagesLoading.value = false }
}

onMounted(() => { loadStats(); loadMessages() })
</script>

<style scoped>
.timeline-page { padding: 20px 16px 30px; min-height: 100%; }
.page-header { text-align: center; margin-bottom: 16px; }
.page-header h1 { font-size: 24px; color: var(--el-color-primary); margin-bottom: 4px; }
.page-header p { font-size: 13px; color: var(--text-secondary); }

.stats-dashboard {
  background: linear-gradient(135deg, #fff 0%, #fff5f8 100%);
  border-radius: 20px; padding: 20px; margin-bottom: 24px;
  box-shadow: 0 4px 20px rgba(255,107,157,0.08);
}
.stats-hero { display: flex; align-items: center; justify-content: space-around; margin-bottom: 20px; }
.hero-item { text-align: center; }
.hero-num { font-size: 36px; font-weight: 800; color: var(--el-color-primary); line-height: 1; margin-bottom: 4px; font-variant-numeric: tabular-nums; }
.hero-label { font-size: 12px; color: var(--text-secondary); }
.heart-divider { font-size: 18px; opacity: 0.5; }

.stats-details { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 16px; }
.detail-row { display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background: rgba(255,255,255,0.7); border-radius: 10px; font-size: 13px; }
.detail-label { color: var(--text-secondary); }
.detail-val { font-weight: 600; color: var(--text-primary); }

.sender-bar { margin-bottom: 16px; }
.sender-label { font-size: 12px; color: var(--text-secondary); margin-bottom: 6px; }
.bar-container { display: flex; height: 24px; border-radius: 12px; overflow: hidden; background: #f0f0f0; }
.bar-male { background: linear-gradient(90deg,#4a90e2,#64b5f6); display:flex; align-items:center; justify-content:center; color:white; font-size:11px; font-weight:600; transition: width .5s ease; }
.bar-female { background: linear-gradient(90deg,#ff6b9d,#ff8fb1); display:flex; align-items:center; justify-content:center; color:white; font-size:11px; font-weight:600; transition: width .5s ease; }

.chart-toggle { text-align: center; margin-bottom: 12px; }
.chart-area { margin-bottom: 16px; }
.chart-bars { display: flex; align-items: flex-end; gap: 4px; height: 110px; padding: 0 4px; overflow-x: auto; }
.bar-item { flex: 1; min-width: 20px; display: flex; flex-direction: column; align-items: center; gap: 4px; }
.bar-stacked { width: 100%; max-width: 28px; display: flex; flex-direction: column; justify-content: flex-end; border-radius: 4px 4px 0 0; overflow: hidden; }
.bar-male-part { background: #4a90e2; min-height: 2px; transition: height .4s ease; }
.bar-female-part { background: #ff6b9d; min-height: 2px; transition: height .4s ease; }
.bar-tick { font-size: 9px; color: var(--text-secondary); white-space: nowrap; }
.bar-count { font-size: 9px; color: var(--el-color-primary); font-weight: 600; }
.chart-empty { text-align: center; padding: 20px; color: var(--text-secondary); font-size: 13px; }

.cat-dist-section { border-top: 1px solid rgba(0,0,0,0.05); padding-top: 16px; }
.section-label { font-size: 13px; font-weight: 600; color: var(--text-primary); margin-bottom: 10px; }
.cat-bars { display: flex; flex-direction: column; gap: 8px; }
.cat-bar-row { display: flex; align-items: center; gap: 8px; font-size: 12px; }
.cat-bar-icon { font-size: 16px; flex-shrink: 0; width: 22px; text-align: center; }
.cat-bar-name { width: 80px; color: var(--text-primary); flex-shrink: 0; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cat-bar-track { flex: 1; height: 12px; background: rgba(0,0,0,0.04); border-radius: 6px; overflow: hidden; }
.cat-bar-fill { height: 100%; border-radius: 6px; transition: width .5s ease; opacity: 0.8; }
.cat-bar-pct { width: 36px; text-align: right; color: var(--text-secondary); font-size: 11px; flex-shrink: 0; }

.timeline-container { padding: 0 8px; }
.empty-state { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
.date-marker { text-align: center; margin: 20px 0 12px; position: relative; }
.date-marker::before { content: ''; position: absolute; left:0; right:0; top:50%; height:1px; background:var(--border-color); z-index:0; }
.date-text { position: relative; z-index: 1; background: var(--bg-color); padding: 4px 16px; border-radius: 20px; font-size: 13px; color: var(--text-secondary); font-weight: 500; }
.timeline-card { background: white; border-radius: 12px; padding: 12px 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); max-width: 100%; }
.card-sender { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.sender-avatar { width:26px; height:26px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:14px; }
.avatar-male { background: var(--male-bubble-bg); }
.avatar-female { background: var(--female-bubble-bg); }
.sender-name { font-size:13px; font-weight:500; color:var(--text-primary); }
.cat-tag { margin-left: auto; }
.cat-tag :deep(.el-tag__content) { font-size: 11px; }
.card-images { margin-bottom: 8px; }
.tl-img { max-width:100%; max-height:200px; border-radius:8px; margin-bottom:6px; }
.tl-video { max-width:100%; max-height:200px; border-radius:8px; margin-bottom:6px; }
.tl-voice { width:100%; height:32px; }
.card-text { font-size:14px; line-height:1.7; color:var(--text-primary); word-break:break-all; }
.ai-note { margin-top:8px; padding-top:8px; border-top:1px dashed var(--border-color); font-size:12px; color:var(--el-color-primary); line-height:1.5; font-style:italic; }
.ai-note span { font-weight: 500; }
:deep(.el-timeline-item__timestamp) { color: var(--text-secondary); font-size: 11px; }
</style>
