<template>
  <div class="categories-page">
    <div class="page-header">
      <h1>💝 分类相册</h1>
      <p>AI 自动归档的甜蜜回忆 · 支持自定义分类</p>
    </div>

    <!-- 自定义分类操作 -->
    <div class="custom-section">
      <el-button type="primary" size="small" round @click="showAddDialog = true" class="add-btn">
        <el-icon><Plus /></el-icon> 新建自定义分类
      </el-button>
    </div>

    <!-- 系统分类 -->
    <div class="section-title">📂 系统分类</div>
    <div class="category-grid">
      <div
        v-for="cat in systemCategories"
        :key="cat.id"
        class="category-card"
        @click="goToCategory(cat)"
      >
        <div class="cat-icon" :style="{ background: cat.color ? `linear-gradient(135deg, ${cat.color}33, ${cat.color}66)` : getCatGradient(cat.id) }">
          {{ cat.icon }}
        </div>
        <div class="cat-info">
          <div class="cat-name">{{ cat.name }}</div>
          <div class="cat-count">{{ cat.message_count }} 条记录</div>
        </div>
        <el-icon class="arrow"><ArrowRight /></el-icon>
      </div>
    </div>

    <!-- 自定义分类 -->
    <div v-if="customCategories.length > 0" class="section-title">🏷️ 我的分类</div>
    <div v-if="customCategories.length > 0" class="category-grid">
      <div
        v-for="cat in customCategories"
        :key="cat.id"
        class="category-card custom-card"
      >
        <div class="cat-icon" @click="goToCategory(cat)" :style="{ background: cat.color ? `linear-gradient(135deg, ${cat.color}33, ${cat.color}66)` : '#f0f0f0' }">
          {{ cat.icon }}
        </div>
        <div class="cat-info" @click="goToCategory(cat)">
          <div class="cat-name">{{ cat.name }}</div>
          <div class="cat-count">{{ cat.message_count }} 条记录</div>
        </div>
        <div class="cat-actions">
          <el-button text size="small" @click.stop="editCategory(cat)">
            <el-icon><Edit /></el-icon>
          </el-button>
          <el-popconfirm title="确定删除该分类？消息将变为无分类" @confirm="removeCategory(cat.id)">
            <template #reference>
              <el-button text size="small" type="danger" @click.stop>
                <el-icon><Delete /></el-icon>
              </el-button>
            </template>
          </el-popconfirm>
        </div>
      </div>
    </div>

    <!-- 空自定义提示 -->
    <div v-if="customCategories.length === 0" class="empty-hint">
      还没有自定义分类，点击上方按钮创建专属分类 ✨
    </div>

    <!-- 新建/编辑分类对话框 -->
    <el-dialog v-model="showAddDialog" :title="editingCat ? '编辑分类' : '新建自定义分类'" width="320px" :close-on-click-modal="false">
      <el-form :model="formData" label-position="top">
        <el-form-item label="分类名称">
          <el-input v-model="formData.name" placeholder="输入分类名称" maxlength="20" show-word-limit />
        </el-form-item>
        <el-form-item label="图标">
          <div class="icon-picker">
            <div
              v-for="icon in iconOptions"
              :key="icon"
              class="icon-option"
              :class="{ active: formData.icon === icon }"
              @click="formData.icon = icon"
            >{{ icon }}</div>
          </div>
        </el-form-item>
        <el-form-item label="颜色">
          <div class="color-picker">
            <div
              v-for="color in colorOptions"
              :key="color"
              class="color-option"
              :class="{ active: formData.color === color }"
              :style="{ background: color }"
              @click="formData.color = color"
            ></div>
          </div>
        </el-form-item>
        <el-form-item label="描述（可选）">
          <el-input v-model="formData.description" placeholder="简单描述这个分类" maxlength="50" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="saveCategory" :loading="saving">{{ editingCat ? '保存' : '创建' }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowRight, Plus, Edit, Delete } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { getCategories, createCustomCategory, updateCustomCategory, deleteCustomCategory } from '../api/category'

const router = useRouter()
const categories = ref([])
const showAddDialog = ref(false)
const editingCat = ref(null)
const saving = ref(false)
const formData = ref({ name: '', icon: '📝', color: '#ff6b9d', description: '' })

const iconOptions = ['💝','🎉','🌸','🎂','🎁','🌟','☀️','🌈','🦋','🍀','🏠','🎵','📚','🛍️','🎮','🏃','🧸','💍','🌙','⭐','🎀','🍰','🏖️','🎪']
const colorOptions = ['#ff6b9d','#ff9800','#2196f3','#4caf50','#9c27b0','#f44336','#00bcd4','#ffc107','#e91e63','#607d8b','#795548','#8bc34a']

const systemCategories = computed(() => categories.value.filter(c => c.is_system))
const customCategories = computed(() => categories.value.filter(c => c.is_custom))

const gradients = [
  'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
  'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #fff1eb 0%, #ace0f9 100%)',
  'linear-gradient(135deg, #d299c2 0%, #fef9d7 100%)',
  'linear-gradient(135deg, #ffd1ff 0%, #fad0c4 100%)',
  'linear-gradient(135deg, #ebc0fd 0%, #d9ded8 100%)',
  'linear-gradient(135deg, #f6d365 0%, #fda085 100%)'
]
const getCatGradient = (id) => gradients[(id - 1) % gradients.length]

const goToCategory = (cat) => {
  router.push(`/category/${cat.id}`)
}

const loadCategories = async () => {
  try {
    categories.value = await getCategories()
  } catch (e) {
    ElMessage.error('加载分类失败')
  }
}

const editCategory = (cat) => {
  editingCat.value = cat
  formData.value = { name: cat.name, icon: cat.icon, color: cat.color || '#ff6b9d', description: cat.description || '' }
  showAddDialog.value = true
}

const saveCategory = async () => {
  if (!formData.value.name.trim()) {
    ElMessage.warning('请输入分类名称')
    return
  }
  saving.value = true
  try {
    if (editingCat.value) {
      await updateCustomCategory(editingCat.value.id, {
        name: formData.value.name.trim(),
        icon: formData.value.icon,
        color: formData.value.color,
        description: formData.value.description
      })
      ElMessage.success('分类已更新')
    } else {
      await createCustomCategory({
        name: formData.value.name.trim(),
        icon: formData.value.icon,
        color: formData.value.color,
        description: formData.value.description
      })
      ElMessage.success('分类创建成功')
    }
    showAddDialog.value = false
    editingCat.value = null
    formData.value = { name: '', icon: '📝', color: '#ff6b9d', description: '' }
    await loadCategories()
  } catch (e) {
    ElMessage.error(e.response?.data?.detail || '操作失败')
  } finally {
    saving.value = false
  }
}

const removeCategory = async (id) => {
  try {
    await deleteCustomCategory(id)
    ElMessage.success('分类已删除')
    await loadCategories()
  } catch (e) {
    ElMessage.error('删除失败')
  }
}

onMounted(() => { loadCategories() })
</script>

<style scoped>
.categories-page { padding: 20px 16px; min-height: 100%; }
.page-header { text-align: center; margin-bottom: 16px; }
.page-header h1 { font-size: 24px; color: var(--el-color-primary); margin-bottom: 4px; }
.page-header p { font-size: 13px; color: var(--text-secondary); }

.custom-section { text-align: center; margin-bottom: 16px; }
.add-btn { border-radius: 20px; padding: 8px 20px; }

.section-title { font-size: 14px; font-weight: 600; color: var(--text-primary); margin: 20px 0 10px; padding-left: 4px; }
.category-grid { display: flex; flex-direction: column; gap: 10px; }

.category-card {
  background: white; border-radius: 14px; padding: 14px 16px;
  display: flex; align-items: center; gap: 14px; box-shadow: var(--shadow-soft); cursor: pointer;
  transition: all 0.2s ease;
}
.category-card:active { transform: scale(0.98); }
.custom-card { cursor: default; }
.custom-card .cat-icon, .custom-card .cat-info { cursor: pointer; }

.cat-icon {
  width: 48px; height: 48px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;
}
.cat-info { flex: 1; min-width: 0; }
.cat-name { font-size: 15px; font-weight: 500; color: var(--text-primary); margin-bottom: 3px; }
.cat-count { font-size: 12px; color: var(--text-secondary); }
.cat-actions { display: flex; gap: 4px; }
.arrow { color: var(--text-secondary); font-size: 18px; }
.empty-hint { text-align: center; padding: 24px; color: var(--text-secondary); font-size: 13px; }

.icon-picker { display: flex; flex-wrap: wrap; gap: 8px; }
.icon-option {
  width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
  font-size: 20px; cursor: pointer; border: 2px solid transparent; background: var(--bg-cream); transition: all .15s;
}
.icon-option.active { border-color: var(--el-color-primary); background: var(--el-color-primary-light-9); }

.color-picker { display: flex; flex-wrap: wrap; gap: 8px; }
.color-option {
  width: 28px; height: 28px; border-radius: 50%; cursor: pointer; border: 3px solid transparent; transition: all .15s;
}
.color-option.active { border-color: var(--text-primary); transform: scale(1.15); }
</style>
