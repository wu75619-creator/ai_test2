<template>
  <div class="category-page">
    <div class="cat-header">
      <el-icon class="back-btn" @click="$router.back()"><ArrowLeft /></el-icon>
      <div class="header-title">
        <span class="cat-icon">{{ categoryIcon }}</span>
        <span>{{ categoryName }}</span>
      </div>
      <div style="width:30px"></div>
    </div>

    <div class="filter-bar">
      <el-radio-group v-model="filterType" size="small" @change="loadMessages">
        <el-radio-button label="all">全部</el-radio-button>
        <el-radio-button label="year">按年</el-radio-button>
        <el-radio-button label="month">按月</el-radio-button>
      </el-radio-group>
      <div v-if="filterType !== 'all'" class="date-pickers">
        <el-date-picker v-if="filterType==='year'" v-model="selectedYear" type="year" placeholder="年份" size="small" format="YYYY年" value-format="YYYY" @change="loadMessages" />
        <el-date-picker v-if="filterType==='month'" v-model="selectedMonth" type="month" placeholder="月份" size="small" format="YYYY年MM月" value-format="YYYY-MM" @change="loadMessages" />
      </div>
    </div>

    <div class="cards-container" v-loading="loading">
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div style="font-size:48px;margin-bottom:12px">📭</div>
        <div>这个分类下还没有记录哦～</div>
        <el-button type="primary" link @click="$router.push('/')">去聊天记录第一条</el-button>
      </div>

      <div v-for="msg in messages" :key="msg.id" class="message-card">
        <div class="card-header">
          <div class="sender">
            <span class="avatar" :class="msg.sender_role==='女主'?'avatar-female':'avatar-male'">{{ msg.sender_role==='女主'?'👩':'👨' }}</span>
            <span class="nickname">{{ msg.sender_nickname }}</span>
          </div>
          <span class="time">{{ formatTime(msg.created_at) }}</span>
        </div>

        <div v-if="msg.attachments && msg.attachments.length > 0" class="card-images">
          <el-image v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='image')" :key="idx" :src="att.file_url" :preview-src-list="msg.attachments.filter(a=>a.file_type==='image').map(a=>a.file_url)" fit="cover" class="card-img" preview-teleported />
          <video v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='video')" :key="'vid'+idx" :src="att.file_url" controls playsinline class="card-video"></video>
          <div v-for="(att,idx) in msg.attachments.filter(a=>a.file_type==='voice')" :key="'vo'+idx" class="voice-play-row" @click="playVoice(att.file_url, idx)">
            <el-icon><VideoPlay /></el-icon>
            <span>语音 {{ formatDur(att.duration) }}</span>
            <audio :ref="el => voiceEls[idx] = el" :src="att.file_url"></audio>
          </div>
        </div>

        <div v-if="msg.text_content" class="card-content">{{ msg.text_content }}</div>
        <div v-if="msg.ai_summary" class="ai-summary-card"><span class="ai-icon">✨</span>{{ msg.ai_summary }}</div>
        <div v-if="msg.main_category_icon" class="card-footer">
          <el-tag size="small" effect="plain" round>{{ msg.main_category_icon }} {{ msg.main_category_name }}</el-tag>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { ArrowLeft, VideoPlay } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { getCategoryMessages, getCategoryMessagesById, getCategories } from '../api/category'

const route = useRoute()
const loading = ref(false)
const messages = ref([])
const categories = ref([])
const filterType = ref('all')
const selectedYear = ref(dayjs().format('YYYY'))
const selectedMonth = ref(dayjs().format('YYYY-MM'))
const voiceEls = ref({})
const currentVoice = ref(null)

const categoryParam = computed(() => route.params.id)
const isNumeric = computed(() => /^\d+$/.test(categoryParam.value))

const categoryInfo = computed(() => {
  if (!isNumeric.value) {
    const name = decodeURIComponent(categoryParam.value)
    const found = categories.value.find(c => c.name === name)
    return found || { name, icon: '📂', color: '#ff6b9d' }
  }
  const id = parseInt(categoryParam.value)
  return categories.value.find(c => c.id === id) || { name: '分类', icon: '📂', color: '#ff6b9d' }
})

const categoryName = computed(() => categoryInfo.value.name || '分类')
const categoryIcon = computed(() => categoryInfo.value.icon || '📂')

const formatTime = (t) => dayjs(t).format('YYYY-MM-DD HH:mm')
const formatDur = (s) => s ? `${s}"` : '1"'

const playVoice = (url, idx) => {
  if (currentVoice.value) currentVoice.value.pause()
  const audio = voiceEls.value[idx]
  if (audio) { audio.play(); currentVoice.value = audio }
}

const loadMessages = async () => {
  const param = categoryParam.value
  if (!param) return
  loading.value = true
  try {
    let params = {}
    if (filterType.value === 'year' && selectedYear.value) params.year = parseInt(selectedYear.value)
    if (filterType.value === 'month' && selectedMonth.value) {
      const [y,m] = selectedMonth.value.split('-')
      params.year = parseInt(y); params.month = parseInt(m)
    }
    if (isNumeric.value) {
      messages.value = await getCategoryMessagesById(parseInt(param), params.year, params.month)
    } else {
      messages.value = await getCategoryMessages(decodeURIComponent(param), params.year, params.month)
    }
  } catch(e) {
    ElMessage.error('加载消息失败')
  } finally {
    loading.value = false
  }
}

onMounted(async () => {
  try { categories.value = await getCategories() } catch(e) {}
  loadMessages()
})
</script>

<style scoped>
.category-page { min-height:100%; display:flex; flex-direction:column; }
.cat-header { padding:16px; display:flex; align-items:center; justify-content:space-between; background:white; border-bottom:1px solid var(--border-color); position:sticky; top:0; z-index:10; }
.back-btn { font-size:22px; color:var(--text-primary); cursor:pointer; padding:4px; }
.header-title { font-size:17px; font-weight:600; display:flex; align-items:center; gap:6px; }
.cat-icon { font-size:22px; }
.filter-bar { padding:12px 16px; background:white; border-bottom:1px solid var(--border-color); display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
.date-pickers { flex:1; min-width:150px; }
.date-pickers :deep(.el-date-editor) { width:100% !important; }
.cards-container { flex:1; padding:16px; display:flex; flex-direction:column; gap:14px; }
.empty-state { text-align:center; padding:60px 20px; color:var(--text-secondary); }
.message-card { background:white; border-radius:14px; padding:14px; box-shadow:var(--shadow-soft); }
.card-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; }
.sender { display:flex; align-items:center; gap:8px; }
.avatar { width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; }
.avatar-male { background:var(--male-bubble-bg); }
.avatar-female { background:var(--female-bubble-bg); }
.nickname { font-size:14px; font-weight:500; }
.time { font-size:12px; color:var(--text-secondary); }
.card-images { margin-bottom:10px; display:flex; flex-wrap:wrap; gap:6px; }
.card-img { max-width:100%; max-height:250px; border-radius:8px; cursor:pointer; }
.card-video { max-width:100%; max-height:250px; border-radius:8px; margin-bottom:6px; }
.voice-play-row { display:flex; align-items:center; gap:8px; padding:8px 12px; background:var(--bg-cream); border-radius:20px; width:100%; margin-bottom:6px; cursor:pointer; font-size:13px; }
.card-content { font-size:15px; line-height:1.7; color:var(--text-primary); word-break:break-all; }
.ai-summary-card { margin-top:12px; padding:10px 12px; background:linear-gradient(135deg,#fff0f6 0%,#fff5f8 100%); border-radius:10px; font-size:13px; color:var(--el-color-primary-dark-2); line-height:1.6; font-style:italic; }
.ai-icon { margin-right:4px; }
.card-footer { margin-top:10px; display:flex; }
.card-footer :deep(.el-tag) { border-color:var(--el-color-primary-light-5); color:var(--el-color-primary); }
</style>
