<template>
  <div class="app-container">
    <div class="main-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </div>
    
    <!-- 底部导航栏 -->
    <div class="bottom-nav">
      <router-link to="/" class="nav-item" active-class="nav-active">
        <el-icon size="22"><ChatDotRound /></el-icon>
        <span>聊天记录</span>
      </router-link>
      <router-link to="/categories" class="nav-item nav-center" active-class="nav-active">
        <div class="center-btn">
          <el-icon size="28"><FolderOpened /></el-icon>
        </div>
        <span>分类相册</span>
      </router-link>
      <router-link to="/timeline" class="nav-item" active-class="nav-active">
        <el-icon size="22"><Clock /></el-icon>
        <span>恋爱时间轴</span>
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ChatDotRound, FolderOpened, Clock } from '@element-plus/icons-vue'
</script>

<style>
.app-container {
  width: 100%;
  height: 100%;
  max-width: 768px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  background: var(--bg-color);
  position: relative;
}

.main-content {
  flex: 1;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  padding-bottom: 70px;
  height: calc(100vh - 65px);
}

/* 页面切换动画 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* 底部导航 */
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  max-width: 768px;
  margin: 0 auto;
  height: 65px;
  background: white;
  display: flex;
  align-items: center;
  justify-content: space-around;
  box-shadow: 0 -2px 12px rgba(255, 107, 157, 0.1);
  border-top: 1px solid var(--border-color);
  z-index: 100;
  padding-bottom: env(safe-area-inset-bottom, 0);
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  text-decoration: none;
  color: var(--text-secondary);
  font-size: 11px;
  transition: all 0.2s ease;
  padding: 6px 16px;
}

.nav-center {
  position: relative;
}

.center-btn {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff6b9d 0%, #ff8fb7 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: -20px;
  box-shadow: 0 4px 12px rgba(255, 107, 157, 0.4);
  margin-bottom: 2px;
  transition: transform 0.2s ease;
}

.nav-item.nav-active {
  color: var(--el-color-primary);
}

.nav-item.nav-active .center-btn {
  transform: scale(1.05);
}

.nav-item:active {
  transform: scale(0.95);
}
</style>
