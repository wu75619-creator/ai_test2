/**
 * 浏览器录音工具 - 使用MediaRecorder API
 */
export class AudioRecorder {
  constructor() {
    this.mediaRecorder = null
    this.audioChunks = []
    this.stream = null
    this.isRecording = false
    this.startTime = null
  }

  /**
   * 检查是否支持录音
   */
  static isSupported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)
  }

  /**
   * 开始录音
   */
  async start() {
    if (this.isRecording) return
    
    try {
      // 获取麦克风权限
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      })

      // 选择最佳音频格式
      let mimeType = 'audio/webm'
      const supportedTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/ogg;codecs=opus',
        'audio/mp4'
      ]
      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) {
          mimeType = type
          break
        }
      }

      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType })
      this.audioChunks = []
      this.startTime = Date.now()

      this.mediaRecorder.addEventListener('dataavailable', (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data)
        }
      })

      this.mediaRecorder.start()
      this.isRecording = true
      return true
    } catch (err) {
      this.cleanup()
      throw err
    }
  }

  /**
   * 停止录音，返回音频Blob和时长
   */
  stop() {
    return new Promise((resolve, reject) => {
      if (!this.isRecording || !this.mediaRecorder) {
        reject(new Error('未在录音中'))
        return
      }

      const duration = Math.round((Date.now() - this.startTime) / 1000)

      this.mediaRecorder.addEventListener('stop', () => {
        const mimeType = this.mediaRecorder.mimeType || 'audio/webm'
        const audioBlob = new Blob(this.audioChunks, { type: mimeType })
        const ext = mimeType.includes('mp4') ? 'mp4' : mimeType.includes('ogg') ? 'ogg' : 'webm'
        const fileName = `recording_${Date.now()}.${ext}`
        const file = new File([audioBlob], fileName, { type: mimeType })
        
        this.cleanup()
        resolve({ file, duration })
      })

      this.mediaRecorder.stop()
    })
  }

  /**
   * 取消录音
   */
  cancel() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop()
    }
    this.cleanup()
  }

  /**
   * 清理资源
   */
  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop())
      this.stream = null
    }
    this.mediaRecorder = null
    this.audioChunks = []
    this.isRecording = false
    this.startTime = null
  }
}
