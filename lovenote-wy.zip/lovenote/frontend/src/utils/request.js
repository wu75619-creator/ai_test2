import axios from 'axios'
import { ElMessage } from 'element-plus'

// In production, set VITE_API_URL to your backend URL
// For local dev, empty string uses Vite proxy
const API_BASE = import.meta.env.VITE_API_URL || ''

const service = axios.create({
  baseURL: API_BASE,
  timeout: 30000
})

service.interceptors.request.use(
  config => {
    return config
  },
  error => Promise.reject(error)
)

service.interceptors.response.use(
  response => response.data,
  error => {
    const msg = error.response?.data?.detail || error.message || '请求失败'
    ElMessage.error(msg)
    return Promise.reject(error)
  }
)

export default service
