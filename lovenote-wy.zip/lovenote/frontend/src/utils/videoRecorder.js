/**
 * 浏览器视频录制工具 - 使用MediaRecorder API
 * 支持同时录制摄像头和麦克风
 */
export class VideoRecorder {
  constructor() {
    this.mediaRecorder = null
    this.videoChunks = []
    this.stream = null
    this.isRecording = false
    this.startTime = null
    this.previewEl = null
  }

  static isSupported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)
  }

  /**
   * 开始录制视频
   * @param {HTMLVideoElement} previewEl - 预览video元素
   */
  async start(previewEl = null) {
    if (this.isRecording) return

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      })

      if (previewEl) {
        this.previewEl = previewEl
        previewEl.srcObject = this.stream
        previewEl.muted = true
        await previewEl.play().catch(() => {})
      }

      let mimeType = 'video/webm;codecs=vp9,opus'
      const supportedTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=h264,opus',
        'video/webm',
        'video/mp4'
      ]
      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) {
          mimeType = type
          break
        }
      }

      this.mediaRecorder = new MediaRecorder(this.stream, {
        mimeType,
        videoBitsPerSecond: 1000000 // 1Mbps for smaller files
      })
      this.videoChunks = []
      this.startTime = Date.now()

      this.mediaRecorder.addEventListener('dataavailable', (event) => {
        if (event.data.size > 0) {
          this.videoChunks.push(event.data)
        }
      })

      this.mediaRecorder.start(1000)
      this.isRecording = true
      return true
    } catch (err) {
      this.cleanup()
      throw err
    }
  }

  /**
   * 停止录制，返回视频File和时长
   */
  stop() {
    return new Promise((resolve, reject) => {
      if (!this.isRecording || !this.mediaRecorder) {
        reject(new Error('未在录制中'))
        return
      }

      const duration = Math.round((Date.now() - this.startTime) / 1000)

      this.mediaRecorder.addEventListener('stop', () => {
        const mimeType = this.mediaRecorder.mimeType || 'video/webm'
        const videoBlob = new Blob(this.videoChunks, { type: mimeType })
        const ext = mimeType.includes('mp4') ? 'mp4' : 'webm'
        const fileName = `video_${Date.now()}.${ext}`
        const file = new File([videoBlob], fileName, { type: mimeType })

        this.cleanup()
        resolve({ file, duration })
      })

      this.mediaRecorder.stop()
    })
  }

  cancel() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop()
    }
    this.cleanup()
  }

  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop())
      this.stream = null
    }
    if (this.previewEl) {
      this.previewEl.srcObject = null
      this.previewEl = null
    }
    this.mediaRecorder = null
    this.videoChunks = []
    this.isRecording = false
    this.startTime = null
  }
}
