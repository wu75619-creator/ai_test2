import request from '../utils/request'

export function getCategories() {
  return request({ url: '/api/categories', method: 'get' })
}

export function getCategoryMessages(categoryName, year, month) {
  return request({
    url: `/api/categories/${encodeURIComponent(categoryName)}`,
    method: 'get',
    params: { year, month }
  })
}

export function getCategoryMessagesById(categoryId, year, month) {
  return request({
    url: `/api/categories/detail/${categoryId}`,
    method: 'get',
    params: { year, month }
  })
}

export function getCategoryStats() {
  return request({ url: '/api/categories/stats/overview', method: 'get' })
}

export function getStatsDashboard() {
  return request({ url: '/api/categories/stats/dashboard', method: 'get' })
}

// Custom category CRUD
export function createCustomCategory(data) {
  return request({
    url: '/api/categories',
    method: 'post',
    data: {
      name: data.name,
      icon: data.icon || '📝',
      color: data.color || '#ff6b9d',
      description: data.description || ''
    }
  })
}

export function updateCustomCategory(id, data) {
  return request({
    url: `/api/categories/${id}`,
    method: 'put',
    data
  })
}

export function deleteCustomCategory(id) {
  return request({
    url: `/api/categories/${id}`,
    method: 'delete'
  })
}
