#!/bin/bash
# 构建脚本 - 编译前端并复制到后端静态目录
set -e

echo "🔨 构建前端..."
cd frontend
npm install
npm run build
cd ..

echo "📦 复制前端到后端静态目录..."
rm -rf backend/static
mkdir -p backend/static
cp -r frontend/dist/* backend/static/

echo "✅ 构建完成！"
echo "启动服务: cd backend && python3 main.py"
echo "访问: http://localhost:8000"
