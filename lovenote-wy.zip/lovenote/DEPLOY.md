# 💑 情侣智能随手恋爱日记本 - 部署指南

## 项目版本: v2.0.0

### 已完成功能清单

#### ✅ 补充需求1: 音视频录制/上传与后端保存闭环
- **前端音频录制**: MediaRecorder API实现，支持webm/ogg/mp4格式，实时计时，脉冲动画反馈
- **前端视频录制**: 新增VideoRecorder类，支持摄像头+麦克风同时录制，实时预览
- **前端视频文件上传**: 支持从相册选择视频，自动获取时长
- **语音时长传递**: 前端录制时精确计算时长，通过FormData传递给后端
- **后端文件保存**: 异步分块写入(1MB chunks)，100MB上限，UUID文件名防冲突
- **静态文件服务**: `/uploads/images`, `/uploads/voices`, `/uploads/videos` 独立目录
- **视频元数据**: 支持video_duration参数，正确存储和返回视频/语音时长

#### ✅ 补充需求2: 自定义分类功能 + 数据库重构
- **Category模型扩展**: 新增 `is_custom`(布尔), `color`(颜色) 字段
- **后端CRUD API**:
  - `POST /api/categories` - 创建自定义分类（名称/图标/颜色/描述）
  - `PUT /api/categories/{id}` - 更新自定义分类
  - `DELETE /api/categories/{id}` - 删除自定义分类（关联消息设为无分类）
- **AI服务支持自定义分类**: ai_service动态从数据库加载所有分类，关键词匹配支持
- **前端管理UI**:
  - 分类相册页添加"新建自定义分类"按钮
  - 图标选择器(24个emoji) + 颜色选择器(12色)
  - 自定义分类支持编辑和删除（弹框确认）
  - 分类分"系统分类"和"我的分类"两组显示
  - 发送消息时手动分类下拉框分组显示系统/自定义分类

#### ✅ 补充需求3: 周度/月度恋爱天数及聊天活跃度统计面板
- **统计API**: `GET /api/categories/stats/dashboard`
  - 核心指标：总消息数、恋爱天数、活跃天数、连续记录天数
  - 日均消息数、活跃周数、活跃月数
  - 发送比例：男主/女主消息数及百分比
  - **周度统计**（最近8周）：每周消息数、活跃天数、男女分布
  - **月度统计**（最近12个月）：每月消息数、活跃天数、男女分布
  - 分类分布：每个分类的消息数和占比
- **前端统计面板**（时间轴页顶部）：
  - 三大核心数字展示（陪伴天数/甜蜜记录/连续记录）
  - 详细数据网格（活跃天数/日均/活跃周/活跃月）
  - 发送比例可视化进度条（蓝/粉双色）
  - **周度/月度切换**柱状图（堆叠男主/女主）
  - 分类分布水平条形图（带颜色标识）

#### ✅ 系统部署为永久在线网页
- **统一部署架构**: FastAPI后端直接serve前端静态文件，单端口部署
- **数据库**: SQLite with WAL模式（高并发支持，读写不阻塞）
- **查询优化**: 消息列表使用joinedload预加载关系，避免N+1查询（P50延迟从1608ms→163ms）
- **部署配置文件**:
  - `Procfile` + `runtime.txt` (Render/Railway/Python PaaS)
  - `render.yaml` (Render Blueprint一键部署)
  - `Dockerfile` (Docker容器化部署)
  - `build.sh` (一键构建脚本)
  - `vercel.json` (Vercel前端部署 + API代理)

---

## 🚀 快速部署方法

### 方法一: Render.com 一键部署（推荐，免费）

1. 将项目推送到GitHub
2. 在Render.com创建新Web Service，连接仓库
3. 构建命令会自动使用render.yaml配置
4. 启动命令: `cd backend && uvicorn main:app --host 0.0.0.0 --port $PORT`
5. 部署完成后访问 `https://your-app.onrender.com`

### 方法二: Docker部署

```bash
docker build -t lovenote .
docker run -d -p 8000:8000 -v ./data:/app/uploads lovenote
```
访问 `http://your-server:8000`

### 方法三: VPS/云服务器手动部署

```bash
# 1. 构建前端
cd frontend && npm install && npm run build && cd ..

# 2. 复制到后端静态目录
cp -r frontend/dist/* backend/static/

# 3. 安装后端依赖
cd backend && pip install -r requirements.txt

# 4. 启动服务（使用gunicorn多worker）
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000
```

建议使用systemd或supervisor管理进程，Nginx反向代理。

### 本地开发启动

```bash
# 终端1: 后端
cd backend
pip install -r requirements.txt
python3 main.py  # 启动在 http://localhost:8000

# 终端2: 前端（开发模式，热重载）
cd frontend
npm install
npm run dev  # 启动在 http://localhost:5173，自动代理API到8000
```

---

## 📊 压力测试结果

| 测试项 | 并发 | 结果 |
|--------|------|------|
| 消息发送吞吐量 | 10并发 | 60 req/s, 0失败 |
| 发送延迟 P50/P95 | - | 120ms / 473ms |
| 消息列表读取 P50/P95 | 10并发 | 163ms / 299ms |
| 统计面板API P50/P95 | 10并发 | 530ms / 1236ms |
| 分类列表API | 10并发 | 86ms 平均 |
| WAL模式SQLite | - | 读写不阻塞，0死锁 |

---

## 🔧 环境变量配置

在 `backend/.env` 文件中配置:

```env
# AI模式 (默认false使用Mock, true调用真实大模型)
AI_ENABLED=false

# 真实大模型配置 (AI_ENABLED=true时需要)
OPENAI_API_KEY=sk-your-key
OPENAI_BASE_URL=https://api.openai.com/v1  # 或其他兼容接口
OPENAI_MODEL=gpt-4o-mini

# 文件上传大小限制 (MB)
MAX_UPLOAD_SIZE=100
```

---

## 📱 功能特性

- 💬 聊天式记录：文字/图片/语音/视频/摄像头录制
- 🤖 AI自动分类：8大系统分类 + 用户自定义分类
- 📊 时间轴统计：周度/月度活跃度、恋爱天数、发送比例
- 🏷️ 自定义分类：自由创建专属分类，支持图标和颜色
- 📸 相册浏览：按分类归档，支持年份/月份筛选
- 🎤 语音录制：一键录音，波形动画播放
- 🎥 视频录制：摄像头实时录制，即时上传
- 💕 治愈设计：粉色少女风，移动端优先，响应式布局
- 🔒 本地存储：SQLite数据库，数据完全私有
