"""
情侣智能随手恋爱日记本 - 后端入口
FastAPI application + serve built frontend static files
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path

from app.core.database import engine, Base
from app import models

# Create all database tables
Base.metadata.create_all(bind=engine)

# Initialize system categories
from app.core.init_data import init_system_categories
init_system_categories()

app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    description="对话式随手记录 + AI自动分类归档的双人恋爱日记本",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Uploads directory
upload_dir = Path("uploads")
upload_dir.mkdir(exist_ok=True)
(upload_dir / "images").mkdir(exist_ok=True)
(upload_dir / "voices").mkdir(exist_ok=True)
(upload_dir / "videos").mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# API routes
from app.api.messages import router as messages_router
from app.api.categories import router as categories_router
app.include_router(messages_router)
app.include_router(categories_router)


@app.get("/api/health", summary="健康检查")
async def health_check():
    ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
    return {
        "status": "ok",
        "message": "情侣日记本服务运行中 💑",
        "ai_mode": "真实大模型" if ai_enabled else "Mock模拟模式",
        "version": "2.0.0"
    }


# Serve built frontend static files if they exist
FRONTEND_DIST = Path(__file__).resolve().parent / "static"
print(f"Frontend static path: {FRONTEND_DIST}, exists: {FRONTEND_DIST.exists()}")
if FRONTEND_DIST.exists() and (FRONTEND_DIST / "index.html").exists():
    app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="assets")

    @app.get("/", include_in_schema=False)
    async def serve_index():
        return FileResponse(str(FRONTEND_DIST / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_frontend(full_path: str):
        # Don't intercept API routes
        if full_path.startswith("api/"):
            from fastapi.responses import JSONResponse
            return JSONResponse({"detail": "Not Found"}, status_code=404)
        file_path = FRONTEND_DIST / full_path
        if file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(FRONTEND_DIST / "index.html"))


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=False
    )
