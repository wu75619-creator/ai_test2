from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime, date, timedelta
from pydantic import BaseModel

from app.core.database import get_db
from app.models import Message, User, Couple, Category, MessageAttachment
from app.services.ai_service import ai_service
from app.api.messages import get_or_create_default_couple, build_message_response

router = APIRouter(prefix="/api/categories", tags=["分类归档接口"])


class CategoryCreate(BaseModel):
    name: str
    icon: str = "📝"
    color: str = "#ff6b9d"
    description: str = ""


class CategoryUpdate(BaseModel):
    name: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    description: Optional[str] = None


@router.get("", summary="获取所有分类列表（系统+自定义）")
async def list_categories(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)

    # 获取系统分类
    system_cats = db.query(Category).filter(
        Category.is_system == True,
        Category.parent_id == None
    ).order_by(Category.sort_order).all()

    # 获取用户自定义分类
    custom_cats = db.query(Category).filter(
        Category.couple_id == couple.id,
        Category.is_custom == True
    ).order_by(Category.created_at).all()

    all_cats = system_cats + custom_cats
    result = []
    for cat in all_cats:
        count = db.query(Message).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat.id,
            Message.is_deleted == False
        ).count()
        result.append({
            "id": cat.id,
            "name": cat.name,
            "icon": cat.icon or "📝",
            "color": cat.color or "#ff6b9d",
            "description": cat.description or "",
            "message_count": count,
            "is_system": cat.is_system,
            "is_custom": cat.is_custom
        })
    return result


@router.post("", summary="创建自定义分类")
async def create_category(
    cat_data: CategoryCreate,
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)

    # 检查重名
    existing = db.query(Category).filter(
        Category.name == cat_data.name,
        ((Category.is_system == True) | (Category.couple_id == couple.id))
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"分类名 '{cat_data.name}' 已存在")

    max_order = db.query(func.max(Category.sort_order)).filter(
        Category.couple_id == couple.id
    ).scalar() or 8

    new_cat = Category(
        couple_id=couple.id,
        parent_id=None,
        name=cat_data.name,
        icon=cat_data.icon,
        color=cat_data.color,
        description=cat_data.description,
        sort_order=max_order + 1,
        is_system=False,
        is_custom=True
    )
    db.add(new_cat)
    db.commit()
    db.refresh(new_cat)
    return {
        "id": new_cat.id,
        "name": new_cat.name,
        "icon": new_cat.icon,
        "color": new_cat.color,
        "description": new_cat.description,
        "message_count": 0,
        "is_system": False,
        "is_custom": True
    }


@router.put("/{category_id}", summary="更新自定义分类")
async def update_category(
    category_id: int,
    cat_data: CategoryUpdate,
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)
    cat = db.query(Category).filter(
        Category.id == category_id,
        Category.couple_id == couple.id,
        Category.is_custom == True
    ).first()
    if not cat:
        raise HTTPException(status_code=404, detail="自定义分类不存在")

    if cat_data.name is not None:
        cat.name = cat_data.name
    if cat_data.icon is not None:
        cat.icon = cat_data.icon
    if cat_data.color is not None:
        cat.color = cat_data.color
    if cat_data.description is not None:
        cat.description = cat_data.description

    db.commit()
    db.refresh(cat)
    return {
        "id": cat.id,
        "name": cat.name,
        "icon": cat.icon,
        "color": cat.color,
        "description": cat.description,
        "is_system": False,
        "is_custom": True
    }


@router.delete("/{category_id}", summary="删除自定义分类")
async def delete_category(category_id: int, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    cat = db.query(Category).filter(
        Category.id == category_id,
        Category.couple_id == couple.id,
        Category.is_custom == True
    ).first()
    if not cat:
        raise HTTPException(status_code=404, detail="自定义分类不存在")

    # 将该分类下的消息设为无分类
    db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.main_category_id == category_id
    ).update({"main_category_id": None, "is_manual_category": False})

    db.delete(cat)
    db.commit()
    return {"status": "ok", "message": "分类已删除"}


@router.get("/stats/overview", summary="获取分类统计概览")
async def get_category_stats(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    cats = db.query(Category).filter(
        (Category.is_system == True) | ((Category.couple_id == couple.id) & (Category.is_custom == True))
    ).order_by(Category.sort_order).all()

    total = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    ).count()

    stats = []
    for cat in cats:
        count = db.query(Message).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat.id,
            Message.is_deleted == False
        ).count()
        stats.append({
            "id": cat.id,
            "name": cat.name,
            "icon": cat.icon or "📝",
            "color": cat.color or "#ff6b9d",
            "count": count,
            "is_custom": cat.is_custom
        })

    return {"total_messages": total, "categories": stats}


@router.get("/detail/{category_id}", summary="按分类ID获取归档消息")
async def get_category_messages_by_id(
    category_id: int,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    cat = db.query(Category).filter(Category.id == category_id).first()
    if not cat:
        raise HTTPException(status_code=404, detail="分类不存在")

    couple = get_or_create_default_couple(db)
    query = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.main_category_id == category_id,
        Message.is_deleted == False
    )

    if year:
        if month:
            start = datetime(year, month, 1)
            end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
        else:
            start = datetime(year, 1, 1)
            end = datetime(year + 1, 1, 1)
        query = query.filter(Message.created_at >= start, Message.created_at < end)

    messages = query.order_by(Message.created_at.desc()).all()
    return [build_message_response(db, msg) for msg in messages]


# ========== 统计面板 API ==========

@router.get("/stats/dashboard", summary="恋爱统计面板数据（周度/月度活跃度）")
async def get_stats_dashboard(db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)

    # 基础数据
    all_msgs = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    ).order_by(Message.created_at.asc()).all()

    total_messages = len(all_msgs)

    if total_messages == 0:
        return {
            "total_messages": 0,
            "total_days": 0,
            "first_date": None,
            "together_days": 0,
            "weekly_stats": [],
            "monthly_stats": [],
            "sender_distribution": {"男主": 0, "女主": 0},
            "category_distribution": [],
            "streak_days": 0,
            "avg_daily_messages": 0,
            "active_weeks": 0,
            "active_months": 0
        }

    first_date = all_msgs[0].created_at.date() if all_msgs[0].created_at else date.today()
    last_date = all_msgs[-1].created_at.date() if all_msgs[-1].created_at else date.today()
    today = date.today()

    # 恋爱天数
    together_days = (today - first_date).days + 1

    # 按日期分组统计
    daily_counts = {}
    sender_daily = {"男主": {}, "女主": {}}
    sender_total = {"男主": 0, "女主": 0}

    for msg in all_msgs:
        if not msg.created_at:
            continue
        d = msg.created_at.date()
        ds = d.isoformat()
        daily_counts[ds] = daily_counts.get(ds, 0) + 1

        sender = db.query(User).get(msg.sender_id)
        role_name = "男主" if sender and sender.role == "male" else "女主"
        sender_daily[role_name][ds] = sender_daily[role_name].get(ds, 0) + 1
        sender_total[role_name] += 1

    # 活跃天数（有消息的天数）
    active_days_count = len(daily_counts)

    # 连续天数（从最近一天往前数）
    streak = 0
    check_date = last_date
    while check_date.isoformat() in daily_counts:
        streak += 1
        check_date -= timedelta(days=1)
    # 如果今天没消息，从昨天开始算的streak已经正确

    # 周度统计（最近8周）
    weekly_stats = []
    current_monday = today - timedelta(days=today.weekday())
    for i in range(7, -1, -1):
        week_start = current_monday - timedelta(weeks=i)
        week_end = week_start + timedelta(days=6)
        week_msgs = 0
        week_active_days = set()
        male_count = 0
        female_count = 0
        for ds, cnt in daily_counts.items():
            d = date.fromisoformat(ds)
            if week_start <= d <= week_end:
                week_msgs += cnt
                week_active_days.add(ds)
        for msg in all_msgs:
            if not msg.created_at:
                continue
            d = msg.created_at.date()
            if week_start <= d <= week_end:
                sender = db.query(User).get(msg.sender_id)
                if sender and sender.role == "male":
                    male_count += 1
                else:
                    female_count += 1
        weekly_stats.append({
            "week_label": f"{week_start.month}/{week_start.day}-{week_end.month}/{week_end.day}",
            "week_start": week_start.isoformat(),
            "week_end": week_end.isoformat(),
            "message_count": week_msgs,
            "active_days": len(week_active_days),
            "male_count": male_count,
            "female_count": female_count
        })

    # 月度统计（最近12个月）
    monthly_stats = []
    for i in range(11, -1, -1):
        ym = today.replace(day=1) - timedelta(days=1)  # go to last day of prev month
        for _ in range(i):
            ym = (ym.replace(day=1) - timedelta(days=1))
        year = ym.year if i < 11 else today.year
        month = ym.month if i < 11 else today.month
        # simpler approach
        m = today.month - i
        y = today.year
        while m <= 0:
            m += 12
            y -= 1
        month_start = date(y, m, 1)
        if m == 12:
            month_end = date(y + 1, 1, 1) - timedelta(days=1)
        else:
            month_end = date(y, m + 1, 1) - timedelta(days=1)
        month_msgs = 0
        month_active_days = set()
        male_count = 0
        female_count = 0
        for ds, cnt in daily_counts.items():
            d = date.fromisoformat(ds)
            if month_start <= d <= month_end:
                month_msgs += cnt
                month_active_days.add(ds)
        for msg in all_msgs:
            if not msg.created_at:
                continue
            d = msg.created_at.date()
            if month_start <= d <= month_end:
                sender = db.query(User).get(msg.sender_id)
                if sender and sender.role == "male":
                    male_count += 1
                else:
                    female_count += 1
        monthly_stats.append({
            "month_label": f"{y}年{m}月",
            "year": y,
            "month": m,
            "message_count": month_msgs,
            "active_days": len(month_active_days),
            "male_count": male_count,
            "female_count": female_count
        })

    # 分类分布
    cat_dist = []
    all_cats = db.query(Category).filter(
        (Category.is_system == True) | ((Category.couple_id == couple.id) & (Category.is_custom == True))
    ).all()
    for cat in all_cats:
        count = db.query(Message).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat.id,
            Message.is_deleted == False
        ).count()
        if count > 0:
            cat_dist.append({
                "name": cat.name,
                "icon": cat.icon or "📝",
                "color": cat.color or "#ff6b9d",
                "count": count,
                "percentage": round(count / total_messages * 100, 1) if total_messages > 0 else 0
            })

    avg_daily = round(total_messages / max(together_days, 1), 1)
    active_weeks = sum(1 for w in weekly_stats if w["message_count"] > 0)
    active_months = sum(1 for m in monthly_stats if m["message_count"] > 0)

    return {
        "total_messages": total_messages,
        "total_days": together_days,
        "active_days": active_days_count,
        "first_date": first_date.isoformat(),
        "last_date": last_date.isoformat(),
        "streak_days": streak,
        "avg_daily_messages": avg_daily,
        "weekly_stats": weekly_stats,
        "monthly_stats": monthly_stats,
        "sender_distribution": sender_total,
        "category_distribution": sorted(cat_dist, key=lambda x: -x["count"]),
        "active_weeks": active_weeks,
        "active_months": active_months
    }
