import os
import uuid
import json
import aiofiles
from pathlib import Path
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db, SessionLocal
from app.models import Message, User, Couple, Category, MessageAttachment, AIProcessLog
from app.schemas.message import MessageResponse, AttachmentInfo
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/messages", tags=["消息接口"])

UPLOAD_DIR = Path("uploads")
IMAGE_DIR = UPLOAD_DIR / "images"
VOICE_DIR = UPLOAD_DIR / "voices"
VIDEO_DIR = UPLOAD_DIR / "videos"
IMAGE_DIR.mkdir(parents=True, exist_ok=True)
VOICE_DIR.mkdir(parents=True, exist_ok=True)
VIDEO_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", 100)) * 1024 * 1024  # 100MB for video


def get_or_create_default_couple(db: Session) -> Couple:
    couple = db.query(Couple).first()
    if not couple:
        import bcrypt
        password = "123456"
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        couple = Couple(access_password=hashed_password, couple_name="我们的小窝")
        db.add(couple)
        db.flush()
        male = User(couple_id=couple.id, role="male", nickname="男主", theme_color="#4a90e2")
        female = User(couple_id=couple.id, role="female", nickname="女主", theme_color="#ff6b9d")
        db.add_all([male, female])
        db.commit()
        db.refresh(couple)
    return couple


async def save_upload_file(upload_file: UploadFile, save_dir: Path) -> tuple:
    """保存上传文件，返回(访问URL, 文件大小, 文件名)"""
    original_ext = os.path.splitext(upload_file.filename or "")[1].lower()
    file_ext = original_ext if original_ext else ".bin"
    file_name = f"{uuid.uuid4().hex}{file_ext}"
    file_path = save_dir / file_name

    file_size = 0
    async with aiofiles.open(file_path, 'wb') as f:
        while chunk := await upload_file.read(1024 * 1024):
            file_size += len(chunk)
            if file_size > MAX_FILE_SIZE:
                await f.close()
                if file_path.exists():
                    os.remove(file_path)
                raise HTTPException(status_code=400, detail=f"文件大小超过限制{MAX_FILE_SIZE//1024//1024}MB")
            await f.write(chunk)

    url_path = f"/uploads/{save_dir.name}/{file_name}"
    return url_path, file_size, str(file_path)


def _get_media_duration(file_path: str) -> Optional[int]:
    """尝试获取音视频时长（秒）"""
    try:
        import struct
        duration = None
        ext = Path(file_path).suffix.lower()
        # WebM/Opus duration estimation from file size and bitrate
        if ext in ['.webm', '.ogg', '.opus']:
            size = os.path.getsize(file_path)
            duration = int(size / 16000)  # rough estimate for voice
            duration = max(1, min(duration, 300))
        return duration
    except Exception:
        return None


async def _process_ai_classification(
    message_id: int,
    text_content: str,
    content_type: str,
    image_paths: List[str],
    voice_duration: Optional[int],
    db_session_factory
):
    db = db_session_factory()
    try:
        start_time = datetime.utcnow()
        ai_result = await ai_service.process_message(text_content, content_type, image_paths, db)

        msg = db.query(Message).get(message_id)
        if not msg:
            return

        msg.main_category_id = ai_result["main_category_id"]
        msg.ai_summary = ai_result["ai_summary"]
        msg.ai_confidence = ai_result["ai_confidence"]
        msg.extracted_nicknames = ai_result.get("extracted_nicknames", [])
        msg.ai_processed = True
        msg.ai_processed_at = datetime.utcnow()
        if voice_duration and content_type == "voice":
            msg.voice_duration = voice_duration

        process_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        log = AIProcessLog(
            message_id=message_id,
            model_used="mock" if not ai_service.ai_enabled else ai_service.model,
            raw_response=ai_result,
            processing_time_ms=process_time,
            status="success"
        )
        db.add(log)
        db.commit()

        # Also update attachment duration
        if voice_duration:
            att = db.query(MessageAttachment).filter(
                MessageAttachment.message_id == message_id,
                MessageAttachment.file_type == "voice"
            ).first()
            if att:
                att.duration = voice_duration
                db.commit()
    except Exception as e:
        db.rollback()
        print(f"AI处理消息{message_id}失败: {e}")
        try:
            log = AIProcessLog(message_id=message_id, status="failed", error_message=str(e))
            db.add(log)
            db.commit()
        except:
            pass
    finally:
        db.close()


def build_message_response(db: Session, msg: Message) -> dict:
    sender = db.query(User).get(msg.sender_id)

    category_name = None
    category_icon = None
    category_color = None
    if msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id, db)
        if cat:
            category_name = cat["name"]
            category_icon = cat.get("icon", "📝")
            category_color = cat.get("color", "#ff6b9d")
        else:
            db_cat = db.query(Category).get(msg.main_category_id)
            if db_cat:
                category_name = db_cat.name
                category_icon = db_cat.icon or "📝"
                category_color = db_cat.color or "#ff6b9d"

    atts = db.query(MessageAttachment).filter(MessageAttachment.message_id == msg.id).all()
    attachments = []
    for att in atts:
        attachments.append({
            "file_type": att.file_type,
            "file_url": att.file_url,
            "thumbnail_url": att.thumbnail_url,
            "duration": att.duration or msg.voice_duration,
            "width": att.width,
            "height": att.height,
            "file_size": att.file_size,
            "mime_type": att.mime_type
        })

    return {
        "id": msg.id,
        "sender_role": "男主" if sender.role == "male" else "女主" if sender.role == "female" else "其他",
        "sender_nickname": sender.nickname,
        "sender_theme_color": sender.theme_color,
        "content_type": msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        "text_content": msg.text_content,
        "ai_summary": msg.ai_summary,
        "main_category_id": msg.main_category_id,
        "main_category_name": category_name,
        "main_category_icon": category_icon,
        "main_category_color": category_color,
        "ai_processed": msg.ai_processed,
        "is_manual_category": msg.is_manual_category,
        "attachments": attachments,
        "voice_duration": msg.voice_duration,
        "created_at": msg.created_at.isoformat() if msg.created_at else None,
    }


@router.post("", summary="发送新消息（支持文字/图片/语音/视频/录音）")
async def create_message(
    background_tasks: BackgroundTasks,
    sender_role: str = Form(...),
    text_content: Optional[str] = Form(None),
    is_ai_auto: bool = Form(True),
    manual_category: Optional[str] = Form(None),
    voice_duration: Optional[int] = Form(None, description="前端传入的语音时长（秒）"),
    video_duration: Optional[int] = Form(None, description="前端传入的视频时长（秒）"),
    images: List[UploadFile] = File([], description="图片文件列表"),
    voice: Optional[UploadFile] = File(None, description="语音/录音文件"),
    video: Optional[UploadFile] = File(None, description="视频文件"),
    db: Session = Depends(get_db)
):
    if sender_role not in ["男主", "女主", "其他"]:
        raise HTTPException(status_code=400, detail="发送人角色只能是男主/女主")

    has_content = bool(text_content and text_content.strip()) or images or voice or video
    if not has_content:
        raise HTTPException(status_code=400, detail="消息内容不能为空")

    if video:
        content_type = "video"
    elif voice:
        content_type = "voice"
    elif images:
        content_type = "image"
    else:
        content_type = "text"

    manual_category_id = None
    if not is_ai_auto:
        if not manual_category:
            raise HTTPException(status_code=400, detail="关闭AI自动分类时必须手动选择分类")
        manual_category_id = ai_service.get_category_id_by_name(manual_category, db)
        if not manual_category_id:
            db_cat = db.query(Category).filter(Category.name == manual_category).first()
            if db_cat:
                manual_category_id = db_cat.id
        if not manual_category_id:
            raise HTTPException(status_code=400, detail=f"分类不存在: {manual_category}")

    couple = get_or_create_default_couple(db)
    role_map = {"男主": "male", "女主": "female", "其他": "other"}
    sender = db.query(User).filter(
        User.couple_id == couple.id,
        User.role == role_map[sender_role]
    ).first()
    if not sender:
        raise HTTPException(status_code=400, detail="发送用户不存在")

    attachments = []
    local_image_paths = []
    final_voice_duration = voice_duration

    for img in images:
        if img.content_type and not img.content_type.startswith("image/"):
            continue
        url_path, file_size, local_path = await save_upload_file(img, IMAGE_DIR)
        local_image_paths.append(local_path)
        width, height = None, None
        try:
            from PIL import Image
            with Image.open(local_path) as pil_img:
                width, height = pil_img.size
        except:
            pass
        attachments.append(MessageAttachment(
            file_type="image", file_url=url_path, file_size=file_size,
            width=width, height=height, mime_type=img.content_type
        ))

    if video:
        if video.content_type and not video.content_type.startswith("video/"):
            raise HTTPException(status_code=400, detail="视频文件格式错误")
        url_path, file_size, local_path = await save_upload_file(video, VIDEO_DIR)
        v_duration = video_duration or _get_media_duration(local_path)
        attachments.append(MessageAttachment(
            file_type="video", file_url=url_path, file_size=file_size,
            duration=v_duration, mime_type=video.content_type or "video/mp4"
        ))

    if voice:
        url_path, file_size, local_path = await save_upload_file(voice, VOICE_DIR)
        if not final_voice_duration:
            final_voice_duration = _get_media_duration(local_path) or 5
        attachments.append(MessageAttachment(
            file_type="voice", file_url=url_path, file_size=file_size,
            duration=final_voice_duration, mime_type=voice.content_type or "audio/webm"
        ))

    db_message = Message(
        couple_id=couple.id,
        sender_id=sender.id,
        content_type=content_type,
        text_content=text_content.strip() if text_content else None,
        ai_processed=False,
        voice_transcribed=False,
        voice_duration=final_voice_duration if content_type == "voice" else None,
        is_manual_category=not is_ai_auto
    )

    if not is_ai_auto:
        db_message.main_category_id = manual_category_id
        db_message.ai_processed = True
        db_message.ai_confidence = 1.0

    db.add(db_message)
    db.flush()

    for att in attachments:
        att.message_id = db_message.id
        db.add(att)

    db.commit()
    db.refresh(db_message)

    if is_ai_auto:
        background_tasks.add_task(
            _process_ai_classification,
            db_message.id,
            text_content or "",
            content_type,
            local_image_paths,
            final_voice_duration,
            SessionLocal
        )

    return build_message_response(db, db_message)


from sqlalchemy.orm import joinedload

@router.get("", summary="获取历史消息")
async def list_messages(
    limit: int = 500,
    offset: int = 0,
    order: str = "asc",
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)
    # Eager load sender and attachments to avoid N+1 queries
    query = db.query(Message).options(
        joinedload(Message.sender),
        joinedload(Message.attachments)
    ).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    )
    query = query.order_by(Message.created_at.asc() if order.lower() == "asc" else Message.created_at.desc())
    msgs = query.offset(offset).limit(limit).all()
    # Prefetch all categories for this couple
    db_cats = {c.id: c for c in db.query(Category).filter(
        (Category.is_system == True) | ((Category.couple_id == couple.id) & (Category.is_custom == True))
    ).all()}
    return [build_message_response_fast(msg, db_cats) for msg in msgs]


def build_message_response_fast(msg, db_cats=None):
    """Fast message response builder using pre-loaded relationships"""
    sender = msg.sender
    category_name = None
    category_icon = None
    category_color = None
    if msg.main_category_id and db_cats:
        cat = db_cats.get(msg.main_category_id)
        if cat:
            category_name = cat.name
            category_icon = cat.icon or "📝"
            category_color = cat.color or "#ff6b9d"
    elif msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id)
        if cat:
            category_name = cat["name"]
            category_icon = cat.get("icon", "📝")
            category_color = cat.get("color", "#ff6b9d")

    attachments = []
    for att in (msg.attachments or []):
        attachments.append({
            "file_type": att.file_type,
            "file_url": att.file_url,
            "thumbnail_url": att.thumbnail_url,
            "duration": att.duration or msg.voice_duration,
            "width": att.width,
            "height": att.height,
            "file_size": att.file_size,
            "mime_type": att.mime_type
        })

    return {
        "id": msg.id,
        "sender_role": "男主" if sender.role == "male" else "女主" if sender.role == "female" else "其他",
        "sender_nickname": sender.nickname,
        "sender_theme_color": sender.theme_color,
        "content_type": msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        "text_content": msg.text_content,
        "ai_summary": msg.ai_summary,
        "main_category_id": msg.main_category_id,
        "main_category_name": category_name,
        "main_category_icon": category_icon,
        "main_category_color": category_color,
        "ai_processed": msg.ai_processed,
        "is_manual_category": msg.is_manual_category,
        "attachments": attachments,
        "voice_duration": msg.voice_duration,
        "created_at": msg.created_at.isoformat() if msg.created_at else None,
    }


@router.put("/{message_id}/category", summary="修改消息分类（手动纠正）")
async def update_message_category(
    message_id: int,
    category_id: int = Form(...),
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)
    msg = db.query(Message).filter(
        Message.id == message_id,
        Message.couple_id == couple.id
    ).first()
    if not msg:
        raise HTTPException(status_code=404, detail="消息不存在")

    cat = db.query(Category).filter(Category.id == category_id).first()
    if not cat:
        raise HTTPException(status_code=404, detail="分类不存在")

    msg.main_category_id = category_id
    msg.is_manual_category = True
    msg.ai_processed = True
    db.commit()
    db.refresh(msg)
    return build_message_response(db, msg)


@router.delete("/{message_id}", summary="删除消息（软删除）")
async def delete_message(message_id: int, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    msg = db.query(Message).filter(
        Message.id == message_id,
        Message.couple_id == couple.id
    ).first()
    if not msg:
        raise HTTPException(status_code=404, detail="消息不存在")
    msg.is_deleted = True
    db.commit()
    return {"status": "ok", "message": "已删除"}
