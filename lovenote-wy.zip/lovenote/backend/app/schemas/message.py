from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from enum import Enum


class SenderRole(str, Enum):
    MALE = "男主"
    FEMALE = "女主"
    OTHER = "其他"


class ContentType(str, Enum):
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    VIDEO = "video"
    STICKER = "sticker"


class AttachmentInfo(BaseModel):
    file_type: str
    file_url: str
    thumbnail_url: Optional[str] = None
    duration: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    file_size: Optional[int] = None
    mime_type: Optional[str] = None


class MessageResponse(BaseModel):
    id: int
    sender_role: str
    sender_nickname: str
    sender_theme_color: Optional[str] = None
    content_type: str
    text_content: Optional[str]
    ai_summary: Optional[str]
    main_category_id: Optional[int] = None
    main_category_name: Optional[str]
    main_category_icon: Optional[str]
    main_category_color: Optional[str] = None
    ai_processed: bool
    is_manual_category: bool = False
    attachments: List[AttachmentInfo] = []
    voice_duration: Optional[int] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
