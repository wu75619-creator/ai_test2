"""
情侣智能随手恋爱日记本 - 桌面客户端入口
==========================================
使用 pywebview 创建原生桌面窗口，FastAPI 后端在后台线程中运行。
双击 exe 即可使用，无需安装 Python、Node.js 或任何命令行工具。

打包命令：
    pip install pyinstaller pywebview
    pyinstaller LoveNote.spec

生成文件：dist/LoveNote.exe （单文件，双击运行）
"""
import os
import sys
import time
import socket
import threading
import urllib.request
import urllib.error

# ── 在导入 app 之前，强制将工作目录设为 exe/脚本所在目录 ──
if getattr(sys, 'frozen', False):
    APP_DIR = os.path.dirname(sys.executable)
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)

# 将 backend 目录加入 path（仅 frozen 模式需要）
BACKEND_DIR = os.path.join(APP_DIR, 'backend') if not getattr(sys, 'frozen', False) else APP_DIR
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)


def find_free_port() -> int:
    """寻找一个空闲的 TCP 端口"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def wait_for_server(port: int, timeout: int = 30) -> bool:
    """轮询等待后端服务就绪"""
    url = f"http://127.0.0.1:{port}/api/health"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            req = urllib.request.urlopen(url, timeout=2)
            if req.status == 200:
                return True
        except (urllib.error.URLError, ConnectionRefusedError, OSError):
            time.sleep(0.3)
    return False


def run_backend(port: int):
    """在后台线程中启动 uvicorn/FastAPI 服务"""
    os.environ["PORT"] = str(port)
    os.environ["AI_ENABLED"] = os.environ.get("AI_ENABLED", "false")
    try:
        import uvicorn
        # 在 frozen 模式下，app 需要从 main 模块导入
        from main import app
        uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning", access_log=False)
    except Exception as e:
        print(f"[Backend] 启动失败: {e}", file=sys.stderr)


def get_window_icon() -> str:
    """返回图标文件路径（打包时作为 data 文件包含）"""
    if getattr(sys, 'frozen', False):
        icon_path = os.path.join(sys._MEIPASS, 'app_icon.ico')
    else:
        icon_path = os.path.join(os.path.dirname(__file__), 'build', 'app_icon.ico')
    return icon_path if os.path.exists(icon_path) else None


def main():
    # 1. 找空闲端口
    port = find_free_port()
    print(f"[LoveNote] 使用端口: {port}")

    # 2. 在后台线程启动 FastAPI
    server_thread = threading.Thread(target=run_backend, args=(port,), daemon=True)
    server_thread.start()

    # 3. 等待服务器就绪
    print("[LoveNote] 等待后端服务启动...")
    if not wait_for_server(port, timeout=30):
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, "服务启动失败，请检查是否有其他程序占用端口。", "情侣日记本", 0x10)
        sys.exit(1)
    print(f"[LoveNote] 后端就绪: http://127.0.0.1:{port}")

    # 4. 启动 pywebview 桌面窗口
    import webview
    url = f"http://127.0.0.1:{port}/"

    icon = get_window_icon()
    window_kwargs = {
        "title": "💑 情侣智能随手恋爱日记本",
        "url": url,
        "width": 480,
        "height": 820,
        "min_size": (360, 600),
        "resizable": True,
        "text_select": True,
    }
    if icon:
        window_kwargs["icon"] = icon

    window = webview.create_window(**window_kwargs)

    # 关闭窗口时确保服务线程结束（daemon=True 会自动结束）
    def on_closed():
        print("[LoveNote] 窗口关闭，正在退出...")
        os._exit(0)

    window.events.closed += on_closed
    webview.start(debug=False)


if __name__ == "__main__":
    main()
