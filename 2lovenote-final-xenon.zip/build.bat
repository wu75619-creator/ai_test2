@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ══════════════════════════════════════════════════
echo   💑 情侣智能随手恋爱日记本 - 桌面端一键构建
echo ══════════════════════════════════════════════════
echo.

:: ── 检查 Python ──────────────────────────────────
where python >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Python，请先安装 Python 3.10+ 并加入 PATH
    echo    下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo ✅ Python 版本: %PYVER%
echo.

:: ── 检查 Node.js（用于构建前端）───────────────────
where node >nul 2>&1
if errorlevel 1 (
    echo ❌ 未检测到 Node.js，请先安装 Node.js 18+
    echo    下载地址: https://nodejs.org/
    pause
    exit /b 1
)
for /f "tokens=1 delims=." %%v in ('node -v') do set NODEVER=%%v
echo ✅ Node.js 版本: %NODEVER%
echo.

:: ── 第1步：构建前端 ──────────────────────────────
echo [1/5] 📦 构建前端 Vue3 应用...
cd frontend
if not exist node_modules (
    echo   安装前端依赖...
    call npm install
    if errorlevel 1 (
        echo ❌ npm install 失败
        cd ..
        pause
        exit /b 1
    )
)
call npm run build
if errorlevel 1 (
    echo ❌ 前端构建失败
    cd ..
    pause
    exit /b 1
)
cd ..
echo ✅ 前端构建完成
echo.

:: ── 第2步：安装 Python 依赖 ─────────────────────
echo [2/5] 🐍 安装后端 Python 依赖...
pip install -r backend\requirements.txt -q
if errorlevel 1 (
    echo ❌ Python 依赖安装失败
    pause
    exit /b 1
)
echo ✅ 后端依赖安装完成
echo.

:: ── 第3步：安装桌面打包依赖 ─────────────────────
echo [3/5] 🖥️  安装桌面打包依赖（pywebview + pyinstaller）...
pip install -r requirements-desktop.txt -q
if errorlevel 1 (
    echo ❌ 桌面依赖安装失败
    pause
    exit /b 1
)
echo ✅ 桌面依赖安装完成
echo.

:: ── 第4步：生成图标 ─────────────────────────────
echo [4/5] 🎨 生成应用图标...
python build\gen_icon.py
if errorlevel 1 (
    echo ⚠️  图标生成失败，将使用默认图标
)
echo.

:: ── 第5步：PyInstaller 打包 ────────────────────
echo [5/5] 📦 PyInstaller 打包为 LoveNote.exe...
echo   （此步骤约需1-3分钟，请耐心等待...）
echo.

pyinstaller LoveNote.spec --clean --noconfirm
if errorlevel 1 (
    echo ❌ 打包失败，请检查上方错误信息
    pause
    exit /b 1
)

echo.
echo ══════════════════════════════════════════════════
echo   🎉 构建成功！
echo ══════════════════════════════════════════════════
echo.
echo   📁 输出文件: dist\LoveNote.exe
echo   📁 大小:
for %%A in (dist\LoveNote.exe) do echo      %%~zA 字节 ^(约 %%~zA MB^)
echo.
echo   💡 使用说明:
echo      - 双击 dist\LoveNote.exe 即可运行
echo      - 数据保存在 %%APPDATA%%\LoveNote\
echo      - 首次运行时浏览器会请求麦克风/摄像头权限，请点击"允许"
echo      - 关闭窗口即完全退出，无后台残留
echo.
echo   ⚠️  注意: Windows SmartScreen 可能提示"未识别的应用"，
echo      点击"更多信息" → "仍要运行"即可（这是正常现象，
echo      因为 exe 未购买代码签名证书）。
echo.

:: 询问是否打开 dist 目录
set /p OPEN="是否打开 dist 目录？(Y/N): "
if /i "%OPEN%"=="Y" explorer dist

pause
