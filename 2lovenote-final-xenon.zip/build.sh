#!/bin/bash
# 情侣智能随手恋爱日记本 - Linux/macOS 桌面端构建脚本
set -e

echo "══════════════════════════════════════════════════"
echo "  💑 情侣智能随手恋爱日记本 - 桌面端构建"
echo "══════════════════════════════════════════════════"
echo ""

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 python3，请先安装 Python 3.10+"
    exit 1
fi
echo "✅ Python: $(python3 --version)"

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "❌ 未找到 node，请先安装 Node.js 18+"
    exit 1
fi
echo "✅ Node.js: $(node --version)"
echo ""

# 第1步：构建前端
echo "[1/5] 📦 构建前端..."
cd frontend
[ ! -d node_modules ] && npm install
npm run build
cd ..
echo "✅ 前端构建完成"
echo ""

# 第2步：安装后端依赖
echo "[2/5] 🐍 安装后端依赖..."
pip3 install -r backend/requirements.txt -q
echo "✅ 后端依赖完成"
echo ""

# 第3步：安装桌面依赖
echo "[3/5] 🖥️  安装桌面打包依赖..."
pip3 install -r requirements-desktop.txt -q
echo "✅ 桌面依赖完成"
echo ""

# Linux 需要安装 webkit2gtk
if [ "$(uname)" = "Linux" ]; then
    echo "   Linux 检测到，如需运行请确保已安装: sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0 gir1.2-webkit2-4.1"
fi

# 第4步：生成图标
echo "[4/5] 🎨 生成图标..."
python3 build/gen_icon.py || echo "⚠️  图标生成失败"
echo ""

# 第5步：打包
echo "[5/5] 📦 PyInstaller 打包..."
pyinstaller LoveNote.spec --clean --noconfirm
echo ""
echo "══════════════════════════════════════════════════"
echo "  🎉 构建成功！"
echo "══════════════════════════════════════════════════"
echo ""
echo "  📁 可执行文件: dist/LoveNote"
ls -lh dist/LoveNote* 2>/dev/null || ls -lh dist/
echo ""
echo "  💡 数据保存在: ~/.lovenote/ (Linux) 或 ~/Library/Application Support/LoveNote/ (macOS)"
