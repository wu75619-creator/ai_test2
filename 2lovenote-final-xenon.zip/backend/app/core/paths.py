"""
路径配置工具 - 自动适配开发模式与PyInstaller打包模式

- 开发模式：数据存放在项目根目录的 data/ 下，前端dist在 frontend/dist/
- 打包模式（PyInstaller frozen）：
  - 静态资源（前端dist）从 sys._MEIPASS 读取（exe内部）
  - 用户数据（数据库、上传文件）存放在系统用户目录：
    - Windows: %APPDATA%/LoveNote/  (即 AppData/Roaming/LoveNote)
    - macOS:   ~/Library/Application Support/LoveNote/
    - Linux:   ~/.lovenote/
"""
import os
import sys
from pathlib import Path


def is_frozen() -> bool:
    """判断是否运行在 PyInstaller 打包后的环境中"""
    return getattr(sys, 'frozen', False)


def get_meipass() -> Path:
    """获取 PyInstaller 临时解压目录（frozen模式下的资源根目录）"""
    if is_frozen():
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent.parent.parent


def get_app_name() -> str:
    return "LoveNote"


def get_user_data_dir() -> Path:
    """
    获取用户数据目录（存放数据库和上传文件）。
    这个目录是可写的，在exe运行时不会被清理。
    """
    if is_frozen():
        if sys.platform == "win32":
            # Windows: %APPDATA%\LoveNote  (C:\Users\xxx\AppData\Roaming\LoveNote)
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
        elif sys.platform == "darwin":
            # macOS: ~/Library/Application Support/LoveNote
            base = Path.home() / "Library" / "Application Support"
        else:
            # Linux: ~/.lovenote
            base = Path.home()
        data_dir = base / get_app_name() if sys.platform != "linux" else base / ".lovenote"
    else:
        # 开发模式：项目根目录的 data/
        data_dir = get_meipass() / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_frontend_dist_dir() -> Path:
    """获取前端 dist 静态资源目录"""
    if is_frozen():
        # PyInstaller 打包时，前端dist会被放到 _MEIPASS/frontend/dist/
        return get_meipass() / "frontend" / "dist"
    else:
        return get_meipass() / "frontend" / "dist"


def get_database_dir() -> Path:
    return get_user_data_dir()


def get_uploads_dir() -> Path:
    upl = get_user_data_dir() / "uploads"
    upl.mkdir(parents=True, exist_ok=True)
    for sub in ["images", "voices", "videos", "thumbnails"]:
        (upl / sub).mkdir(exist_ok=True)
    return upl


def get_database_url() -> str:
    """返回 SQLite 数据库连接 URL"""
    db_path = get_database_dir() / "love_diary.db"
    return f"sqlite:///{db_path}"
