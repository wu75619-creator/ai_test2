"""
情侣智能随手恋爱日记本 - 后端入口 v2.1
- 支持 PyInstaller frozen 打包模式
- 数据自动存入用户目录（Windows: AppData/Roaming/LoveNote）
- 可通过 PORT 环境变量指定端口（桌面外壳自动寻找空闲端口）
"""
import os
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response

from app.core.paths import get_frontend_dist_dir, get_uploads_dir, is_frozen
from app.core.database import engine, Base
from app import models

# 创建所有数据库表
Base.metadata.create_all(bind=engine)

# 初始化系统预设8大分类
from app.core.init_data import init_system_categories
init_system_categories()

app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    description="对话式随手记录 + AI自动分类归档的双人恋爱日记本",
    version="2.1.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 上传文件静态服务（路径自动适配frozen模式）
upload_dir = get_uploads_dir()
app.mount("/uploads", StaticFiles(directory=str(upload_dir)), name="uploads")

# 注册API路由
from app.api.messages import router as messages_router
from app.api.categories import router as categories_router
from app.api.stats import router as stats_router
app.include_router(messages_router)
app.include_router(categories_router)
app.include_router(stats_router)


@app.get("/api/health", summary="健康检查")
async def health_check():
    ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
    return {
        "status": "ok",
        "message": "情侣日记本服务运行中 💑",
        "ai_mode": "真实大模型" if ai_enabled else "Mock模拟模式",
        "version": "2.1.0",
        "frozen": is_frozen()
    }


# ========== SPA 前端静态文件服务 ==========
FRONTEND_DIST = get_frontend_dist_dir()

if FRONTEND_DIST.exists():
    assets_dir = FRONTEND_DIST / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str, request: Request):
        if full_path.startswith("api/") or full_path.startswith("uploads/"):
            return Response(status_code=404)
        file_path = FRONTEND_DIST / full_path
        if full_path and file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(FRONTEND_DIST / "index.html"))
else:
    @app.get("/", include_in_schema=False)
    async def root():
        return {"message": "情侣日记本API运行中，请先构建前端", "docs": "/api/docs"}


def get_port() -> int:
    """获取运行端口，桌面外壳模式下自动寻找空闲端口"""
    return int(os.getenv("PORT", "8000"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=get_port(), reload=not is_frozen())
