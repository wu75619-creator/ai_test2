# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller 打包配置 - 情侣智能随手恋爱日记本
===============================================
生成单文件 LoveNote.exe，包含：
  - FastAPI 后端（含所有路由、AI服务、数据库初始化）
  - Vue3 前端静态资源（frontend/dist/）
  - pywebview 桌面窗口外壳
  - 应用图标

数据（数据库、上传图片/语音/视频）保存在：
  Windows: %APPDATA%/LoveNote/
  macOS:   ~/Library/Application Support/LoveNote/
  Linux:   ~/.lovenote/

用法：
  pip install pyinstaller pywebview
  pyinstaller LoveNote.spec
"""
import os
import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# ── 路径 ──────────────────────────────────────────────────────────────
SPEC_DIR = os.path.abspath(os.path.dirname(SPEC)) if 'SPEC' in dir() else os.path.abspath('.')
BACKEND_DIR = os.path.join(SPEC_DIR, 'backend')
FRONTEND_DIST = os.path.join(SPEC_DIR, 'frontend', 'dist')
ICON_PATH = os.path.join(SPEC_DIR, 'build', 'app_icon.ico')

# ── 收集隐藏导入 ─────────────────────────────────────────────────────
hidden_imports = [
    'uvicorn.logging',
    'uvicorn.loops',
    'uvicorn.loops.auto',
    'uvicorn.protocols',
    'uvicorn.protocols.http',
    'uvicorn.protocols.http.auto',
    'uvicorn.protocols.websockets',
    'uvicorn.protocols.websockets.auto',
    'uvicorn.lifespan',
    'uvicorn.lifespan.on',
    'app.api.messages',
    'app.api.categories',
    'app.api.stats',
    'app.core.database',
    'app.core.paths',
    'app.core.couple',
    'app.core.init_data',
    'app.models',
    'app.models.models',
    'app.schemas.message',
    'app.services.ai_service',
    'sqlalchemy.dialects.sqlite',
    'PIL._tkinter_finder',
    'webview',
    'webview.platforms.winforms',
    'multipart',
    'aiofiles',
]

# pywebview 平台相关隐藏导入（Windows）
if sys.platform == 'win32':
    hidden_imports += [
        'clr',
        'pythonnet',
        'webview.platforms.winforms',
    ]

# ── 收集数据文件 ─────────────────────────────────────────────────────
datas = []

# 前端 dist 全部文件 → 打包到 frontend/dist/
if os.path.isdir(FRONTEND_DIST):
    for root, dirs, files in os.walk(FRONTEND_DIST):
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SPEC_DIR)
            # PyInstaller 期望 (源路径, 目标目录)
            target_dir = os.path.dirname(rel)
            datas.append((full, target_dir))

# 图标
if os.path.exists(ICON_PATH):
    datas.append((ICON_PATH, '.'))

# ── Analysis ─────────────────────────────────────────────────────────
a = Analysis(
    ['desktop_app.py'],
    pathex=[BACKEND_DIR, SPEC_DIR],
    binaries=[],
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'matplotlib', 'numpy.random._examples'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='LoveNote',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,           # 不显示黑色命令行窗口
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=ICON_PATH if os.path.exists(ICON_PATH) else None,
)
