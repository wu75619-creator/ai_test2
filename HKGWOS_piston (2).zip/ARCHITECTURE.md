# 情侣智能随手恋爱日记本 - 架构设计文档 v1.0
## 第1步产出 | 后续开发严格基准

---

## 一、技术栈选型确认

### 1.1 前端技术栈（核心体验层）
| 技术 | 版本建议 | 选型理由 |
|------|----------|----------|
| Vue.js | 3.4+ | 渐进式框架，Composition API适合复杂交互，移动端适配优秀 |
| Vite | 5.x | 极速构建热更新，开发体验流畅 |
| Pinia | 2.x | Vue3官方推荐状态管理，简单直观 |
| Vue Router | 4.x | 路由管理，支持分类页/时间轴/首页切换 |
| Element Plus | 2.7+ | UI组件库，支持自定义主题，可快速搭建治愈风界面 |
| Axios | 1.7+ | HTTP请求库，拦截器统一处理鉴权/错误 |
| wavesurfer.js | 7.x | 语音波形可视化+播放，支持进度拖拽 |
| dayjs | 1.11+ | 轻量时间处理库，体积小 |
| vue3-picture-swipe | 3.x | 图片点击放大、滑动预览 |
| 响应式布局 | - | 移动端优先，适配手机/平板/桌面 |

### 1.2 后端技术栈（业务处理层）
| 技术 | 版本建议 | 选型理由 |
|------|----------|----------|
| Python | 3.11+ | AI生态最完善，对接视觉/大模型接口最方便 |
| FastAPI | 0.110+ | 高性能异步框架，自动生成OpenAPI文档，类型提示减少bug |
| SQLAlchemy | 2.0+ | Python最成熟ORM，支持复杂查询 |
| Alembic | 1.13+ | 数据库迁移工具，版本化管理表结构 |
| Pydantic | 2.x | 数据校验，自动类型转换 |
| python-multipart | 0.0.9+ | 支持图片/语音文件上传 |
| Pillow | 10.x | 图片处理、缩略图生成 |
| OpenAI SDK | 1.x+ | 统一AI接口适配层（可替换任意大模型/视觉模型） |
| Uvicorn | 0.29+ | ASGI服务器，支持异步高并发 |
| python-jose | 3.x+ | JWT鉴权，密码加密存储 |

### 1.3 数据存储层
| 组件 | 选型 | 说明 |
|------|------|------|
| 关系型数据库 | PostgreSQL 16 | 支持JSONB字段、全文搜索、事务安全，性能优秀；开发阶段可切换SQLite快速原型 |
| 文件存储 | 本地文件系统 → 阿里云OSS/腾讯云COS | 开发阶段本地存储，生产环境切换对象存储，永久保存图片/语音 |
| 缓存（可选） | Redis 7.x | 后续优化AI处理结果缓存、会话管理，第一版可省略 |

### 1.4 部署方案
- 前端：Vercel/Netlify 静态托管（自动HTTPS、全球CDN），或阿里云OSS
- 后端：Docker容器化部署，阿里云ECS/Fly.io/Render
- 数据库：Supabase（免运维PostgreSQL）或云RDS
- 域名：绑定情侣专属二级域名，密码访问保护

---

## 二、核心数据库表结构设计（PostgreSQL DDL）

### 设计原则
1. 完美支撑「单条内容唯一主分类+多个子标签」
2. 全局时间轴按精确时间排序
3. 支持文字/图片/语音全媒介
4. AI字段完整预留（分类、标签、小结、处理状态）
5. 双人权限体系，软删除防误删
6. 可扩展自定义分类

```sql
-- ============================================
-- 1. 情侣对表：核心顶层实体，一对情侣对应一个空间
-- ============================================
CREATE TABLE couples (
    id BIGSERIAL PRIMARY KEY,
    couple_name VARCHAR(100) NOT NULL DEFAULT '我们的小窝', -- 情侣空间名称
    together_date DATE, -- 在一起纪念日
    access_password VARCHAR(255) NOT NULL, -- 访问密码（bcrypt加密）
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE
);

-- ============================================
-- 2. 用户表：男主/女主两个用户，归属一个情侣对
-- ============================================
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    couple_id BIGINT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL, -- 'male' / 'female' / 'other'
    nickname VARCHAR(50) NOT NULL, -- 昵称（男主/女主/自定义）
    avatar_url VARCHAR(500), -- 头像
    theme_color VARCHAR(20) DEFAULT '#ff6b9d', -- 专属气泡配色
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(couple_id, role)
);

-- ============================================
-- 3. 分类表：包含8大系统主分类 + 可扩展子标签
-- 支持情侣自定义标签
-- ============================================
CREATE TABLE categories (
    id BIGSERIAL PRIMARY KEY,
    couple_id BIGINT REFERENCES couples(id) ON DELETE CASCADE, -- NULL=系统预设，对所有情侣可见
    parent_id BIGINT REFERENCES categories(id) ON DELETE CASCADE, -- NULL=主分类，NOT NULL=子标签
    name VARCHAR(50) NOT NULL, -- 分类名称
    icon VARCHAR(100), -- 图标（emoji或图标路径）
    description VARCHAR(200), -- 分类描述
    sort_order INT NOT NULL DEFAULT 0, -- 排序
    is_system BOOLEAN NOT NULL DEFAULT FALSE, -- 是否系统预设8大分类
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(couple_id, name, parent_id)
);

-- 预置8大核心主分类（couple_id=NULL代表全局系统预设）
INSERT INTO categories (parent_id, name, icon, description, is_system, sort_order) VALUES
(NULL, '美食探店存档', '🍜', '一起吃过的美食、喝过的奶茶、探店记录', TRUE, 1),
(NULL, '旅行外出约会存档', '✈️', '旅行、逛街、看电影、约会游玩记录', TRUE, 2),
(NULL, '情侣合照存档', '📸', '双人自拍、同框合照、甜蜜合影', TRUE, 3),
(NULL, '趣味日常存档', '😂', '搞笑对话、互怼日常、可爱瞬间、表情包', TRUE, 4),
(NULL, '专属昵称存档', '💌', '专属称呼、私密代号、只有我们懂的梗', TRUE, 5),
(NULL, '深度谈心存档', '💬', '走心对话、三观交流、情绪倾诉、爱意表达', TRUE, 6),
(NULL, '矛盾复盘存档', '🤝', '小矛盾、争吵、反思、道歉、和解约定、成长记录', TRUE, 7),
(NULL, '语音专属存档', '🎤', '所有语音消息独立归档，甜蜜声音收藏', TRUE, 8);

-- ============================================
-- 4. 消息主表：所有聊天记录核心表（全局时间轴数据源）
-- ============================================
CREATE TABLE messages (
    id BIGSERIAL PRIMARY KEY,
    couple_id BIGINT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- 内容类型
    content_type VARCHAR(20) NOT NULL, -- 'text' / 'image' / 'voice' / 'sticker'
    
    -- 文字内容（语音转写后也存在这里）
    text_content TEXT,
    
    -- AI处理核心字段
    main_category_id BIGINT REFERENCES categories(id), -- 唯一主分类（AI自动识别/可手动修改）
    ai_summary TEXT, -- AI生成的1-2句温柔小结
    ai_processed BOOLEAN NOT NULL DEFAULT FALSE, -- AI是否处理完成
    ai_processed_at TIMESTAMPTZ, -- AI处理时间
    ai_confidence DECIMAL(5,4), -- AI分类置信度
    location VARCHAR(200), -- AI识别的地点（餐厅/景点名等）
    extracted_nicknames JSONB DEFAULT '[]'::JSONB, -- AI提取的专属昵称列表
    
    -- 语音特殊字段（冗余存储方便查询）
    voice_duration INT, -- 语音时长（秒）
    voice_transcribed BOOLEAN NOT NULL DEFAULT FALSE, -- 语音是否已转文字
    
    -- 状态
    is_edited BOOLEAN NOT NULL DEFAULT FALSE, -- 是否编辑过（原始内容不可篡改，仅分类可改）
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE, -- 软删除标记
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 精确发送时间（时间轴排序关键字段）
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 时间轴查询核心索引
CREATE INDEX idx_messages_couple_time ON messages(couple_id, created_at DESC);
-- 分类查询索引
CREATE INDEX idx_messages_category ON messages(couple_id, main_category_id, created_at DESC);
-- AI待处理队列索引
CREATE INDEX idx_messages_ai_pending ON messages(couple_id, ai_processed) WHERE ai_processed = FALSE;

-- ============================================
-- 5. 消息附件表：一条消息可包含多张图片/一个语音
-- ============================================
CREATE TABLE message_attachments (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    file_type VARCHAR(20) NOT NULL, -- 'image' / 'voice' / 'sticker'
    file_url VARCHAR(1000) NOT NULL, -- 文件访问路径
    thumbnail_url VARCHAR(1000), -- 图片缩略图
    file_size BIGINT, -- 文件大小（字节）
    width INT, -- 图片宽度
    height INT, -- 图片高度
    duration INT, -- 语音时长（秒）冗余
    mime_type VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_attachments_message ON message_attachments(message_id);

-- ============================================
-- 6. 消息-子标签关联表：一条消息可多个子标签（多对多）
-- ============================================
CREATE TABLE message_tags (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    category_id BIGINT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    is_ai_tagged BOOLEAN NOT NULL DEFAULT TRUE, -- 是否AI自动打标
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, category_id)
);

CREATE INDEX idx_message_tags_message ON message_tags(message_id);
CREATE INDEX idx_message_tags_category ON message_tags(category_id);

-- ============================================
-- 7. AI处理日志表：记录每次AI处理详情，方便调优
-- ============================================
CREATE TABLE ai_process_logs (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    model_used VARCHAR(100), -- 使用的模型名称
    raw_response JSONB, -- AI原始返回
    processing_time_ms INT, -- 处理耗时
    status VARCHAR(20) NOT NULL DEFAULT 'success', -- 'success' / 'failed' / 'pending'
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 8. 月度/年度AI汇总表：缓存AI生成的总结
-- ============================================
CREATE TABLE memory_summaries (
    id BIGSERIAL PRIMARY KEY,
    couple_id BIGINT NOT NULL REFERENCES couples(id) ON DELETE CASCADE,
    summary_type VARCHAR(20) NOT NULL, -- 'monthly' / 'yearly'
    summary_date DATE NOT NULL, -- 月份/年份的第一天
    content TEXT NOT NULL, -- AI总结内容
    stats JSONB DEFAULT '{}'::JSONB, -- 统计数据：美食次数、约会次数等
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(couple_id, summary_type, summary_date)
);
```

### 表设计关键说明
1. **主分类唯一**：`messages.main_category_id` 直接存储唯一主分类，满足「单条内容匹配唯一主分类」
2. **多子标签支持**：`message_tags` 多对多关联表，支持任意数量子标签
3. **全局时间轴**：`messages.created_at` 带时区精确时间戳，建立联合索引，支持正序/倒序快速拉取全量记录
4. **AI字段完备**：分类置信度、处理状态、提取昵称、语音转写、小结文案全部预留
5. **软删除**：`is_deleted` 标记，原始内容永远保留，支持双方确认后恢复
6. **多情侣扩展**：顶层`couples`表设计，虽然当前仅双人，但架构支持未来多租户（可选）
7. **附件独立存储**：支持多图消息，语音独立存储不污染主表

---

## 三、系统架构与数据流转说明

### 3.1 整体三层架构
```
┌─────────────────────────────────────────────────────────┐
│                前端聊天交互层 (Vue3)                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐   │
│  │ 聊天对话流│  │ 分类相册页│  │   全局时间轴/特色板块 │   │
│  └──────────┘  └──────────┘  └──────────────────────┘   │
│        │            │                  │                │
│        └────────────┴──────────────────┘                │
│                           │                             │
│                    Axios HTTP + WebSocket               │
└───────────────────────────┬─────────────────────────────┘
                            │
┌───────────────────────────┴─────────────────────────────┐
│                后端处理层 (FastAPI)                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐   │
│  │ 消息上传 │  │ 内容存储  │  │  AI处理队列异步消费   │   │
│  │ 接口     │  │ 文件+DB  │  │                      │   │
│  └──────────┘  └──────────┘  └──────────┬───────────┘   │
│        │            │                   │               │
│  ┌──────────┐  ┌──────────┐              │               │
│  │ 查询接口 │  │ 分类调整 │              │               │
│  │ 时间轴   │  │ 手动改类 │              │               │
│  └──────────┘  └──────────┘              │               │
└───────────────────────────┬──────────────┘               │
                            │                              │
                    ┌───────┴───────┐                      │
                    │  AI处理调度器  │                      │
                    └───────┬───────┘                      │
└───────────────────────────┼──────────────────────────────┘
                            │
┌───────────────────────────┴─────────────────────────────┐
│              AI模型分类层（可插拔多模型）                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────────┐   │
│  │ 文字NLP  │  │ 图像识别  │  │   语音转文字ASR      │   │
│  │ 场景分类 │  │ 内容理解  │  │                      │   │
│  └──────────┘  └──────────┘  └──────────┬───────────┘   │
│                                         │               │
│  ┌──────────────────────────────────────┴───────────┐   │
│  │              大模型总结生成                        │   │
│  │  主分类判断 → 子标签生成 → 温柔小结撰写            │   │
│  └──────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

### 3.2 核心数据流转过程（用户发消息 → AI归档完成）

#### 阶段1：用户端发送（同步即时响应）
1. 用户在聊天框输入文字/选择图片/录制语音
2. 前端先做本地预览：消息气泡立即显示在对话流中（乐观UI，无等待感）
3. 前端调用后端`POST /api/messages`接口：
   - 文字消息：直接传text_content
   - 图片/语音：先调用文件上传接口获得file_url，再提交消息
4. 后端立即返回201：消息入库，`ai_processed = FALSE`，原始消息立刻持久化
5. 前端收到响应，替换本地临时消息为正式消息，完成发送流程
6. **用户无感知：发送即完成，不需要等待AI处理**

#### 阶段2：AI异步处理（后台静默执行）
1. 后端消息入库后，推送一条任务到AI处理队列（可使用asyncio.create_task简单实现，后续扩展Celery）
2. AI调度器根据内容类型分派处理：
   - 纯文字：直接调用大模型，输入文字+8大分类描述，返回主分类、子标签、小结
   - 带图片：调用视觉大模型（GPT-4o/Qwen-VL等），传入图片+文字，识别场景分类
   - 带语音：先调用ASR服务转文字，再走文字分类流程，同时语音自动归入「语音专属存档」
3. AI返回标准化结果：
   ```json
   {
     "main_category_id": 1,
     "sub_tag_ids": [12, 15],
     "summary": "今天和宝贝一起打卡了超好吃的重庆火锅，辣得过瘾又开心～",
     "confidence": 0.98,
     "location": "重庆火锅店",
     "extracted_nicknames": ["宝贝"]
   }
   ```
4. 后端更新`messages`表对应字段，批量插入`message_tags`关联子标签，写入`ai_process_logs`
5. 处理完成后，通过WebSocket推送给前端："消息xxx AI归档完成"，前端可轻提示（可选）

#### 阶段3：分类/时间轴查询
1. **全局时间轴查询**：`GET /api/messages?timeline=true` → 按`created_at DESC`拉取所有消息，按日期分组渲染
2. **分类页查询**：`GET /api/messages?category_id=1` → 拉取该主分类下所有消息，按时间瀑布流展示
3. **子标签筛选**：`GET /api/messages?tag_id=12` → 通过`message_tags`关联查询
4. **特色板块**：专属昵称从`messages.extracted_nicknames`聚合，矛盾复盘单独查分类id=7，语音查所有content_type=voice的消息
5. **月度/年度总结**：定时任务每月1号触发，聚合上月数据调用大模型生成总结，存入`memory_summaries`表

### 3.3 手动修正流程
- 若AI分类错误，用户可长按消息→修改分类
- 后端更新`main_category_id`，记录操作日志，不删除原始AI结果用于后续优化
- 所有原始消息内容不可修改、不可永久删除（仅可软删除+双方确认后彻底删除）

---

## 四、第一版开发里程碑预留
1. 项目初始化 → 2. 数据库+基础CRUD → 3. 聊天界面+上传 → 4. AI分类对接 → 5. 分类展示页 → 6. 全局时间轴 → 7. 部署上线
