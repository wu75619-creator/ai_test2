# 情侣智能随手恋爱日记本 💑

> 对话式随手记录 + AI 自动分类归档的双人专属恋爱纪念Web应用

## 技术栈
| 层级 | 技术选型 |
|------|----------|
| 前端 | Vue 3 + Vite + Pinia + Element Plus + Vue Router |
| 后端 | Python 3 + FastAPI + SQLAlchemy 2.0 |
| 数据库 | SQLite（零配置，开箱即用） |
| 文件存储 | 本地文件系统（后续可扩展OSS） |

---

## 项目目录结构
```
.
├── frontend/                 # Vue3 前端项目
│   ├── src/
│   │   ├── components/       # 公共组件
│   │   ├── views/            # 页面（聊天/时间轴/分类）
│   │   ├── router/           # 路由配置
│   │   ├── store/            # Pinia状态管理
│   │   ├── utils/            # 工具函数
│   │   └── assets/           # 静态资源
│   ├── package.json
│   └── vite.config.js
│
├── backend/                  # FastAPI 后端项目
│   ├── app/
│   │   ├── models/           # SQLAlchemy数据模型
│   │   ├── api/              # API路由
│   │   ├── services/         # 业务逻辑（AI处理/文件上传）
│   │   └── core/             # 核心配置（数据库/初始化）
│   ├── uploads/              # 用户上传文件（图片/语音）
│   ├── requirements.txt      # Python依赖
│   ├── schema.sql            # 数据库DDL（SQLite版本）
│   └── main.py               # 后端入口
│
├── ARCHITECTURE.md           # 完整架构设计文档
└── README.md                 # 本文件
```

---

## 核心数据库表结构

共8张表，完整支撑PRD所有功能：

### 1. `couples` 情侣对表（顶层实体）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| couple_name | VARCHAR(100) | 情侣空间名称 |
| together_date | DATE | 在一起纪念日 |
| access_password | VARCHAR(255) | bcrypt加密访问密码 |
| created_at | DATETIME | 创建时间 |
| is_deleted | BOOLEAN | 软删除标记 |

### 2. `users` 用户表（男主/女主）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| couple_id | BIGINT | 关联情侣空间 |
| role | VARCHAR(20) | male/female/other |
| nickname | VARCHAR(50) | 昵称 |
| avatar_url | VARCHAR(500) | 头像地址 |
| theme_color | VARCHAR(20) | 专属气泡配色 |

### 3. `categories` 分类表（8大系统预设+自定义子标签）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| couple_id | BIGINT | NULL=系统全局分类 |
| parent_id | BIGINT | NULL=主分类，NOT NULL=子标签 |
| name | VARCHAR(50) | 分类名称 |
| icon | VARCHAR(100) | 图标emoji |
| is_system | BOOLEAN | 是否系统预设 |
| sort_order | INT | 排序权重 |

**预置8大主分类：**
🍜 美食探店存档 / ✈️ 旅行外出约会存档 / 📸 情侣合照存档 / 😂 趣味日常存档 / 💌 专属昵称存档 / 💬 深度谈心存档 / 🤝 矛盾复盘存档 / 🎤 语音专属存档

### 4. `messages` 消息主表（全局时间轴核心）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| couple_id | BIGINT | 关联情侣空间 |
| sender_id | BIGINT | 发送人 |
| content_type | VARCHAR(20) | text/image/voice/sticker |
| text_content | TEXT | 文字内容/语音转写结果 |
| **main_category_id** | BIGINT | **唯一主分类（AI识别）** |
| ai_summary | TEXT | AI生成1-2句温柔小结 |
| ai_processed | BOOLEAN | AI是否处理完成 |
| ai_confidence | FLOAT | AI分类置信度 |
| location | VARCHAR(200) | AI识别地点 |
| extracted_nicknames | JSON | AI提取的专属昵称列表 |
| voice_duration | INT | 语音时长（秒） |
| is_deleted | BOOLEAN | 软删除 |
| **created_at** | DATETIME | **精确发送时间，时间轴排序核心字段** |

### 5. `message_attachments` 消息附件表（多图/语音）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| message_id | BIGINT | 关联消息 |
| file_type | VARCHAR(20) | image/voice/sticker |
| file_url | VARCHAR(1000) | 文件访问路径 |
| thumbnail_url | VARCHAR(1000) | 图片缩略图 |
| duration | INT | 语音时长 |

### 6. `message_tags` 消息子标签关联表（多对多）
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| message_id | BIGINT | 关联消息 |
| category_id | BIGINT | 关联子标签分类 |
| is_ai_tagged | BOOLEAN | 是否AI自动打标 |

> ✅ 支撑设计：`messages.main_category_id` = 唯一主分类；`message_tags` = 多个子标签

### 7. `ai_process_logs` AI处理日志表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| message_id | BIGINT | 关联消息 |
| model_used | VARCHAR(100) | 使用模型 |
| raw_response | JSON | AI原始返回 |
| processing_time_ms | INT | 处理耗时 |
| status | VARCHAR(20) | success/failed |

### 8. `memory_summaries` 月度/年度汇总表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT | 主键 |
| couple_id | BIGINT | 关联情侣空间 |
| summary_type | VARCHAR(20) | monthly/yearly |
| summary_date | DATE | 月份/年份 |
| content | TEXT | AI总结内容 |
| stats | JSON | 统计数据（约会次数/美食数等） |

---

## 核心索引
| 索引名 | 字段 | 用途 |
|--------|------|------|
| idx_messages_couple_time | couple_id, created_at DESC | 全局时间轴查询 |
| idx_messages_category | couple_id, main_category_id, created_at DESC | 分类页瀑布流查询 |
| idx_messages_ai_pending | couple_id, ai_processed | AI待处理任务队列 |

---

## 快速启动命令

### 1. 启动后端服务
```bash
cd backend

# 创建虚拟环境（可选）
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt

# 启动服务（自动创建SQLite数据库和表，自动初始化8大系统分类）
python main.py
# 或 uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
- 后端服务地址：**http://localhost:8000**
- 📄 **Swagger 接口文档地址：http://localhost:8000/docs** （启动后直接在浏览器打开即可在线调试所有API）
- ReDoc 文档：http://localhost:8000/redoc
- SQLite数据库文件：`backend/love_diary.db`（启动时自动生成）
- 默认情侣空间已内置：男主昵称「男主」(蓝色气泡)、女主昵称「女主」(粉色气泡)，访问密码 `123456`

### 已实现核心API
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查（显示当前AI模式） |
| POST | `/api/messages` | 发送消息，后台异步调用AI分类打标+生成小结 |
| GET | `/api/messages` | 获取历史消息，支持正/倒序，作为时间轴数据源 |
| GET | `/api/categories` | 获取所有8大分类列表+每个分类消息数量 |
| GET | `/api/categories/{name}` | 按分类名称拉取归档消息，支持按年/月时间筛选 |
| GET | `/api/categories/stats/overview` | 分类统计概览 |

### AI智能分类说明
#### 模式切换
- **默认Mock模式（开箱即用）**：无需配置任何API Key即可运行，基于关键词自动匹配8大分类，随机生成温柔小结，完全可本地测试
- **真实大模型模式**：
  1. 复制 `backend/.env.example` 为 `backend/.env`
  2. 设置 `AI_ENABLED=true`
  3. 配置你的OpenAI兼容API参数：
     ```env
     AI_ENABLED=true
     OPENAI_API_KEY=你的API Key
     OPENAI_BASE_URL=https://api.openai.com/v1  # 可替换为任意兼容接口（通义千问/豆包/DeepSeek/Ollama等）
     OPENAI_MODEL=gpt-4o-mini  # 推荐支持视觉的模型，可识别图片内容
     ```
  4. 重启后端服务即可使用真实AI图文识别分类

#### 自动/手动双模式
- 默认开启「AI自动分类」，发送文字/图片后后台自动识别场景打标签+生成小结
- 关闭AI开关后，必须手动选择分类，消息直接归档到所选分类，不调用AI
- 手动分类的消息会显示「手动」标签，和AI自动分类区分开

### 多媒体支持
- 支持多图上传，单张最大10MB
- 支持语音文件上传，自动归入语音专属存档
- 图片可点击放大预览，语音支持浏览器原生播放控件
- 所有文件保存在 `backend/uploads/` 目录，通过 `/uploads/xxx` URL直接访问

### 前端页面说明
前端共4个页面，通过底部导航栏无缝切换：
1. **聊天记录页（首页 `/`）**：双人对话流，发送消息入口
2. **分类相册列表页（`/categories`）**：8大分类卡片展示，显示每个分类记录数
3. **分类详情页（`/category/:name`）**：瀑布流卡片展示该分类所有消息，带时间筛选器，每卡片显示AI标签+AI小结
4. **恋爱时间轴（`/timeline`）**：使用el-timeline组件按日期分组串联所有历史记录，顶部统计卡片展示总记录数/分类数/陪伴天数

### 2. 启动前端服务
```bash
cd frontend

# 安装依赖（首次启动需要）
npm install

# 启动开发服务器
npm run dev
```
- 前端访问地址：**http://localhost:5173**（默认首页就是聊天界面）
- 已配置Vite代理：前端发出的 `/api` 和 `/uploads` 请求会自动转发到后端 `http://127.0.0.1:8000`，无需手动处理跨域
- 聊天界面支持：男主/女主身份切换发送、左右气泡不同颜色区分、历史消息自动加载、发送后自动滚动到底部
- 已实现温柔治愈粉色主题，覆盖Element Plus默认蓝色，符合少女感恋爱产品调性

### ❌ 跨域报错常见排查方式
如果遇到跨域/CORS错误，请按以下顺序排查：

1. **确认后端服务已启动**：后端必须先启动在8000端口，访问 http://localhost:8000/api/health 能正常返回json
2. **使用代理地址不要写IP**：前端代码中API请求不要写 `http://127.0.0.1:8000/api/xxx`，直接写 `/api/xxx`，走Vite代理
3. **确认后端CORS配置正常**：后端main.py中已配置`allow_origins=["*"]`允许所有源，无需额外配置
4. **端口冲突检查**：确保5173（前端）和8000（后端）端口没有被其他程序占用
5. **重启服务**：修改vite.config.js后需要重启前端npm run dev才会生效
6. **浏览器缓存**：清空浏览器缓存或使用无痕模式访问，避免旧缓存影响

### 🧪 如何测试新增页面
1. **先启动后端**：`cd backend && python main.py`，访问 http://localhost:8000/api/health 确认服务正常（显示ai_mode为Mock模式）
2. **启动前端**：`cd frontend && npm install && npm run dev`，访问 http://localhost:5173
3. **测试聊天功能**：在首页聊天框发送几条测试消息，可以尝试发包含关键词的内容：
   - 发「今天火锅好好吃」→ 会自动归入🍜美食探店存档
   - 发「宝宝我爱你」→ 会自动归入💬深度谈心/💌专属昵称
   - 发「对不起我错了」→ 会自动归入🤝矛盾复盘存档
   - 发送后等待1-2秒AI处理完成，刷新即可看到分类标签和温柔小结
4. **测试分类相册**：点击底部中间「分类相册」按钮，可看到8个分类卡片，每个卡片显示记录数量；点击任意分类进入详情页，可以看到卡片式消息列表，每张卡片都展示AI标签和AI小结；顶部支持「全部/按年/按月」时间筛选
5. **测试AI自动模式（默认）**：
   - 直接输入文字或选择图片/语音发送，消息旁边会显示「AI归档中...」
   - 1-2秒后自动刷新，显示匹配的分类标签和AI温柔小结
   - 尝试发送带关键词的内容：「今天火锅好好吃」→🍜美食分类、「宝宝我爱你」→💬深度谈心、「对不起我错了」→🤝矛盾复盘
6. **测试手动分类模式**：
   - 关闭输入框上方的「AI自动分类」开关
   - 此时会显示分类下拉选择框，必须选择一个分类才能发送
   - 不选分类直接点击发送会被拦截并提示
   - 发送成功后消息显示分类标签和「手动」标识，不会调用AI生成小结
7. **测试多媒体消息**：
   - 点击输入框左侧的「图片」按钮，选择一张或多张图片发送，图片会显示在气泡中，点击可放大预览
   - 点击「麦克风」按钮选择语音文件发送，会显示原生音频播放器
   - 注意：图片和语音不能同时发送，会自动互斥
8. **测试分类相册和时间轴**：
   - 分类相册页会显示每个分类的消息数量，点进去能看到包含图片的完整卡片
   - 恋爱时间轴按日期串联所有记录，支持图片和语音展示

---

## 开发进度
- [x] 架构设计（ARCHITECTURE.md）
- [x] 目录结构创建
- [x] 数据库模型设计 + DDL
- [x] 后端基础框架
- [x] 前端基础框架
- [ ] 用户登录/鉴权
- [ ] 聊天消息发送API
- [ ] 图片/语音上传
- [ ] AI分类对接
- [ ] 聊天界面开发
- [ ] 分类归档页开发
- [ ] 全局时间轴开发
