import enum
from datetime import datetime
from sqlalchemy import (
    Column,
    Integer,
    BigInteger,
    String,
    Text,
    DateTime,
    Boolean,
    Float,
    ForeignKey,
    Date,
    Enum,
)
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.sqlite import JSON

from app.core.database import Base


class ContentType(str, enum.Enum):
    """消息内容类型枚举"""
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    STICKER = "sticker"


class UserRole(str, enum.Enum):
    """用户角色枚举"""
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class SummaryType(str, enum.Enum):
    """总结类型枚举"""
    MONTHLY = "monthly"
    YEARLY = "yearly"


class Couple(Base):
    """情侣对表 - 顶层空间实体"""
    __tablename__ = "couples"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    couple_name = Column(String(100), nullable=False, default="我们的小窝")
    together_date = Column(Date, nullable=True)  # 在一起纪念日
    access_password = Column(String(255), nullable=False)  # bcrypt加密访问密码
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    is_deleted = Column(Boolean, default=False, nullable=False)

    # 关系
    users = relationship("User", back_populates="couple", cascade="all, delete-orphan")
    messages = relationship("Message", back_populates="couple", cascade="all, delete-orphan")
    categories = relationship("Category", back_populates="couple", cascade="all, delete-orphan")
    summaries = relationship("MemorySummary", back_populates="couple", cascade="all, delete-orphan")


class User(Base):
    """用户表 - 男主/女主"""
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    couple_id = Column(BigInteger, ForeignKey("couples.id", ondelete="CASCADE"), nullable=False)
    role = Column(String(20), nullable=False)  # male / female / other
    nickname = Column(String(50), nullable=False)
    avatar_url = Column(String(500), nullable=True)
    theme_color = Column(String(20), default="#ff6b9d", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # 关系
    couple = relationship("Couple", back_populates="users")
    messages = relationship("Message", back_populates="sender")

    __table_args__ = (
        {"sqlite_autoincrement": True},
    )


class Category(Base):
    """分类表 - 8大系统分类 + 子标签"""
    __tablename__ = "categories"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    couple_id = Column(BigInteger, ForeignKey("couples.id", ondelete="CASCADE"), nullable=True)  # NULL=系统全局预设
    parent_id = Column(BigInteger, ForeignKey("categories.id", ondelete="CASCADE"), nullable=True)  # NULL=主分类
    name = Column(String(50), nullable=False)
    icon = Column(String(100), nullable=True)
    description = Column(String(200), nullable=True)
    sort_order = Column(Integer, default=0, nullable=False)
    is_system = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # 关系
    couple = relationship("Couple", back_populates="categories")
    parent = relationship("Category", remote_side=[id], backref="children")
    messages_as_main = relationship("Message", foreign_keys="Message.main_category_id", back_populates="main_category")
    message_tags = relationship("MessageTag", back_populates="category", cascade="all, delete-orphan")


class Message(Base):
    """消息主表 - 全局时间轴核心"""
    __tablename__ = "messages"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    couple_id = Column(BigInteger, ForeignKey("couples.id", ondelete="CASCADE"), nullable=False)
    sender_id = Column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # 内容类型
    content_type = Column(Enum(ContentType), nullable=False)
    text_content = Column(Text, nullable=True)

    # AI处理核心字段
    main_category_id = Column(BigInteger, ForeignKey("categories.id"), nullable=True)
    ai_summary = Column(Text, nullable=True)
    ai_processed = Column(Boolean, default=False, nullable=False)
    ai_processed_at = Column(DateTime, nullable=True)
    ai_confidence = Column(Float, nullable=True)
    location = Column(String(200), nullable=True)
    extracted_nicknames = Column(JSON, default=list, nullable=False)

    # 语音特殊字段
    voice_duration = Column(Integer, nullable=True)  # 语音时长（秒）
    voice_transcribed = Column(Boolean, default=False, nullable=False)

    # 状态
    is_edited = Column(Boolean, default=False, nullable=False)
    is_deleted = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # 关系
    couple = relationship("Couple", back_populates="messages")
    sender = relationship("User", back_populates="messages")
    main_category = relationship("Category", foreign_keys=[main_category_id], back_populates="messages_as_main")
    attachments = relationship("MessageAttachment", back_populates="message", cascade="all, delete-orphan")
    tags = relationship("MessageTag", back_populates="message", cascade="all, delete-orphan")
    ai_logs = relationship("AIProcessLog", back_populates="message", cascade="all, delete-orphan")


class MessageAttachment(Base):
    """消息附件表 - 图片/语音多文件支持"""
    __tablename__ = "message_attachments"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    message_id = Column(BigInteger, ForeignKey("messages.id", ondelete="CASCADE"), nullable=False)
    file_type = Column(String(20), nullable=False)  # image / voice / sticker
    file_url = Column(String(1000), nullable=False)
    thumbnail_url = Column(String(1000), nullable=True)
    file_size = Column(BigInteger, nullable=True)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    duration = Column(Integer, nullable=True)
    mime_type = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # 关系
    message = relationship("Message", back_populates="attachments")


class MessageTag(Base):
    """消息-子标签关联表 - 多对多"""
    __tablename__ = "message_tags"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    message_id = Column(BigInteger, ForeignKey("messages.id", ondelete="CASCADE"), nullable=False)
    category_id = Column(BigInteger, ForeignKey("categories.id", ondelete="CASCADE"), nullable=False)
    is_ai_tagged = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # 关系
    message = relationship("Message", back_populates="tags")
    category = relationship("Category", back_populates="message_tags")

    __table_args__ = (
        {"sqlite_autoincrement": True},
    )


class AIProcessLog(Base):
    """AI处理日志表"""
    __tablename__ = "ai_process_logs"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    message_id = Column(BigInteger, ForeignKey("messages.id", ondelete="CASCADE"), nullable=False)
    model_used = Column(String(100), nullable=True)
    raw_response = Column(JSON, nullable=True)
    processing_time_ms = Column(Integer, nullable=True)
    status = Column(String(20), default="success", nullable=False)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # 关系
    message = relationship("Message", back_populates="ai_logs")


class MemorySummary(Base):
    """月度/年度AI汇总表"""
    __tablename__ = "memory_summaries"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    couple_id = Column(BigInteger, ForeignKey("couples.id", ondelete="CASCADE"), nullable=False)
    summary_type = Column(Enum(SummaryType), nullable=False)
    summary_date = Column(Date, nullable=False)
    content = Column(Text, nullable=False)
    stats = Column(JSON, default=dict, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # 关系
    couple = relationship("Couple", back_populates="summaries")
