"""
AI分类处理服务
支持两种模式：
1. Mock模式（AI_ENABLED=false）：基于关键词匹配，无需API Key，本地测试用
2. 真实大模型模式（AI_ENABLED=true）：调用OpenAI兼容接口，支持图文多模态识别
"""
import os
import random
import base64
import json
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 8大核心分类定义
CATEGORIES = [
    {"id": 1, "name": "美食探店存档", "icon": "🍜", "description": "美食、奶茶、火锅、餐厅、探店、餐饮相关", "keywords": ["吃", "饭", "奶茶", "火锅", "好吃", "餐厅", "探店", "美味", "咖啡", "蛋糕", "烧烤", "零食", "好喝", "干饭"]},
    {"id": 2, "name": "旅行外出约会存档", "icon": "✈️", "description": "旅行、逛街、看电影、约会、出门游玩、景点相关", "keywords": ["出门", "约会", "逛街", "旅行", "出去玩", "看电影", "公园", "景点", "散步", "地铁", "打车", "出行", "游玩", "风景"]},
    {"id": 3, "name": "情侣合照存档", "icon": "📸", "description": "双人自拍、情侣合照、同框合影、拍照片相关", "keywords": ["拍照", "合照", "自拍", "照片", "拍", "合影", "好看", "相机", "合影", "同框"]},
    {"id": 4, "name": "趣味日常存档", "icon": "😂", "description": "搞笑对话、互怼、段子、可爱瞬间、表情包、趣味日常", "keywords": ["哈哈", "搞笑", "傻", "可爱", "笑死", "梗", "逗", "有趣", "表情包", "笑", "沙雕"]},
    {"id": 5, "name": "专属昵称存档", "icon": "💌", "description": "专属称呼、私密代号、情侣昵称、只有两个人懂的梗", "keywords": ["宝宝", "宝贝", "亲爱的", "老公", "老婆", "憨憨", "小猪", "乖乖", "笨蛋", "猪猪"]},
    {"id": 6, "name": "深度谈心存档", "icon": "💬", "description": "走心对话、爱意表达、未来规划、情绪倾诉、三观交流", "keywords": ["爱你", "喜欢", "想你", "未来", "心事", "开心", "难过", "心情", "感受", "希望", "永远", "爱", "心意"]},
    {"id": 7, "name": "矛盾复盘存档", "icon": "🤝", "description": "吵架、矛盾、道歉、反思、和解、问题复盘、感情成长", "keywords": ["生气", "吵架", "对不起", "错了", "原谅", "不开心", "矛盾", "道歉", "和好", "反思", "抱歉", "委屈"]},
    {"id": 8, "name": "语音专属存档", "icon": "🎤", "description": "语音消息单独归档，所有语音自动关联该分类", "keywords": []}
]

# 温柔小结模板
SUMMARY_TEMPLATES = {
    1: [
        "今天和宝贝一起吃到了超好吃的美食，又是被投喂幸福的一天～",
        "干饭人干饭魂，两个人一起吃的饭总是格外香呀😋",
        "打卡了心心念念的美食，和你在一起吃什么都美味",
        "甜甜的奶茶配甜甜的你，今天也是糖分超标的一天"
    ],
    2: [
        "和宝贝一起出门约会的日子，连风都是甜的✨",
        "手牵手一起走过大街小巷，这就是最简单的幸福吧",
        "今天的出行记录下了我们又一个美好回忆",
        "和你在一起的每一次出行都值得被好好珍藏"
    ],
    3: [
        "咔嚓～用照片定格下我们此刻的甜蜜瞬间📸",
        "这张合照里的两个人都笑得好开心呀",
        "影像为证，我们又多了一张值得珍藏的合影",
        "看着合照里的彼此，就觉得好幸福呀"
    ],
    4: [
        "今日份快乐源泉已送达，和你在一起总是笑个不停😂",
        "可可爱爱的日常碎片，是专属于我们的小趣味",
        "两个有趣的灵魂碰撞，每天都有新笑点",
        "这些傻乎乎的快乐瞬间，想起来都会笑出声"
    ],
    5: [
        "又解锁了新的专属昵称，是只属于我们两个人的小秘密💌",
        "甜甜的称呼里藏着满满的爱意呀",
        "这些专属代号，是我们恋爱的独家密码",
        "被你叫昵称的时候，心都要化了"
    ],
    6: [
        "掏心窝子的聊天时刻，两颗心靠得更近了💗",
        "认真交流彼此的想法，我们的感情又升温啦",
        "谢谢你愿意和我分享内心的感受，我都认真听着呢",
        "深度谈心让我们更懂彼此，未来也要一直这样坦诚呀"
    ],
    7: [
        "小小的摩擦也是感情的催化剂，说开了我们就更相爱了🤝",
        "吵架没关系，重要的是我们愿意一起面对和改进",
        "每一次和好都让我们更珍惜彼此",
        "矛盾过后的反思，会让我们走得更远"
    ],
    8: [
        "你的声音真好听，想反复听好多好多遍🎤",
        "语音里的语气都带着爱意，要永久收藏呀",
        "隔着屏幕都能感受到你的情绪，这就是声音的魔力",
        "把你的声音存起来，想你的时候就听听"
    ]
}

GENERIC_SUMMARIES = [
    "又是和你在一起的美好一天，点滴都值得珍藏💕",
    "平凡的日常因为有你而变得闪闪发光",
    "随手记录下此刻的心情，未来回看都是甜蜜",
    "简单的一句话，因为是你说的就格外有意义"
]


class AIService:
    def __init__(self):
        self.ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
        self.client = None
        self.model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        
        if self.ai_enabled:
            api_key = os.getenv("OPENAI_API_KEY")
            base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
            if not api_key:
                print("⚠️ AI_ENABLED=true 但未配置OPENAI_API_KEY，降级为Mock模式")
                self.ai_enabled = False
            else:
                self.client = OpenAI(api_key=api_key, base_url=base_url)
                print(f"🤖 AI服务初始化完成，使用模型: {self.model}")
        else:
            print("🤖 AI服务运行在Mock模式（关键词匹配）")

    def _keyword_match(self, text: str, content_type: str = "text") -> int:
        """基于关键词简单匹配分类"""
        if content_type == "voice":
            return 8
        text = text.lower()
        scores = {}
        for cat in CATEGORIES:
            score = sum(1 for kw in cat["keywords"] if kw in text)
            if score > 0:
                scores[cat["id"]] = score
        
        if scores:
            return max(scores.keys(), key=lambda k: scores[k])
        return random.choice(CATEGORIES)["id"]

    def _generate_mock_result(self, text_content: str, content_type: str = "text") -> Dict[str, Any]:
        """生成Mock AI处理结果"""
        if content_type == "voice":
            category_id = 8
        else:
            category_id = self._keyword_match(text_content, content_type)
        
        templates = SUMMARY_TEMPLATES.get(category_id, GENERIC_SUMMARIES)
        summary = random.choice(templates)

        nicknames = []
        nickname_words = ["宝宝", "宝贝", "亲爱的", "老公", "老婆", "憨憨", "小猪", "乖乖", "笨蛋", "猪猪"]
        for word in nickname_words:
            if word in text_content:
                nicknames.append(word)

        import time
        time.sleep(0.05)

        return {
            "main_category_id": category_id,
            "ai_summary": summary,
            "ai_confidence": round(random.uniform(0.75, 0.98), 2),
            "extracted_nicknames": nicknames,
            "location": None,
            "tag_ids": []
        }

    def _encode_image(self, image_path: str) -> str:
        """将本地图片编码为base64"""
        try:
            from PIL import Image
            import io
            img = Image.open(image_path)
            max_size = 1024
            if max(img.size) > max_size:
                ratio = max_size / max(img.size)
                img = img.resize((int(img.size[0]*ratio), int(img.size[1]*ratio)))
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=85)
            return base64.b64encode(buf.getvalue()).decode('utf-8')
        except Exception as e:
            print(f"图片编码失败: {e}")
            return None

    async def _call_real_llm(self, text_content: str, content_type: str = "text", image_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """调用真实OpenAI兼容大模型，支持图文多模态"""
        category_list = "\n".join([f"{cat['id']}. {cat['name']}：{cat['description']}" for cat in CATEGORIES if cat['id'] != 8])
        
        system_prompt = f"""
        你是一个情侣恋爱日记的AI分类助手。用户会发送文字或图片记录恋爱日常，请你完成以下任务：
        1. 从以下7个主分类中选择最匹配的一个（只返回数字ID）：
        {category_list}
        2. 如果是语音消息，分类ID为8
        3. 生成1句温柔简短的中文小结，语气甜蜜治愈，不超过30字
        4. 提取文本中出现的情侣专属昵称（如宝宝、老公等）

        请严格以JSON格式返回，不要包含其他文字，格式如下：
        {{
            "category_id": 分类ID数字,
            "summary": "温柔小结文案",
            "confidence": 置信度0-1之间的小数,
            "nicknames": ["昵称1", "昵称2"]
        }}
        """

        messages = [{"role": "system", "content": system_prompt}]
        user_content = []

        if text_content:
            user_content.append({"type": "text", "text": f"文字内容：{text_content}"})
        
        if content_type == "image" and image_paths:
            for img_path in image_paths:
                b64_img = self._encode_image(img_path)
                if b64_img:
                    user_content.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64_img}"}
                    })
            if not text_content:
                user_content.append({"type": "text", "text": "这是一张图片，请识别内容分类"})

        messages.append({"role": "user", "content": user_content})

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                response_format={"type": "json_object"},
                temperature=0.3,
                max_tokens=200
            )
            result = json.loads(response.choices[0].message.content.strip())
            
            category_id = int(result.get("category_id", 4))
            if category_id < 1 or category_id > 8:
                category_id = 4
                
            return {
                "main_category_id": category_id,
                "ai_summary": result.get("summary", random.choice(GENERIC_SUMMARIES)),
                "ai_confidence": float(result.get("confidence", 0.9)),
                "extracted_nicknames": result.get("nicknames", []),
                "location": None,
                "tag_ids": []
            }
        except Exception as e:
            print(f"大模型调用失败，降级到Mock: {e}")
            return self._generate_mock_result(text_content, content_type)

    async def process_message(
        self, 
        text_content: str, 
        content_type: str = "text", 
        image_paths: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        处理消息，返回AI分类结果
        :param text_content: 文本内容
        :param content_type: text/image/voice
        :param image_paths: 本地图片路径列表
        """
        if self.ai_enabled:
            return await self._call_real_llm(text_content, content_type, image_paths)
        else:
            return self._generate_mock_result(text_content, content_type)

    def get_category_by_id(self, category_id: int) -> Optional[Dict[str, Any]]:
        for cat in CATEGORIES:
            if cat["id"] == category_id:
                return cat
        return None

    def get_category_by_name(self, category_name: str) -> Optional[Dict[str, Any]]:
        for cat in CATEGORIES:
            if cat["name"] == category_name:
                return cat
        return None

    def get_all_categories(self) -> List[Dict[str, Any]]:
        return CATEGORIES
    
    def get_category_id_by_name(self, category_name: str) -> Optional[int]:
        cat = self.get_category_by_name(category_name)
        return cat["id"] if cat else None


ai_service = AIService()
