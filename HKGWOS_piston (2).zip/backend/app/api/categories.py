from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from app.core.database import get_db
from app.models import Message, User, Couple, Category, MessageAttachment
from app.schemas.message import MessageResponse, AttachmentInfo
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/categories", tags=["分类归档接口"])


def get_default_couple(db: Session) -> Couple:
    couple = db.query(Couple).first()
    if not couple:
        raise HTTPException(status_code=400, detail="请先初始化情侣空间，发送第一条消息")
    return couple


def build_message_response(db: Session, msg: Message) -> MessageResponse:
    sender = db.query(User).get(msg.sender_id)
    category_name = None
    category_icon = None
    if msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id)
        if cat:
            category_name = cat["name"]
            category_icon = cat["icon"]
        else:
            db_cat = db.query(Category).get(msg.main_category_id)
            if db_cat:
                category_name = db_cat.name
                category_icon = db_cat.icon
    
    atts = db.query(MessageAttachment).filter(MessageAttachment.message_id == msg.id).all()
    attachments = []
    for att in atts:
        attachments.append(AttachmentInfo(
            file_type=att.file_type,
            file_url=att.file_url,
            thumbnail_url=att.thumbnail_url,
            duration=att.duration,
            width=att.width,
            height=att.height
        ))
    
    return MessageResponse(
        id=msg.id,
        sender_role="男主" if sender.role == "male" else "女主" if sender.role == "female" else "其他",
        sender_nickname=sender.nickname,
        content_type=msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        text_content=msg.text_content,
        ai_summary=msg.ai_summary,
        main_category_id=msg.main_category_id,
        main_category_name=category_name,
        main_category_icon=category_icon,
        ai_processed=msg.ai_processed,
        is_manual_category=msg.is_manual_category,
        attachments=attachments,
        voice_duration=msg.voice_duration,
        created_at=msg.created_at
    )


@router.get("", summary="获取所有分类列表")
async def list_categories(db: Session = Depends(get_db)):
    system_cats = ai_service.get_all_categories()
    couple = get_default_couple(db)
    
    result = []
    for cat in system_cats:
        count = db.query(Message).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat["id"],
            Message.is_deleted == False
        ).count()
        result.append({
            "id": cat["id"],
            "name": cat["name"],
            "icon": cat["icon"],
            "description": cat.get("description", ""),
            "message_count": count
        })
    
    return result


@router.get("/{category_name}", response_model=List[MessageResponse], summary="按分类名称获取归档消息")
async def get_category_messages(
    category_name: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    cat_info = ai_service.get_category_by_name(category_name)
    if not cat_info:
        db_cat = db.query(Category).filter(Category.name == category_name).first()
        if not db_cat:
            raise HTTPException(status_code=404, detail=f"分类 {category_name} 不存在")
        category_id = db_cat.id
    else:
        category_id = cat_info["id"]

    couple = get_default_couple(db)
    query = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.main_category_id == category_id,
        Message.is_deleted == False
    )

    if year:
        if month:
            start = datetime(year, month, 1)
            end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
            query = query.filter(Message.created_at >= start, Message.created_at < end)
        else:
            start = datetime(year, 1, 1)
            end = datetime(year + 1, 1, 1)
            query = query.filter(Message.created_at >= start, Message.created_at < end)

    messages = query.order_by(Message.created_at.desc()).all()
    return [build_message_response(db, msg) for msg in messages]


@router.get("/stats/overview", summary="获取分类统计概览")
async def get_category_stats(db: Session = Depends(get_db)):
    couple = get_default_couple(db)
    cats = ai_service.get_all_categories()
    
    stats = []
    total = 0
    for cat in cats:
        count = db.query(Message).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat["id"],
            Message.is_deleted == False
        ).count()
        total += count
        stats.append({**cat, "count": count})
    
    return {"total_messages": total, "categories": stats}
