from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.models import Message, User, Couple, Category
from app.schemas.message import MessageCreate, MessageResponse

router = APIRouter(prefix="/api/messages", tags=["消息接口"])


def get_or_create_default_couple(db: Session) -> Couple:
    """获取或创建默认情侣空间（第一版简化，单情侣模式）"""
    couple = db.query(Couple).first()
    if not couple:
        # 创建默认情侣空间，密码: 123456
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        couple = Couple(
            couple_name="我们的小窝",
            access_password=pwd_context.hash("123456")
        )
        db.add(couple)
        db.flush()

        # 创建默认男主和女主
        male = User(
            couple_id=couple.id,
            role="male",
            nickname="男主",
            theme_color="#4a90e2"
        )
        female = User(
            couple_id=couple.id,
            role="female",
            nickname="女主",
            theme_color="#ff6b9d"
        )
        db.add_all([male, female])
        db.commit()
        db.refresh(couple)
    return couple


@router.post("", response_model=MessageResponse, summary="发送新消息")
async def create_message(
    message_in: MessageCreate,
    db: Session = Depends(get_db)
):
    """
    发送聊天消息
    - sender_role: 发送人角色，男主/女主
    - text_content: 消息文本内容
    """
    # 获取默认情侣空间
    couple = get_or_create_default_couple(db)

    # 根据角色查找发送用户
    role_map = {
        "男主": "male",
        "女主": "female",
        "其他": "other"
    }
    sender = db.query(User).filter(
        User.couple_id == couple.id,
        User.role == role_map[message_in.sender_role.value]
    ).first()

    if not sender:
        raise HTTPException(status_code=400, detail="发送用户不存在")

    # 创建消息
    db_message = Message(
        couple_id=couple.id,
        sender_id=sender.id,
        content_type=message_in.content_type.value,
        text_content=message_in.text_content,
        ai_processed=False,
        voice_transcribed=False
    )
    db.add(db_message)
    db.commit()
    db.refresh(db_message)

    # TODO: 接入AI分类打标逻辑
    # 1. 异步调用AI模型识别文本/图片内容
    # 2. 匹配8大主分类（main_category_id）
    # 3. 生成子标签
    # 4. 生成1-2句温柔小结写入ai_summary
    # 5. 提取专属昵称写入extracted_nicknames
    # 6. 更新ai_processed = True

    # 构建响应
    response = MessageResponse(
        id=db_message.id,
        sender_role=message_in.sender_role.value,
        sender_nickname=sender.nickname,
        content_type=db_message.content_type.value,
        text_content=db_message.text_content,
        ai_summary=db_message.ai_summary,
        main_category_name=None,
        main_category_icon=None,
        ai_processed=db_message.ai_processed,
        created_at=db_message.created_at
    )
    return response


@router.get("", response_model=List[MessageResponse], summary="获取历史消息")
async def list_messages(
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """
    按时间正序返回所有历史消息（全局时间轴）
    - limit: 返回条数，默认100
    - offset: 分页偏移
    """
    couple = get_or_create_default_couple(db)

    messages = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    ).order_by(Message.created_at.asc()).offset(offset).limit(limit).all()

    result = []
    for msg in messages:
        sender = db.query(User).get(msg.sender_id)
        category_name = None
        category_icon = None
        if msg.main_category_id:
            cat = db.query(Category).get(msg.main_category_id)
            if cat:
                category_name = cat.name
                category_icon = cat.icon

        result.append(MessageResponse(
            id=msg.id,
            sender_role="男主" if sender.role == "male" else "女主" if sender.role == "female" else "其他",
            sender_nickname=sender.nickname,
            content_type=msg.content_type.value,
            text_content=msg.text_content,
            ai_summary=msg.ai_summary,
            main_category_name=category_name,
            main_category_icon=category_icon,
            ai_processed=msg.ai_processed,
            created_at=msg.created_at
        ))

    return result
