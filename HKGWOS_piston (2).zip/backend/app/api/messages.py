import os
import uuid
import aiofiles
from pathlib import Path
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db, SessionLocal
from app.models import Message, User, Couple, Category, MessageAttachment, AIProcessLog
from app.schemas.message import MessageResponse, AttachmentInfo
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/messages", tags=["消息接口"])

# 上传目录配置
UPLOAD_DIR = Path("uploads")
IMAGE_DIR = UPLOAD_DIR / "images"
VOICE_DIR = UPLOAD_DIR / "voices"
IMAGE_DIR.mkdir(parents=True, exist_ok=True)
VOICE_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", 10)) * 1024 * 1024  # 默认10MB


def get_or_create_default_couple(db: Session) -> Couple:
    """获取或创建默认情侣空间"""
    couple = db.query(Couple).first()
    if not couple:
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        couple = Couple(
            couple_name="我们的小窝",
            access_password=pwd_context.hash("123456")
        )
        db.add(couple)
        db.flush()

        male = User(couple_id=couple.id, role="male", nickname="男主", theme_color="#4a90e2")
        female = User(couple_id=couple.id, role="female", nickname="女主", theme_color="#ff6b9d")
        db.add_all([male, female])
        db.commit()
        db.refresh(couple)
    return couple


async def save_upload_file(upload_file: UploadFile, save_dir: Path) -> tuple[str, int]:
    """保存上传文件，返回(访问URL, 文件大小)"""
    file_ext = os.path.splitext(upload_file.filename)[1].lower()
    file_name = f"{uuid.uuid4().hex}{file_ext}"
    file_path = save_dir / file_name
    
    file_size = 0
    async with aiofiles.open(file_path, 'wb') as f:
        while chunk := await upload_file.read(1024 * 1024):  # 1MB chunk
            file_size += len(chunk)
            if file_size > MAX_FILE_SIZE:
                await f.close()
                os.remove(file_path)
                raise HTTPException(status_code=400, detail=f"文件大小超过限制{MAX_FILE_SIZE//1024//1024}MB")
            await f.write(chunk)
    
    # 返回可访问的URL路径
    url_path = f"/uploads/{save_dir.name}/{file_name}"
    return url_path, file_size


async def _process_ai_classification(
    message_id: int, 
    text_content: str, 
    content_type: str, 
    image_paths: List[str],
    db_session_factory
):
    """后台异步处理AI分类"""
    db = db_session_factory()
    try:
        start_time = datetime.utcnow()
        ai_result = await ai_service.process_message(text_content, content_type, image_paths)
        
        msg = db.query(Message).get(message_id)
        if not msg:
            return
        
        msg.main_category_id = ai_result["main_category_id"]
        msg.ai_summary = ai_result["ai_summary"]
        msg.ai_confidence = ai_result["ai_confidence"]
        msg.extracted_nicknames = ai_result.get("extracted_nicknames", [])
        msg.ai_processed = True
        msg.ai_processed_at = datetime.utcnow()
        
        process_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        log = AIProcessLog(
            message_id=message_id,
            model_used="mock" if not ai_service.ai_enabled else ai_service.model,
            raw_response=ai_result,
            processing_time_ms=process_time,
            status="success"
        )
        db.add(log)
        db.commit()
        
    except Exception as e:
        db.rollback()
        print(f"AI处理消息{message_id}失败: {e}")
        try:
            log = AIProcessLog(message_id=message_id, status="failed", error_message=str(e))
            db.add(log)
            db.commit()
        except:
            pass
    finally:
        db.close()


@router.post("", response_model=MessageResponse, summary="发送新消息（支持文字/图片/语音）")
async def create_message(
    background_tasks: BackgroundTasks,
    sender_role: str = Form(..., description="发送人角色：男主/女主"),
    text_content: Optional[str] = Form(None, description="文本内容"),
    is_ai_auto: bool = Form(True, description="是否AI自动分类"),
    manual_category: Optional[str] = Form(None, description="手动选择的分类名称，is_ai_auto=false时必填"),
    images: List[UploadFile] = File([], description="图片文件列表，支持多图"),
    voice: Optional[UploadFile] = File(None, description="语音文件"),
    db: Session = Depends(get_db)
):
    """
    发送消息，支持multipart/form-data格式
    - 支持文字、多图、语音混合发送
    - 支持AI自动分类 / 手动选择分类双模式
    """
    # 参数校验
    if sender_role not in ["男主", "女主", "其他"]:
        raise HTTPException(status_code=400, detail="发送人角色只能是男主/女主")
    
    if not text_content and not images and not voice:
        raise HTTPException(status_code=400, detail="消息内容不能为空")
    
    # 判断内容类型
    if voice:
        content_type = "voice"
    elif images:
        content_type = "image"
    else:
        content_type = "text"
    
    # 手动分类校验
    manual_category_id = None
    if not is_ai_auto:
        if not manual_category:
            raise HTTPException(status_code=400, detail="关闭AI自动分类时必须手动选择分类")
        manual_category_id = ai_service.get_category_id_by_name(manual_category)
        if not manual_category_id:
            raise HTTPException(status_code=400, detail=f"分类不存在: {manual_category}")
    
    couple = get_or_create_default_couple(db)
    role_map = {"男主": "male", "女主": "female", "其他": "other"}
    sender = db.query(User).filter(
        User.couple_id == couple.id,
        User.role == role_map[sender_role]
    ).first()
    if not sender:
        raise HTTPException(status_code=400, detail="发送用户不存在")
    
    # 保存文件
    attachments = []
    local_image_paths = []
    
    # 保存图片
    for img in images:
        if not img.content_type.startswith("image/"):
            continue
        url_path, file_size = await save_upload_file(img, IMAGE_DIR)
        local_path = IMAGE_DIR / url_path.split("/")[-1]
        local_image_paths.append(str(local_path))
        # 获取图片尺寸
        width, height = None, None
        try:
            from PIL import Image
            with Image.open(local_path) as pil_img:
                width, height = pil_img.size
        except:
            pass
        attachments.append(MessageAttachment(
            file_type="image",
            file_url=url_path,
            file_size=file_size,
            width=width,
            height=height,
            mime_type=img.content_type
        ))
    
    # 保存语音
    voice_duration = None
    if voice:
        if not voice.content_type.startswith("audio/"):
            raise HTTPException(status_code=400, detail="语音文件格式错误")
        url_path, file_size = await save_upload_file(voice, VOICE_DIR)
        attachments.append(MessageAttachment(
            file_type="voice",
            file_url=url_path,
            file_size=file_size,
            duration=None,
            mime_type=voice.content_type
        ))
        # 语音自动归入语音分类
        if is_ai_auto:
            pass  # AI处理时会识别
    
    # 创建消息
    db_message = Message(
        couple_id=couple.id,
        sender_id=sender.id,
        content_type=content_type,
        text_content=text_content,
        ai_processed=False,
        voice_transcribed=False,
        voice_duration=voice_duration,
        is_manual_category=not is_ai_auto
    )
    
    # 手动分类直接设置分类
    if not is_ai_auto:
        db_message.main_category_id = manual_category_id
        db_message.ai_summary = None  # 手动模式不生成小结
        db_message.ai_processed = True
        db_message.ai_confidence = 1.0
    
    db.add(db_message)
    db.flush()
    
    # 关联附件
    for att in attachments:
        att.message_id = db_message.id
        db.add(att)
    
    db.commit()
    db.refresh(db_message)
    
    # 自动模式则后台异步处理AI
    if is_ai_auto:
        background_tasks.add_task(
            _process_ai_classification,
            db_message.id,
            text_content or "",
            content_type,
            local_image_paths,
            SessionLocal
        )
    
    # 构建响应
    return await _build_message_response(db, db_message)


@router.get("", response_model=List[MessageResponse], summary="获取历史消息")
async def list_messages(
    limit: int = 200,
    offset: int = 0,
    order: str = "asc",
    db: Session = Depends(get_db)
):
    """
    获取历史消息列表
    - order: asc正序（聊天页），desc倒序（时间轴）
    """
    couple = get_or_create_default_couple(db)
    query = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    )
    
    query = query.order_by(Message.created_at.asc() if order.lower() == "asc" else Message.created_at.desc())
    messages = query.offset(offset).limit(limit).all()
    
    result = []
    for msg in messages:
        result.append(await _build_message_response(db, msg))
    return result


async def _build_message_response(db: Session, msg: Message) -> MessageResponse:
    """构建消息响应，包含附件、分类信息"""
    sender = db.query(User).get(msg.sender_id)
    
    # 分类信息
    category_name = None
    category_icon = None
    if msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id)
        if cat:
            category_name = cat["name"]
            category_icon = cat["icon"]
        else:
            db_cat = db.query(Category).get(msg.main_category_id)
            if db_cat:
                category_name = db_cat.name
                category_icon = db_cat.icon
    
    # 附件信息
    atts = db.query(MessageAttachment).filter(MessageAttachment.message_id == msg.id).all()
    attachments = []
    for att in atts:
        attachments.append(AttachmentInfo(
            file_type=att.file_type,
            file_url=att.file_url,
            thumbnail_url=att.thumbnail_url,
            duration=att.duration,
            width=att.width,
            height=att.height
        ))
    
    return MessageResponse(
        id=msg.id,
        sender_role="男主" if sender.role == "male" else "女主" if sender.role == "female" else "其他",
        sender_nickname=sender.nickname,
        content_type=msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        text_content=msg.text_content,
        ai_summary=msg.ai_summary,
        main_category_id=msg.main_category_id,
        main_category_name=category_name,
        main_category_icon=category_icon,
        ai_processed=msg.ai_processed,
        is_manual_category=msg.is_manual_category,
        attachments=attachments,
        voice_duration=msg.voice_duration,
        created_at=msg.created_at
    )
