from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from enum import Enum


class SenderRole(str, Enum):
    """发送人角色"""
    MALE = "男主"
    FEMALE = "女主"
    OTHER = "其他"


class ContentType(str, Enum):
    """消息内容类型"""
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    STICKER = "sticker"


class AttachmentInfo(BaseModel):
    """附件信息"""
    file_type: str
    file_url: str
    thumbnail_url: Optional[str] = None
    duration: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None


class MessageResponse(BaseModel):
    """消息响应体"""
    id: int
    sender_role: str
    sender_nickname: str
    content_type: str
    text_content: Optional[str]
    ai_summary: Optional[str]
    main_category_id: Optional[int] = None
    main_category_name: Optional[str]
    main_category_icon: Optional[str]
    ai_processed: bool
    is_manual_category: bool = False
    attachments: List[AttachmentInfo] = []
    voice_duration: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True
