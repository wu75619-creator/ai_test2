from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from enum import Enum


class SenderRole(str, Enum):
    """发送人角色"""
    MALE = "男主"
    FEMALE = "女主"
    OTHER = "其他"


class ContentType(str, Enum):
    """消息内容类型"""
    TEXT = "text"
    IMAGE = "image"
    VOICE = "voice"
    STICKER = "sticker"


class MessageCreate(BaseModel):
    """创建消息请求体"""
    sender_role: SenderRole = Field(..., description="发送人角色：男主/女主")
    content_type: ContentType = Field(default=ContentType.TEXT, description="内容类型")
    text_content: str = Field(..., min_length=1, max_length=5000, description="消息文本内容")


class MessageResponse(BaseModel):
    """消息响应体"""
    id: int
    sender_role: str
    sender_nickname: str
    content_type: str
    text_content: Optional[str]
    ai_summary: Optional[str]
    main_category_name: Optional[str]
    main_category_icon: Optional[str]
    ai_processed: bool
    created_at: datetime

    class Config:
        from_attributes = True
