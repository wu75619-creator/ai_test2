-- ============================================
-- 情侣智能随手恋爱日记本 - SQLite DDL
-- 自动生成，与SQLAlchemy模型完全对应
-- ============================================

-- 1. 情侣对表
CREATE TABLE IF NOT EXISTS couples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couple_name VARCHAR(100) NOT NULL DEFAULT '我们的小窝',
    together_date DATE,
    access_password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_deleted BOOLEAN NOT NULL DEFAULT 0
);

-- 2. 用户表
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couple_id INTEGER NOT NULL,
    role VARCHAR(20) NOT NULL,
    nickname VARCHAR(50) NOT NULL,
    avatar_url VARCHAR(500),
    theme_color VARCHAR(20) NOT NULL DEFAULT '#ff6b9d',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (couple_id) REFERENCES couples(id) ON DELETE CASCADE,
    UNIQUE(couple_id, role)
);

-- 3. 分类表
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couple_id INTEGER,
    parent_id INTEGER,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(100),
    description VARCHAR(200),
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_system BOOLEAN NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (couple_id) REFERENCES couples(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- 预置8大系统主分类
INSERT OR IGNORE INTO categories (parent_id, name, icon, description, is_system, sort_order) VALUES
(NULL, '美食探店存档', '🍜', '一起吃过的美食、喝过的奶茶、探店记录', 1, 1),
(NULL, '旅行外出约会存档', '✈️', '旅行、逛街、看电影、约会游玩记录', 1, 2),
(NULL, '情侣合照存档', '📸', '双人自拍、同框合照、甜蜜合影', 1, 3),
(NULL, '趣味日常存档', '😂', '搞笑对话、互怼日常、可爱瞬间、表情包', 1, 4),
(NULL, '专属昵称存档', '💌', '专属称呼、私密代号、只有我们懂的梗', 1, 5),
(NULL, '深度谈心存档', '💬', '走心对话、三观交流、情绪倾诉、爱意表达', 1, 6),
(NULL, '矛盾复盘存档', '🤝', '小矛盾、争吵、反思、道歉、和解约定、成长记录', 1, 7),
(NULL, '语音专属存档', '🎤', '所有语音消息独立归档，甜蜜声音收藏', 1, 8);

-- 4. 消息主表
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couple_id INTEGER NOT NULL,
    sender_id INTEGER NOT NULL,
    content_type VARCHAR(20) NOT NULL, -- text/image/voice/sticker
    text_content TEXT,
    main_category_id INTEGER,
    ai_summary TEXT,
    ai_processed BOOLEAN NOT NULL DEFAULT 0,
    ai_processed_at DATETIME,
    ai_confidence REAL,
    location VARCHAR(200),
    extracted_nicknames TEXT DEFAULT '[]', -- JSON array
    voice_duration INTEGER,
    voice_transcribed BOOLEAN NOT NULL DEFAULT 0,
    is_edited BOOLEAN NOT NULL DEFAULT 0,
    is_deleted BOOLEAN NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (couple_id) REFERENCES couples(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (main_category_id) REFERENCES categories(id)
);

-- 核心查询索引
CREATE INDEX IF NOT EXISTS idx_messages_couple_time ON messages(couple_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_category ON messages(couple_id, main_category_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_ai_pending ON messages(couple_id, ai_processed) WHERE ai_processed = 0;

-- 5. 消息附件表
CREATE TABLE IF NOT EXISTS message_attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    file_type VARCHAR(20) NOT NULL,
    file_url VARCHAR(1000) NOT NULL,
    thumbnail_url VARCHAR(1000),
    file_size INTEGER,
    width INTEGER,
    height INTEGER,
    duration INTEGER,
    mime_type VARCHAR(100),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_attachments_message ON message_attachments(message_id);

-- 6. 消息子标签关联表
CREATE TABLE IF NOT EXISTS message_tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    category_id INTEGER NOT NULL,
    is_ai_tagged BOOLEAN NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE(message_id, category_id)
);
CREATE INDEX IF NOT EXISTS idx_message_tags_message ON message_tags(message_id);
CREATE INDEX IF NOT EXISTS idx_message_tags_category ON message_tags(category_id);

-- 7. AI处理日志表
CREATE TABLE IF NOT EXISTS ai_process_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL,
    model_used VARCHAR(100),
    raw_response TEXT, -- JSON
    processing_time_ms INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'success',
    error_message TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
);

-- 8. 月度/年度汇总表
CREATE TABLE IF NOT EXISTS memory_summaries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    couple_id INTEGER NOT NULL,
    summary_type VARCHAR(20) NOT NULL, -- monthly/yearly
    summary_date DATE NOT NULL,
    content TEXT NOT NULL,
    stats TEXT DEFAULT '{}', -- JSON object
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (couple_id) REFERENCES couples(id) ON DELETE CASCADE,
    UNIQUE(couple_id, summary_type, summary_date)
);
