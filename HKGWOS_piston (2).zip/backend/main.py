"""
情侣智能随手恋爱日记本 - 后端入口
FastAPI application
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from app.core.database import engine, Base
from app import models

# 创建所有数据库表（SQLite自动建库建表）
Base.metadata.create_all(bind=engine)

# 初始化系统预设8大分类
from app.core.init_data import init_system_categories
init_system_categories()

app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    description="对话式随手记录 + AI自动分类归档的双人恋爱日记本",
    version="1.1.0"
)

# CORS配置：允许所有源跨域请求
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 静态文件目录
upload_dir = Path("uploads")
upload_dir.mkdir(exist_ok=True)
(upload_dir / "images").mkdir(exist_ok=True)
(upload_dir / "voices").mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# 注册API路由
from app.api.messages import router as messages_router
from app.api.categories import router as categories_router
app.include_router(messages_router)
app.include_router(categories_router)


@app.get("/api/health", summary="健康检查")
async def health_check():
    ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
    return {
        "status": "ok",
        "message": "情侣日记本服务运行中 💑",
        "ai_mode": "真实大模型" if ai_enabled else "Mock模拟模式",
        "docs": "/docs 访问Swagger接口文档"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
