<template>
  <div class="timeline-page">
    <div class="page-header">
      <h1>💕 恋爱时间轴</h1>
      <p>每一条记录，都是我们相爱的证据</p>
    </div>

    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-num">{{ totalMessages }}</div>
        <div class="stat-label">条甜蜜记录</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-num">{{ categoryCount }}</div>
        <div class="stat-label">个分类归档</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-num">{{ dayCount }}</div>
        <div class="stat-label">天陪伴</div>
      </div>
    </div>

    <div class="timeline-container" v-loading="loading">
      <div v-if="groupedMessages.length === 0 && !loading" class="empty-state">
        <div style="font-size: 48px; margin-bottom: 12px">📖</div>
        <div>还没有任何记录，去聊天页留下第一条回忆吧～</div>
        <el-button type="primary" link @click="$router.push('/')">去聊天</el-button>
      </div>

      <el-timeline v-else>
        <div v-for="group in groupedMessages" :key="group.date">
          <!-- 日期分割 -->
          <div class="date-marker">
            <span class="date-text">{{ formatDateLabel(group.date) }}</span>
          </div>
          
          <!-- 当日消息 -->
          <el-timeline-item
            v-for="msg in group.messages"
            :key="msg.id"
            :timestamp="formatTime(msg.created_at)"
            :color="msg.sender_role === '女主' ? '#ff6b9d' : '#4a90e2'"
            placement="top"
          >
            <div class="timeline-card">
              <div class="card-sender">
                <span class="sender-avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
                  {{ msg.sender_role === '女主' ? '👩' : '👨' }}
                </span>
                <span class="sender-name">{{ msg.sender_nickname }}</span>
                <el-tag 
                  v-if="msg.main_category_icon" 
                  size="small" 
                  effect="plain" 
                  round
                  class="cat-tag"
                >
                  {{ msg.main_category_icon }} {{ msg.main_category_name }}
                </el-tag>
              </div>
              
              <div v-if="msg.attachments && msg.attachments.length > 0" class="card-images">
                <img 
                  v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'image')" 
                  :key="idx" 
                  :src="att.file_url" 
                  class="tl-img"
                />
                <audio 
                  v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'voice')" 
                  :key="'v'+idx" 
                  :src="att.file_url" 
                  controls
                  class="tl-voice"
                ></audio>
              </div>
              <div v-if="msg.text_content" class="card-text">{{ msg.text_content }}</div>
              
              <div v-if="msg.ai_summary" class="ai-note">
                <span>✨ AI小结：</span>{{ msg.ai_summary }}
              </div>
            </div>
          </el-timeline-item>
        </div>
      </el-timeline>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { getMessages } from '../api/message'
import { getCategoryStats } from '../api/category'

const loading = ref(false)
const messages = ref([])
const categoryCount = ref(8)

const totalMessages = computed(() => messages.value.length)

// 计算第一天到今天的天数
const dayCount = computed(() => {
  if (messages.value.length === 0) return 0
  const first = dayjs(messages.value[messages.value.length - 1].created_at)
  return dayjs().diff(first, 'day') + 1
})

// 按日期分组消息
const groupedMessages = computed(() => {
  const groups = {}
  // 按时间倒序排列
  const sorted = [...messages.value].sort((a, b) => dayjs(b.created_at).valueOf() - dayjs(a.created_at).valueOf())
  sorted.forEach(msg => {
    const date = dayjs(msg.created_at).format('YYYY-MM-DD')
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(msg)
  })
  return Object.keys(groups).map(date => ({
    date,
    messages: groups[date]
  }))
})

const formatTime = (time) => dayjs(time).format('HH:mm')

const formatDateLabel = (date) => {
  const d = dayjs(date)
  const today = dayjs().format('YYYY-MM-DD')
  const yesterday = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
  if (date === today) return '今天'
  if (date === yesterday) return '昨天'
  return d.format('M月D日 dddd')
}

const loadData = async () => {
  loading.value = true
  try {
    const [msgsRes, statsRes] = await Promise.all([
      getMessages(),
      getCategoryStats().catch(() => null)
    ])
    messages.value = msgsRes
    if (statsRes) {
      categoryCount.value = statsRes.categories.filter(c => c.count > 0).length
    }
  } catch (e) {
    ElMessage.error('加载时间轴失败')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.timeline-page {
  padding: 20px 16px 30px;
  min-height: 100%;
}

.page-header {
  text-align: center;
  margin-bottom: 20px;
}
.page-header h1 {
  font-size: 24px;
  color: var(--el-color-primary);
  margin-bottom: 4px;
}
.page-header p {
  font-size: 13px;
  color: var(--text-secondary);
}

.stats-bar {
  background: white;
  border-radius: 16px;
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-bottom: 24px;
  box-shadow: var(--shadow-soft);
  background: linear-gradient(135deg, #fff 0%, #fff5f8 100%);
}
.stat-item {
  text-align: center;
}
.stat-num {
  font-size: 28px;
  font-weight: 700;
  color: var(--el-color-primary);
  line-height: 1;
  margin-bottom: 6px;
}
.stat-label {
  font-size: 12px;
  color: var(--text-secondary);
}
.stat-divider {
  width: 1px;
  height: 30px;
  background: var(--border-color);
}

.timeline-container {
  padding: 0 8px;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-secondary);
}

.date-marker {
  text-align: center;
  margin: 20px 0 12px;
  position: relative;
}
.date-marker::before {
  content: '';
  position: absolute;
  left: 0;
  right: 0;
  top: 50%;
  height: 1px;
  background: var(--border-color);
  z-index: 0;
}
.date-text {
  position: relative;
  z-index: 1;
  background: var(--bg-color);
  padding: 4px 16px;
  border-radius: 20px;
  font-size: 13px;
  color: var(--text-secondary);
  font-weight: 500;
}

.timeline-card {
  background: white;
  border-radius: 12px;
  padding: 12px 14px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  max-width: 100%;
}

.card-sender {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}
.sender-avatar {
  width: 26px;
  height: 26px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}
.avatar-male {
  background: var(--male-bubble-bg);
}
.avatar-female {
  background: var(--female-bubble-bg);
}
.sender-name {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-primary);
}
.cat-tag {
  margin-left: auto;
}
.cat-tag :deep(.el-tag__content) {
  font-size: 11px;
}

.card-images {
  margin-bottom: 8px;
}
.tl-img {
  max-width: 100%;
  max-height: 180px;
  border-radius: 8px;
}
.tl-voice {
  width: 100%;
  height: 32px;
}
.card-text {
  font-size: 14px;
  line-height: 1.7;
  color: var(--text-primary);
  word-break: break-all;
}

.ai-note {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px dashed var(--border-color);
  font-size: 12px;
  color: var(--el-color-primary);
  line-height: 1.5;
  font-style: italic;
}
.ai-note span {
  font-weight: 500;
}

:deep(.el-timeline-item__timestamp) {
  color: var(--text-secondary);
  font-size: 11px;
}
</style>
