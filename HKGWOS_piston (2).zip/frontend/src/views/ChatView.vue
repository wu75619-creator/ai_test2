<template>
  <div class="chat-page">
    <!-- 顶部标题栏 -->
    <div class="chat-header">
      <div class="header-title">💑 我们的恋爱日记本</div>
      <div class="header-subtitle">随手记录，自动归档，珍藏每一份甜蜜</div>
    </div>

    <!-- 消息列表区域 -->
    <div class="chat-messages" ref="messageListRef">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载消息中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💌</div>
        <div>还没有消息，发第一条消息开始记录我们的故事吧～</div>
      </div>
      <template v-else>
        <div 
          v-for="msg in messages" 
          :key="msg.id"
          class="message-item"
          :class="msg.sender_role === '女主' ? 'message-female' : 'message-male'"
        >
          <!-- 头像 -->
          <div class="avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
            {{ msg.sender_role === '女主' ? '👩' : '👨' }}
          </div>
          <!-- 消息内容 -->
          <div class="message-body">
            <div class="sender-name">{{ msg.sender_nickname }}</div>
            <div class="bubble" :class="msg.sender_role === '女主' ? 'bubble-female' : 'bubble-male'">
              {{ msg.text_content }}
              <div v-if="msg.ai_summary && msg.ai_processed" class="ai-summary">
                🤖 {{ msg.ai_summary }}
              </div>
              <div v-if="msg.main_category_name" class="category-tag">
                {{ msg.main_category_icon }} {{ msg.main_category_name }}
              </div>
            </div>
            <div class="message-time">{{ formatTime(msg.created_at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- 底部输入区域 -->
    <div class="chat-input-area">
      <div class="input-wrapper">
        <el-input
          v-model="inputText"
          type="textarea"
          :rows="2"
          placeholder="说点什么吧～ 文字/图片/语音都可以哦（当前版本仅支持文字）"
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
        />
        <el-button 
          type="primary" 
          class="send-btn"
          @click="handleSend"
          :loading="sending"
          :disabled="!inputText.trim()"
        >
          发送 💕
        </el-button>
      </div>
      <div class="role-tip">
        当前发送身份：
        <el-radio-group v-model="currentSender" size="small">
          <el-radio-button label="男主">👨 男主</el-radio-button>
          <el-radio-button label="女主">👩 女主</el-radio-button>
        </el-radio-group>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { Loading } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'

const messageListRef = ref(null)
const loading = ref(false)
const sending = ref(false)
const messages = ref([])
const inputText = ref('')
// 默认发送身份为女主，可切换
const currentSender = ref('女主')

// 格式化时间
const formatTime = (time) => {
  return dayjs(time).format('MM-DD HH:mm')
}

// 滚动到底部
const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}

// 加载历史消息
const loadMessages = async () => {
  loading.value = true
  try {
    const res = await getMessages()
    messages.value = res
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  } finally {
    loading.value = false
  }
}

// 发送消息
const handleSend = async () => {
  if (!inputText.value.trim() || sending.value) return

  sending.value = true
  try {
    await sendMessage({
      sender_role: currentSender.value,
      text_content: inputText.value.trim(),
      content_type: 'text'
    })
    ElMessage.success('发送成功 💌')
    inputText.value = ''
    // 重新加载消息
    await loadMessages()
  } catch (e) {
    console.error('发送失败', e)
  } finally {
    sending.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.chat-page {
  width: 100%;
  height: 100%;
  max-width: 768px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  background: var(--bg-color);
  box-shadow: var(--shadow-soft);
}

/* 头部 */
.chat-header {
  padding: 20px 16px 12px;
  text-align: center;
  background: white;
  border-bottom: 1px solid var(--border-color);
}
.header-title {
  font-size: 20px;
  font-weight: 600;
  color: var(--el-color-primary);
  margin-bottom: 4px;
}
.header-subtitle {
  font-size: 12px;
  color: var(--text-secondary);
}

/* 消息列表 */
.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}
.loading-tip, .empty-tip {
  text-align: center;
  color: var(--text-secondary);
  padding: 40px 0;
  font-size: 14px;
}
.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.message-item {
  display: flex;
  gap: 10px;
  max-width: 80%;
}
.message-male {
  align-self: flex-start;
}
.message-female {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}
.avatar-male {
  background: var(--male-bubble-bg);
}
.avatar-female {
  background: var(--female-bubble-bg);
}

.message-body {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.message-female .message-body {
  align-items: flex-end;
}
.sender-name {
  font-size: 12px;
  color: var(--text-secondary);
  padding: 0 4px;
}
.bubble {
  padding: 10px 14px;
  border-radius: 18px;
  font-size: 15px;
  line-height: 1.6;
  word-break: break-all;
  position: relative;
  max-width: 100%;
}
.bubble-male {
  background: white;
  color: var(--text-primary);
  border-bottom-left-radius: 4px;
  border: 1px solid var(--border-color);
}
.bubble-female {
  background: var(--female-bubble-bg);
  color: var(--female-bubble-text);
  border-bottom-right-radius: 4px;
}

.ai-summary {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px dashed rgba(255,255,255,0.5);
  font-size: 12px;
  opacity: 0.8;
  font-style: italic;
}
.bubble-male .ai-summary {
  border-top-color: var(--border-color);
}

.category-tag {
  margin-top: 6px;
  display: inline-block;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
  background: rgba(255,255,255,0.6);
}
.bubble-male .category-tag {
  background: var(--el-color-primary-light-9);
  color: var(--el-color-primary);
}

.message-time {
  font-size: 11px;
  color: var(--text-secondary);
  padding: 0 4px;
}

/* 输入区域 */
.chat-input-area {
  background: white;
  padding: 12px 16px 20px;
  border-top: 1px solid var(--border-color);
}
.input-wrapper {
  display: flex;
  gap: 10px;
  align-items: flex-end;
}
.input-wrapper :deep(.el-textarea__inner) {
  border-radius: 12px;
  border-color: var(--border-color);
  background: var(--bg-cream);
}
.input-wrapper :deep(.el-textarea__inner:focus) {
  border-color: var(--el-color-primary);
}
.send-btn {
  border-radius: 12px !important;
  height: 40px;
  padding: 0 20px;
  flex-shrink: 0;
}
.role-tip {
  margin-top: 10px;
  font-size: 12px;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 8px;
}
.role-tip :deep(.el-radio-button__inner) {
  padding: 4px 12px;
  font-size: 12px;
}
.role-tip :deep(.el-radio-button:first-child .el-radio-button__inner) {
  border-radius: 8px 0 0 8px;
}
.role-tip :deep(.el-radio-button:last-child .el-radio-button__inner) {
  border-radius: 0 8px 8px 0;
}
</style>
