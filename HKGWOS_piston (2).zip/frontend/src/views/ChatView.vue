<template>
  <div class="chat-page">
    <!-- 顶部标题栏 -->
    <div class="chat-header">
      <div class="header-title">💑 我们的恋爱日记本</div>
      <div class="header-subtitle">随手记录，AI自动归档，珍藏每一份甜蜜</div>
    </div>

    <!-- 消息列表区域 -->
    <div class="chat-messages" ref="messageListRef">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载消息中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💌</div>
        <div>还没有消息，发第一条消息开始记录我们的故事吧～</div>
        <div class="empty-hint">支持文字、图片、语音，AI自动分类归档</div>
      </div>
      <template v-else>
        <div 
          v-for="msg in messages" 
          :key="msg.id"
          class="message-item"
          :class="msg.sender_role === '女主' ? 'message-female' : 'message-male'"
        >
          <!-- 头像 -->
          <div class="avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
            {{ msg.sender_role === '女主' ? '👩' : '👨' }}
          </div>
          <!-- 消息内容 -->
          <div class="message-body">
            <div class="sender-name">{{ msg.sender_nickname }}</div>
            
            <div class="bubble" :class="msg.sender_role === '女主' ? 'bubble-female' : 'bubble-male'">
              <!-- 图片附件 -->
              <div v-if="msg.attachments && msg.attachments.length > 0" class="attachments">
                <div v-for="(att, idx) in msg.attachments" :key="idx" class="attachment-item">
                  <img 
                    v-if="att.file_type === 'image'" 
                    :src="att.file_url" 
                    class="msg-image"
                    @click="previewImage(att.file_url)"
                  />
                  <audio 
                    v-if="att.file_type === 'voice'" 
                    :src="att.file_url" 
                    controls
                    class="msg-voice"
                  ></audio>
                </div>
              </div>
              
              <!-- 文字内容 -->
              <div v-if="msg.text_content" class="text-content">{{ msg.text_content }}</div>
              
              <!-- AI 小结 -->
              <div v-if="msg.ai_summary && msg.ai_processed && !msg.is_manual_category" class="ai-summary">
                <span class="ai-tag">✨ AI小结</span>
                {{ msg.ai_summary }}
              </div>
              
              <!-- 分类标签 -->
              <div v-if="msg.main_category_name" class="category-tag">
                {{ msg.main_category_icon }} {{ msg.main_category_name }}
                <span v-if="msg.is_manual_category" class="manual-badge">手动</span>
              </div>
              <div v-else-if="!msg.ai_processed" class="processing-tag">
                <el-icon class="is-loading"><Loading /></el-icon> AI归档中...
              </div>
            </div>
            
            <div class="message-time">{{ formatTime(msg.created_at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- 底部输入区域 -->
    <div class="chat-input-area">
      <!-- 模式与分类选择 -->
      <div class="input-options">
        <div class="ai-switch">
          <el-switch v-model="isAiAuto" size="small" active-color="#ff6b9d" />
          <span class="switch-label">AI自动分类</span>
        </div>
        
        <el-select
          v-if="!isAiAuto"
          v-model="selectedCategory"
          placeholder="请选择分类"
          size="small"
          class="category-select"
        >
          <el-option
            v-for="cat in categories"
            :key="cat.id"
            :label="`${cat.icon} ${cat.name}`"
            :value="cat.name"
          />
        </el-select>
      </div>

      <!-- 预览选中的图片 -->
      <div v-if="selectedImages.length > 0" class="preview-images">
        <div v-for="(img, idx) in selectedImages" :key="idx" class="preview-img-item">
          <img :src="img.preview" />
          <el-icon class="remove-btn" @click="removeImage(idx)"><Close /></el-icon>
        </div>
      </div>

      <!-- 选中的语音预览 -->
      <div v-if="selectedVoice" class="voice-preview">
        <audio :src="selectedVoice.preview" controls class="preview-voice"></audio>
        <el-icon class="remove-voice" @click="selectedVoice = null"><Close /></el-icon>
      </div>

      <div class="input-wrapper">
        <!-- 功能按钮 -->
        <div class="func-btns">
          <el-upload
            :show-file-list="false"
            accept="image/*"
            multiple
            :before-upload="handleImageSelect"
            class="upload-btn"
          >
            <el-button circle size="small" icon="Picture" :disabled="!!selectedVoice"></el-button>
          </el-upload>
          <el-upload
            :show-file-list="false"
            accept="audio/*"
            :before-upload="handleVoiceSelect"
            class="upload-btn"
          >
            <el-button circle size="small" icon="Microphone" :disabled="selectedImages.length > 0"></el-button>
          </el-upload>
        </div>

        <el-input
          v-model="inputText"
          type="textarea"
          :rows="1"
          autosize
          placeholder="说点什么吧～ 支持文字、图片、语音"
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
          class="msg-input"
        />
        
        <el-button 
          type="primary" 
          class="send-btn"
          @click="handleSend"
          :loading="sending"
          :disabled="!canSend"
        >
          发送 💕
        </el-button>
      </div>
      
      <div class="role-tip">
        发送身份：
        <el-radio-group v-model="currentSender" size="small">
          <el-radio-button label="男主">👨 男主</el-radio-button>
          <el-radio-button label="女主">👩 女主</el-radio-button>
        </el-radio-group>
      </div>
    </div>

    <!-- 图片预览弹窗 -->
    <el-image-viewer
      v-if="previewImgUrl"
      :url-list="[previewImgUrl]"
      @close="previewImgUrl = ''"
      hide-on-click-modal
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, nextTick } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { Loading, Picture, Microphone, Close } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'
import { getCategories } from '../api/category'

const messageListRef = ref(null)
const loading = ref(false)
const sending = ref(false)
const messages = ref([])
const inputText = ref('')
const currentSender = ref('女主')
// AI模式
const isAiAuto = ref(true)
const selectedCategory = ref('')
const categories = ref([
  {id:1,name:'美食探店存档',icon:'🍜'},
  {id:2,name:'旅行外出约会存档',icon:'✈️'},
  {id:3,name:'情侣合照存档',icon:'📸'},
  {id:4,name:'趣味日常存档',icon:'😂'},
  {id:5,name:'专属昵称存档',icon:'💌'},
  {id:6,name:'深度谈心存档',icon:'💬'},
  {id:7,name:'矛盾复盘存档',icon:'🤝'},
  {id:8,name:'语音专属存档',icon:'🎤'}
])
// 文件选择
const selectedImages = ref([])
const selectedVoice = ref(null)
// 图片预览
const previewImgUrl = ref('')

// 是否可以发送
const canSend = computed(() => {
  if (sending.value) return false
  const hasContent = inputText.value.trim() || selectedImages.value.length > 0 || selectedVoice.value
  if (!hasContent) return false
  if (!isAiAuto.value && !selectedCategory.value) return false
  return true
})

const formatTime = (time) => dayjs(time).format('MM-DD HH:mm')

const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) {
    messageListRef.value.scrollTop = messageListRef.value.scrollHeight
  }
}

const loadCategories = async () => {
  try {
    const res = await getCategories()
    if (res && res.length > 0) {
      categories.value = res
    }
  } catch (e) {
    // 用默认分类
  }
}

const loadMessages = async () => {
  loading.value = true
  try {
    const res = await getMessages('asc')
    messages.value = res
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  } finally {
    loading.value = false
  }
}

const handleImageSelect = (file) => {
  if (selectedVoice.value) {
    ElMessage.warning('语音和图片不能同时发送哦')
    return false
  }
  const preview = URL.createObjectURL(file)
  selectedImages.value.push({ file, preview })
  return false // 阻止自动上传
}

const handleVoiceSelect = (file) => {
  if (selectedImages.value.length > 0) {
    ElMessage.warning('图片和语音不能同时发送哦')
    return false
  }
  const preview = URL.createObjectURL(file)
  selectedVoice.value = { file, preview }
  if (isAiAuto.value === false) {
    selectedCategory.value = '语音专属存档'
  }
  return false
}

const removeImage = (idx) => {
  selectedImages.value.splice(idx, 1)
}

const previewImage = (url) => {
  previewImgUrl.value = url
}

const handleSend = async () => {
  if (!canSend.value) {
    if (!isAiAuto.value && !selectedCategory.value) {
      ElMessage.warning('关闭AI自动分类时请先选择分类')
    }
    return
  }

  sending.value = true
  try {
    await sendMessage({
      sender_role: currentSender.value,
      text_content: inputText.value.trim(),
      is_ai_auto: isAiAuto.value,
      manual_category: isAiAuto.value ? null : selectedCategory.value,
      images: selectedImages.value.map(i => i.file),
      voice: selectedVoice.value?.file || null
    })
    
    // 清空输入
    inputText.value = ''
    selectedImages.value = []
    selectedVoice.value = null
    
    await loadMessages()
    
    if (isAiAuto.value) {
      ElMessage.success('发送成功，AI正在自动归档 ✨')
      // 轮询刷新AI结果
      let refreshCount = 0
      const refreshTimer = setInterval(async () => {
        await loadMessages()
        refreshCount++
        // 最多刷新5次，或者所有消息都处理完了
        const allProcessed = messages.value.every(m => m.ai_processed)
        if (refreshCount >= 5 || allProcessed) {
          clearInterval(refreshTimer)
        }
      }, 1500)
    } else {
      ElMessage.success('发送成功，已手动分类 💌')
    }
  } catch (e) {
    console.error('发送失败', e)
  } finally {
    sending.value = false
  }
}

onMounted(() => {
  loadCategories()
  loadMessages()
})
</script>

<style scoped>
.chat-page {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  background: var(--bg-color);
}

/* 头部 */
.chat-header {
  padding: 16px 16px 10px;
  text-align: center;
  background: white;
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}
.header-title {
  font-size: 18px;
  font-weight: 600;
  color: var(--el-color-primary);
  margin-bottom: 2px;
}
.header-subtitle {
  font-size: 11px;
  color: var(--text-secondary);
}

/* 消息列表 */
.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.loading-tip, .empty-tip {
  text-align: center;
  color: var(--text-secondary);
  padding: 40px 0;
  font-size: 14px;
}
.empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}
.empty-hint {
  font-size: 12px;
  margin-top: 8px;
  opacity: 0.7;
}

.message-item {
  display: flex;
  gap: 8px;
  max-width: 85%;
}
.message-male {
  align-self: flex-start;
}
.message-female {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
}
.avatar-male {
  background: var(--male-bubble-bg);
}
.avatar-female {
  background: var(--female-bubble-bg);
}

.message-body {
  display: flex;
  flex-direction: column;
  gap: 3px;
  min-width: 0;
}
.message-female .message-body {
  align-items: flex-end;
}
.sender-name {
  font-size: 11px;
  color: var(--text-secondary);
  padding: 0 4px;
}
.bubble {
  padding: 10px 12px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.6;
  word-break: break-all;
  position: relative;
  max-width: 100%;
  overflow: hidden;
}
.bubble-male {
  background: white;
  color: var(--text-primary);
  border-bottom-left-radius: 4px;
  border: 1px solid var(--border-color);
}
.bubble-female {
  background: var(--female-bubble-bg);
  color: var(--female-bubble-text);
  border-bottom-right-radius: 4px;
}

/* 附件样式 */
.attachments {
  margin-bottom: 8px;
}
.attachment-item {
  border-radius: 8px;
  overflow: hidden;
}
.msg-image {
  max-width: 220px;
  max-height: 300px;
  border-radius: 8px;
  cursor: pointer;
  display: block;
}
.msg-voice {
  height: 36px;
  min-width: 180px;
}

.text-content {
  margin-bottom: 4px;
}

.ai-summary {
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px dashed rgba(0,0,0,0.08);
  font-size: 12px;
  opacity: 0.9;
  font-style: italic;
  line-height: 1.5;
}
.ai-tag {
  font-weight: 500;
  margin-right: 4px;
  font-style: normal;
  color: var(--el-color-primary);
}
.bubble-female .ai-summary {
  border-top-color: rgba(255,255,255,0.5);
}

.category-tag {
  margin-top: 6px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
  background: rgba(255,255,255,0.7);
}
.bubble-male .category-tag {
  background: var(--el-color-primary-light-9);
  color: var(--el-color-primary);
}
.manual-badge {
  font-size: 9px;
  background: #e6f7ff;
  color: #1890ff;
  padding: 0 4px;
  border-radius: 4px;
  margin-left: 2px;
}
.processing-tag {
  margin-top: 6px;
  font-size: 11px;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 3px;
}

.message-time {
  font-size: 10px;
  color: var(--text-secondary);
  padding: 0 4px;
}

/* 输入区域 */
.chat-input-area {
  background: white;
  padding: 10px 12px 16px;
  border-top: 1px solid var(--border-color);
  flex-shrink: 0;
}

.input-options {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
  flex-wrap: wrap;
}
.ai-switch {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-secondary);
}
.category-select {
  flex: 1;
  min-width: 180px;
}

/* 预览区 */
.preview-images {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 8px;
}
.preview-img-item {
  position: relative;
  width: 70px;
  height: 70px;
  border-radius: 8px;
  overflow: hidden;
}
.preview-img-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.remove-btn {
  position: absolute;
  top: 2px;
  right: 2px;
  background: rgba(0,0,0,0.6);
  color: white;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  cursor: pointer;
}

.voice-preview {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
  padding: 8px;
  background: var(--bg-cream);
  border-radius: 8px;
}
.preview-voice {
  flex: 1;
  height: 32px;
}
.remove-voice {
  cursor: pointer;
  color: var(--text-secondary);
}

.input-wrapper {
  display: flex;
  gap: 8px;
  align-items: flex-end;
}
.func-btns {
  display: flex;
  gap: 4px;
  padding-bottom: 4px;
}
.upload-btn :deep(.el-button) {
  color: var(--text-secondary);
  border-color: var(--border-color);
  background: white;
}
.msg-input {
  flex: 1;
}
.msg-input :deep(.el-textarea__inner) {
  border-radius: 20px;
  border-color: var(--border-color);
  background: var(--bg-cream);
  padding: 8px 16px;
  resize: none;
  max-height: 100px;
}
.msg-input :deep(.el-textarea__inner:focus) {
  border-color: var(--el-color-primary);
}
.send-btn {
  border-radius: 20px !important;
  height: 36px;
  padding: 0 16px;
  flex-shrink: 0;
}

.role-tip {
  margin-top: 8px;
  font-size: 11px;
  color: var(--text-secondary);
  display: flex;
  align-items: center;
  gap: 6px;
}
.role-tip :deep(.el-radio-button__inner) {
  padding: 3px 10px;
  font-size: 11px;
}
.role-tip :deep(.el-radio-button:first-child .el-radio-button__inner) {
  border-radius: 6px 0 0 6px;
}
.role-tip :deep(.el-radio-button:last-child .el-radio-button__inner) {
  border-radius: 0 6px 6px 0;
}
</style>
