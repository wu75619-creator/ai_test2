<template>
  <div class="category-page">
    <!-- 顶部返回+标题 -->
    <div class="cat-header">
      <el-icon class="back-btn" @click="$router.back()"><ArrowLeft /></el-icon>
      <div class="header-title">
        <span class="cat-icon">{{ currentCatIcon }}</span>
        <span>{{ categoryName }}</span>
      </div>
      <div style="width: 30px"></div>
    </div>

    <!-- 时间筛选器 -->
    <div class="filter-bar">
      <el-radio-group v-model="filterType" size="small" @change="loadMessages">
        <el-radio-button label="all">全部</el-radio-button>
        <el-radio-button label="year">按年</el-radio-button>
        <el-radio-button label="month">按月</el-radio-button>
      </el-radio-group>
      
      <div v-if="filterType !== 'all'" class="date-pickers">
        <el-date-picker
          v-if="filterType === 'year'"
          v-model="selectedYear"
          type="year"
          placeholder="选择年份"
          size="small"
          format="YYYY 年"
          value-format="YYYY"
          @change="loadMessages"
        />
        <el-date-picker
          v-if="filterType === 'month'"
          v-model="selectedMonth"
          type="month"
          placeholder="选择月份"
          size="small"
          format="YYYY 年 MM 月"
          value-format="YYYY-MM"
          @change="loadMessages"
        />
      </div>
    </div>

    <!-- 消息卡片瀑布流 -->
    <div class="cards-container" v-loading="loading">
      <div v-if="messages.length === 0 && !loading" class="empty-state">
        <div style="font-size: 48px; margin-bottom: 12px">📭</div>
        <div>这个分类下还没有记录哦～</div>
        <el-button type="primary" link @click="$router.push('/')">去聊天记录第一条</el-button>
      </div>

      <div v-for="msg in messages" :key="msg.id" class="message-card">
        <div class="card-header">
          <div class="sender">
            <span class="avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
              {{ msg.sender_role === '女主' ? '👩' : '👨' }}
            </span>
            <span class="nickname">{{ msg.sender_nickname }}</span>
          </div>
          <span class="time">{{ formatTime(msg.created_at) }}</span>
        </div>
        
        <div v-if="msg.attachments && msg.attachments.length > 0" class="card-images">
          <img 
            v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'image')" 
            :key="idx" 
            :src="att.file_url" 
            class="card-img"
          />
          <audio 
            v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'voice')" 
            :key="'v'+idx" 
            :src="att.file_url" 
            controls
            class="card-voice"
          ></audio>
        </div>

        <div v-if="msg.text_content" class="card-content">
          {{ msg.text_content }}
        </div>

        <!-- AI 小结 -->
        <div v-if="msg.ai_summary" class="ai-summary-card">
          <span class="ai-icon">✨</span>
          <span>{{ msg.ai_summary }}</span>
        </div>

        <!-- 分类标签 -->
        <div v-if="msg.main_category_icon" class="card-footer">
          <el-tag size="small" type="info" effect="plain" round>
            {{ msg.main_category_icon }} {{ msg.main_category_name }}
          </el-tag>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { ArrowLeft } from '@element-plus/icons-vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { getCategoryMessages } from '../api/category'

const route = useRoute()
const loading = ref(false)
const messages = ref([])
const filterType = ref('all')
const selectedYear = ref(dayjs().format('YYYY'))
const selectedMonth = ref(dayjs().format('YYYY-MM'))

const categoryName = computed(() => decodeURIComponent(route.params.id || ''))

const catIconMap = {
  '美食探店存档': '🍜',
  '旅行外出约会存档': '✈️',
  '情侣合照存档': '📸',
  '趣味日常存档': '😂',
  '专属昵称存档': '💌',
  '深度谈心存档': '💬',
  '矛盾复盘存档': '🤝',
  '语音专属存档': '🎤'
}
const currentCatIcon = computed(() => catIconMap[categoryName.value] || '📂')

const formatTime = (time) => {
  return dayjs(time).format('YYYY-MM-DD HH:mm')
}

const loadMessages = async () => {
  if (!categoryName.value) return
  loading.value = true
  try {
    let params = {}
    if (filterType.value === 'year' && selectedYear.value) {
      params.year = parseInt(selectedYear.value)
    }
    if (filterType.value === 'month' && selectedMonth.value) {
      const [y, m] = selectedMonth.value.split('-')
      params.year = parseInt(y)
      params.month = parseInt(m)
    }
    messages.value = await getCategoryMessages(categoryName.value, params.year, params.month)
  } catch (e) {
    ElMessage.error('加载消息失败')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadMessages()
})
</script>

<style scoped>
.category-page {
  min-height: 100%;
  display: flex;
  flex-direction: column;
}

.cat-header {
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: white;
  border-bottom: 1px solid var(--border-color);
  position: sticky;
  top: 0;
  z-index: 10;
}
.back-btn {
  font-size: 22px;
  color: var(--text-primary);
  cursor: pointer;
  padding: 4px;
}
.back-btn:active {
  opacity: 0.7;
}
.header-title {
  font-size: 17px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 6px;
}
.cat-icon {
  font-size: 22px;
}

.filter-bar {
  padding: 12px 16px;
  background: white;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
.date-pickers {
  flex: 1;
  min-width: 150px;
}
.date-pickers :deep(.el-date-editor) {
  width: 100% !important;
}

.cards-container {
  flex: 1;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: var(--text-secondary);
}

.message-card {
  background: white;
  border-radius: 14px;
  padding: 14px;
  box-shadow: var(--shadow-soft);
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}
.sender {
  display: flex;
  align-items: center;
  gap: 8px;
}
.avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
}
.avatar-male {
  background: var(--male-bubble-bg);
}
.avatar-female {
  background: var(--female-bubble-bg);
}
.nickname {
  font-size: 14px;
  font-weight: 500;
}
.time {
  font-size: 12px;
  color: var(--text-secondary);
}

.card-images {
  margin-bottom: 10px;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.card-img {
  max-width: 100%;
  max-height: 200px;
  border-radius: 8px;
  cursor: pointer;
}
.card-voice {
  width: 100%;
  height: 36px;
}
.card-content {
  font-size: 15px;
  line-height: 1.7;
  color: var(--text-primary);
  word-break: break-all;
}

.ai-summary-card {
  margin-top: 12px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #fff0f6 0%, #fff5f8 100%);
  border-radius: 10px;
  font-size: 13px;
  color: var(--el-color-primary-dark-2);
  line-height: 1.6;
  font-style: italic;
}
.ai-icon {
  margin-right: 4px;
}

.card-footer {
  margin-top: 10px;
  display: flex;
  justify-content: flex-start;
}
.card-footer :deep(.el-tag) {
  border-color: var(--el-color-primary-light-5);
  color: var(--el-color-primary);
}
</style>
