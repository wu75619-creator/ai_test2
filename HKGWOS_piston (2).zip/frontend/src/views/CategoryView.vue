<template>
  <div class="page">
    <h1>📂 分类归档</h1>
    <p>分类ID: {{ $route.params.id }} - 功能开发中...</p>
    <el-button type="primary" @click="$router.push('/')">返回聊天</el-button>
  </div>
</template>

<script setup>
</script>

<style scoped>
.page {
  padding: 40px 20px;
  text-align: center;
}
h1 {
  color: var(--el-color-primary);
  margin-bottom: 20px;
}
</style>
