<template>
  <div class="categories-page">
    <div class="page-header">
      <h1>💝 分类相册</h1>
      <p>AI 自动归档的甜蜜回忆</p>
    </div>

    <div class="category-grid">
      <div 
        v-for="cat in categories" 
        :key="cat.id"
        class="category-card"
        @click="goToCategory(cat.name)"
      >
        <div class="cat-icon" :style="{ background: getCatColor(cat.id) }">
          {{ cat.icon }}
        </div>
        <div class="cat-info">
          <div class="cat-name">{{ cat.name }}</div>
          <div class="cat-count">{{ cat.message_count }} 条记录</div>
        </div>
        <el-icon class="arrow"><ArrowRight /></el-icon>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowRight } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { getCategoryStats } from '../api/category'

const router = useRouter()
const categories = ref([])

const catColors = [
  'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
  'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
  'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
  'linear-gradient(135deg, #fff1eb 0%, #ace0f9 100%)',
  'linear-gradient(135deg, #d299c2 0%, #fef9d7 100%)',
  'linear-gradient(135deg, #ffd1ff 0%, #fad0c4 100%)',
  'linear-gradient(135deg, #ebc0fd 0%, #d9ded8 100%)',
  'linear-gradient(135deg, #f6d365 0%, #fda085 100%)'
]

const getCatColor = (id) => {
  return catColors[(id - 1) % catColors.length]
}

const goToCategory = (name) => {
  router.push(`/category/${encodeURIComponent(name)}`)
}

const loadStats = async () => {
  try {
    const res = await getCategoryStats()
    categories.value = res.categories
  } catch (e) {
    ElMessage.error('加载分类失败')
  }
}

onMounted(() => {
  loadStats()
})
</script>

<style scoped>
.categories-page {
  padding: 20px 16px;
  min-height: 100%;
}

.page-header {
  text-align: center;
  margin-bottom: 24px;
}
.page-header h1 {
  font-size: 24px;
  color: var(--el-color-primary);
  margin-bottom: 4px;
}
.page-header p {
  font-size: 13px;
  color: var(--text-secondary);
}

.category-grid {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.category-card {
  background: white;
  border-radius: 16px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 14px;
  box-shadow: var(--shadow-soft);
  cursor: pointer;
  transition: all 0.2s ease;
}
.category-card:active {
  transform: scale(0.98);
}
.category-card:hover {
  box-shadow: 0 4px 16px rgba(255, 107, 157, 0.15);
}

.cat-icon {
  width: 52px;
  height: 52px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  flex-shrink: 0;
}

.cat-info {
  flex: 1;
}
.cat-name {
  font-size: 16px;
  font-weight: 500;
  color: var(--text-primary);
  margin-bottom: 4px;
}
.cat-count {
  font-size: 12px;
  color: var(--text-secondary);
}

.arrow {
  color: var(--text-secondary);
  font-size: 18px;
}
</style>
