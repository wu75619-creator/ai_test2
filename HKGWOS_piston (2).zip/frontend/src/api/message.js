import request from '../utils/request'

/**
 * 获取历史消息列表
 * @param {string} order - asc正序/desc倒序，默认asc
 */
export function getMessages(order = 'asc') {
  return request({
    url: '/api/messages',
    method: 'get',
    params: { order }
  })
}

/**
 * 发送新消息（支持文字/图片/语音，FormData格式）
 * @param {Object} data
 * @param {string} data.sender_role - 男主/女主
 * @param {string} data.text_content - 文本内容
 * @param {boolean} data.is_ai_auto - 是否AI自动分类
 * @param {string} data.manual_category - 手动选择的分类名称
 * @param {File[]} data.images - 图片文件列表
 * @param {File} data.voice - 语音文件
 */
export function sendMessage(data) {
  const formData = new FormData()
  formData.append('sender_role', data.sender_role)
  formData.append('is_ai_auto', data.is_ai_auto)
  
  if (data.text_content) {
    formData.append('text_content', data.text_content)
  }
  if (!data.is_ai_auto && data.manual_category) {
    formData.append('manual_category', data.manual_category)
  }
  // 多图
  if (data.images && data.images.length > 0) {
    data.images.forEach(img => {
      formData.append('images', img)
    })
  }
  // 语音
  if (data.voice) {
    formData.append('voice', data.voice)
  }

  return request({
    url: '/api/messages',
    method: 'post',
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    timeout: 30000  // 上传文件超时时间长一点
  })
}
