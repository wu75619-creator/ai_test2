import request from '../utils/request'

/**
 * 获取历史消息列表
 */
export function getMessages() {
  return request({
    url: '/api/messages',
    method: 'get'
  })
}

/**
 * 发送新消息
 * @param {Object} data 
 * @param {string} data.sender_role - 发送人角色：男主/女主
 * @param {string} data.text_content - 消息内容
 */
export function sendMessage(data) {
  return request({
    url: '/api/messages',
    method: 'post',
    data
  })
}
