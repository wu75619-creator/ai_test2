import request from '../utils/request'

/**
 * 获取所有分类列表
 */
export function getCategories() {
  return request({
    url: '/api/categories',
    method: 'get'
  })
}

/**
 * 获取分类下的消息
 * @param {string} categoryName 分类名称
 * @param {number} year 年份，可选
 * @param {number} month 月份，可选
 */
export function getCategoryMessages(categoryName, year, month) {
  return request({
    url: `/api/categories/${encodeURIComponent(categoryName)}`,
    method: 'get',
    params: { year, month }
  })
}

/**
 * 获取分类统计概览
 */
export function getCategoryStats() {
  return request({
    url: '/api/categories/stats/overview',
    method: 'get'
  })
}
