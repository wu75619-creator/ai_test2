from sqlalchemy import Column, String, Text, Integer, Float, Boolean, DateTime, ForeignKey, JSON, Date
from sqlalchemy.orm import relationship, declarative_base
from datetime import datetime
import uuid

Base = declarative_base()


def generate_uuid():
    return str(uuid.uuid4())


class AppSetting(Base):
    """应用设置表 - 单例存储全局配置"""
    __tablename__ = "app_settings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    setup_completed = Column(Boolean, default=False, comment="是否完成首次引导")
    male_nickname = Column(String(50), default="男朋友", comment="男主昵称")
    female_nickname = Column(String(50), default="女朋友", comment="女主昵称")
    male_avatar = Column(String(500), comment="男主头像URL")
    female_avatar = Column(String(500), comment="女主头像URL")
    love_start_date = Column(Date, comment="在一起的日期")
    access_password = Column(String(100), default="", comment="访问密码，空则不启用")
    couple_title = Column(String(100), default="我们的恋爱日记本", comment="情侣标题")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class User(Base):
    """用户表 - 男主/女主双角色"""
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    role = Column(String(20), nullable=False, unique=True, comment="male=男主, female=女主")
    nickname = Column(String(50), nullable=False)
    avatar_url = Column(String(500))
    theme_color = Column(String(20), default="#ff6b9d", comment="气泡专属配色")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages = relationship("Message", back_populates="sender")


class Category(Base):
    """分类表 - 支持系统预置 + 用户自定义"""
    __tablename__ = "categories"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    code = Column(String(50), unique=True, nullable=False, comment="分类编码")
    name = Column(String(50), nullable=False, comment="分类名称")
    icon = Column(String(100), comment="分类图标emoji")
    color = Column(String(20), comment="分类主题色")
    description = Column(String(200))
    sort_order = Column(Integer, default=0)
    is_system = Column(Boolean, default=True, comment="是否系统预置")
    created_at = Column(DateTime, default=datetime.utcnow)

    messages = relationship("Message", back_populates="category", foreign_keys="Message.main_category_id")


class Message(Base):
    """消息记录表 - 核心表"""
    __tablename__ = "messages"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    sender_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # 消息类型与内容
    message_type = Column(String(20), nullable=False, default="text", comment="text/image/voice/video")
    text_content = Column(Text, comment="文字内容/图片配文/语音转写")
    media_urls = Column(JSON, comment="图片URL数组")
    voice_url = Column(String(500), comment="语音文件URL")
    voice_duration = Column(Integer, comment="语音时长(秒)")
    video_url = Column(String(500), comment="视频文件URL")
    video_duration = Column(Integer, comment="视频时长(秒)")
    media_size = Column(Integer, comment="媒体文件大小(bytes)")
    voice_transcript = Column(Text, comment="语音ASR转文字结果")

    # 分类相关
    main_category_id = Column(String(36), ForeignKey("categories.id", ondelete="SET NULL"), comment="主分类")
    tags = Column(JSON, comment="子标签数组")
    ai_summary = Column(String(500), comment="AI生成的温柔小结")
    ai_confidence = Column(Float, comment="AI分类置信度 0-1")
    ai_processed = Column(Boolean, default=False, comment="AI是否完成处理")
    ai_processed_at = Column(DateTime, comment="AI处理完成时间")

    # 时间与状态
    sent_at = Column(DateTime, default=datetime.utcnow, nullable=False, comment="发送时间")
    hour_of_day = Column(Integer, comment="发送小时0-23，用于统计")
    is_deleted = Column(Boolean, default=False, comment="软删除标记")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    sender = relationship("User", back_populates="messages")
    category = relationship("Category", back_populates="messages", foreign_keys=[main_category_id])
