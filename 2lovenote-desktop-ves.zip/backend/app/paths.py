"""
路径适配模块 - 兼容开发环境、PyInstaller打包环境、跨平台数据目录
- 程序资源（前端dist、内置静态文件）：从 exe/源码所在目录读取
- 用户数据（数据库、上传文件）：写入系统用户数据目录
  - Windows: %APPDATA%/LoveNote  (C:/Users/<user>/AppData/Roaming/LoveNote)
  - macOS:   ~/Library/Application Support/LoveNote
  - Linux:   ~/.local/share/LoveNote
"""
import os
import sys
from pathlib import Path


def is_pyinstaller() -> bool:
    """判断是否运行在 PyInstaller 打包后的环境中"""
    return getattr(sys, 'frozen', False)


def get_resource_dir() -> Path:
    """
    获取程序静态资源目录（只读，随exe/源码分发）
    - PyInstaller: sys._MEIPASS (临时解压目录)
    - 源码运行: backend/ 的父目录（即项目根目录）
    """
    if is_pyinstaller():
        return Path(sys._MEIPASS)
    # 源码运行：此文件在 backend/app/paths.py，资源根目录是 backend/../frontend/dist
    # 即 backend 的父目录
    return Path(__file__).resolve().parent.parent.parent


def get_frontend_dist_dir() -> Path:
    """前端 dist 目录路径"""
    return get_resource_dir() / "frontend" / "dist"


def get_data_dir() -> Path:
    """
    获取用户数据目录（可写，跨平台）
    Windows: %APPDATA%\\LoveNote
    macOS:   ~/Library/Application Support/LoveNote
    Linux:   ~/.local/share/LoveNote
    """
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        data_dir = Path(base) / "LoveNote"
    elif sys.platform == "darwin":
        data_dir = Path.home() / "Library" / "Application Support" / "LoveNote"
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
        data_dir = Path(base) / "LoveNote"

    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_database_path() -> Path:
    """SQLite 数据库文件路径"""
    db_path = get_data_dir() / "love_diary.db"
    return db_path


def get_database_url() -> str:
    """SQLAlchemy 数据库连接字符串"""
    return f"sqlite:///{get_database_path().as_posix()}"


def get_uploads_dir() -> Path:
    """上传文件存储目录（图片/语音/视频）"""
    uploads = get_data_dir() / "uploads"
    uploads.mkdir(parents=True, exist_ok=True)
    return uploads


def get_upload_url_prefix() -> str:
    """StaticFiles 挂载的 URL 前缀"""
    return "/uploads"


def get_uploads_mount_dir() -> str:
    """传给 StaticFiles 的本地目录路径（字符串）"""
    return str(get_uploads_dir())
