import random
import os
import base64
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()

AI_MOCK_MODE = os.getenv("AI_MOCK", "true").lower() == "true"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

# 系统预设分类关键词与模板
SYSTEM_CATEGORIES_DATA = [
    {"code": "food", "name": "美食探店存档", "icon": "🍜", "color": "#ff9f43",
     "tags": ["奶茶", "火锅", "探店", "甜品", "烧烤", "日料", "咖啡", "好吃", "餐厅", "美食"],
     "keywords": ["吃", "饭", "奶茶", "火锅", "好吃", "餐厅", "探店", "喝", "咖啡", "饿", "外卖", "蛋糕", "烧烤", "日料", "甜品"]},
    {"code": "travel", "name": "旅行&外出约会", "icon": "✈️", "color": "#54a0ff",
     "tags": ["约会", "逛街", "看电影", "公园", "旅行", "景点", "散步", "出门", "电影"],
     "keywords": ["约会", "出门", "玩", "旅行", "逛街", "电影", "走", "公园", "机场", "高铁", "酒店", "风景", "景区"]},
    {"code": "couple_photo", "name": "情侣合照存档", "icon": "📸", "color": "#ff6b9d",
     "tags": ["合照", "自拍", "同框", "纪念照", "合影"],
     "keywords": ["照片", "合照", "自拍", "拍", "合影", "拍照", "相机"]},
    {"code": "daily_fun", "name": "趣味日常存档", "icon": "😂", "color": "#feca57",
     "tags": ["搞笑", "互怼", "可爱", "梗", "段子", "表情包"],
     "keywords": ["哈哈", "搞笑", "傻", "梗", "笑死", "笑死我了", "逗", "可爱", "哈哈哈"]},
    {"code": "nickname", "name": "专属昵称词典", "icon": "💌", "color": "#c8d6e5",
     "tags": ["昵称", "代号", "专属梗", "暗号"],
     "keywords": ["宝宝", "宝贝", "猪猪", "傻瓜", "笨蛋", "亲爱的", "老公", "老婆"]},
    {"code": "deep_talk", "name": "深度谈心存档", "icon": "💬", "color": "#5f27cd",
     "tags": ["谈心", "未来", "爱意", "三观", "告白", "想你"],
     "keywords": ["爱你", "喜欢", "未来", "谈心", "心里话", "想你", "告白", "爱", "永远", "一辈子"]},
    {"code": "conflict", "name": "矛盾复盘成长", "icon": "💡", "color": "#ee5253",
     "tags": ["矛盾", "吵架", "反思", "和解", "约定", "对不起"],
     "keywords": ["对不起", "错了", "吵架", "生气", "反思", "抱歉", "原谅", "不开心", "难过", "委屈"]},
    {"code": "voice", "name": "语音专属存档", "icon": "🎤", "color": "#00d2d3",
     "tags": ["语音", "告白", "晚安", "早安"],
     "keywords": []},
]

SUMMARY_TEMPLATES = {
    "food": [
        "今天又和宝贝打卡了好吃的，又是被美食和爱意填满的一天呀~",
        "两个人一起吃的饭，总是格外香甜，干饭人情侣的甜蜜瞬间~",
        "记录下这次一起尝的美味，下次还要一起来吃哦😋"
    ],
    "travel": [
        "和你一起走过的路，都是最美的风景，今天的约会超开心！",
        "手牵手出门的日子，连风都是甜的，又是值得纪念的约会日~",
        "去哪里不重要，重要的是身边是你，今天也超爱你呀🥰"
    ],
    "couple_photo": [
        "咔嚓！留下我们的同框瞬间，每一张合照都是爱的证明~",
        "和你的每一张合照，都要好好收藏起来，以后慢慢看",
        "最幸福的事就是和你一起拍好多好多照片📸"
    ],
    "daily_fun": [
        "今天也是和宝互怼欢乐多的一天，有你在每天都好好笑哈哈哈",
        "奇奇怪怪可可爱爱的日常，只有我们懂的小乐趣~",
        "和你在一起连无聊都变得有趣，这就是爱情的魔力吧😂"
    ],
    "nickname": [
        "发现了我们的专属小暗号，这是只属于我们两个人的秘密~",
        "又多了一个可爱的专属昵称，以后就这么叫你啦😜",
        "专属昵称库又更新啦，这些暗号只有我们懂"
    ],
    "deep_talk": [
        "今晚和你说了好多心里话，感觉我们的心又更近了一步",
        "谢谢你愿意和我分享所有想法，我们要一直这样坦诚下去呀",
        "和你聊完感觉对未来更有期待了，我们一起加油💪"
    ],
    "conflict": [
        "虽然有小矛盾，但说开了就好，我们又一起成长了一点点",
        "谢谢你愿意包容我，我们约定好下次都不冷战好不好",
        "每一次和解都让我们更懂彼此，感情也会越来越好的💡"
    ],
    "voice": [
        "你的语音我要反复听好多遍，声音真的太好听啦🎤",
        "记录下你的声音，想你的时候就拿出来听一听",
        "软软的语音真的太治愈了，所有疲惫都没啦"
    ],
}

DEFAULT_SUMMARIES = [
    "今天也是和你在一起的甜蜜一天~ 💕",
    "又记录下了一个和你的美好瞬间~",
    "平凡日子里的小确幸，因为有你而特别✨"
]


def encode_image(image_path: str) -> str:
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode('utf-8')


def _get_all_categories(db=None) -> list:
    """从DB获取所有分类（系统+自定义），如无DB则返回系统分类"""
    if db is not None:
        from ..models import Category
        db_cats = db.query(Category).order_by(Category.sort_order, Category.created_at).all()
        return [
            {"code": c.code, "name": c.name, "icon": c.icon, "color": c.color,
             "tags": [], "is_system": c.is_system}
            for c in db_cats
        ]
    return SYSTEM_CATEGORIES_DATA


def _find_mock_category(text_content: str, message_type: str, image_paths: list, db=None) -> dict:
    """Mock模式：关键词匹配分类"""
    if message_type == "voice":
        return next(c for c in SYSTEM_CATEGORIES_DATA if c["code"] == "voice")

    content = text_content or ""

    # 先匹配系统分类关键词
    for cat in SYSTEM_CATEGORIES_DATA:
        if cat["code"] == "voice":
            continue
        for kw in cat.get("keywords", []):
            if kw in content:
                return cat

    # 有图片默认到daily_fun或者couple_photo
    if image_paths and len(image_paths) > 0:
        return random.choice([
            next(c for c in SYSTEM_CATEGORIES_DATA if c["code"] == "daily_fun"),
            next(c for c in SYSTEM_CATEGORIES_DATA if c["code"] == "couple_photo"),
            next(c for c in SYSTEM_CATEGORIES_DATA if c["code"] == "food"),
        ])

    return random.choice(SYSTEM_CATEGORIES_DATA[:7])  # 排除voice


def mock_ai_process(text_content: str, message_type: str = "text",
                    image_paths: List[str] = None, db=None) -> Dict[str, Any]:
    cat = _find_mock_category(text_content, message_type, image_paths, db)
    category_code = cat["code"]

    tag_pool = cat.get("tags", []) or ["记录", "甜蜜"]
    tag_count = random.randint(1, min(3, len(tag_pool)))
    tags = random.sample(tag_pool, tag_count)

    summaries = SUMMARY_TEMPLATES.get(category_code, DEFAULT_SUMMARIES)
    summary = random.choice(summaries)

    return {
        "main_category_code": category_code,
        "main_category_name": cat["name"],
        "tags": tags,
        "ai_summary": summary,
        "confidence": round(random.uniform(0.75, 0.98), 2),
        "processed_at": datetime.utcnow().isoformat()
    }


def real_ai_process(text_content: str, message_type: str = "text",
                    image_paths: List[str] = None, db=None) -> Dict[str, Any]:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_API_KEY, base_url=OPENAI_BASE_URL)

        all_cats = _get_all_categories(db)
        categories_desc = "\n".join(
            ["- %s: %s" % (c['code'], c['name']) for c in all_cats]
        )

        prompt = """你是一个情侣恋爱日记的AI分类助手。请根据用户发送的内容，从以下分类中选择最合适的一个：

%s

请返回JSON格式（不要其他内容）：
{
  "category_code": "分类code，必须是上面之一",
  "tags": ["1-3个简短标签"],
  "summary": "1-2句温柔治愈的小结，语气甜蜜，适合情侣看，50字以内"
}

用户发送的内容：%s""" % (categories_desc, text_content or "(无文本，只有图片/媒体)")

        content = [{"type": "text", "text": prompt}]

        if image_paths:
            for img_path in image_paths:
                try:
                    b64_img = encode_image(img_path)
                    ext = img_path.split('.')[-1].lower()
                    mime_map = {'jpg': 'jpeg', 'jpeg': 'jpeg', 'png': 'png', 'gif': 'gif', 'webp': 'webp'}
                    mime_type = "image/%s" % mime_map.get(ext, 'jpeg')
                    content.append({
                        "type": "image_url",
                        "image_url": {"url": "data:%s;base64,%s" % (mime_type, b64_img)}
                    })
                except Exception as e:
                    print("图片编码失败: %s" % e)

        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "你是一个专业的情侣日记AI助手，只返回JSON格式结果。"},
                {"role": "user", "content": content}
            ],
            temperature=0.7,
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)

        valid_codes = [c["code"] for c in all_cats]
        category_code = result.get("category_code", "daily_fun")
        if category_code not in valid_codes:
            category_code = "daily_fun"

        selected = next(c for c in all_cats if c["code"] == category_code)

        return {
            "main_category_code": category_code,
            "main_category_name": selected["name"],
            "tags": result.get("tags", [])[:3],
            "ai_summary": result.get("summary", "今天也是甜蜜的一天呀~"),
            "confidence": 0.9,
            "processed_at": datetime.utcnow().isoformat()
        }
    except Exception as e:
        print("OpenAI调用失败，降级到Mock: %s" % e)
        return mock_ai_process(text_content, message_type, image_paths, db)


def process_message_content(
    text_content: str = "",
    message_type: str = "text",
    image_paths: List[str] = None,
    manual_category: Optional[str] = None,
    db=None
) -> Dict[str, Any]:
    """处理消息分类，支持手动指定分类（包括自定义分类）"""
    if manual_category:
        # 查找该分类（可能是系统分类或自定义分类）
        all_cats = _get_all_categories(db)
        found = next((c for c in all_cats if c["code"] == manual_category), None)
        if found:
            return {
                "main_category_code": manual_category,
                "main_category_name": found["name"],
                "tags": ["手动分类"],
                "ai_summary": None,
                "confidence": 1.0,
                "processed_at": datetime.utcnow().isoformat()
            }

    if AI_MOCK_MODE:
        return mock_ai_process(text_content, message_type, image_paths, db)
    else:
        return real_ai_process(text_content, message_type, image_paths, db)
