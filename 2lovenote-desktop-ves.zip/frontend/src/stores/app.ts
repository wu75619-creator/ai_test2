import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getSettings, type AppSettings } from '../api'

export const useAppStore = defineStore('app', () => {
  const settings = ref<AppSettings | null>(null)
  const authenticated = ref(false)
  const loveDays = ref<number | null>(null)

  async function loadSettings() {
    try {
      settings.value = await getSettings()
    } catch (e) {
      console.error('加载设置失败', e)
    }
  }

  function setAuthenticated(v: boolean) {
    authenticated.value = v
    if (v) sessionStorage.setItem('auth_token', 'ok')
  }

  function checkAuth() {
    authenticated.value = !!sessionStorage.getItem('auth_token')
    return authenticated.value
  }

  return { settings, authenticated, loveDays, loadSettings, setAuthenticated, checkAuth }
})
