import axios from 'axios'

// In production, API is same origin (served by backend). In dev, uses vite proxy.
const API_BASE = import.meta.env.DEV ? '' : ''

const request = axios.create({
  baseURL: `${API_BASE}/api`,
  timeout: 30000,
})

request.interceptors.request.use(config => {
  const token = sessionStorage.getItem('auth_token')
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`
  }
  return config
})

request.interceptors.response.use(
  response => response.data,
  error => {
    console.error('API请求错误:', error)
    return Promise.reject(error)
  }
)

export default request

// Helper: get full media URL (handles dev/prod)
export function getMediaUrl(path: string): string {
  if (!path) return ''
  if (path.startsWith('http')) return path
  if (import.meta.env.DEV) {
    return path // dev uses vite proxy
  }
  return path // production: same origin
}
