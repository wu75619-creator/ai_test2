<template>
  <div id="app">
    <!-- Password Gate -->
    <div v-if="showPasswordGate" class="gate-overlay">
      <div class="gate-card fade-in-up">
        <div class="gate-icon">🔒</div>
        <h3>我们的秘密空间</h3>
        <p>输入密码进入恋爱日记本</p>
        <el-input
          v-model="passwordInput"
          type="password"
          placeholder="请输入密码"
          size="large"
          show-password
          @keyup.enter="doVerify"
          style="margin: 20px 0"
        />
        <el-button type="primary" size="large" @click="doVerify" style="width:100%" :loading="verifying">
          进入
        </el-button>
      </div>
    </div>

    <!-- Onboarding Modal -->
    <div v-else-if="showOnboarding" class="gate-overlay">
      <div class="onboarding-card fade-in-up">
        <div class="onboarding-header">
          <span class="heart-big">💕</span>
          <h2>欢迎来到我们的恋爱日记本</h2>
          <p class="sub">首次使用，请完成简单设置</p>
        </div>

        <div class="onboarding-form">
          <div class="form-row">
            <label>👦 他的昵称</label>
            <el-input v-model="onboardForm.maleName" placeholder="男朋友" size="large" />
          </div>
          <div class="form-row">
            <label>👧 她的昵称</label>
            <el-input v-model="onboardForm.femaleName" placeholder="女朋友" size="large" />
          </div>
          <div class="form-row">
            <label>📅 在一起的日期</label>
            <el-date-picker
              v-model="onboardForm.startDate"
              type="date"
              placeholder="选择你们在一起的第一天"
              format="YYYY-MM-DD"
              value-format="YYYY-MM-DD"
              size="large"
              style="width:100%"
            />
          </div>
          <div class="form-row">
            <label>🔐 访问密码（可选）</label>
            <el-input
              v-model="onboardForm.password"
              type="password"
              placeholder="设置密码保护私密内容，留空则不设密码"
              size="large"
              show-password
            />
          </div>
        </div>

        <el-button type="primary" size="large" @click="completeOnboarding"
          style="width:100%;margin-top:8px" :loading="submitting">
          开始记录我们的故事 ❤️
        </el-button>
      </div>
    </div>

    <!-- Main App -->
    <template v-else>
      <!-- Header -->
      <header class="app-header">
        <div class="header-content">
          <span class="logo">💕</span>
          <span class="title">{{ pageTitle }}</span>
          <el-dropdown trigger="click" @command="handleCmd">
            <el-icon class="settings-btn" :size="20"><Setting /></el-icon>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="settings">⚙️ 设置</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- Floating Love Days Widget -->
      <div v-if="stats && stats.love_days !== null" class="love-days-float" @click="showDaysDetail = true">
        <div class="days-number">{{ stats.love_days }}</div>
        <div class="days-label">天</div>
        <div class="days-hearts">💕</div>
      </div>

      <main class="main-content">
        <router-view v-slot="{ Component }">
          <transition name="page-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>

      <!-- Bottom Nav -->
      <nav class="bottom-nav">
        <router-link to="/" class="nav-item">
          <el-icon :size="22"><ChatDotRound /></el-icon>
          <span>聊天</span>
        </router-link>
        <router-link to="/category" class="nav-item">
          <el-icon :size="22"><FolderOpened /></el-icon>
          <span>相册</span>
        </router-link>
        <router-link to="/timeline" class="nav-item">
          <el-icon :size="22"><DataLine /></el-icon>
          <span>时光</span>
        </router-link>
      </nav>

      <!-- Days Detail Popup -->
      <el-dialog v-model="showDaysDetail" width="320px" align-center :show-close="true" class="days-dialog">
        <div class="days-detail">
          <div class="days-big">
            <span class="num">{{ stats?.love_days || 0 }}</span>
            <span class="unit">天</span>
          </div>
          <p class="since">从 {{ stats?.love_start_date || '---' }} 开始</p>
          <div class="mini-stats">
            <div class="mini-stat">
              <div class="mini-num">{{ stats?.total_messages || 0 }}</div>
              <div class="mini-label">条消息</div>
            </div>
            <div class="mini-stat">
              <div class="mini-num">{{ stats?.image_count || 0 }}</div>
              <div class="mini-label">张照片</div>
            </div>
            <div class="mini-stat">
              <div class="mini-num">{{ stats?.video_count + stats?.voice_count || 0 }}</div>
              <div class="mini-label">条音视频</div>
            </div>
          </div>
        </div>
      </el-dialog>

      <!-- Settings Dialog -->
      <el-dialog v-model="showSettings" title="设置" width="340px" align-center>
        <div class="settings-form">
          <div class="form-row">
            <label>他的昵称</label>
            <el-input v-model="settingsForm.maleName" size="default" />
          </div>
          <div class="form-row">
            <label>她的昵称</label>
            <el-input v-model="settingsForm.femaleName" size="default" />
          </div>
          <div class="form-row">
            <label>在一起日期</label>
            <el-date-picker v-model="settingsForm.startDate" type="date"
              format="YYYY-MM-DD" value-format="YYYY-MM-DD" style="width:100%" />
          </div>
          <div class="form-row">
            <label>修改密码</label>
            <el-input v-model="settingsForm.password" type="password" placeholder="留空则不修改" show-password />
          </div>
        </div>
        <template #footer>
          <el-button @click="showSettings = false">取消</el-button>
          <el-button type="primary" @click="saveSettings" :loading="savingSettings">保存</el-button>
        </template>
      </el-dialog>
    </template>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import { useAppStore } from './stores/app'
import { getSettings, updateSettings, verifyPassword, checkPasswordRequired, getStatsOverview, type StatsOverview } from './api'
import { ElMessage } from 'element-plus'
import { Setting, ChatDotRound, FolderOpened, DataLine } from '@element-plus/icons-vue'

const route = useRoute()
const store = useAppStore()

const pageTitle = computed(() => {
  const p = route.path
  if (p === '/') return store.settings?.couple_title || '聊天记录'
  if (p.startsWith('/category')) return '分类相册'
  if (p === '/timeline') return '恋爱时光轴'
  return '我们的日记本'
})

// Password gate
const showPasswordGate = ref(false)
const passwordInput = ref('')
const verifying = ref(false)

// Onboarding
const showOnboarding = ref(false)
const onboardForm = ref({ maleName: '男朋友', femaleName: '女朋友', startDate: '', password: '' })
const submitting = ref(false)

// Settings
const showSettings = ref(false)
const settingsForm = ref({ maleName: '', femaleName: '', startDate: '', password: '' })
const savingSettings = ref(false)

// Stats
const stats = ref<StatsOverview | null>(null)
const showDaysDetail = ref(false)

async function loadStats() {
  try {
    stats.value = await getStatsOverview()
  } catch (e) { console.error(e) }
}

async function init() {
  await store.loadSettings()
  if (!store.settings) return

  // Check password
  try {
    const pr = await checkPasswordRequired()
    if (pr.required && !store.checkAuth()) {
      showPasswordGate.value = true
      return
    }
  } catch (e) { /* no password required */ }

  if (!store.settings.setup_completed) {
    showOnboarding.value = true
  } else {
    loadStats()
  }
}

async function doVerify() {
  if (!passwordInput.value) return
  verifying.value = true
  try {
    const r = await verifyPassword(passwordInput.value)
    if (r.ok) {
      store.setAuthenticated(true)
      showPasswordGate.value = false
      if (!store.settings?.setup_completed) {
        showOnboarding.value = true
      } else {
        loadStats()
      }
    } else {
      ElMessage.error('密码错误')
    }
  } catch (e) {
    ElMessage.error('验证失败')
  } finally {
    verifying.value = false
  }
}

async function completeOnboarding() {
  if (!onboardForm.value.maleName.trim() || !onboardForm.value.femaleName.trim()) {
    ElMessage.warning('请填写双方昵称')
    return
  }
  submitting.value = true
  try {
    await updateSettings({
      setup_completed: true,
      male_nickname: onboardForm.value.maleName.trim(),
      female_nickname: onboardForm.value.femaleName.trim(),
      love_start_date: onboardForm.value.startDate || '',
      access_password: onboardForm.value.password || ''
    })
    if (onboardForm.value.password) {
      sessionStorage.setItem('auth_token', 'ok')
    }
    await store.loadSettings()
    showOnboarding.value = false
    ElMessage.success('设置完成！开始记录吧 💕')
    loadStats()
  } catch (e) {
    ElMessage.error('设置失败，请重试')
  } finally {
    submitting.value = false
  }
}

function handleCmd(cmd: string) {
  if (cmd === 'settings') {
    if (store.settings) {
      settingsForm.value = {
        maleName: store.settings.male_nickname,
        femaleName: store.settings.female_nickname,
        startDate: store.settings.love_start_date || '',
        password: ''
      }
    }
    showSettings.value = true
  }
}

async function saveSettings() {
  savingSettings.value = true
  try {
    const payload: Record<string, any> = {
      male_nickname: settingsForm.value.maleName.trim(),
      female_nickname: settingsForm.value.femaleName.trim(),
      love_start_date: settingsForm.value.startDate || ''
    }
    if (settingsForm.value.password) {
      payload.access_password = settingsForm.value.password
    }
    await updateSettings(payload)
    await store.loadSettings()
    loadStats()
    showSettings.value = false
    ElMessage.success('设置已保存')
  } catch (e) {
    ElMessage.error('保存失败')
  } finally {
    savingSettings.value = false
  }
}

// Refresh stats when navigating
watch(() => route.path, () => {
  if (!showOnboarding.value && !showPasswordGate.value) loadStats()
})

onMounted(init)
</script>

<style scoped>
#app { min-height: 100vh; display: flex; flex-direction: column; background: #fff5f8; }

.gate-overlay {
  position: fixed; inset: 0; z-index: 1000;
  background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 50%, #ffecd2 100%);
  display: flex; align-items: center; justify-content: center;
  padding: 20px;
}
.gate-card {
  background: white; border-radius: 24px; padding: 40px 28px;
  width: 100%; max-width: 340px; text-align: center;
  box-shadow: 0 20px 60px rgba(255,107,157,0.2);
}
.gate-icon { font-size: 48px; margin-bottom: 12px; }
.gate-card h3 { font-size: 20px; color: #2d3436; margin-bottom: 6px; }
.gate-card p { color: #b2bec3; font-size: 14px; }

.onboarding-card {
  background: white; border-radius: 24px; padding: 32px 24px;
  width: 100%; max-width: 380px; max-height: 90vh; overflow-y: auto;
  box-shadow: 0 20px 60px rgba(255,107,157,0.2);
}
.onboarding-header { text-align: center; margin-bottom: 20px; }
.heart-big { font-size: 48px; display: block; animation: heartBeat 1.5s infinite; }
.onboarding-header h2 { font-size: 20px; margin-top: 8px; color: #2d3436; }
.onboarding-header .sub { font-size: 13px; color: #b2bec3; margin-top: 4px; }
.form-row { margin-bottom: 14px; }
.form-row label { display: block; font-size: 13px; color: #636e72; margin-bottom: 6px; font-weight: 500; }

.app-header {
  height: 52px; background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
  color: white; position: sticky; top: 0; z-index: 100;
  box-shadow: 0 2px 12px rgba(255,107,157,0.15);
}
.header-content {
  max-width: 768px; margin: 0 auto; height: 100%;
  display: flex; align-items: center; padding: 0 16px; gap: 8px;
}
.logo { font-size: 20px; }
.title { flex: 1; font-size: 17px; font-weight: 600; }
.settings-btn { cursor: pointer; opacity: 0.9; }

.love-days-float {
  position: fixed; top: 60px; right: 12px; z-index: 90;
  background: linear-gradient(135deg, #ff6b9d, #ff9a9e);
  color: white; border-radius: 50%;
  width: 56px; height: 56px;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  box-shadow: 0 4px 16px rgba(255,107,157,0.4);
  cursor: pointer;
  animation: heartBeat 3s infinite;
}
.days-number { font-size: 16px; font-weight: 800; line-height: 1; }
.days-label { font-size: 10px; opacity: 0.9; }
.days-hearts { position: absolute; top: -6px; right: -2px; font-size: 12px; }

.main-content {
  flex: 1; max-width: 768px; width: 100%; margin: 0 auto;
  background: #fff9fb; padding-bottom: 70px;
}

.bottom-nav {
  position: fixed; bottom: 0; left: 0; right: 0;
  height: 60px; background: white;
  display: flex; justify-content: space-around; align-items: center;
  box-shadow: 0 -2px 12px rgba(255,107,157,0.1);
  z-index: 100; max-width: 768px; margin: 0 auto;
  border-top: 1px solid #ffe3ee;
}
.nav-item {
  display: flex; flex-direction: column; align-items: center; gap: 2px;
  text-decoration: none; color: #b2bec3; font-size: 10px;
  padding: 6px 20px; border-radius: 12px;
  transition: all 0.3s;
}
.nav-item.router-link-active {
  color: #ff6b9d;
  background: linear-gradient(135deg, #fff0f5, #ffe3ee);
  transform: translateY(-2px);
}

.days-detail { text-align: center; padding: 8px 0; }
.days-big { margin-bottom: 12px; }
.days-big .num { font-size: 56px; font-weight: 800;
  background: linear-gradient(135deg, #ff6b9d, #ff9a9e);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.days-big .unit { font-size: 20px; color: #ff6b9d; margin-left: 4px; }
.since { color: #b2bec3; font-size: 13px; margin-bottom: 20px; }
.mini-stats { display: flex; gap: 12px; }
.mini-stat {
  flex: 1; background: #fff5f8; border-radius: 12px; padding: 12px 8px;
}
.mini-num { font-size: 22px; font-weight: 700; color: #ff6b9d; }
.mini-label { font-size: 11px; color: #b2bec3; margin-top: 2px; }

.page-fade-enter-active, .page-fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.page-fade-enter-from { opacity: 0; transform: translateX(10px); }
.page-fade-leave-to { opacity: 0; transform: translateX(-10px); }

@media (max-width: 768px) {
  .main-content { max-width: 100%; }
}
</style>
