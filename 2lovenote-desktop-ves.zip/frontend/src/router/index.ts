import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', name: 'Chat', component: () => import('../views/ChatView.vue'), meta: { title: '聊天记录' } },
  { path: '/category', name: 'Category', component: () => import('../views/CategoryView.vue'), meta: { title: '分类相册' } },
  { path: '/timeline', name: 'Timeline', component: () => import('../views/TimelineView.vue'), meta: { title: '恋爱时间轴' } },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior() {
    return { top: 0 }
  }
})

export default router
