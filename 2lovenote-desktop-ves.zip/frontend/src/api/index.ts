import request from '../utils/request'

export interface Message {
  id: string
  sender_id: string
  sender_role: 'male' | 'female'
  sender_nickname: string
  sender_color?: string
  message_type: 'text' | 'image' | 'voice' | 'video'
  text_content: string
  media_urls?: string[]
  voice_url?: string
  voice_duration?: number
  video_url?: string
  video_duration?: number
  tags: string[]
  ai_summary: string | null
  ai_confidence?: number
  category_code?: string
  category_name?: string
  category_icon?: string
  category_color?: string
  sent_at: string
  ai_processed: boolean
}

export interface Category {
  id: string
  code: string
  name: string
  icon: string
  color: string
  description: string
  is_system: boolean
}

export interface AppSettings {
  setup_completed: boolean
  male_nickname: string
  female_nickname: string
  love_start_date: string | null
  couple_title: string
  has_password: boolean
  male_color: string
  female_color: string
}

export interface StatsOverview {
  love_days: number | null
  love_start_date: string | null
  total_messages: number
  male_count: number
  female_count: number
  image_count: number
  voice_count: number
  video_count: number
  male_nickname: string
  female_nickname: string
  categories: Record<string, { name: string; icon: string; count: number; color: string }>
  couple_title: string
}

export interface PeriodStats {
  period_label: string
  period_start: string
  period_end: string
  total: number
  male_count: number
  female_count: number
  hour_distribution: number[]
  peak_hour: number
  peak_label: string
  category_distribution: Record<string, number>
  day_stats: Record<string, { total: number; male: number; female: number }>
  type_distribution: Record<string, number>
}

// ========== Messages ==========
export const getMessages = () => request.get<any, Message[]>('/messages')

export interface CreateMessageParams {
  sender_role: 'male' | 'female'
  text_content?: string
  is_ai_auto: boolean
  manual_category?: string
  voice_duration?: number
  video_duration?: number
  images?: File[]
  voice?: File | null
  video?: File | null
}

export const createMessage = async (params: CreateMessageParams): Promise<Message> => {
  const formData = new FormData()
  formData.append('sender_role', params.sender_role)
  formData.append('text_content', params.text_content || '')
  formData.append('is_ai_auto', params.is_ai_auto ? 'true' : 'false')
  if (params.manual_category) formData.append('manual_category', params.manual_category)
  if (params.voice_duration) formData.append('voice_duration', String(params.voice_duration))
  if (params.video_duration) formData.append('video_duration', String(params.video_duration))
  if (params.images) {
    params.images.forEach(f => formData.append('images', f))
  }
  if (params.voice) formData.append('voice', params.voice)
  if (params.video) formData.append('video', params.video)

  const resp = await fetch(`/api/messages`, { method: 'POST', body: formData })
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({ detail: '发送失败' }))
    throw new Error(err.detail || '发送失败')
  }
  return resp.json()
}

export const deleteMessage = (id: string) => request.delete(`/messages/${id}`)

// ========== Categories ==========
export const getCategories = () => request.get<any, Category[]>('/categories')
export const getCategoryMessages = (code: string, year?: number, month?: number) =>
  request.get<any, Message[]>(`/categories/${code}/messages`, { params: { year, month } })
export const createCategory = (data: { name: string; icon?: string; color?: string; description?: string }) => {
  const form = new FormData()
  form.append('name', data.name)
  if (data.icon) form.append('icon', data.icon)
  if (data.color) form.append('color', data.color)
  if (data.description) form.append('description', data.description)
  return fetch('/api/categories', { method: 'POST', body: form }).then(r => {
    if (!r.ok) throw new Error('创建分类失败')
    return r.json()
  })
}
export const deleteCategory = (code: string) => request.delete(`/categories/${code}`)
export const updateCategory = (code: string, data: { name?: string; icon?: string; color?: string }) => {
  const form = new FormData()
  if (data.name) form.append('name', data.name)
  if (data.icon) form.append('icon', data.icon)
  if (data.color) form.append('color', data.color)
  return fetch(`/api/categories/${code}`, { method: 'PUT', body: form }).then(r => r.json())
}

// ========== Settings ==========
export const getSettings = () => request.get<any, AppSettings>('/settings')
export const updateSettings = (data: Record<string, any>) => {
  const form = new FormData()
  Object.entries(data).forEach(([k, v]) => {
    if (v !== undefined && v !== null) form.append(k, String(v))
  })
  return fetch('/api/settings', { method: 'POST', body: form }).then(r => r.json())
}
export const checkPasswordRequired = () => request.get<any, { required: boolean }>('/auth/password')
export const verifyPassword = (password: string) => {
  const form = new FormData()
  form.append('password', password)
  return fetch('/api/auth/verify', { method: 'POST', body: form }).then(r => r.json())
}

// ========== Stats ==========
export const getStatsOverview = () => request.get<any, StatsOverview>('/stats/overview')
export const getWeeklyStats = () => request.get<any, PeriodStats>('/stats/weekly')
export const getMonthlyStats = (year?: number, month?: number) =>
  request.get<any, PeriodStats>('/stats/monthly', { params: { year, month } })
