<template>
  <div class="category-page">
    <!-- Category Tabs -->
    <div class="category-tabs-wrapper">
      <div class="category-tabs" ref="tabsRef">
        <div
          v-for="cat in categories" :key="cat.code"
          class="cat-tab" :class="{ active: currentCategory === cat.code }"
          :style="{ '--cat-color': cat.color }"
          @click="selectCategory(cat.code)"
        >
          <span class="cat-icon">{{ cat.icon }}</span>
          <span class="cat-name">{{ cat.name }}</span>
          <el-icon v-if="!cat.is_system" class="delete-cat" @click.stop="confirmDelete(cat)">
            <Close />
          </el-icon>
        </div>
        <div class="cat-tab add-cat" @click="showAddDialog = true">
          <el-icon><Plus /></el-icon>
          <span>新建</span>
        </div>
      </div>
    </div>

    <!-- Filter bar -->
    <div class="filter-bar">
      <el-date-picker
        v-model="filterDate" type="month" placeholder="按月筛选"
        format="YYYY年MM月" value-format="YYYY-MM" clearable
        @change="loadMessages" style="width: 160px" size="small" />
      <div class="total-count">共 {{ messages.length }} 条</div>
    </div>

    <!-- Content -->
    <div class="content-area">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>加载中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">📭</div>
        <p>这个分类还没有记录</p>
        <p class="sub">去聊天页记录甜蜜吧~</p>
      </div>
      <div v-else class="cards-container">
        <div v-for="msg in messages" :key="msg.id" class="memory-card"
          :style="{ borderLeftColor: getCatColor(msg.category_code) }">
          <div class="card-header">
            <div class="sender-info">
              <div class="avatar" :class="msg.sender_role === 'female' ? 'female-avatar' : 'male-avatar'">
                {{ msg.sender_nickname.charAt(0) }}
              </div>
              <span class="nickname">{{ msg.sender_nickname }}</span>
            </div>
            <span class="date">{{ formatDate(msg.sent_at) }}</span>
          </div>

          <div v-if="msg.video_url" class="card-video">
            <video :src="getMediaUrl(msg.video_url)" controls preload="metadata" playsinline class="card-video-el" />
            <span v-if="msg.video_duration" class="vid-dur">{{ formatDur(msg.video_duration) }}</span>
          </div>

          <div v-if="msg.media_urls && msg.media_urls.length > 0" class="card-images"
            :class="{ single: msg.media_urls.length === 1 }">
            <el-image
              v-for="(url, idx) in msg.media_urls" :key="idx"
              :src="getMediaUrl(url)" class="card-image"
              :preview-src-list="msg.media_urls.map(u => getMediaUrl(u))"
              :initial-index="idx" fit="cover" preview-teleported />
          </div>

          <div v-if="msg.voice_url" class="card-voice" @click="playVoice(msg)">
            <el-icon><Microphone /></el-icon>
            <span>语音 {{ formatDur(msg.voice_duration || 5) }}</span>
            <el-icon v-if="playingId === msg.id" class="playing-anim"><VideoPlay /></el-icon>
          </div>
          <audio ref="audioEl" style="display:none" @ended="playingId = null" />

          <div v-if="msg.text_content" class="card-content">{{ msg.text_content }}</div>

          <div v-if="msg.tags && msg.tags.length > 0" class="card-tags">
            <el-tag v-for="tag in msg.tags" :key="tag" size="small" effect="plain" class="tag-item">#{{ tag }}</el-tag>
          </div>
          <div v-if="msg.ai_summary" class="ai-summary">
            <el-icon><MagicStick /></el-icon><span>{{ msg.ai_summary }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Add Category Dialog -->
    <el-dialog v-model="showAddDialog" title="新建自定义分类" width="320px" align-center>
      <div class="add-cat-form">
        <div class="form-row">
          <label>分类名称</label>
          <el-input v-model="newCat.name" placeholder="如：装修日记、养宠日常" maxlength="10" show-word-limit />
        </div>
        <div class="form-row">
          <label>选择图标</label>
          <div class="emoji-picker">
            <span v-for="emoji in emojiOptions" :key="emoji"
              class="emoji-opt" :class="{ selected: newCat.icon === emoji }"
              @click="newCat.icon = emoji">{{ emoji }}</span>
          </div>
        </div>
        <div class="form-row">
          <label>选择颜色</label>
          <div class="color-picker">
            <span v-for="c in colorOptions" :key="c" class="color-opt"
              :class="{ selected: newCat.color === c }"
              :style="{ background: c }" @click="newCat.color = c" />
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="doAddCategory" :loading="adding">创建</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Loading, MagicStick, Microphone, VideoPlay, Close, Plus } from '@element-plus/icons-vue'
import { getCategories, getCategoryMessages, createCategory, deleteCategory, type Category, type Message } from '../api'
import { getMediaUrl } from '../utils/request'

const categories = ref<Category[]>([])
const currentCategory = ref('')
const filterDate = ref('')
const messages = ref<Message[]>([])
const loading = ref(false)
const tabsRef = ref<HTMLElement | null>(null)
const audioEl = ref<HTMLAudioElement | null>(null)
const playingId = ref<string | null>(null)

// Add category
const showAddDialog = ref(false)
const adding = ref(false)
const newCat = ref({ name: '', icon: '💕', color: '#ff6b9d' })

const emojiOptions = ['💕','🌸','🎀','🏠','🐱','🎵','📚','🎮','🍰','🌙','⭐','🎁','🌈','🍀','🦋','🎨','🏃','🛍️','🎂','💝','🐶','🎬','✈️','🏖️']
const colorOptions = ['#ff6b9d','#ff9f43','#54a0ff','#5f27cd','#00d2d3','#10ac84','#ee5253','#feca57','#c8d6e5','#ff9ff3']

function getCatColor(code?: string) {
  return categories.value.find(c => c.code === code)?.color || '#ff6b9d'
}

function formatDate(ts: string) {
  const d = new Date(ts)
  return `${d.getFullYear()}年${d.getMonth()+1}月${d.getDate()}日`
}

function formatDur(s: number) {
  if (!s) return '0"'
  const m = Math.floor(s/60), sec = Math.floor(s%60)
  return m > 0 ? `${m}'${String(sec).padStart(2,'0')}"` : `${sec}"`
}

function selectCategory(code: string) {
  currentCategory.value = code
  loadMessages()
  // Scroll tab into view
  nextTick(() => {
    const el = tabsRef.value?.querySelector(`[data-code="${code}"]`) as HTMLElement
    el?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' })
  })
}

import { nextTick } from 'vue'

async function loadMessages() {
  if (!currentCategory.value) return
  loading.value = true
  try {
    let y: number | undefined, m: number | undefined
    if (filterDate.value) {
      const [yr, mo] = filterDate.value.split('-').map(Number)
      y = yr; m = mo
    }
    messages.value = await getCategoryMessages(currentCategory.value, y, m)
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

async function loadCategories() {
  try {
    categories.value = await getCategories()
    if (categories.value.length > 0 && !currentCategory.value) {
      currentCategory.value = categories.value[0].code
      await loadMessages()
    }
  } catch (e) { ElMessage.error('加载分类失败') }
}

function playVoice(msg: Message) {
  if (!msg.voice_url || !audioEl.value) return
  audioEl.value.src = getMediaUrl(msg.voice_url)
  audioEl.value.play()
  playingId.value = msg.id
}

async function doAddCategory() {
  if (!newCat.value.name.trim()) { ElMessage.warning('请输入分类名称'); return }
  adding.value = true
  try {
    await createCategory({ name: newCat.value.name.trim(), icon: newCat.value.icon, color: newCat.value.color })
    await loadCategories()
    showAddDialog.value = false
    newCat.value = { name: '', icon: '💕', color: '#ff6b9d' }
    ElMessage.success('分类创建成功')
  } catch (e: any) {
    ElMessage.error(e.message || '创建失败')
  } finally {
    adding.value = false
  }
}

async function confirmDelete(cat: Category) {
  try {
    await ElMessageBox.confirm(`确定删除"${cat.name}"分类吗？该分类下的内容将移至"趣味日常"。`, '确认删除', {
      type: 'warning', confirmButtonText: '删除', cancelButtonText: '取消'
    })
    await deleteCategory(cat.code)
    if (currentCategory.value === cat.code) currentCategory.value = ''
    await loadCategories()
    if (currentCategory.value) await loadMessages()
    ElMessage.success('已删除')
  } catch (e) { /* cancelled */ }
}

onMounted(loadCategories)
</script>

<style scoped>
.category-page { min-height: calc(100vh - 52px - 60px); background: #fff9fb; padding-bottom: 20px; }

.category-tabs-wrapper { background: white; border-bottom: 1px solid #ffe3ee; position: sticky; top: 52px; z-index: 10; }
.category-tabs {
  display: flex; overflow-x: auto; gap: 6px;
  padding: 10px 12px; scrollbar-width: none;
  -webkit-overflow-scrolling: touch;
}
.category-tabs::-webkit-scrollbar { display: none; }

.cat-tab {
  flex-shrink: 0; display: flex; align-items: center; gap: 4px;
  padding: 7px 12px; border-radius: 18px; background: #fff5f8;
  font-size: 12px; cursor: pointer; transition: all 0.25s;
  border: 1.5px solid transparent; position: relative; white-space: nowrap;
}
.cat-tab.active {
  background: var(--cat-color); color: white;
  transform: scale(1.04); box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.cat-icon { font-size: 14px; }
.delete-cat {
  margin-left: 2px; font-size: 12px; opacity: 0.7;
  background: rgba(255,255,255,0.3); border-radius: 50%; width: 14px; height: 14px;
  display: flex; align-items: center; justify-content: center;
}
.cat-tab.active .delete-cat:hover { opacity: 1; background: rgba(255,255,255,0.5); }
.add-cat {
  border: 1.5px dashed #ffb8d4; color: #ff6b9d; background: transparent;
}
.add-cat:hover { background: #fff0f5; }

.filter-bar { padding: 10px 16px; display: flex; align-items: center; justify-content: space-between; background: white; }
.total-count { font-size: 12px; color: #b2bec3; }

.content-area { padding: 16px; }
.loading-tip, .empty-tip { text-align: center; padding: 60px 20px; color: #b2bec3; }
.empty-icon { font-size: 48px; margin-bottom: 12px; }
.empty-tip .sub { font-size: 12px; margin-top: 4px; }

.cards-container { display: flex; flex-direction: column; gap: 14px; }
.memory-card {
  background: white; border-radius: 14px; padding: 14px;
  box-shadow: 0 2px 10px rgba(255,107,157,0.07);
  border-left: 4px solid #ff6b9d; transition: transform 0.2s;
}
.memory-card:active { transform: scale(0.99); }

.card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.sender-info { display: flex; align-items: center; gap: 7px; }
.avatar {
  width: 30px; height: 30px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: white; font-weight: bold; font-size: 13px;
}
.female-avatar { background: linear-gradient(135deg, #ff6b9d, #ff89b3); }
.male-avatar { background: linear-gradient(135deg, #54a0ff, #74b3ff); }
.nickname { font-size: 13px; font-weight: 500; }
.date { font-size: 11px; color: #b2bec3; }

.card-video { margin-bottom: 10px; position: relative; }
.card-video-el { max-width: 100%; max-height: 280px; border-radius: 8px; background: #000; }
.vid-dur {
  position: absolute; bottom: 6px; right: 6px;
  background: rgba(0,0,0,0.6); color: white; font-size: 10px;
  padding: 1px 5px; border-radius: 3px;
}

.card-images { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 10px; }
.card-images.single .card-image { width: 100%; max-width: 200px; height: 180px; }
.card-image { width: 90px; height: 90px; border-radius: 8px; overflow: hidden; }

.card-voice {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 6px 12px; background: #e3f0ff; color: #54a0ff;
  border-radius: 12px; font-size: 12px; margin-bottom: 8px; cursor: pointer;
}
.playing-anim { animation: pulse 0.8s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }

.card-content { font-size: 14px; line-height: 1.6; color: #2d3436; margin-bottom: 10px; }
.card-tags { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 8px; }
.tag-item { border-radius: 6px; font-size: 10px; }
.ai-summary {
  padding: 7px 10px; background: linear-gradient(135deg, #f8f5ff, #f0e7ff);
  border-radius: 8px; font-size: 11px; color: #5f27cd;
  display: flex; align-items: center; gap: 4px;
}

.add-cat-form .form-row { margin-bottom: 14px; }
.add-cat-form label { display: block; font-size: 13px; color: #636e72; margin-bottom: 6px; }
.emoji-picker { display: flex; flex-wrap: wrap; gap: 6px; }
.emoji-opt {
  width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
  border-radius: 8px; cursor: pointer; font-size: 18px;
  border: 2px solid transparent; transition: all 0.15s;
}
.emoji-opt.selected { border-color: #ff6b9d; background: #fff0f5; }
.color-picker { display: flex; gap: 6px; flex-wrap: wrap; }
.color-opt {
  width: 28px; height: 28px; border-radius: 50%; cursor: pointer;
  border: 3px solid transparent; transition: all 0.15s;
}
.color-opt.selected { border-color: #2d3436; transform: scale(1.1); }
</style>
