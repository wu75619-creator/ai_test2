<template>
  <div class="chat-page">
    <div class="messages-container" ref="messagesContainer">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💕</div>
        <p>还没有消息哦，快来记录第一条甜蜜吧~</p>
        <p class="sub">支持文字、图片、语音、视频随手记录</p>
      </div>
      <template v-else>
        <div
          v-for="msg in messages"
          :key="msg.id"
          class="message-item"
          :class="msg.sender_role === 'female' ? 'message-right' : 'message-left'"
        >
          <div class="avatar" :class="msg.sender_role === 'female' ? 'female-avatar' : 'male-avatar'">
            {{ msg.sender_nickname.charAt(0) }}
          </div>
          <div class="message-content">
            <div class="nickname">{{ msg.sender_nickname }}</div>

            <!-- Video -->
            <div v-if="msg.video_url" class="video-container">
              <video :src="getMediaUrl(msg.video_url)" controls preload="metadata" playsinline class="chat-video" />
              <span v-if="msg.video_duration" class="media-duration">
                <el-icon><VideoPlay /></el-icon>{{ formatDuration(msg.video_duration) }}
              </span>
            </div>

            <!-- Images -->
            <div v-if="msg.media_urls && msg.media_urls.length > 0" class="image-grid"
              :class="{ 'single-img': msg.media_urls.length === 1 }">
              <el-image
                v-for="(url, idx) in msg.media_urls" :key="idx"
                :src="getMediaUrl(url)" class="chat-image"
                :preview-src-list="msg.media_urls.map(u => getMediaUrl(u))"
                :initial-index="idx" fit="cover" preview-teleported />
            </div>

            <!-- Voice with progress bar -->
            <div v-if="msg.voice_url" class="voice-message"
              :class="{ playing: playingVoiceId === msg.id }"
              @click="toggleVoicePlay(msg)">
              <div class="voice-play-btn">
                <el-icon v-if="playingVoiceId !== msg.id"><VideoPlay /></el-icon>
                <el-icon v-else><VideoPause /></el-icon>
              </div>
              <div class="voice-wave">
                <div v-for="i in 12" :key="i" class="wave-bar"
                  :class="{ active: playingVoiceId === msg.id && isInWaveRange(i) }"
                  :style="{ height: getWaveHeight(i) + 'px', animationDelay: (i * 0.08) + 's' }"/>
              </div>
              <div class="voice-info">
                <span class="voice-dur">{{ formatDuration(msg.voice_duration || 5) }}</span>
                <span v-if="playingVoiceId === msg.id" class="voice-pos">
                  {{ formatDuration(Math.floor(voiceProgress)) }}
                </span>
              </div>
              <div v-if="playingVoiceId === msg.id" class="voice-progress-track">
                <div class="voice-progress-fill" :style="{ width: voiceProgressPercent + '%' }"/>
              </div>
            </div>
            <audio ref="voiceAudioEl" style="display:none" @timeupdate="onVoiceTimeUpdate" @ended="onVoiceEnded" />

            <!-- Text bubble -->
            <div v-if="msg.text_content" class="bubble"
              :class="msg.sender_role === 'female' ? 'bubble-female' : 'bubble-male'">
              {{ msg.text_content }}
            </div>

            <!-- Tags and category -->
            <div v-if="msg.tags && msg.tags.length > 0" class="tags-row">
              <el-tag v-for="tag in msg.tags" :key="tag" size="small" effect="plain" class="ai-tag">#{{ tag }}</el-tag>
              <span v-if="msg.category_icon" class="category-badge"
                :style="{ background: (msg.category_color || '#ff6b9d') + '20', color: msg.category_color }">
                {{ msg.category_icon }} {{ msg.category_name }}
              </span>
            </div>

            <!-- AI summary -->
            <div v-if="msg.ai_summary" class="ai-summary">
              <el-icon><MagicStick /></el-icon>
              <span>{{ msg.ai_summary }}</span>
            </div>

            <div class="time">{{ formatTime(msg.sent_at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- Input Area -->
    <div class="input-area">
      <!-- Category mode row -->
      <div class="mode-switch-row">
        <div class="switch-left">
          <el-switch v-model="isAiAuto" class="ai-switch" />
          <span class="switch-label"><el-icon><MagicStick /></el-icon>AI分类</span>
        </div>
        <el-select v-if="!isAiAuto" v-model="manualCategory" placeholder="选分类" size="small" class="category-select">
          <el-option v-for="cat in categories" :key="cat.code"
            :label="cat.icon + ' ' + cat.name" :value="cat.code" />
        </el-select>
      </div>

      <!-- Selected media preview -->
      <div v-if="selectedImages.length > 0 || selectedVideo || recordedVideo" class="selected-medias">
        <div v-for="(img, idx) in selectedImages" :key="'img-'+idx" class="selected-img-item">
          <img :src="URL.createObjectURL(img)" />
          <el-icon class="remove-btn" @click="selectedImages.splice(idx,1)"><Close /></el-icon>
        </div>
        <div v-if="recordedVideo || selectedVideo" class="selected-video-item">
          <video :src="URL.createObjectURL(recordedVideo || selectedVideo!)" class="preview-video" muted />
          <el-icon class="remove-btn" @click="clearVideo"><Close /></el-icon>
          <span class="video-label">🎬 {{ formatDuration(recordedVideoDuration || 0) }}</span>
        </div>
      </div>

      <!-- Audio recording UI -->
      <div v-if="isRecordingAudio" class="recording-panel">
        <div class="rec-indicator">
          <div class="rec-dot" />
          <span>录音中 {{ formatDuration(recordTimer) }}</span>
        </div>
        <canvas ref="audioCanvas" class="audio-canvas" width="200" height="40" />
        <div class="rec-actions">
          <el-button size="small" @click="cancelAudioRecording">
            <el-icon><Close /></el-icon> 取消
          </el-button>
          <el-button size="small" type="danger" @click="stopAudioRecording">
            <el-icon><Check /></el-icon> 完成
          </el-button>
        </div>
      </div>

      <!-- Video recording UI -->
      <div v-if="isRecordingVideo" class="recording-panel video-rec">
        <video ref="videoPreviewEl" autoplay muted playsinline class="video-preview-live" />
        <div class="rec-indicator">
          <div class="rec-dot" />
          <span>录像中 {{ formatDuration(videoRecordTimer) }}</span>
        </div>
        <div class="rec-actions">
          <el-button size="small" @click="cancelVideoRecording">
            <el-icon><Close /></el-icon> 取消
          </el-button>
          <el-button size="small" type="danger" @click="stopVideoRecording">
            <el-icon><VideoCamera /></el-icon> 完成录像
          </el-button>
        </div>
      </div>

      <!-- Input row -->
      <div v-if="!isRecordingAudio && !isRecordingVideo" class="input-row">
        <div class="action-btns">
          <el-upload :show-file-list="false" accept="image/*" multiple :before-upload="handleImageSelect">
            <el-button circle size="small"><el-icon><Picture /></el-icon></el-button>
          </el-upload>
          <el-upload :show-file-list="false" accept="video/*" :before-upload="handleVideoFileSelect">
            <el-button circle size="small"><el-icon><Film /></el-icon></el-button>
          </el-upload>
          <el-button circle size="small" @click="startAudioRecording"
            :type="recordedAudio ? 'warning' : ''">
            <el-icon><Microphone /></el-icon>
          </el-button>
          <el-button circle size="small" @click="startVideoRecording" :type="isRecordingVideo ? 'danger' : ''">
            <el-icon><VideoCameraFilled /></el-icon>
          </el-button>
        </div>
        <el-input
          v-model="inputText"
          type="textarea"
          :rows="1"
          :autosize="{ minRows: 1, maxRows: 4 }"
          placeholder="记录此刻的甜蜜..."
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
        />
        <div class="send-section">
          <div class="sender-switch">
            <el-radio-group v-model="currentSender" size="small">
              <el-radio-button value="female">她</el-radio-button>
              <el-radio-button value="male">他</el-radio-button>
            </el-radio-group>
          </div>
          <el-button type="primary" class="send-btn" :loading="sending" :disabled="!canSend" @click="handleSend">
            发送
          </el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import {
  Loading, MagicStick, Picture, Microphone, Close, VideoPlay, VideoPause,
  Check, VideoCamera, VideoCameraFilled, Film
} from '@element-plus/icons-vue'
import { getMessages, createMessage, getCategories, type Message, type Category } from '../api'
import { getMediaUrl } from '../utils/request'

const messages = ref<Message[]>([])
const categories = ref<Category[]>([])
const loading = ref(false)
const sending = ref(false)
const inputText = ref('')
const currentSender = ref<'male' | 'female'>('female')
const messagesContainer = ref<HTMLElement | null>(null)

// Categories
const isAiAuto = ref(true)
const manualCategory = ref('')

// Media
const selectedImages = ref<File[]>([])
const selectedVideo = ref<File | null>(null)
const selectedVideoDuration = ref(0)

// Audio recording
const isRecordingAudio = ref(false)
const recordTimer = ref(0)
const recordedAudio = ref<File | null>(null)
const recordedAudioDuration = ref(0)
let mediaRecorder: MediaRecorder | null = null
let audioChunks: Blob[] = []
let audioTimer: number | null = null
let audioStream: MediaStream | null = null
let audioAnalyser: AnalyserNode | null = null
let audioCtx: AudioContext | null = null
let animationFrameId: number | null = null
const audioCanvas = ref<HTMLCanvasElement | null>(null)
const waveHeights = ref<number[]>(Array(12).fill(8))

// Video recording
const isRecordingVideo = ref(false)
const videoRecordTimer = ref(0)
const recordedVideo = ref<File | null>(null)
const recordedVideoDuration = ref(0)
let videoRecorder: MediaRecorder | null = null
let videoChunks: Blob[] = []
let videoTimer: number | null = null
let videoStream: MediaStream | null = null
const videoPreviewEl = ref<HTMLVideoElement | null>(null)

// Voice playback
const voiceAudioEl = ref<HTMLAudioElement | null>(null)
const playingVoiceId = ref<string | null>(null)
const voiceProgress = ref(0)
const voiceProgressPercent = ref(0)
let currentVoiceDuration = 5

const canSend = computed(() => {
  const hasContent = inputText.value.trim() || selectedImages.value.length > 0 ||
    recordedAudio.value || recordedVideo.value || selectedVideo.value
  if (!isAiAuto.value && !manualCategory.value) return false
  return hasContent && !sending.value
})

function formatTime(ts: string) {
  const d = new Date(ts)
  const now = new Date()
  const sameDay = d.toDateString() === now.toDateString()
  const t = `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`
  if (sameDay) return t
  return `${d.getMonth()+1}/${d.getDate()} ${t}`
}

function formatDuration(s: number) {
  if (!s || s < 0) return '0"'
  const m = Math.floor(s / 60)
  const sec = Math.floor(s % 60)
  if (m > 0) return `${m}'${String(sec).padStart(2,'0')}"`
  return `${sec}"`
}

function getWaveHeight(i: number) {
  return waveHeights.value[i - 1] || 8
}
function isInWaveRange(i: number) {
  // Animate waves when playing
  return playingVoiceId.value !== null
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

function handleImageSelect(file: File) {
  if (file.type.startsWith('image/')) {
    selectedImages.value.push(file)
  }
  return false
}

function handleVideoFileSelect(file: File) {
  if (file.type.startsWith('video/')) {
    selectedVideo.value = file
    // Get video duration
    const v = document.createElement('video')
    v.preload = 'metadata'
    v.onloadedmetadata = () => {
      selectedVideoDuration.value = Math.round(v.duration)
      URL.revokeObjectURL(v.src)
    }
    v.src = URL.createObjectURL(file)
  }
  return false
}

function clearVideo() {
  selectedVideo.value = null
  recordedVideo.value = null
  selectedVideoDuration.value = 0
  recordedVideoDuration.value = 0
}

// ===== Audio Recording =====
async function startAudioRecording() {
  try {
    audioStream = await navigator.mediaDevices.getUserMedia({ audio: true })
    mediaRecorder = new MediaRecorder(audioStream)
    audioChunks = []
    recordTimer.value = 0
    recordedAudio.value = null

    // Setup audio visualization
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)()
    const source = audioCtx.createMediaStreamSource(audioStream)
    audioAnalyser = audioCtx.createAnalyser()
    audioAnalyser.fftSize = 256
    source.connect(audioAnalyser)
    const dataArray = new Uint8Array(audioAnalyser.frequencyBinCount)

    function drawWave() {
      if (!audioAnalyser || !audioCanvas.value) return
      const ctx = audioCanvas.value.getContext('2d')!
      const w = audioCanvas.value.width, h = audioCanvas.value.height
      audioAnalyser.getByteFrequencyData(dataArray)
      ctx.clearRect(0, 0, w, h)
      const barWidth = w / 12
      for (let i = 0; i < 12; i++) {
        const val = dataArray[i * 4] / 255
        const barH = Math.max(4, val * h * 0.9)
        waveHeights.value[i] = barH
        ctx.fillStyle = '#ff6b9d'
        ctx.beginPath()
        ctx.roundRect(i * barWidth + 2, h - barH, barWidth - 4, barH, 2)
        ctx.fill()
      }
      animationFrameId = requestAnimationFrame(drawWave)
    }

    mediaRecorder.ondataavailable = e => { if (e.data.size > 0) audioChunks.push(e.data) }
    mediaRecorder.onstop = () => {
      const blob = new Blob(audioChunks, { type: 'audio/webm' })
      recordedAudio.value = new File([blob], `voice_${Date.now()}.webm`, { type: 'audio/webm' })
      recordedAudioDuration.value = recordTimer.value
      audioStream?.getTracks().forEach(t => t.stop())
      if (animationFrameId) cancelAnimationFrame(animationFrameId)
      audioCtx?.close()
    }
    mediaRecorder.start(100)
    isRecordingAudio.value = true
    audioTimer = window.setInterval(() => { recordTimer.value++ }, 1000)
    nextTick(drawWave)
  } catch (e) {
    ElMessage.error('无法访问麦克风，请检查权限')
    console.error(e)
  }
}

function stopAudioRecording() {
  if (mediaRecorder && isRecordingAudio.value) {
    mediaRecorder.stop()
    isRecordingAudio.value = false
    if (audioTimer) { clearInterval(audioTimer); audioTimer = null }
    ElMessage.success(`语音已录制 ${formatDuration(recordTimer.value)}`)
  }
}

function cancelAudioRecording() {
  if (mediaRecorder) {
    mediaRecorder.onstop = () => {
      audioStream?.getTracks().forEach(t => t.stop())
      audioCtx?.close()
    }
    mediaRecorder.stop()
    recordedAudio.value = null
  }
  isRecordingAudio.value = false
  if (audioTimer) { clearInterval(audioTimer); audioTimer = null }
  if (animationFrameId) cancelAnimationFrame(animationFrameId)
  recordTimer.value = 0
}

// ===== Video Recording =====
async function startVideoRecording() {
  try {
    videoStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
      audio: true
    })
    videoChunks = []
    videoRecordTimer.value = 0
    recordedVideo.value = null

    // Try to use MP4 if supported, otherwise webm
    let mimeType = 'video/webm;codecs=vp9,opus'
    if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/webm'
    if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/mp4'

    videoRecorder = new MediaRecorder(videoStream, { mimeType })
    videoRecorder.ondataavailable = e => { if (e.data.size > 0) videoChunks.push(e.data) }
    videoRecorder.onstop = () => {
      const ext = mimeType.includes('mp4') ? 'mp4' : 'webm'
      const blob = new Blob(videoChunks, { type: mimeType })
      recordedVideo.value = new File([blob], `video_${Date.now()}.${ext}`, { type: mimeType })
      recordedVideoDuration.value = videoRecordTimer.value
      videoStream?.getTracks().forEach(t => t.stop())
    }

    nextTick(() => {
      if (videoPreviewEl.value && videoStream) {
        videoPreviewEl.value.srcObject = videoStream
      }
    })

    videoRecorder.start(100)
    isRecordingVideo.value = true
    videoTimer = window.setInterval(() => { videoRecordTimer.value++ }, 1000)
  } catch (e) {
    ElMessage.error('无法访问摄像头，请检查权限')
    console.error(e)
  }
}

function stopVideoRecording() {
  if (videoRecorder && isRecordingVideo.value) {
    videoRecorder.stop()
    isRecordingVideo.value = false
    if (videoTimer) { clearInterval(videoTimer); videoTimer = null }
    ElMessage.success(`视频已录制 ${formatDuration(videoRecordTimer.value)}`)
  }
}

function cancelVideoRecording() {
  if (videoRecorder) {
    videoRecorder.onstop = () => videoStream?.getTracks().forEach(t => t.stop())
    videoRecorder.stop()
    recordedVideo.value = null
  }
  isRecordingVideo.value = false
  if (videoTimer) { clearInterval(videoTimer); videoTimer = null }
  videoRecordTimer.value = 0
}

// ===== Voice Playback =====
function toggleVoicePlay(msg: Message) {
  if (playingVoiceId.value === msg.id) {
    voiceAudioEl.value?.pause()
    playingVoiceId.value = null
    return
  }
  if (!msg.voice_url) return
  if (voiceAudioEl.value) {
    voiceAudioEl.value.src = getMediaUrl(msg.voice_url)
    voiceAudioEl.value.play()
    playingVoiceId.value = msg.id
    currentVoiceDuration = msg.voice_duration || 5
    voiceProgress.value = 0
    voiceProgressPercent.value = 0
  }
}

function onVoiceTimeUpdate() {
  const a = voiceAudioEl.value
  if (!a) return
  voiceProgress.value = a.currentTime
  if (a.duration) {
    voiceProgressPercent.value = (a.currentTime / a.duration) * 100
    currentVoiceDuration = Math.round(a.duration)
  }
}

function onVoiceEnded() {
  playingVoiceId.value = null
  voiceProgress.value = 0
  voiceProgressPercent.value = 0
}

// ===== Send =====
async function handleSend() {
  if (!canSend.value) {
    if (!isAiAuto.value && !manualCategory.value) ElMessage.warning('手动模式请选分类')
    return
  }
  sending.value = true
  try {
    const videoFile = recordedVideo.value || selectedVideo.value
    const vidDur = recordedVideo.value ? recordedVideoDuration.value : selectedVideoDuration.value

    await createMessage({
      sender_role: currentSender.value,
      text_content: inputText.value.trim(),
      is_ai_auto: isAiAuto.value,
      manual_category: isAiAuto.value ? undefined : manualCategory.value,
      images: selectedImages.value.length > 0 ? [...selectedImages.value] : undefined,
      voice: recordedAudio.value || undefined,
      voice_duration: recordedAudio.value ? recordedAudioDuration.value : undefined,
      video: videoFile || undefined,
      video_duration: vidDur || undefined
    })
    inputText.value = ''
    selectedImages.value = []
    clearVideo()
    recordedAudio.value = null
    recordedAudioDuration.value = 0
    manualCategory.value = ''
    ElMessage.success('发送成功 💕')
    await loadMessages()
  } catch (e: any) {
    ElMessage.error(e.message || '发送失败')
  } finally {
    sending.value = false
  }
}

async function loadMessages() {
  loading.value = true
  try {
    messages.value = await getMessages()
    scrollToBottom()
  } catch (e) {
    ElMessage.error('加载消息失败，请确认后端运行')
  } finally {
    loading.value = false
  }
}

async function loadCategories() {
  try {
    categories.value = await getCategories()
  } catch (e) { console.error(e) }
}

onMounted(() => {
  loadMessages()
  loadCategories()
})

onUnmounted(() => {
  if (audioTimer) clearInterval(audioTimer)
  if (videoTimer) clearInterval(videoTimer)
  if (animationFrameId) cancelAnimationFrame(animationFrameId)
  audioStream?.getTracks().forEach(t => t.stop())
  videoStream?.getTracks().forEach(t => t.stop())
})
</script>

<style scoped>
.chat-page { display: flex; flex-direction: column; height: calc(100vh - 52px - 60px); background: #fff5f8; }

.messages-container { flex: 1; overflow-y: auto; padding: 16px; -webkit-overflow-scrolling: touch; }
.loading-tip, .empty-tip { text-align: center; padding: 60px 20px; color: #b2bec3; }
.empty-icon { font-size: 48px; margin-bottom: 12px; }
.empty-tip .sub { font-size: 12px; margin-top: 6px; opacity: 0.7; }

.message-item { display: flex; margin-bottom: 18px; gap: 8px; animation: fadeInUp 0.3s ease-out; }
.message-right { flex-direction: row-reverse; }
.message-content { max-width: 78%; }
.message-right .message-content { display: flex; flex-direction: column; align-items: flex-end; }

.avatar {
  width: 38px; height: 38px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  color: white; font-weight: bold; flex-shrink: 0; font-size: 15px;
}
.female-avatar { background: linear-gradient(135deg, #ff6b9d, #ff89b3); }
.male-avatar { background: linear-gradient(135deg, #54a0ff, #74b3ff); }

.nickname { font-size: 11px; color: #b2bec3; margin-bottom: 3px; padding: 0 4px; }

/* Video */
.video-container { margin-bottom: 6px; position: relative; }
.chat-video { max-width: 240px; max-height: 350px; border-radius: 12px; background: #000; }
.media-duration {
  position: absolute; bottom: 6px; right: 6px; background: rgba(0,0,0,0.6);
  color: white; font-size: 11px; padding: 2px 6px; border-radius: 4px;
  display: flex; align-items: center; gap: 2px;
}

/* Images */
.image-grid { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 6px; max-width: 260px; }
.image-grid.single-img .chat-image { width: 200px; height: 200px; }
.chat-image {
  width: 80px; height: 80px; border-radius: 10px; cursor: pointer; overflow: hidden;
}

/* Voice message */
.voice-message {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 14px; border-radius: 20px;
  margin-bottom: 6px; cursor: pointer; position: relative;
  min-width: 120px; max-width: 240px;
  transition: transform 0.15s;
}
.voice-message:active { transform: scale(0.97); }
.message-right .voice-message {
  background: linear-gradient(135deg, #ff6b9d, #ff89b3); color: white;
  border-bottom-right-radius: 4px;
}
.message-left .voice-message {
  background: white; border: 1px solid #ffe3ee;
  border-bottom-left-radius: 4px;
}
.voice-play-btn { width: 28px; height: 28px; border-radius: 50%;
  background: rgba(255,255,255,0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.message-left .voice-play-btn { background: #fff0f5; color: #ff6b9d; }
.voice-wave { display: flex; align-items: center; gap: 2px; height: 24px; flex: 1; }
.wave-bar { width: 3px; background: currentColor; border-radius: 2px; opacity: 0.5;
  transition: height 0.1s; }
.wave-bar.active { opacity: 1; animation: wavePulse 0.6s ease-in-out infinite alternate; }
@keyframes wavePulse { from { opacity: 0.4; } to { opacity: 1; } }
.voice-info { font-size: 11px; opacity: 0.8; display: flex; flex-direction: column; align-items: flex-end; gap: 1px; }
.voice-pos { font-size: 10px; opacity: 0.7; }
.voice-progress-track {
  position: absolute; bottom: 2px; left: 14px; right: 14px; height: 2px;
  background: rgba(255,255,255,0.3); border-radius: 1px;
}
.message-left .voice-progress-track { background: rgba(255,107,157,0.2); }
.voice-progress-fill { height: 100%; background: currentColor; border-radius: 1px; transition: width 0.1s linear; }

/* Bubble */
.bubble {
  padding: 10px 14px; border-radius: 18px; font-size: 15px;
  line-height: 1.5; word-break: break-word;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}
.bubble-female {
  background: linear-gradient(135deg, #ff6b9d, #ff89b3); color: white;
  border-bottom-right-radius: 4px;
}
.bubble-male { background: white; color: #2d3436; border: 1px solid #ffe3ee; border-bottom-left-radius: 4px; }

.tags-row { margin-top: 5px; display: flex; flex-wrap: wrap; gap: 4px; align-items: center; }
.ai-tag { border-radius: 8px; font-size: 10px; }
.category-badge { font-size: 10px; padding: 2px 7px; border-radius: 8px; }
.ai-summary {
  margin-top: 4px; padding: 5px 9px;
  background: linear-gradient(135deg, #f8f5ff, #f0e7ff);
  border-radius: 10px; font-size: 11px; color: #5f27cd;
  display: flex; align-items: center; gap: 4px;
}
.time { font-size: 10px; color: #dfe6e9; margin-top: 3px; padding: 0 4px; }

/* Input area */
.input-area {
  background: white; padding: 8px 12px 10px;
  border-top: 1px solid #ffe3ee;
  box-shadow: 0 -2px 10px rgba(255,107,157,0.05);
}
.mode-switch-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; gap: 8px; flex-wrap: wrap; }
.switch-left { display: flex; align-items: center; gap: 5px; font-size: 12px; color: #636e72; }
.category-select { width: 160px; }

.selected-medias { display: flex; gap: 6px; margin-bottom: 6px; flex-wrap: wrap; }
.selected-img-item { position: relative; width: 56px; height: 56px; }
.selected-img-item img { width: 100%; height: 100%; object-fit: cover; border-radius: 8px; }
.selected-video-item { position: relative; width: 80px; height: 80px; }
.preview-video { width: 100%; height: 100%; object-fit: cover; border-radius: 8px; background: #000; }
.video-label {
  position: absolute; bottom: 2px; left: 2px;
  background: rgba(0,0,0,0.6); color: white; font-size: 9px; padding: 1px 4px; border-radius: 3px;
}
.remove-btn {
  position: absolute; top: -5px; right: -5px; background: #ff6b9d; color: white;
  border-radius: 50%; width: 18px; height: 18px; cursor: pointer; font-size: 12px;
  display: flex; align-items: center; justify-content: center;
}

.recording-panel {
  padding: 10px 14px; background: linear-gradient(135deg, #fff0f5, #ffe3ee);
  border-radius: 14px; margin-bottom: 8px;
}
.video-rec { padding: 8px; }
.video-preview-live {
  width: 100%; max-height: 200px; border-radius: 10px; background: #000; margin-bottom: 8px; object-fit: cover;
}
.rec-indicator { display: flex; align-items: center; gap: 6px; color: #ff6b9d; font-size: 13px; font-weight: 500; }
.rec-dot { width: 8px; height: 8px; border-radius: 50%; background: #ff4757; animation: pulse 1s infinite; }
.audio-canvas { width: 100%; height: 40px; margin: 6px 0; }
.rec-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 6px; }

.input-row { display: flex; gap: 6px; align-items: flex-end; }
.action-btns { display: flex; gap: 4px; flex-wrap: wrap; }
.send-section { display: flex; flex-direction: column; gap: 4px; flex-shrink: 0; align-items: flex-end; }
.sender-switch :deep(.el-radio-button__inner) { padding: 4px 8px; font-size: 11px; }
.input-row :deep(.el-textarea__inner) {
  border-radius: 18px; padding: 9px 14px; border-color: #ffe3ee; font-size: 14px;
}
.input-row :deep(.el-textarea__inner:focus) { border-color: #ff6b9d; }
.send-btn { border-radius: 18px; height: 36px; padding: 0 16px; font-size: 14px; }
</style>
