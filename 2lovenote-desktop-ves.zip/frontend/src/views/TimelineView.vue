<template>
  <div class="timeline-page">
    <div class="page-header">
      <h2>📅 恋爱时光轴</h2>
      <p class="subtitle" v-if="stats?.love_days">我们已经在一起 {{ stats.love_days }} 天啦 💕</p>
      <p class="subtitle" v-else>一起记录的每一个瞬间都值得珍藏</p>
    </div>

    <!-- Stats Panel -->
    <div class="stats-panel">
      <div class="stats-tabs">
        <div class="stats-tab" :class="{ active: statsPeriod === 'week' }" @click="statsPeriod = 'week'; loadStats()">
          📊 本周统计
        </div>
        <div class="stats-tab" :class="{ active: statsPeriod === 'month' }" @click="statsPeriod = 'month'; loadStats()">
          📈 本月统计
        </div>
      </div>

      <div v-if="statsLoading" class="stats-loading">
        <el-icon class="is-loading"><Loading /></el-icon> 统计中...
      </div>

      <template v-else-if="periodStats">
        <!-- Key metrics -->
        <div class="metrics-row">
          <div class="metric-card">
            <div class="metric-value">{{ periodStats.total }}</div>
            <div class="metric-label">条消息</div>
          </div>
          <div class="metric-card split">
            <div class="metric-half female-h">
              <span class="dot female-dot" />{{ stats?.female_nickname || '她' }}
              <strong>{{ periodStats.female_count }}</strong>
            </div>
            <div class="metric-half male-h">
              <span class="dot male-dot" />{{ stats?.male_nickname || '他' }}
              <strong>{{ periodStats.male_count }}</strong>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-value small-h">🔥</div>
            <div class="metric-label">{{ periodStats.peak_label }}</div>
          </div>
        </div>

        <!-- Activity Bar Chart (by hour) -->
        <div class="chart-section">
          <div class="chart-title">⏰ 活跃度时段分布</div>
          <div class="hour-chart">
            <div v-for="(cnt, h) in periodStats.hour_distribution" :key="h" class="hour-bar-wrap">
              <div class="hour-bar" :style="{ height: getBarH(cnt) + '%' }"
                :class="{ peak: h === periodStats.peak_hour }"
                :title="`${h}:00 - ${cnt}条`" />
              <span v-if="h % 4 === 0" class="hour-label">{{ h }}</span>
            </div>
          </div>
          <div class="chart-axis">
            <span>0时</span><span>6时</span><span>12时</span><span>18时</span><span>24时</span>
          </div>
        </div>

        <!-- Category breakdown -->
        <div class="chart-section" v-if="Object.keys(periodStats.category_distribution).length > 0">
          <div class="chart-title">🏷️ 分类分布</div>
          <div class="cat-bars">
            <div v-for="(cnt, code) in topCategories" :key="code" class="cat-bar-row">
              <span class="cat-bar-name">{{ getCatInfo(String(code)).icon }} {{ getCatInfo(String(code)).name }}</span>
              <div class="cat-bar-track">
                <div class="cat-bar-fill" :style="{ width: getCatBarW(cnt) + '%', background: getCatInfo(String(code)).color }" />
              </div>
              <span class="cat-bar-cnt">{{ cnt }}</span>
            </div>
          </div>
        </div>

        <!-- Daily activity -->
        <div class="chart-section">
          <div class="chart-title">📆 每日记录</div>
          <div class="day-dots">
            <div v-for="(day, key) in sortedDays" :key="key" class="day-dot-item"
              :title="`${key}: ${day.total}条`">
              <div class="day-dot" :class="getDotClass(day.total)" />
              <span class="day-label">{{ key.slice(-2) }}</span>
            </div>
          </div>
        </div>

        <!-- Fun stats -->
        <div class="fun-stats">
          <div class="fun-item" v-if="periodStats.total > 0">
            <span>💬 平均每天</span>
            <strong>{{ Math.ceil(periodStats.total / Object.keys(periodStats.day_stats).length || 1) }} 条</strong>
          </div>
          <div class="fun-item" v-if="periodStats.type_distribution.video">
            <span>🎬 视频</span><strong>{{ periodStats.type_distribution.video }} 条</strong>
          </div>
          <div class="fun-item" v-if="periodStats.type_distribution.voice">
            <span>🎤 语音</span><strong>{{ periodStats.type_distribution.voice }} 条</strong>
          </div>
          <div class="fun-item" v-if="periodStats.type_distribution.image">
            <span>📷 图片</span><strong>{{ periodStats.type_distribution.image }} 条</strong>
          </div>
        </div>
      </template>

      <div v-else class="stats-empty">这个周期还没有记录~</div>
    </div>

    <!-- Timeline -->
    <div v-if="loading" class="loading-tip">
      <el-icon class="is-loading"><Loading /></el-icon>加载中...
    </div>
    <div v-else-if="messages.length === 0" class="empty-tip">
      <div class="empty-icon">💌</div>
      <p>还没有任何记录</p>
    </div>
    <el-timeline v-else class="timeline-container">
      <el-timeline-item
        v-for="(group, dateKey) in groupedMessages" :key="dateKey"
        :timestamp="formatDateLabel(dateKey)" placement="top"
        :color="getDateColor(group[0])" size="large"
        :icon="getDateIcon(group[0])"
      >
        <div class="date-card">
          <div class="date-header">
            <span class="date-badge" :style="{ background: getDateColor(group[0]) }">
              {{ getDateEmoji(group[0]) }} {{ formatDateHeader(dateKey) }}
            </span>
            <span class="count-badge">{{ group.length }} 条</span>
          </div>
          <div class="day-messages">
            <div v-for="msg in group" :key="msg.id" class="timeline-msg">
              <div class="msg-time">{{ formatTime(msg.sent_at) }}</div>
              <div class="msg-bubble" :class="msg.sender_role">
                <div class="msg-sender">{{ msg.sender_nickname }}</div>
                <div v-if="msg.video_url" class="msg-video">
                  <video :src="getMediaUrl(msg.video_url)" controls preload="metadata" playsinline class="msg-video-el" />
                </div>
                <div v-if="msg.media_urls && msg.media_urls.length > 0" class="msg-images">
                  <el-image
                    v-for="(url, idx) in msg.media_urls" :key="idx"
                    :src="getMediaUrl(url)" class="msg-image"
                    :preview-src-list="msg.media_urls.map(u => getMediaUrl(u))"
                    :initial-index="idx" fit="cover" preview-teleported />
                </div>
                <div v-if="msg.voice_url" class="msg-voice">
                  <el-icon><Microphone /></el-icon> 语音 {{ formatDur(msg.voice_duration || 5) }}
                </div>
                <div v-if="msg.text_content" class="msg-content">{{ msg.text_content }}</div>
                <div v-if="msg.category_icon" class="msg-category">
                  {{ msg.category_icon }} {{ msg.category_name }}
                </div>
                <div v-if="msg.ai_summary" class="msg-ai">✨ {{ msg.ai_summary }}</div>
              </div>
            </div>
          </div>
        </div>
      </el-timeline-item>
    </el-timeline>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Loading, Microphone } from '@element-plus/icons-vue'
import {
  getMessages, getStatsOverview, getWeeklyStats, getMonthlyStats, getCategories,
  type Message, type StatsOverview, type PeriodStats, type Category
} from '../api'
import { getMediaUrl } from '../utils/request'

const messages = ref<Message[]>([])
const stats = ref<StatsOverview | null>(null)
const categories = ref<Category[]>([])
const loading = ref(false)
const statsLoading = ref(false)
const statsPeriod = ref<'week' | 'month'>('week')
const periodStats = ref<PeriodStats | null>(null)

const groupedMessages = computed(() => {
  const groups: Record<string, Message[]> = {}
  messages.value.forEach(msg => {
    const d = new Date(msg.sent_at)
    const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`
    if (!groups[key]) groups[key] = []
    groups[key].push(msg)
  })
  return Object.fromEntries(Object.entries(groups).sort((a, b) => b[0].localeCompare(a[0])))
})

const topCategories = computed(() => {
  if (!periodStats.value) return []
  const entries = Object.entries(periodStats.value.category_distribution)
  return entries.sort((a, b) => b[1] - a[1]).slice(0, 6)
})

const sortedDays = computed(() => {
  if (!periodStats.value) return []
  return Object.entries(periodStats.value.day_stats).sort((a, b) => a[0].localeCompare(b[0]))
})

const maxHourCount = computed(() => {
  if (!periodStats.value) return 1
  return Math.max(...periodStats.value.hour_distribution, 1)
})
const maxCatCount = computed(() => {
  if (!periodStats.value) return 1
  return Math.max(...Object.values(periodStats.value.category_distribution), 1)
})

function getBarH(cnt: number) { return (cnt / maxHourCount.value) * 100 }
function getCatBarW(cnt: number) { return (cnt / maxCatCount.value) * 100 }
function getCatInfo(code: string) {
  return categories.value.find(c => c.code === code) || { name: code, icon: '📝', color: '#b2bec3' }
}
function getDotClass(total: number) {
  if (total >= 10) return 'dot-4'
  if (total >= 5) return 'dot-3'
  if (total >= 2) return 'dot-2'
  return 'dot-1'
}

function formatDateLabel(k: string) { const [y,m,d] = k.split('-'); return `${y}年${+m}月${+d}日` }
function formatDateHeader(k: string) { const [_,m,d] = k.split('-'); return `${+m}月${+d}日` }
function formatTime(ts: string) { const d = new Date(ts); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}` }
function formatDur(s: number) { const m = Math.floor(s/60), sec = Math.floor(s%60); return m>0?`${m}'${String(sec).padStart(2,'0')}"`:`${sec}"` }

function getDateColor(msg: Message) { return msg.category_color || '#ff6b9d' }
function getDateEmoji(msg: Message) { return msg.category_icon || '💕' }
function getDateIcon(msg: Message) { return undefined }

async function loadMessages() {
  loading.value = true
  try {
    const data = await getMessages()
    messages.value = data.reverse()
  } catch (e) {
    ElMessage.error('加载时间轴失败')
  } finally { loading.value = false }
}

async function loadStats() {
  statsLoading.value = true
  try {
    stats.value = await getStatsOverview()
    if (statsPeriod.value === 'week') {
      periodStats.value = await getWeeklyStats()
    } else {
      periodStats.value = await getMonthlyStats()
    }
  } catch (e) {
    console.error(e)
  } finally { statsLoading.value = false }
}

async function loadCategories() {
  try { categories.value = await getCategories() } catch(e) {}
}

onMounted(() => {
  loadMessages()
  loadStats()
  loadCategories()
})
</script>

<style scoped>
.timeline-page { min-height: calc(100vh - 52px - 60px); background: #fff9fb; padding: 16px; }

.page-header { text-align: center; margin-bottom: 16px; }
.page-header h2 { font-size: 20px; color: #2d3436; margin-bottom: 4px; }
.subtitle { font-size: 13px; color: #ff6b9d; }

/* Stats Panel */
.stats-panel {
  background: white; border-radius: 16px; padding: 14px;
  box-shadow: 0 2px 12px rgba(255,107,157,0.08);
  margin-bottom: 20px;
}
.stats-tabs { display: flex; gap: 8px; margin-bottom: 14px; }
.stats-tab {
  flex: 1; text-align: center; padding: 8px; border-radius: 10px;
  font-size: 13px; cursor: pointer; transition: all 0.2s;
  background: #fff5f8; color: #b2bec3;
}
.stats-tab.active {
  background: linear-gradient(135deg, #ff6b9d, #ff9a9e); color: white;
  box-shadow: 0 2px 8px rgba(255,107,157,0.3);
}
.stats-loading { text-align: center; padding: 30px; color: #b2bec3; }
.stats-empty { text-align: center; padding: 24px; color: #b2bec3; font-size: 13px; }

.metrics-row { display: flex; gap: 8px; margin-bottom: 14px; }
.metric-card {
  flex: 1; background: linear-gradient(135deg, #fff0f5, #ffe3ee);
  border-radius: 12px; padding: 12px 8px; text-align: center;
}
.metric-card.split { padding: 0; display: flex; flex-direction: column; gap: 0; }
.metric-value { font-size: 28px; font-weight: 800; color: #ff6b9d; line-height: 1; }
.metric-value.small-h { font-size: 20px; }
.metric-label { font-size: 11px; color: #b2bec3; margin-top: 4px; }
.metric-half {
  flex: 1; display: flex; align-items: center; gap: 4px; padding: 8px 6px;
  font-size: 10px; color: #636e72;
}
.metric-half strong { margin-left: auto; font-size: 16px; }
.metric-half.female-h { border-bottom: 1px solid rgba(255,255,255,0.6); }
.female-h strong { color: #ff6b9d; }
.male-h strong { color: #54a0ff; }
.dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.female-dot { background: #ff6b9d; }
.male-dot { background: #54a0ff; }

.chart-section { margin-bottom: 14px; }
.chart-title { font-size: 12px; font-weight: 600; color: #636e72; margin-bottom: 8px; }

.hour-chart { display: flex; align-items: flex-end; gap: 2px; height: 50px; padding: 0 2px; }
.hour-bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; justify-content: flex-end; }
.hour-bar {
  width: 100%; min-height: 2px; border-radius: 2px 2px 0 0;
  background: linear-gradient(180deg, #ffb8d4, #ff6b9d);
  transition: height 0.3s;
}
.hour-bar.peak { background: linear-gradient(180deg, #ff6b9d, #ee5253); }
.hour-label { font-size: 8px; color: #dfe6e9; margin-top: 2px; }
.chart-axis { display: flex; justify-content: space-between; font-size: 9px; color: #dfe6e9; margin-top: 2px; }

.cat-bars { display: flex; flex-direction: column; gap: 6px; }
.cat-bar-row { display: flex; align-items: center; gap: 6px; font-size: 11px; }
.cat-bar-name { width: 70px; color: #636e72; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 11px; }
.cat-bar-track { flex: 1; height: 8px; background: #f5f5f5; border-radius: 4px; overflow: hidden; }
.cat-bar-fill { height: 100%; border-radius: 4px; transition: width 0.5s ease; }
.cat-bar-cnt { width: 22px; text-align: right; font-size: 11px; color: #b2bec3; }

.day-dots { display: flex; gap: 4px; flex-wrap: wrap; }
.day-dot-item { display: flex; flex-direction: column; align-items: center; gap: 2px; }
.day-dot { width: 14px; height: 14px; border-radius: 3px; background: #f5f5f5; }
.day-dot.dot-1 { background: #ffe3ee; }
.day-dot.dot-2 { background: #ffb8d4; }
.day-dot.dot-3 { background: #ff6b9d; }
.day-dot.dot-4 { background: #e55a8c; }
.day-label { font-size: 8px; color: #dfe6e9; }

.fun-stats { display: flex; flex-wrap: wrap; gap: 6px; padding-top: 8px; border-top: 1px solid #fff0f5; }
.fun-item {
  display: flex; align-items: center; gap: 4px;
  background: #fff9fb; border-radius: 8px; padding: 5px 8px; font-size: 11px; color: #636e72;
}
.fun-item strong { color: #ff6b9d; font-size: 13px; }

/* Timeline */
.loading-tip, .empty-tip { text-align: center; padding: 40px 20px; color: #b2bec3; }
.empty-icon { font-size: 42px; margin-bottom: 8px; }
.timeline-container { padding: 0 4px; }

.date-card {
  background: white; border-radius: 14px; padding: 12px;
  box-shadow: 0 2px 8px rgba(255,107,157,0.07); margin-bottom: 10px;
}
.date-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.date-badge { padding: 3px 10px; border-radius: 14px; color: white; font-size: 12px; font-weight: 500; }
.count-badge { font-size: 11px; color: #b2bec3; background: #f5f5f5; padding: 2px 8px; border-radius: 8px; }

.day-messages { display: flex; flex-direction: column; gap: 10px; }
.timeline-msg { display: flex; gap: 8px; }
.msg-time { font-size: 11px; color: #b2bec3; width: 36px; flex-shrink: 0; padding-top: 2px; }
.msg-bubble { flex: 1; padding: 10px 12px; border-radius: 10px; font-size: 13px; line-height: 1.5; }
.msg-bubble.female { background: linear-gradient(135deg, #ffe3ee, #fff0f5); }
.msg-bubble.male { background: linear-gradient(135deg, #e3f0ff, #f0f7ff); }
.msg-sender { font-size: 11px; font-weight: 600; margin-bottom: 3px; opacity: 0.8; }
.msg-bubble.female .msg-sender { color: #ff6b9d; }
.msg-bubble.male .msg-sender { color: #54a0ff; }

.msg-images { display: flex; flex-wrap: wrap; gap: 3px; margin-bottom: 5px; }
.msg-video { margin-bottom: 5px; }
.msg-video-el { max-width: 180px; max-height: 240px; border-radius: 6px; background: #000; }
.msg-image { width: 70px; height: 70px; border-radius: 6px; overflow: hidden; }
.msg-voice { display: flex; align-items: center; gap: 3px; font-size: 11px; color: #54a0ff; margin-bottom: 4px; }
.msg-content { color: #2d3436; margin-bottom: 4px; }
.msg-category { font-size: 10px; color: #b2bec3; margin-bottom: 3px; }
.msg-ai { font-size: 10px; color: #5f27cd; padding-top: 4px; border-top: 1px dashed rgba(95,39,205,0.12); margin-top: 3px; }

:deep(.el-timeline-item__timestamp) { color: #ff6b9d; font-weight: 500; font-size: 12px; }
:deep(.el-timeline-item__node) { left: 0; }
</style>
