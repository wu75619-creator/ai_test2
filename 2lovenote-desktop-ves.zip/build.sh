#!/bin/bash
# ============================================
#   💕 情侣智能恋爱日记本 - Linux/Mac 打包脚本
#   注意：在 Linux 上打包只能生成 Linux 可执行文件，
#         在 Mac 上打包只能生成 Mac 可执行文件。
#         Windows exe 请在 Windows 上运行 build.bat。
# ============================================
set -e

echo "============================================"
echo "  💕 情侣智能恋爱日记本 - 桌面端打包"
echo "============================================"
echo

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未找到 python3，请先安装 Python 3.10+"
    exit 1
fi

echo "[1/5] 安装 Python 依赖..."
pip3 install -r backend/requirements.txt -q
pip3 install -r requirements-desktop.txt -q
echo "[✓] Python 依赖已安装"

# Linux 下 pywebview 需要 GTK 依赖
if [ "$(uname)" = "Linux" ]; then
    echo "    Linux 环境，检查 GTK/webkit 依赖..."
    if ! dpkg -l | grep -q libwebkit2gtk 2>/dev/null; then
        echo "    请先安装: sudo apt install python3-gi python3-gi-cairo gir1.2-webkit2-4.1"
        echo "    (打包完成后运行时需要，不影响打包本身)"
    fi
fi

# 检查 Node.js
if ! command -v node &> /dev/null; then
    echo "[错误] 未找到 Node.js，请先安装 Node.js 18+"
    exit 1
fi

echo "[2/5] 构建前端..."
cd frontend
[ ! -d node_modules ] && npm install --silent
npx vite build
cd ..
echo "[✓] 前端构建完成"

echo "[3/5] 清理旧构建..."
rm -rf build dist

echo "[4/5] PyInstaller 打包..."
pyinstaller LoveNote.spec --clean --noconfirm
echo "[✓] PyInstaller 打包完成"

echo "[5/5] 完成！"
echo
echo "============================================"
echo "  ✅ 构建成功！"
EXE_PATH=$(ls dist/ 2>/dev/null | head -1)
echo "  📁 输出位置: dist/${EXE_PATH}"
echo "  💾 数据存储:"
if [ "$(uname)" = "Darwin" ]; then
    echo "     ~/Library/Application Support/LoveNote/"
else
    echo "     ~/.local/share/LoveNote/"
fi
echo "  🚀 双击或 ./dist/${EXE_PATH} 运行"
echo "============================================"
