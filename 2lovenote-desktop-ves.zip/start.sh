#!/bin/bash
# Start LoveNote - builds frontend if needed and starts backend
set -e

cd "$(dirname "$0")"

echo "💕 LoveNote Starting..."

echo "📦 Ensuring Python dependencies..."
pip3 install -r backend/requirements.txt -q

if [ ! -d "frontend/dist" ]; then
    echo "🏗️ Building frontend..."
    cd frontend
    if [ ! -d "node_modules" ]; then
        npm install --silent
    fi
    npx vite build
    cd ..
fi

echo "🚀 Starting LoveNote server on port ${PORT:-8000}..."
cd backend
exec python3 -m uvicorn app.main:app --host ${HOST:-0.0.0.0} --port ${PORT:-8000}
