# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for 情侣智能恋爱日记本 (LoveNote)
打包为单文件 Windows/Mac/Linux 桌面应用
用法: pyinstaller LoveNote.spec
"""

import os
import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# 项目根目录 (spec 文件所在目录)
PROJECT_ROOT = os.path.abspath(os.path.dirname(SPECPATH))
FRONTEND_DIST = os.path.join(PROJECT_ROOT, 'frontend', 'dist')
BACKEND_DIR = os.path.join(PROJECT_ROOT, 'backend')

# ===== 收集需要的 data 文件 =====
datas = []

# 1. 前端 dist 目录整体打包（包含 index.html 和 assets/）
if os.path.isdir(FRONTEND_DIST):
    datas += [
        (os.path.join(FRONTEND_DIST, 'index.html'), 'frontend/dist'),
    ]
    assets_dir = os.path.join(FRONTEND_DIST, 'assets')
    if os.path.isdir(assets_dir):
        for fname in os.listdir(assets_dir):
            fpath = os.path.join(assets_dir, fname)
            if os.path.isfile(fpath):
                datas.append((fpath, 'frontend/dist/assets'))

# 2. 收集 backend Python 包的所有 .py 文件（通过 hiddenimports 处理更可靠）
# datas 中不需要加 .py 文件，PyInstaller 自动处理

# 3. dotenv 文件（可选）
env_example = os.path.join(BACKEND_DIR, '.env.example')
if os.path.exists(env_example):
    datas.append((env_example, 'backend'))

# ===== 隐式导入（防止 PyInstaller 漏检）=====
hiddenimports = [
    # FastAPI / uvicorn
    'uvicorn.logging',
    'uvicorn.loops',
    'uvicorn.loops.auto',
    'uvicorn.protocols',
    'uvicorn.protocols.http',
    'uvicorn.protocols.http.auto',
    'uvicorn.protocols.websockets',
    'uvicorn.protocols.websockets.auto',
    'uvicorn.lifespan',
    'uvicorn.lifespan.on',
    'fastapi',
    'starlette',
    'pydantic',
    # SQLAlchemy
    'sqlalchemy',
    'sqlalchemy.ext.declarative',
    'sqlalchemy.orm',
    'sqlalchemy.dialects.sqlite',
    # python-multipart (form parsing)
    'multipart',
    'multipart.multipart',
    # aiofiles (static file serving)
    'aiofiles',
    # dotenv
    'dotenv',
    # pywebview
    'webview',
    'webview.platforms',
    'webview.platforms.winforms' if sys.platform == 'win32' else (
        'webview.platforms.cocoa' if sys.platform == 'darwin' else 'webview.platforms.gtk'
    ),
    # 我们自己的模块
    'backend',
    'backend.app',
    'backend.app.database',
    'backend.app.models',
    'backend.app.init_db',
    'backend.app.paths',
    'backend.app.main',
    'backend.app.services',
    'backend.app.services.ai_service',
    'backend.app.services.__init__',
]

# ===== Windows 专属：隐藏控制台窗口 =====
# Windows 使用 'pyi_rth_win32comgenpy' 等
if sys.platform == 'win32':
    exe_type = 'windowed'  # 无控制台窗口（GUI模式）
else:
    exe_type = 'console'   # Mac/Linux 保留控制台便于排查（也可改为 None 使用默认）

# ===== 分析 =====
a = Analysis(
    ['desktop_app.py'],
    pathex=[PROJECT_ROOT, BACKEND_DIR],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter',           # 不需要
        'matplotlib',        # 不需要
        'numpy',             # 不需要（除非用了）
        'pytest',
        'openai',            # Mock模式不需要，若用真实AI需移除此行
        'PIL.ImageTk',       # Pillow 不要带 tk 支持
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='💕恋爱日记本',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,          # 使用 UPX 压缩（减小体积，可选）
    upx_exclude=[
        'Qt5*', 'Qt6*', 'PySide6*',  # pywebview 在 Windows 依赖 WebView2 不需要 Qt
        'vcruntime140*',
    ],
    runtime_tmpdir=None,
    console=False if sys.platform == 'win32' else True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # 可设置为 .ico 文件路径（Windows）或 .icns（Mac）
)
