@echo off
chcp 65001 >nul
echo ============================================
echo   💕 情侣智能恋爱日记本 - Windows 一键打包
echo ============================================
echo.

:: ===== 检查 Python =====
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Python，请先安装 Python 3.10+ 并加入 PATH
    echo 下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/5] 安装 Python 依赖...
pip install -r backend\requirements.txt -q
pip install -r requirements-desktop.txt -q
if %errorlevel% neq 0 (
    echo [错误] Python 依赖安装失败
    pause
    exit /b 1
)

:: ===== 检查 Node.js =====
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Node.js，请先安装 Node.js 18+ 并加入 PATH
    echo 下载地址: https://nodejs.org/
    pause
    exit /b 1
)

echo [2/5] 安装前端依赖并构建...
cd frontend
if not exist node_modules (
    call npm install
)
call npx vite build
if %errorlevel% neq 0 (
    echo [错误] 前端构建失败
    cd ..
    pause
    exit /b 1
)
cd ..
echo [✓] 前端构建完成 -> frontend\dist\

:: ===== 清理旧的构建 =====
echo [3/5] 清理旧构建...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

:: ===== PyInstaller 打包 =====
echo [4/5] PyInstaller 打包 exe (这一步可能需要1-3分钟)...
pyinstaller LoveNote.spec --clean --noconfirm
if %errorlevel% neq 0 (
    echo [错误] PyInstaller 打包失败
    pause
    exit /b 1
)

:: ===== 完成 =====
echo [5/5] 打包完成！
echo.
echo ============================================
echo   ✅ 构建成功！
echo   📁 输出位置: dist\💕恋爱日记本.exe
echo   💾 数据存储: %%APPDATA%%\LoveNote\
echo   🚀 双击 exe 即可运行
echo ============================================
echo.
pause
