"""
💕 LoveNote 桌面端入口
- 后台线程启动 FastAPI (uvicorn) 监听 127.0.0.1 随机空闲端口
- 主线程启动 pywebview 桌面窗口加载前端
- 关闭窗口时自动终止后端进程/线程
"""
import sys
import os
import time
import socket
import threading
import uvicorn

# 必须在导入 app 之前设置环境变量，告知 paths 模块使用桌面模式
# 设置 PORT 为 0 让系统自动分配空闲端口，后续通过 socket 方式拿到实际端口
os.environ.setdefault("AI_MOCK", "true")

from backend.app.main import app  # noqa: E402


def find_free_port() -> int:
    """让操作系统分配一个空闲端口"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class UvicornServer(uvicorn.Server):
    """可在外部信号下优雅停止的 uvicorn 服务器"""
    def install_signal_handlers(self):
        pass  # pywebview 环境下不要接管信号


def run_backend(port: int, started_event: threading.Event):
    """在子线程中启动 uvicorn"""
    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=port,
        log_level="warning",
        access_log=False,
    )
    server = UvicornServer(config)

    # 在启动后通知主线程
    original_startup = server.startup

    async def startup_with_signal():
        await original_startup()
        started_event.set()

    server.startup = startup_with_signal
    server.run()
    return server


_SERVER_REF: UvicornServer | None = None


def stop_backend():
    """安全停止后端服务器"""
    global _SERVER_REF
    if _SERVER_REF:
        _SERVER_REF.should_exit = True


def main():
    global _SERVER_REF

    # 1. 找空闲端口
    port = find_free_port()
    url = f"http://127.0.0.1:{port}"

    # 2. 后台线程启动 uvicorn
    started_event = threading.Event()

    def _run():
        global _SERVER_REF
        config = uvicorn.Config(
            app, host="127.0.0.1", port=port,
            log_level="warning", access_log=False,
        )
        _SERVER_REF = UvicornServer(config)
        _SERVER_REF.run()

    backend_thread = threading.Thread(target=_run, daemon=True)
    backend_thread.start()

    # 等待后端启动（最多5秒）
    if not started_event.wait(timeout=8):
        # 轮询等待
        import urllib.request
        for _ in range(40):
            time.sleep(0.2)
            try:
                urllib.request.urlopen(f"{url}/api/health", timeout=1)
                break
            except Exception:
                continue

    # 3. 启动 pywebview 桌面窗口
    try:
        import webview
    except ImportError:
        print("=" * 60)
        print("pywebview 未安装，请先运行: pip install pywebview")
        print(f"或直接在浏览器访问: {url}")
        print("=" * 60)
        # Fallback: 直接在浏览器打开
        import webbrowser
        webbrowser.open(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            stop_backend()
        return

    # 权限提示文案（macOS/Windows首次录音需要）
    window = webview.create_window(
        title="💕 恋爱日记本",
        url=url,
        width=420,
        height=800,
        min_size=(360, 600),
        resizable=True,
        text_select=True,
        background_color="#fff5f8",
    )

    def on_closing(*_):
        stop_backend()

    window.events.closing += on_closing

    webview.start(debug=False, http_server=False)
    stop_backend()


if __name__ == "__main__":
    main()
