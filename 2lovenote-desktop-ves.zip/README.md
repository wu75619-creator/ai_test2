# 💕 情侣智能随手恋爱日记本

对话式随手记录、AI 自动分类归档的双人专属恋爱记忆存档工具。
**支持双击 exe 直接运行，无需安装任何环境，Windows 即用！**

---

## ✨ 功能一览

| 功能 | 说明 |
|------|------|
| 💬 聊天式记录 | 仿微信界面，文字/图片/语音/视频随手发送 |
| 🎤 内置录音 | 点击麦克风实时录音，波形动画可视化，播放带进度条 |
| 🎬 视频录制 | 调用设备摄像头直接录制短视频，也可上传本地视频文件 |
| 🤖 AI智能分类 | 默认Mock模式零配置可用，可切换 GPT-4o 真实接口 |
| 📂 自定义分类 | 8大系统分类，支持新建/删除用户自定义分类 |
| 📊 周/月统计面板 | 恋爱天数、时段活跃度柱状图、分类分布、每日热力点 |
| 💝 恋爱天数悬浮球 | 右上角悬浮，点击弹出统计卡片 |
| 🔒 密码保护 | 首次引导可设置访问密码，保护私密内容 |
| 📱 全端响应式 | 手机/平板/电脑浏览器均可访问 |
| 💻 桌面exe | Windows 双击即用，数据存入 AppData 本地目录 |

---

## 🚀 方式一：双击桌面 exe 运行（推荐）

### Windows 用户
1. 双击运行 `💕恋爱日记本.exe`（可能被 SmartScreen 提示"未知发布者"，点击"更多信息"→"仍要运行"即可）
2. 首次使用填写双方昵称和在一起的日期，可选设密码
3. 开始记录！

### 🎤 麦克风录音权限说明（重要）
- **首次录音授权**：点击麦克风按钮时，Windows 会弹出"是否允许此应用访问麦克风"的系统提示框，点击**"是"**即可授权。
- **摄像头授权**：点击录像按钮时同理，首次使用需允许摄像头权限。
- **如果误点了拒绝**：打开 `设置 → 隐私和安全性 → 麦克风（或摄像头）`，在"允许桌面应用访问麦克风"列表中找到本程序并打开。
- **Windows 7**：不弹出系统授权框，直接可用。
- **数据存储位置**：
  - Windows：`C:\Users\<你的用户名>\AppData\Roaming\LoveNote\`
  - macOS：`~/Library/Application Support/LoveNote/`
  - Linux：`~/.local/share/LoveNote/`
  - 目录中包含 `love_diary.db` 数据库文件和 `uploads/` 照片/语音/视频文件夹，备份此目录即可迁移全部数据。
- **窗口关闭后**：后台进程会自动退出，不会占用端口。

---

## 🛠 方式二：本地源码运行（开发者/服务器部署）

### 环境要求
- Python 3.10+
- Node.js 18+

```bash
# 1. 安装 Python 依赖
pip install -r backend/requirements.txt

# 2. 构建前端
cd frontend
npm install
npx vite build
cd ..

# 3. 启动服务器
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```
浏览器访问 http://localhost:8000 即可使用。手机访问需替换为电脑局域网 IP。

---

## 📦 自行打包 exe（开发者）

### Windows 打包环境
1. 安装 **Python 3.10+**（[python.org](https://www.python.org/downloads/)），安装时**务必勾选** "Add Python to PATH"
2. 安装 **Node.js 18+**（[nodejs.org](https://nodejs.org/)），安装后重启命令行
3. 确认环境：打开 cmd 运行 `python --version` 和 `node --version`，均有版本号输出

### 一键打包
在项目根目录**双击** `build.bat`，等待1-3分钟（首次需要下载依赖）。
打包完成后在 `dist/` 目录下得到最终的 `💕恋爱日记本.exe`，可直接发给另一台电脑使用，无需安装任何东西。

### macOS 打包
```bash
chmod +x build.sh
./build.sh
```
> 注意：必须在目标平台上打包（Windows 打包出 exe，Mac 打包出 Mac 可执行文件，无法交叉编译）。

### 打包产物说明
- 单文件 exe，约 35-50MB
- 首次运行时会在 AppData 中创建数据目录
- 不写注册表，可随时删除 exe 和数据目录完全卸载

---

## ⚙️ 配置真实 AI 接口（可选）

默认 Mock 模式使用本地关键词匹配+随机温柔文案，无需任何配置即可分类。
如需接入 GPT-4o 多模态（能识别图片内容）：
1. 在数据存储目录（见上文）创建 `.env` 文件（或复制 `backend/.env.example`）
2. 修改：
```env
AI_MOCK=false
OPENAI_API_KEY=sk-你的key
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o-mini
```
3. 重启程序生效。

---

## 🏗 技术栈
| 层级 | 技术 |
|------|------|
| 前端 | Vue 3 + TypeScript + Vite + Element Plus |
| 后端 | Python FastAPI + SQLAlchemy + SQLite |
| 桌面外壳 | pywebview（Windows 调用 Edge WebView2，零 Electron 体积）|
| 打包 | PyInstaller 单文件打包 |

---

## 📂 项目结构
```
├── desktop_app.py              # 桌面端入口（启动后端线程+pywebview窗口）
├── LoveNote.spec               # PyInstaller 打包配置
├── build.bat                   # Windows 一键打包脚本
├── build.sh                    # macOS/Linux 打包脚本
├── start.sh                    # 服务器模式启动脚本
├── requirements-desktop.txt    # 桌面打包额外依赖（pywebview, pyinstaller）
├── backend/
│   ├── requirements.txt        # 后端 Python 依赖
│   ├── .env.example            # 环境变量示例
│   └── app/
│       ├── main.py             # FastAPI 全部 16 个 API 接口
│       ├── models.py           # SQLAlchemy 数据模型（4张表）
│       ├── database.py         # 数据库连接
│       ├── paths.py            # 跨平台路径适配（exe/源码/用户数据目录）
│       ├── init_db.py          # 初始化8大预设分类
│       └── services/
│           └── ai_service.py   # AI分类服务（Mock+GPT双模式）
└── frontend/
    ├── package.json
    ├── vite.config.ts
    └── src/
        ├── App.vue             # 全局布局+引导页+密码门+恋爱天数球
        ├── api/index.ts        # 前端所有 API 调用封装
        ├── stores/app.ts       # Pinia 状态管理
        └── views/
            ├── ChatView.vue    # 聊天记录页（录音/录像/多媒体发送）
            ├── CategoryView.vue # 分类相册页（自定义分类CRUD）
            └── TimelineView.vue # 时间轴+周/月统计面板
```

---

## 🔒 隐私说明
- 所有数据（消息、照片、语音、视频、密码）**完全存储在本地电脑**，不上传任何服务器
- 默认 AI Mock 模式不发起任何外部网络请求
- 开启真实AI接口后，消息内容才会发送至配置的 OpenAI 兼容端点
- 如需彻底清除数据，删除对应数据目录（见上文"数据存储位置"）即可
