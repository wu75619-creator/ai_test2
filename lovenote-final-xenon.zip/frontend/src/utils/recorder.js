/**
 * 浏览器音视频录制工具 - 使用MediaRecorder API
 */

export class AudioRecorder {
  constructor() {
    this.mediaRecorder = null
    this.audioChunks = []
    this.stream = null
    this.isRecording = false
    this.startTime = null
  }

  static isSupported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)
  }

  async start() {
    if (this.isRecording) return
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      })
      let mimeType = 'audio/webm'
      const supportedTypes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4']
      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) { mimeType = type; break }
      }
      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType })
      this.audioChunks = []
      this.startTime = Date.now()
      this.mediaRecorder.addEventListener('dataavailable', (e) => {
        if (e.data.size > 0) this.audioChunks.push(e.data)
      })
      this.mediaRecorder.start()
      this.isRecording = true
      return true
    } catch (err) {
      this.cleanup()
      throw err
    }
  }

  stop() {
    return new Promise((resolve, reject) => {
      if (!this.isRecording || !this.mediaRecorder) { reject(new Error('未在录音中')); return }
      const duration = Math.round((Date.now() - this.startTime) / 1000)
      this.mediaRecorder.addEventListener('stop', () => {
        const mimeType = this.mediaRecorder.mimeType || 'audio/webm'
        const audioBlob = new Blob(this.audioChunks, { type: mimeType })
        const ext = mimeType.includes('mp4') ? 'mp4' : mimeType.includes('ogg') ? 'ogg' : 'webm'
        const fileName = `voice_${Date.now()}.${ext}`
        const file = new File([audioBlob], fileName, { type: mimeType })
        this.cleanup()
        resolve({ file, duration })
      })
      this.mediaRecorder.stop()
    })
  }

  cancel() {
    if (this.mediaRecorder && this.isRecording) this.mediaRecorder.stop()
    this.cleanup()
  }

  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop())
      this.stream = null
    }
    this.mediaRecorder = null
    this.audioChunks = []
    this.isRecording = false
    this.startTime = null
  }
}


export class VideoRecorder {
  constructor() {
    this.mediaRecorder = null
    this.videoChunks = []
    this.stream = null
    this.isRecording = false
    this.startTime = null
    this.previewVideoEl = null
  }

  static isSupported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)
  }

  async start(previewEl) {
    if (this.isRecording) return
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 1280 } },
        audio: { echoCancellation: true, noiseSuppression: true }
      })

      // 预览
      if (previewEl) {
        this.previewVideoEl = previewEl
        previewEl.srcObject = this.stream
        previewEl.muted = true
        await previewEl.play().catch(() => {})
      }

      let mimeType = 'video/webm;codecs=vp9,opus'
      const supportedTypes = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm',
        'video/mp4'
      ]
      for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) { mimeType = type; break }
      }

      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType })
      this.videoChunks = []
      this.startTime = Date.now()

      this.mediaRecorder.addEventListener('dataavailable', (e) => {
        if (e.data.size > 0) this.videoChunks.push(e.data)
      })
      this.mediaRecorder.start(1000) // 每秒收集一个chunk，防止内存积压
      this.isRecording = true
      return true
    } catch (err) {
      this.cleanup()
      throw err
    }
  }

  stop() {
    return new Promise((resolve, reject) => {
      if (!this.isRecording || !this.mediaRecorder) { reject(new Error('未在录像中')); return }
      const duration = Math.round((Date.now() - this.startTime) / 1000)

      this.mediaRecorder.addEventListener('stop', () => {
        const mimeType = this.mediaRecorder.mimeType || 'video/webm'
        const videoBlob = new Blob(this.videoChunks, { type: mimeType })
        const ext = mimeType.includes('mp4') ? 'mp4' : 'webm'
        const fileName = `video_${Date.now()}.${ext}`
        const file = new File([videoBlob], fileName, { type: mimeType })
        this.cleanup()
        resolve({ file, duration })
      })
      this.mediaRecorder.stop()
    })
  }

  cancel() {
    if (this.mediaRecorder && this.isRecording) this.mediaRecorder.stop()
    this.cleanup()
  }

  cleanup() {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop())
      this.stream = null
    }
    if (this.previewVideoEl) {
      this.previewVideoEl.srcObject = null
      this.previewVideoEl = null
    }
    this.mediaRecorder = null
    this.videoChunks = []
    this.isRecording = false
    this.startTime = null
  }
}
