<template>
  <div class="chat-page">
    <div class="chat-header">
      <div class="header-title">💑 我们的恋爱日记本</div>
      <div class="header-subtitle">随手记录，AI自动归档，珍藏每一份甜蜜</div>
      <div class="love-days-badge" v-if="loveDays > 0" @click="showDaysDetail = true">
        <span class="days-icon">💕</span>
        <span class="days-text">已相恋 <b>{{ loveDays }}</b> 天</span>
      </div>
    </div>

    <div class="chat-messages" ref="messageListRef">
      <div v-if="loading" class="loading-tip">
        <el-icon class="is-loading"><Loading /></el-icon>加载消息中...
      </div>
      <div v-else-if="messages.length === 0" class="empty-tip">
        <div class="empty-icon">💌</div>
        <div>还没有消息，发第一条消息开始记录我们的故事吧～</div>
        <div class="empty-hint">支持文字、图片、语音、视频，AI自动分类归档</div>
      </div>
      <template v-else>
        <div v-for="msg in messages" :key="msg.id" class="message-item" :class="msg.sender_role === '女主' ? 'message-female' : 'message-male'">
          <div class="avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
            {{ msg.sender_role === '女主' ? '👩' : '👨' }}
          </div>
          <div class="message-body">
            <div class="sender-name">{{ msg.sender_nickname }}</div>
            <div class="bubble" :class="msg.sender_role === '女主' ? 'bubble-female' : 'bubble-male'">
              <div v-if="msg.attachments && msg.attachments.filter(a => a.file_type === 'image').length > 0" class="images-wrap">
                <div :class="['image-grid', `grid-${Math.min(msg.attachments.filter(a => a.file_type === 'image').length, 4)}`]">
                  <el-image v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'image')" :key="idx"
                    :src="att.file_url" :preview-src-list="msg.attachments.filter(a => a.file_type === 'image').map(a => a.file_url)"
                    :initial-index="idx" fit="cover" class="msg-image" preview-teleported hide-on-click-modal />
                </div>
              </div>
              <div v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'video')" :key="'v'+idx" class="video-wrap">
                <video :src="att.file_url" controls playsinline preload="metadata" class="msg-video"></video>
              </div>
              <div v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'voice')" :key="'voice'+idx" class="voice-msg" @click="toggleVoice(att.file_url)">
                <div class="voice-icon">
                  <el-icon :class="{'playing': currentPlayingVoice === att.file_url}">
                    <VideoPause v-if="currentPlayingVoice === att.file_url" /><VideoPlay v-else />
                  </el-icon>
                </div>
                <div class="voice-wave">
                  <div class="wave-bar" v-for="n in 14" :key="n" :style="{height: getWaveHeight(n, att.duration || msg.voice_duration)}"></div>
                </div>
                <span class="voice-duration">{{ formatDuration(att.duration || msg.voice_duration) }}</span>
                <audio ref="voiceAudios" :src="att.file_url" @ended="currentPlayingVoice = null" preload="metadata"></audio>
              </div>
              <div v-if="msg.text_content" class="text-content">{{ msg.text_content }}</div>
              <div v-if="msg.ai_summary && msg.ai_processed && !msg.is_manual_category" class="ai-summary">
                <span class="ai-tag">✨ AI小结</span>{{ msg.ai_summary }}
              </div>
              <div v-if="msg.main_category_name" class="category-tag">
                {{ msg.main_category_icon }} {{ msg.main_category_name }}
                <span v-if="msg.is_manual_category" class="manual-badge">手动</span>
              </div>
              <div v-else-if="!msg.ai_processed" class="processing-tag">
                <el-icon class="is-loading"><Loading /></el-icon> AI归档中...
              </div>
            </div>
            <div class="message-time">{{ formatTime(msg.created_at) }}</div>
          </div>
        </div>
      </template>
    </div>

    <!-- 录音遮罩 -->
    <div v-if="isRecording" class="recording-overlay" @click.stop>
      <div class="recording-panel">
        <div class="recording-indicator">
          <div class="recording-pulse"></div>
          <el-icon class="mic-icon"><Microphone /></el-icon>
        </div>
        <div class="recording-time">{{ recordingDuration }}s</div>
        <div class="recording-hint">点击确认或取消</div>
        <div class="recording-actions">
          <el-button type="danger" circle @click="cancelRecording" size="large"><el-icon><Close /></el-icon></el-button>
          <el-button type="primary" circle @click="finishRecording" size="large"><el-icon><Check /></el-icon></el-button>
        </div>
      </div>
    </div>

    <!-- 录像遮罩 -->
    <div v-if="isVideoRecording" class="recording-overlay" @click.stop>
      <div class="video-recording-panel">
        <div class="video-rec-header">
          <div class="rec-badge"><div class="rec-dot"></div> 录制中</div>
          <div class="rec-timer">{{ videoDuration }}s</div>
        </div>
        <video ref="videoPreviewEl" class="video-preview-el" autoplay muted playsinline></video>
        <div class="video-rec-hint">最长录制60秒</div>
        <div class="recording-actions">
          <el-button type="danger" circle @click="cancelVideoRecording" size="large"><el-icon><Close /></el-icon></el-button>
          <el-button type="success" circle @click="finishVideoRecording" size="large"><el-icon><Check /></el-icon></el-button>
        </div>
      </div>
    </div>

    <!-- 恋爱天数弹窗 -->
    <el-dialog v-model="showDaysDetail" title="💕 我们的恋爱计时" width="320px" align-center>
      <div class="days-dialog-content">
        <div class="big-days">{{ loveDays }}</div>
        <div class="days-label">天</div>
        <div v-if="togetherDate" class="since-date">在一起日期：{{ togetherDate }}</div>
        <div class="days-actions">
          <el-button size="small" @click="showEditDate = true; showDaysDetail = false">设置纪念日</el-button>
        </div>
      </div>
    </el-dialog>

    <el-dialog v-model="showEditDate" title="设置在一起的日期" width="300px" align-center>
      <el-date-picker v-model="editDate" type="date" placeholder="选择日期" format="YYYY-MM-DD" value-format="YYYY-MM-DD" style="width:100%" />
      <template #footer>
        <el-button @click="showEditDate = false">取消</el-button>
        <el-button type="primary" @click="saveTogetherDate">保存</el-button>
      </template>
    </el-dialog>

    <!-- 输入区域 -->
    <div class="chat-input-area">
      <div class="input-options">
        <div class="ai-switch">
          <el-switch v-model="isAiAuto" size="small" active-color="#ff6b9d" />
          <span class="switch-label">AI自动分类</span>
        </div>
        <el-select v-if="!isAiAuto" v-model="selectedCategory" placeholder="请选择分类" size="small" class="category-select" filterable>
          <el-option-group label="系统分类">
            <el-option v-for="cat in categories.filter(c => c.is_system)" :key="'s'+cat.id" :label="cat.icon+' '+cat.name" :value="cat.name" />
          </el-option-group>
          <el-option-group v-if="categories.filter(c => !c.is_system).length" label="自定义分类">
            <el-option v-for="cat in categories.filter(c => !c.is_system)" :key="'c'+cat.id" :label="cat.icon+' '+cat.name" :value="cat.name" />
          </el-option-group>
        </el-select>
      </div>

      <div v-if="selectedImages.length > 0" class="preview-images">
        <div v-for="(img, idx) in selectedImages" :key="idx" class="preview-img-item">
          <img :src="img.preview" />
          <el-icon class="remove-btn" @click="removeImage(idx)"><Close /></el-icon>
        </div>
      </div>

      <div v-if="selectedVideo" class="video-preview">
        <video :src="selectedVideo.preview" controls class="preview-video"></video>
        <el-icon class="remove-btn" @click="selectedVideo = null; selectedVideoDuration = null"><Close /></el-icon>
        <span v-if="selectedVideoDuration" class="video-dur-badge">{{ selectedVideoDuration }}s</span>
      </div>

      <div v-if="selectedVoice" class="voice-preview">
        <audio :src="selectedVoice.preview" controls class="preview-voice"></audio>
        <span class="voice-dur-badge">{{ selectedVoice.duration }}s</span>
        <el-icon class="remove-voice-btn" @click="clearVoice"><Close /></el-icon>
      </div>

      <div class="input-wrapper">
        <div class="func-btns">
          <el-upload :show-file-list="false" accept="image/*" multiple :before-upload="handleImageSelect" class="upload-btn">
            <el-button circle size="small" :disabled="!!selectedVoice || isRecording || isVideoRecording || !!selectedVideo" :icon="Picture"></el-button>
          </el-upload>
          <el-upload :show-file-list="false" accept="video/*" :before-upload="handleVideoFileSelect" class="upload-btn">
            <el-button circle size="small" :disabled="!!selectedVoice || isRecording || isVideoRecording || selectedImages.length > 0" :icon="Film"></el-button>
          </el-upload>
          <el-button circle size="small" :type="isVideoRecording ? 'danger' : 'default'"
            :disabled="selectedImages.length > 0 || !!selectedVideo || !!selectedVoice || !!inputText.trim()"
            @click="startVideoRecording"><el-icon><VideoCamera /></el-icon>
          </el-button>
          <el-button circle size="small" :class="{'recording-btn': isRecording}"
            :disabled="selectedImages.length > 0 || !!selectedVideo || !!selectedVoice || !!inputText.trim() || isVideoRecording"
            @mousedown.prevent="startRecording" @touchstart.prevent="startRecording">
            <el-icon><Microphone /></el-icon>
          </el-button>
        </div>
        <el-input v-model="inputText" type="textarea" :rows="1" autosize placeholder="说点什么吧～ 文字/图片/语音/视频"
          @keydown.enter.exact.prevent="handleSend" resize="none" class="msg-input" :disabled="isRecording || isVideoRecording" />
        <el-button type="primary" class="send-btn" @click="handleSend" :loading="sending" :disabled="!canSend">发送 💕</el-button>
      </div>

      <div class="role-tip">
        发送身份：
        <el-radio-group v-model="currentSender" size="small">
          <el-radio-button label="男主">👨 男主</el-radio-button>
          <el-radio-button label="女主">👩 女主</el-radio-button>
        </el-radio-group>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, nextTick, onBeforeUnmount } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { Loading, Picture, Microphone, Close, Check, VideoPlay, VideoPause, Film, VideoCamera } from '@element-plus/icons-vue'
import { getMessages, sendMessage } from '../api/message'
import { getCategories } from '../api/category'
import { getCoupleInfo, updateCoupleInfo } from '../api/stats'
import { AudioRecorder, VideoRecorder } from '../utils/recorder'

const messageListRef = ref(null)
const voiceAudios = ref([])
const videoPreviewEl = ref(null)
const loading = ref(false)
const sending = ref(false)
const messages = ref([])
const inputText = ref('')
const currentSender = ref('女主')
const isAiAuto = ref(true)
const selectedCategory = ref('')
const categories = ref([])
const loveDays = ref(0)
const togetherDate = ref('')
const showDaysDetail = ref(false)
const showEditDate = ref(false)
const editDate = ref('')

const selectedImages = ref([])
const selectedVideo = ref(null)
const selectedVideoDuration = ref(null)
const selectedVoice = ref(null)

const audioRecorder = ref(null)
const isRecording = ref(false)
const recordingDuration = ref(0)
const recordingTimer = ref(null)

const videoRecorder = ref(null)
const isVideoRecording = ref(false)
const videoDuration = ref(0)
const videoTimer = ref(null)

const currentPlayingVoice = ref(null)
const currentAudio = ref(null)

const canSend = computed(() => {
  if (sending.value || isRecording.value || isVideoRecording.value) return false
  const hasContent = inputText.value.trim() || selectedImages.value.length > 0 || selectedVideo.value || selectedVoice.value
  if (!hasContent) return false
  if (!isAiAuto.value && !selectedCategory.value) return false
  return true
})

const formatTime = (t) => dayjs(t).format('MM-DD HH:mm')
const formatDuration = (s) => (!s || s < 1) ? '1"' : `${s}"`
const getWaveHeight = (n, dur) => `${8 + ((n * 7 + (dur || 3) * 3) % 17) % 16}px`

const scrollToBottom = async () => {
  await nextTick()
  if (messageListRef.value) messageListRef.value.scrollTop = messageListRef.value.scrollHeight
}

const loadCoupleInfo = async () => {
  try { const info = await getCoupleInfo(); loveDays.value = info.love_days || 0; togetherDate.value = info.together_date || '' } catch(e) {}
}

const loadCategories = async () => {
  try { const res = await getCategories(); if (res?.length) categories.value = res } catch(e) {}
}

const loadMessages = async () => {
  loading.value = true
  try { messages.value = await getMessages('asc'); scrollToBottom() }
  catch(e) { console.error('加载失败', e) }
  finally { loading.value = false }
}

const handleImageSelect = (file) => {
  if (selectedVideo.value || isRecording.value || isVideoRecording.value) { ElMessage.warning('请先完成当前操作'); return false }
  selectedImages.value.push({ file, preview: URL.createObjectURL(file) })
  return false
}

const handleVideoFileSelect = (file) => {
  if (selectedImages.value.length > 0 || isRecording.value || isVideoRecording.value) { ElMessage.warning('请先完成当前操作'); return false }
  if (selectedVideo.value) { ElMessage.warning('一次只能发送一个视频'); return false }
  const v = document.createElement('video')
  v.preload = 'metadata'
  v.onloadedmetadata = () => { selectedVideoDuration.value = Math.round(v.duration) }
  v.src = URL.createObjectURL(file)
  selectedVideo.value = { file, preview: v.src }
  return false
}

const removeImage = (idx) => selectedImages.value.splice(idx, 1)

const startRecording = async () => {
  if (!AudioRecorder.isSupported()) { ElMessage.error('当前浏览器不支持录音'); return }
  try {
    audioRecorder.value = new AudioRecorder()
    await audioRecorder.value.start()
    isRecording.value = true
    recordingDuration.value = 0
    recordingTimer.value = setInterval(() => { recordingDuration.value++; if (recordingDuration.value >= 60) finishRecording() }, 1000)
  } catch(err) {
    if (err.name === 'NotAllowedError') ElMessage.error('麦克风权限被拒绝')
    else ElMessage.error('录音失败: ' + err.message)
  }
}

const finishRecording = async () => {
  if (!audioRecorder.value) return
  try {
    const { file, duration } = await audioRecorder.value.stop()
    clearInterval(recordingTimer.value)
    isRecording.value = false
    selectedVoice.value = { file, preview: URL.createObjectURL(file), duration }
    if (!isAiAuto.value) selectedCategory.value = '语音专属存档'
    audioRecorder.value = null
  } catch(err) { cancelRecording() }
}

const cancelRecording = () => {
  if (audioRecorder.value) audioRecorder.value.cancel()
  clearInterval(recordingTimer.value)
  isRecording.value = false; audioRecorder.value = null
}

const clearVoice = () => { selectedVoice.value = null }

const startVideoRecording = async () => {
  if (!VideoRecorder.isSupported()) { ElMessage.error('当前浏览器不支持录像'); return }
  try {
    videoRecorder.value = new VideoRecorder()
    isVideoRecording.value = true; videoDuration.value = 0
    await nextTick()
    await videoRecorder.value.start(videoPreviewEl.value)
    videoTimer.value = setInterval(() => { videoDuration.value++; if (videoDuration.value >= 60) finishVideoRecording() }, 1000)
  } catch(err) {
    cancelVideoRecording()
    if (err.name === 'NotAllowedError') ElMessage.error('摄像头/麦克风权限被拒绝')
    else ElMessage.error('录像失败: ' + err.message)
  }
}

const finishVideoRecording = async () => {
  if (!videoRecorder.value) return
  try {
    const { file, duration } = await videoRecorder.value.stop()
    clearInterval(videoTimer.value)
    isVideoRecording.value = false
    selectedVideo.value = { file, preview: URL.createObjectURL(file) }
    selectedVideoDuration.value = duration
    videoRecorder.value = null
  } catch(err) { cancelVideoRecording() }
}

const cancelVideoRecording = () => {
  if (videoRecorder.value) videoRecorder.value.cancel()
  clearInterval(videoTimer.value)
  isVideoRecording.value = false; videoDuration.value = 0; videoRecorder.value = null
}

const toggleVoice = (url) => {
  if (currentAudio.value) {
    currentAudio.value.pause()
    if (currentPlayingVoice.value === url) { currentPlayingVoice.value = null; currentAudio.value = null; return }
  }
  for (const a of voiceAudios.value) {
    if (a && a.src && a.src.endsWith(url)) {
      a.play(); currentAudio.value = a; currentPlayingVoice.value = url
      a.onended = () => { currentPlayingVoice.value = null; currentAudio.value = null }
      break
    }
  }
}

const handleSend = async () => {
  if (!canSend.value) return
  sending.value = true
  try {
    await sendMessage({
      sender_role: currentSender.value, text_content: inputText.value.trim(),
      is_ai_auto: isAiAuto.value, manual_category: isAiAuto.value ? null : selectedCategory.value,
      images: selectedImages.value.map(i => i.file), voice: selectedVoice.value?.file || null,
      video: selectedVideo.value?.file || null,
      voice_duration: selectedVoice.value?.duration ?? null, video_duration: selectedVideoDuration.value
    })
    inputText.value = ''; selectedImages.value = []; selectedVideo.value = null; selectedVideoDuration.value = null; selectedVoice.value = null
    await loadMessages()
    if (isAiAuto.value) {
      ElMessage.success('发送成功，AI正在归档 ✨')
      let cnt = 0
      const timer = setInterval(async () => { await loadMessages(); cnt++; if (cnt >= 8 || messages.value.every(m => m.ai_processed)) clearInterval(timer) }, 1500)
    } else { ElMessage.success('发送成功 💌') }
    loadCategories(); loadCoupleInfo()
  } catch(e) { ElMessage.error(e.response?.data?.detail || '发送失败') }
  finally { sending.value = false }
}

const saveTogetherDate = async () => {
  if (!editDate.value) return
  try { await updateCoupleInfo({ together_date: editDate.value }); showEditDate.value = false; loadCoupleInfo(); ElMessage.success('纪念日已保存') }
  catch(e) { ElMessage.error('保存失败') }
}

onBeforeUnmount(() => {
  if (audioRecorder.value) audioRecorder.value.cleanup()
  if (videoRecorder.value) videoRecorder.value.cleanup()
  if (recordingTimer.value) clearInterval(recordingTimer.value)
  if (videoTimer.value) clearInterval(videoTimer.value)
})

onMounted(() => { loadCategories(); loadMessages(); loadCoupleInfo() })
</script>

<style scoped>
.chat-page { width:100%; height:100%; display:flex; flex-direction:column; background:var(--bg-color); }
.chat-header { padding:12px 16px 8px; text-align:center; background:white; border-bottom:1px solid var(--border-color); flex-shrink:0; }
.header-title { font-size:17px; font-weight:600; color:var(--el-color-primary); margin-bottom:2px; }
.header-subtitle { font-size:11px; color:var(--text-secondary); margin-bottom:6px; }
.love-days-badge { display:inline-flex; align-items:center; gap:4px; background:linear-gradient(135deg,#fff0f6,#ffe3ef); border-radius:20px; padding:4px 14px; font-size:12px; color:var(--el-color-primary-dark-2); cursor:pointer; animation:gentlePulse 3s ease-in-out infinite; }
@keyframes gentlePulse { 0%,100%{box-shadow:0 0 0 0 rgba(255,107,157,.2)} 50%{box-shadow:0 0 0 6px rgba(255,107,157,0)} }
.days-text b { font-size:14px; }
.chat-messages { flex:1; overflow-y:auto; padding:12px; display:flex; flex-direction:column; gap:14px; -webkit-overflow-scrolling:touch; }
.loading-tip,.empty-tip { text-align:center; color:var(--text-secondary); padding:40px 0; font-size:14px; }
.empty-icon { font-size:48px; margin-bottom:12px; }
.empty-hint { font-size:12px; margin-top:8px; opacity:.7; }
.message-item { display:flex; gap:8px; max-width:85%; animation:fadeSlideUp .3s ease; }
@keyframes fadeSlideUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
.message-male { align-self:flex-start; }
.message-female { align-self:flex-end; flex-direction:row-reverse; }
.avatar { width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }
.avatar-male { background:var(--male-bubble-bg); }
.avatar-female { background:var(--female-bubble-bg); }
.message-body { display:flex; flex-direction:column; gap:3px; min-width:0; }
.message-female .message-body { align-items:flex-end; }
.sender-name { font-size:11px; color:var(--text-secondary); padding:0 4px; }
.bubble { padding:8px 10px; border-radius:14px; font-size:14px; line-height:1.6; word-break:break-all; max-width:100%; overflow:hidden; transition:transform .15s; }
.bubble:active { transform:scale(.98); }
.bubble-male { background:white; color:var(--text-primary); border-bottom-left-radius:4px; border:1px solid var(--border-color); }
.bubble-female { background:var(--female-bubble-bg); color:var(--female-bubble-text); border-bottom-right-radius:4px; }
.images-wrap { margin-bottom:6px; border-radius:8px; overflow:hidden; }
.image-grid { display:grid; gap:3px; border-radius:8px; overflow:hidden; }
.grid-1 { grid-template-columns:1fr; max-width:220px; }
.grid-2 { grid-template-columns:1fr 1fr; max-width:220px; }
.grid-3,.grid-4 { grid-template-columns:1fr 1fr; max-width:220px; }
.msg-image { width:100%; min-height:80px; max-height:250px; border-radius:6px; cursor:pointer; background:#f5f5f5; }
.grid-1 .msg-image { max-height:300px; }
.video-wrap { margin-bottom:6px; border-radius:8px; overflow:hidden; }
.msg-video { max-width:240px; max-height:300px; border-radius:8px; display:block; }
.voice-msg { display:flex; align-items:center; gap:8px; min-width:130px; padding:8px 12px; background:rgba(255,255,255,.6); border-radius:20px; cursor:pointer; margin-bottom:4px; user-select:none; }
.bubble-male .voice-msg { background:var(--el-color-primary-light-9); }
.voice-icon { width:28px; height:28px; border-radius:50%; background:var(--el-color-primary); color:white; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.voice-icon .playing { animation:pulseIcon 1s infinite; }
@keyframes pulseIcon { 0%,100%{transform:scale(1)} 50%{transform:scale(1.15)} }
.voice-wave { flex:1; display:flex; align-items:center; gap:2px; height:24px; overflow:hidden; }
.wave-bar { width:2px; background:var(--el-color-primary); border-radius:1px; opacity:.6; }
.voice-duration { font-size:12px; color:var(--text-secondary); flex-shrink:0; }
.text-content { margin:4px 0; }
.ai-summary { margin-top:8px; padding-top:8px; border-top:1px dashed rgba(0,0,0,.08); font-size:12px; opacity:.9; font-style:italic; line-height:1.5; }
.ai-tag { font-weight:500; margin-right:4px; font-style:normal; color:var(--el-color-primary); }
.bubble-female .ai-summary { border-top-color:rgba(255,255,255,.5); }
.category-tag { margin-top:6px; display:inline-flex; align-items:center; gap:4px; font-size:11px; padding:2px 8px; border-radius:10px; background:rgba(255,255,255,.7); }
.bubble-male .category-tag { background:var(--el-color-primary-light-9); color:var(--el-color-primary); }
.manual-badge { font-size:9px; background:#e6f7ff; color:#1890ff; padding:0 4px; border-radius:4px; margin-left:2px; }
.processing-tag { margin-top:6px; font-size:11px; color:var(--text-secondary); display:flex; align-items:center; gap:3px; }
.message-time { font-size:10px; color:var(--text-secondary); padding:0 4px; }
.recording-overlay { position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,.6); z-index:1000; display:flex; align-items:center; justify-content:center; backdrop-filter:blur(4px); }
.recording-panel { background:white; border-radius:24px; padding:40px 30px 30px; text-align:center; box-shadow:0 20px 60px rgba(0,0,0,.3); width:280px; }
.recording-indicator { position:relative; width:100px; height:100px; margin:0 auto 20px; display:flex; align-items:center; justify-content:center; }
.recording-pulse { position:absolute; width:100%; height:100%; border-radius:50%; background:rgba(255,107,157,.3); animation:recPulse 1.5s infinite; }
@keyframes recPulse { 0%{transform:scale(1);opacity:.7} 100%{transform:scale(1.5);opacity:0} }
.mic-icon { font-size:40px; color:white; background:linear-gradient(135deg,#ff6b9d,#ff4081); width:80px; height:80px; border-radius:50%; display:flex; align-items:center; justify-content:center; z-index:1; }
.recording-time { font-size:36px; font-weight:700; color:var(--el-color-primary); margin-bottom:8px; font-variant-numeric:tabular-nums; }
.recording-hint { font-size:13px; color:var(--text-secondary); margin-bottom:24px; }
.recording-actions { display:flex; justify-content:center; gap:30px; }
.video-recording-panel { background:#1a1a1a; border-radius:20px; padding:20px; width:320px; max-width:90vw; text-align:center; }
.video-rec-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
.rec-badge { display:flex; align-items:center; gap:6px; color:#ff4444; font-size:14px; font-weight:600; }
.rec-dot { width:10px; height:10px; border-radius:50%; background:#ff4444; animation:blink 1s infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:.3} }
.rec-timer { font-size:24px; font-weight:700; color:white; font-variant-numeric:tabular-nums; }
.video-preview-el { width:100%; max-height:50vh; border-radius:12px; background:black; object-fit:cover; margin-bottom:12px; }
.video-rec-hint { color:#aaa; font-size:12px; margin-bottom:16px; }
.days-dialog-content { text-align:center; }
.big-days { font-size:64px; font-weight:800; color:var(--el-color-primary); line-height:1; }
.days-label { font-size:16px; color:var(--text-secondary); margin-bottom:8px; }
.since-date { font-size:13px; color:var(--text-secondary); margin-bottom:16px; }
.days-actions { margin-top:8px; }
.chat-input-area { background:white; padding:10px 12px 16px; border-top:1px solid var(--border-color); flex-shrink:0; }
.input-options { display:flex; align-items:center; gap:10px; margin-bottom:8px; flex-wrap:wrap; }
.ai-switch { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--text-secondary); }
.category-select { flex:1; min-width:180px; }
.preview-images { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
.preview-img-item { position:relative; width:65px; height:65px; border-radius:8px; overflow:hidden; }
.preview-img-item img { width:100%; height:100%; object-fit:cover; }
.remove-btn { position:absolute; top:2px; right:2px; background:rgba(0,0,0,.6); color:white; border-radius:50%; width:18px; height:18px; display:flex; align-items:center; justify-content:center; font-size:12px; cursor:pointer; z-index:2; }
.video-preview { position:relative; margin-bottom:8px; border-radius:8px; overflow:hidden; display:inline-block; }
.preview-video { max-height:120px; border-radius:8px; }
.video-dur-badge { position:absolute; bottom:4px; right:4px; background:rgba(0,0,0,.6); color:white; font-size:11px; padding:1px 6px; border-radius:4px; }
.voice-preview { display:flex; align-items:center; gap:8px; margin-bottom:8px; padding:8px; background:var(--bg-cream); border-radius:8px; position:relative; }
.preview-voice { flex:1; height:32px; }
.voice-dur-badge { font-size:12px; color:var(--el-color-primary); font-weight:600; }
.remove-voice-btn { background:rgba(0,0,0,.4); color:white; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; cursor:pointer; font-size:12px; }
.input-wrapper { display:flex; gap:6px; align-items:flex-end; }
.func-btns { display:flex; gap:3px; padding-bottom:4px; flex-wrap:wrap; }
.upload-btn :deep(.el-button) { color:var(--text-secondary); border-color:var(--border-color); background:white; }
.recording-btn { background:var(--el-color-danger)!important; border-color:var(--el-color-danger)!important; color:white!important; animation:pulseIcon 1s infinite; }
.msg-input { flex:1; }
.msg-input :deep(.el-textarea__inner) { border-radius:20px; border-color:var(--border-color); background:var(--bg-cream); padding:8px 16px; resize:none; max-height:100px; }
.msg-input :deep(.el-textarea__inner:focus) { border-color:var(--el-color-primary); }
.send-btn { border-radius:20px!important; height:36px; padding:0 16px; flex-shrink:0; }
.role-tip { margin-top:8px; font-size:11px; color:var(--text-secondary); display:flex; align-items:center; gap:6px; }
.role-tip :deep(.el-radio-button__inner) { padding:3px 10px; font-size:11px; }
.role-tip :deep(.el-radio-button:first-child .el-radio-button__inner) { border-radius:6px 0 0 6px; }
.role-tip :deep(.el-radio-button:last-child .el-radio-button__inner) { border-radius:0 6px 6px 0; }
</style>
