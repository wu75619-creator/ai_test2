<template>
  <div class="timeline-page">
    <div class="page-header">
      <h1>💕 恋爱时间轴</h1>
      <p>每一条记录，都是我们相爱的证据</p>
    </div>

    <!-- 恋爱天数大卡 -->
    <div class="love-days-hero" v-if="stats.love_days > 0">
      <div class="hero-left">
        <div class="hero-days">{{ stats.love_days }}</div>
        <div class="hero-label">天相恋</div>
      </div>
      <div class="hero-right">
        <div class="hero-stat-row">
          <span class="h-stat-val">{{ stats.total_messages }}</span>
          <span class="h-stat-lbl">条甜蜜记录</span>
        </div>
        <div class="hero-stat-row">
          <span class="h-stat-val male">👨 {{ stats.male_count }}</span>
          <span class="h-stat-val female">👩 {{ stats.female_count }}</span>
        </div>
      </div>
      <div class="hearts-float"><span v-for="i in 6" :key="i" class="float-heart" :style="heartStyle(i)">💕</span></div>
    </div>

    <!-- 统计面板切换 -->
    <div class="stats-tabs">
      <div class="tab" :class="{active: activeTab === 'week'}" @click="activeTab = 'week'">📅 本周</div>
      <div class="tab" :class="{active: activeTab === 'month'}" @click="activeTab = 'month'">📆 本月</div>
      <div class="tab" :class="{active: activeTab === 'all'}" @click="activeTab = 'all'">📊 总览</div>
    </div>

    <!-- 本周统计 -->
    <div v-if="activeTab === 'week'" class="stats-panel">
      <div class="panel-title">本周恋爱数据</div>
      <div class="stat-cards-row">
        <div class="mini-stat">
          <div class="ms-num">{{ stats.this_week?.total || 0 }}</div>
          <div class="ms-lbl">条消息</div>
        </div>
        <div class="mini-stat">
          <div class="ms-num">{{ stats.this_week?.active_days || 0 }}/7</div>
          <div class="ms-lbl">活跃天</div>
        </div>
        <div class="mini-stat">
          <div class="ms-num peak-lbl">{{ stats.this_week?.peak_hour_label || '-' }}</div>
          <div class="ms-lbl">最活跃时段</div>
        </div>
      </div>
      <div class="activity-bars" v-if="stats.this_week?.daily">
        <div class="bars-title">每日互动量</div>
        <div class="bars-row">
          <div v-for="d in stats.this_week.daily" :key="d.date" class="bar-col">
            <div class="bar-wrap">
              <div class="bar-fill" :style="{height: barHeight(d.count, weekMax)}"></div>
              <div v-if="d.count > 0" class="bar-count">{{ d.count }}</div>
            </div>
            <div class="bar-label">{{ d.day }}</div>
          </div>
        </div>
      </div>
      <div class="sender-compare">
        <div class="sc-label">双方互动量</div>
        <div class="sc-bars">
          <div class="sc-row">
            <span class="sc-name">👨 男主</span>
            <div class="sc-bar-track"><div class="sc-bar male-bar" :style="{width: senderPct(stats.this_week?.male_count, stats.this_week?.total)}"></div></div>
            <span class="sc-count">{{ stats.this_week?.male_count || 0 }}</span>
          </div>
          <div class="sc-row">
            <span class="sc-name">👩 女主</span>
            <div class="sc-bar-track"><div class="sc-bar female-bar" :style="{width: senderPct(stats.this_week?.female_count, stats.this_week?.total)}"></div></div>
            <span class="sc-count">{{ stats.this_week?.female_count || 0 }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 本月统计 -->
    <div v-if="activeTab === 'month'" class="stats-panel">
      <div class="panel-title">本月恋爱数据</div>
      <div class="stat-cards-row">
        <div class="mini-stat">
          <div class="ms-num">{{ stats.this_month?.total || 0 }}</div>
          <div class="ms-lbl">条消息</div>
        </div>
        <div class="mini-stat">
          <div class="ms-num">{{ stats.this_month?.active_days || 0 }}</div>
          <div class="ms-lbl">活跃天</div>
        </div>
        <div class="mini-stat">
          <div class="ms-num peak-lbl">{{ stats.this_month?.peak_hour_label || '-' }}</div>
          <div class="ms-lbl">最活跃时段</div>
        </div>
      </div>
      <div class="sender-compare">
        <div class="sc-label">双方互动量</div>
        <div class="sc-bars">
          <div class="sc-row">
            <span class="sc-name">👨 男主</span>
            <div class="sc-bar-track"><div class="sc-bar male-bar" :style="{width: senderPct(stats.this_month?.male_count, stats.this_month?.total)}"></div></div>
            <span class="sc-count">{{ stats.this_month?.male_count || 0 }}</span>
          </div>
          <div class="sc-row">
            <span class="sc-name">👩 女主</span>
            <div class="sc-bar-track"><div class="sc-bar female-bar" :style="{width: senderPct(stats.this_month?.female_count, stats.this_month?.total)}"></div></div>
            <span class="sc-count">{{ stats.this_month?.female_count || 0 }}</span>
          </div>
        </div>
      </div>
      <div v-if="stats.this_month?.categories?.length" class="month-cats">
        <div class="mc-title">本月热门分类</div>
        <div class="mc-list">
          <div v-for="c in stats.this_month.categories" :key="c.name" class="mc-item">
            <span class="mc-icon">{{ c.icon }}</span>
            <span class="mc-name">{{ c.name }}</span>
            <span class="mc-count">{{ c.count }}条</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 总览统计 -->
    <div v-if="activeTab === 'all'" class="stats-panel">
      <div class="panel-title">总体数据概览</div>
      <!-- 30天热力图 -->
      <div v-if="stats.heatmap_30d?.length" class="heatmap-section">
        <div class="bars-title">近30天互动热力图</div>
        <div class="heatmap-grid">
          <div v-for="(d, i) in stats.heatmap_30d" :key="i" class="heat-cell" :style="{background: heatColor(d.count)}" :title="d.date+': '+d.count+'条'">
            <span v-if="d.count > 0" class="heat-val">{{ d.count }}</span>
          </div>
        </div>
        <div class="heat-legend">
          <span>少</span>
          <div class="legend-cells">
            <div class="l-cell" style="background:#ffe3ef"></div>
            <div class="l-cell" style="background:#ffb3d1"></div>
            <div class="l-cell" style="background:#ff6b9d"></div>
            <div class="l-cell" style="background:#e55a8c"></div>
          </div>
          <span>多</span>
        </div>
      </div>
      <!-- 24小时分布 -->
      <div v-if="stats.hour_distribution?.data?.length" class="hour-section">
        <div class="bars-title">24小时互动时段分布</div>
        <div class="hour-chart">
          <div v-for="(h, i) in stats.hour_distribution.data" :key="i" class="h-col">
            <div class="h-bar-wrap">
              <div class="h-bar" :style="{height: hourBarHeight(h)}" :class="{peak: isPeakHour(i, stats.hour_distribution.data)}"></div>
            </div>
            <span class="h-label" v-if="i % 4 === 0">{{ i }}</span>
            <span class="h-label" v-else></span>
          </div>
        </div>
      </div>
      <!-- 分类分布 -->
      <div v-if="stats.category_distribution?.length" class="cat-dist-section">
        <div class="bars-title">分类归档分布</div>
        <div class="cat-dist-list">
          <div v-for="c in stats.category_distribution" :key="c.name" class="cd-item">
            <span class="cd-icon">{{ c.icon }}</span>
            <span class="cd-name">{{ c.name }}</span>
            <div class="cd-bar-track"><div class="cd-bar" :style="{width: cdPct(c.count)}"></div></div>
            <span class="cd-count">{{ c.count }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 时间轴消息列表 -->
    <div class="timeline-container" v-loading="loading">
      <div v-if="groupedMessages.length === 0 && !loading" class="empty-state">
        <div style="font-size:48px;margin-bottom:12px">📖</div>
        <div>还没有任何记录，去聊天页留下第一条回忆吧～</div>
        <el-button type="primary" link @click="$router.push('/')">去聊天</el-button>
      </div>

      <el-timeline v-else>
        <div v-for="group in groupedMessages" :key="group.date">
          <div class="date-marker">
            <span class="date-text">{{ formatDateLabel(group.date) }}</span>
          </div>
          <el-timeline-item
            v-for="msg in group.messages"
            :key="msg.id"
            :timestamp="formatTime(msg.created_at)"
            :color="msg.sender_role === '女主' ? '#ff6b9d' : '#4a90e2'"
            placement="top"
          >
            <div class="timeline-card">
              <div class="card-sender">
                <span class="sender-avatar" :class="msg.sender_role === '女主' ? 'avatar-female' : 'avatar-male'">
                  {{ msg.sender_role === '女主' ? '👩' : '👨' }}
                </span>
                <span class="sender-name">{{ msg.sender_nickname }}</span>
                <el-tag v-if="msg.main_category_icon" size="small" effect="plain" round class="cat-tag">
                  {{ msg.main_category_icon }} {{ msg.main_category_name }}
                </el-tag>
              </div>
              <div v-if="msg.attachments && msg.attachments.length > 0" class="card-images">
                <el-image v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'image')" :key="idx"
                  :src="att.file_url" :preview-src-list="msg.attachments.filter(a => a.file_type === 'image').map(a => a.file_url)"
                  fit="cover" class="tl-img" preview-teleported />
                <video v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'video')" :key="'vid'+idx"
                  :src="att.file_url" controls playsinline class="tl-video"></video>
                <audio v-for="(att, idx) in msg.attachments.filter(a => a.file_type === 'voice')" :key="'v'+idx"
                  :src="att.file_url" controls class="tl-voice"></audio>
              </div>
              <div v-if="msg.text_content" class="card-text">{{ msg.text_content }}</div>
              <div v-if="msg.ai_summary" class="ai-note"><span>✨ AI小结：</span>{{ msg.ai_summary }}</div>
            </div>
          </el-timeline-item>
        </div>
      </el-timeline>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import dayjs from 'dayjs'
import { ElMessage } from 'element-plus'
import { getMessages } from '../api/message'
import { getTimelineStats } from '../api/stats'

const loading = ref(false)
const messages = ref([])
const stats = ref({})
const activeTab = ref('week')

const weekMax = computed(() => {
  const d = stats.value.this_week?.daily || []
  return Math.max(1, ...d.map(x => x.count))
})
const monthMax = computed(() => stats.value.this_month?.total || 1)

const groupedMessages = computed(() => {
  const groups = {}
  const sorted = [...messages.value].sort((a,b) => dayjs(b.created_at).valueOf() - dayjs(a.created_at).valueOf())
  sorted.forEach(msg => {
    const date = dayjs(msg.created_at).format('YYYY-MM-DD')
    if (!groups[date]) groups[date] = []
    groups[date].push(msg)
  })
  return Object.keys(groups).map(date => ({ date, messages: groups[date] }))
})

const formatTime = (t) => dayjs(t).format('HH:mm')
const formatDateLabel = (date) => {
  const today = dayjs().format('YYYY-MM-DD')
  const yesterday = dayjs().subtract(1,'day').format('YYYY-MM-DD')
  if (date === today) return '今天'
  if (date === yesterday) return '昨天'
  return dayjs(date).format('M月D日 dddd')
}

const barHeight = (count, max) => `${Math.max(4, (count / max) * 80)}px`
const senderPct = (val, total) => total > 0 ? `${Math.max(2, (val/total)*100)}%` : '0%'

const hourBarHeight = (h) => {
  const arr = stats.value.hour_distribution?.data || []
  const mx = Math.max(1, ...arr)
  return `${Math.max(2, (h/mx)*60)}px`
}
const isPeakHour = (i, arr) => {
  const mx = Math.max(...arr)
  return arr[i] === mx && mx > 0
}

const heatColor = (count) => {
  if (count === 0) return '#f8f8f8'
  if (count <= 2) return '#ffe3ef'
  if (count <= 5) return '#ffb3d1'
  if (count <= 10) return '#ff6b9d'
  return '#e55a8c'
}

const cdPct = (count) => {
  const arr = stats.value.category_distribution || []
  const mx = Math.max(1, ...arr.map(x => x.count))
  return `${(count/mx)*100}%`
}

const heartStyle = (i) => ({
  left: `${10 + i*15}%`,
  animationDelay: `${i*0.5}s`,
  animationDuration: `${3 + i*0.3}s`
})

const loadData = async () => {
  loading.value = true
  try {
    const [msgs, sts] = await Promise.all([
      getMessages('desc').catch(() => []),
      getTimelineStats().catch(() => ({}))
    ])
    messages.value = msgs
    stats.value = sts
  } catch(e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

onMounted(() => loadData())
</script>

<style scoped>
.timeline-page { padding: 20px 16px 30px; min-height: 100%; }
.page-header { text-align: center; margin-bottom: 20px; }
.page-header h1 { font-size: 24px; color: var(--el-color-primary); margin-bottom: 4px; }
.page-header p { font-size: 13px; color: var(--text-secondary); }

/* 恋爱天数大卡 */
.love-days-hero {
  position: relative; overflow: hidden;
  background: linear-gradient(135deg, #ff6b9d 0%, #ff8fb7 50%, #ffb3d1 100%);
  border-radius: 20px; padding: 24px 20px;
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 20px; color: white;
  box-shadow: 0 8px 32px rgba(255,107,157,.3);
}
.hero-left { text-align: center; }
.hero-days { font-size: 56px; font-weight: 800; line-height: 1; text-shadow: 0 2px 8px rgba(0,0,0,.15); }
.hero-label { font-size: 14px; opacity: .9; margin-top: 4px; }
.hero-right { text-align: right; }
.hero-stat-row { margin-bottom: 8px; }
.h-stat-val { font-size: 18px; font-weight: 700; }
.h-stat-val.male { font-size: 14px; opacity: .9; }
.h-stat-val.female { font-size: 14px; opacity: .9; margin-left: 8px; }
.h-stat-lbl { font-size: 12px; opacity: .8; margin-left: 4px; }
.float-heart { position: absolute; font-size: 16px; opacity: .4; animation: floatUp 4s ease-in-out infinite; pointer-events: none; }
@keyframes floatUp { 0%{transform:translateY(0) scale(1);opacity:.4} 50%{transform:translateY(-30px) scale(1.2);opacity:.7} 100%{transform:translateY(-60px) scale(.8);opacity:0} }

/* Tab切换 */
.stats-tabs { display: flex; gap: 8px; margin-bottom: 16px; }
.tab {
  flex: 1; text-align: center; padding: 10px; border-radius: 12px;
  background: white; font-size: 13px; font-weight: 500; cursor: pointer;
  color: var(--text-secondary); transition: all .2s;
  box-shadow: 0 1px 4px rgba(0,0,0,.04);
}
.tab.active { background: var(--el-color-primary); color: white; box-shadow: 0 4px 12px rgba(255,107,157,.3); }

/* 统计面板 */
.stats-panel { margin-bottom: 24px; }
.panel-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 14px; padding-left: 4px; }

.stat-cards-row { display: flex; gap: 10px; margin-bottom: 18px; }
.mini-stat {
  flex: 1; background: white; border-radius: 14px; padding: 14px 8px;
  text-align: center; box-shadow: var(--shadow-soft);
}
.ms-num { font-size: 22px; font-weight: 700; color: var(--el-color-primary); line-height: 1.2; }
.peak-lbl { font-size: 13px; }
.ms-lbl { font-size: 11px; color: var(--text-secondary); margin-top: 4px; }

/* 每日柱状图 */
.bars-title { font-size: 12px; color: var(--text-secondary); margin-bottom: 10px; padding-left: 2px; }
.activity-bars { background: white; border-radius: 14px; padding: 16px 12px; margin-bottom: 14px; box-shadow: var(--shadow-soft); }
.bars-row { display: flex; align-items: flex-end; justify-content: space-around; height: 100px; gap: 4px; }
.bar-col { display: flex; flex-direction: column; align-items: center; flex: 1; }
.bar-wrap { display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 80px; }
.bar-fill {
  width: 22px; background: linear-gradient(180deg, #ff6b9d, #ffb3d1);
  border-radius: 6px 6px 2px 2px; min-height: 4px;
  transition: height .5s ease;
}
.bar-count { font-size: 10px; color: var(--el-color-primary); margin-bottom: 2px; font-weight: 600; }
.bar-label { font-size: 11px; color: var(--text-secondary); margin-top: 4px; }

/* 双方对比 */
.sender-compare { background: white; border-radius: 14px; padding: 16px; box-shadow: var(--shadow-soft); }
.sc-label { font-size: 12px; color: var(--text-secondary); margin-bottom: 10px; }
.sc-bars { display: flex; flex-direction: column; gap: 10px; }
.sc-row { display: flex; align-items: center; gap: 8px; }
.sc-name { font-size: 12px; width: 52px; flex-shrink: 0; }
.sc-bar-track { flex: 1; height: 16px; background: #f5f5f5; border-radius: 8px; overflow: hidden; }
.sc-bar { height: 100%; border-radius: 8px; transition: width .6s ease; }
.male-bar { background: linear-gradient(90deg, #4a90e2, #7bb3f0); }
.female-bar { background: linear-gradient(90deg, #ff6b9d, #ffb3d1); }
.sc-count { font-size: 12px; font-weight: 600; width: 28px; text-align: right; }

/* 本月分类 */
.month-cats { margin-top: 14px; background: white; border-radius: 14px; padding: 16px; box-shadow: var(--shadow-soft); }
.mc-title { font-size: 12px; color: var(--text-secondary); margin-bottom: 10px; }
.mc-list { display: flex; flex-direction: column; gap: 8px; }
.mc-item { display: flex; align-items: center; gap: 8px; font-size: 13px; }
.mc-icon { font-size: 18px; }
.mc-name { flex: 1; color: var(--text-primary); }
.mc-count { font-size: 12px; color: var(--el-color-primary); font-weight: 600; }

/* 热力图 */
.heatmap-section { background: white; border-radius: 14px; padding: 16px; box-shadow: var(--shadow-soft); margin-bottom: 14px; }
.heatmap-grid { display: grid; grid-template-columns: repeat(10, 1fr); gap: 5px; margin-bottom: 10px; }
.heat-cell {
  aspect-ratio: 1; border-radius: 6px; display: flex; align-items: center; justify-content: center;
  font-size: 10px; color: white; font-weight: 600;
}
.heat-val { text-shadow: 0 1px 2px rgba(0,0,0,.3); }
.heat-legend { display: flex; align-items: center; gap: 6px; font-size: 11px; color: var(--text-secondary); justify-content: flex-end; }
.legend-cells { display: flex; gap: 3px; }
.l-cell { width: 14px; height: 14px; border-radius: 3px; }

/* 24小时分布 */
.hour-section { background: white; border-radius: 14px; padding: 16px; box-shadow: var(--shadow-soft); margin-bottom: 14px; }
.hour-chart { display: flex; align-items: flex-end; gap: 2px; height: 80px; padding-top: 8px; }
.h-col { flex: 1; display: flex; flex-direction: column; align-items: center; }
.h-bar-wrap { height: 60px; display: flex; align-items: flex-end; width: 100%; justify-content: center; }
.h-bar { width: 80%; background: linear-gradient(180deg, #ff6b9d, #ffd7e8); border-radius: 3px 3px 1px 1px; min-height: 2px; transition: height .5s; }
.h-bar.peak { background: linear-gradient(180deg, #e55a8c, #ff6b9d); }
.h-label { font-size: 9px; color: var(--text-secondary); margin-top: 4px; }

/* 分类分布 */
.cat-dist-section { background: white; border-radius: 14px; padding: 16px; box-shadow: var(--shadow-soft); }
.cat-dist-list { display: flex; flex-direction: column; gap: 10px; }
.cd-item { display: flex; align-items: center; gap: 8px; font-size: 12px; }
.cd-icon { font-size: 16px; }
.cd-name { width: 80px; flex-shrink: 0; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cd-bar-track { flex: 1; height: 12px; background: #f5f5f5; border-radius: 6px; overflow: hidden; }
.cd-bar { height: 100%; background: linear-gradient(90deg, #ff6b9d, #ffb3d1); border-radius: 6px; transition: width .6s; }
.cd-count { width: 28px; text-align: right; font-weight: 600; color: var(--el-color-primary); }

/* 时间轴 */
.timeline-container { padding: 0 8px; }
.empty-state { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
.date-marker { text-align: center; margin: 20px 0 12px; position: relative; }
.date-marker::before { content:''; position: absolute; left:0; right:0; top:50%; height:1px; background: var(--border-color); z-index:0; }
.date-text { position: relative; z-index:1; background: var(--bg-color); padding: 4px 16px; border-radius: 20px; font-size: 13px; color: var(--text-secondary); font-weight: 500; }

.timeline-card { background: white; border-radius: 12px; padding: 12px 14px; box-shadow: 0 2px 8px rgba(0,0,0,.04); max-width: 100%; }
.card-sender { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.sender-avatar { width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; }
.avatar-male { background: var(--male-bubble-bg); }
.avatar-female { background: var(--female-bubble-bg); }
.sender-name { font-size: 13px; font-weight: 500; }
.cat-tag { margin-left: auto; }
.cat-tag :deep(.el-tag__content) { font-size: 11px; }

.card-images { margin-bottom: 8px; }
.tl-img { max-width: 100%; max-height: 200px; border-radius: 8px; margin-bottom: 6px; }
.tl-video { max-width: 100%; max-height: 200px; border-radius: 8px; margin-bottom: 6px; }
.tl-voice { width: 100%; height: 32px; }
.card-text { font-size: 14px; line-height: 1.7; color: var(--text-primary); word-break: break-all; }
.ai-note { margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border-color); font-size: 12px; color: var(--el-color-primary); line-height: 1.5; font-style: italic; }
.ai-note span { font-weight: 500; }
:deep(.el-timeline-item__timestamp) { color: var(--text-secondary); font-size: 11px; }
</style>
