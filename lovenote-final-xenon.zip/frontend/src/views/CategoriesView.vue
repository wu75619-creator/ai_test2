<template>
  <div class="categories-page">
    <div class="page-header">
      <h1>💝 分类相册</h1>
      <p>AI 自动归档的甜蜜回忆</p>
    </div>

    <div class="category-list">
      <div v-for="(cat, idx) in categories" :key="cat.id" class="category-card" @click="goToCategory(cat.name)">
        <div class="cat-icon" :style="{ background: getCatColor(idx) }">{{ cat.icon }}</div>
        <div class="cat-info">
          <div class="cat-name-row">
            <span class="cat-name">{{ cat.name }}</span>
            <el-tag v-if="!cat.is_system" size="small" type="warning" effect="plain" round class="custom-tag">自定义</el-tag>
          </div>
          <div class="cat-count">{{ cat.message_count }} 条记录</div>
        </div>
        <el-icon v-if="cat.can_delete" class="delete-icon" @click.stop="confirmDelete(cat)"><Delete /></el-icon>
        <el-icon v-else class="arrow"><ArrowRight /></el-icon>
      </div>
      <div class="add-category-card" @click="showAddDialog = true">
        <div class="add-icon"><el-icon :size="24"><Plus /></el-icon></div>
        <div class="add-text">添加自定义分类</div>
      </div>
    </div>

    <el-dialog v-model="showAddDialog" title="✨ 添加自定义分类" width="320px" align-center>
      <div class="add-form">
        <div class="form-item">
          <label>分类名称</label>
          <el-input v-model="newCatName" placeholder="如：装修日记、养宠日常" maxlength="20" show-word-limit />
        </div>
        <div class="form-item">
          <label>选择图标</label>
          <div class="icon-picker">
            <div v-for="ico in iconOptions" :key="ico" class="icon-option" :class="{active: newCatIcon === ico}" @click="newCatIcon = ico">{{ ico }}</div>
          </div>
        </div>
      </div>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="handleAddCategory" :loading="adding">确认添加</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ArrowRight, Plus, Delete } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getCategoryStats, createCategory, deleteCategory } from '../api/category'

const router = useRouter()
const categories = ref([])
const showAddDialog = ref(false)
const newCatName = ref('')
const newCatIcon = ref('📂')
const adding = ref(false)
const iconOptions = ['📂','🏠','🐱','🐶','🎮','🎵','📚','🏋️','🎂','🌸','🎁','☀️','🌙','🍿','🎬','🎨','🏖️','🎿','🚗','💼']

const catColors = [
  'linear-gradient(135deg,#ffecd2 0%,#fcb69f 100%)',
  'linear-gradient(135deg,#a8edea 0%,#fed6e3 100%)',
  'linear-gradient(135deg,#ff9a9e 0%,#fecfef 100%)',
  'linear-gradient(135deg,#fff1eb 0%,#ace0f9 100%)',
  'linear-gradient(135deg,#d299c2 0%,#fef9d7 100%)',
  'linear-gradient(135deg,#ffd1ff 0%,#fad0c4 100%)',
  'linear-gradient(135deg,#ebc0fd 0%,#d9ded8 100%)',
  'linear-gradient(135deg,#f6d365 0%,#fda085 100%)',
  'linear-gradient(135deg,#a1c4fd 0%,#c2e9fb 100%)',
  'linear-gradient(135deg,#d4fc79 0%,#96e6a1 100%)',
  'linear-gradient(135deg,#fbc2eb 0%,#a6c1ee 100%)',
  'linear-gradient(135deg,#fdcbf1 0%,#e6dee9 100%)',
]
const getCatColor = (idx) => catColors[idx % catColors.length]
const goToCategory = (name) => router.push(`/category/${encodeURIComponent(name)}`)

const loadStats = async () => {
  try { const res = await getCategoryStats(); categories.value = res.categories } catch(e) { ElMessage.error('加载分类失败') }
}

const handleAddCategory = async () => {
  if (!newCatName.value.trim()) { ElMessage.warning('请输入分类名称'); return }
  adding.value = true
  try {
    await createCategory({ name: newCatName.value.trim(), icon: newCatIcon.value, description: '' })
    ElMessage.success('添加成功'); showAddDialog.value = false; newCatName.value = ''; newCatIcon.value = '📂'
    await loadStats()
  } catch(e) { ElMessage.error(e.response?.data?.detail || '添加失败') }
  finally { adding.value = false }
}

const confirmDelete = async (cat) => {
  try {
    await ElMessageBox.confirm(`确定要删除「${cat.name}」吗？该分类下的记录将移至趣味日常存档。`, '删除自定义分类',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' })
    await deleteCategory(cat.id)
    ElMessage.success('删除成功'); await loadStats()
  } catch(e) { if (e !== 'cancel') ElMessage.error('删除失败') }
}

onMounted(() => loadStats())
</script>

<style scoped>
.categories-page { padding:20px 16px; min-height:100%; }
.page-header { text-align:center; margin-bottom:24px; }
.page-header h1 { font-size:24px; color:var(--el-color-primary); margin-bottom:4px; }
.page-header p { font-size:13px; color:var(--text-secondary); }
.category-list { display:flex; flex-direction:column; gap:12px; }
.category-card { background:white; border-radius:16px; padding:16px; display:flex; align-items:center; gap:14px; box-shadow:var(--shadow-soft); cursor:pointer; transition:all .2s; }
.category-card:active { transform:scale(.98); }
.category-card:hover { box-shadow:0 4px 16px rgba(255,107,157,.15); }
.cat-icon { width:52px; height:52px; border-radius:14px; display:flex; align-items:center; justify-content:center; font-size:26px; flex-shrink:0; }
.cat-info { flex:1; min-width:0; }
.cat-name-row { display:flex; align-items:center; gap:6px; margin-bottom:4px; }
.cat-name { font-size:16px; font-weight:500; color:var(--text-primary); }
.custom-tag { font-size:10px; }
.cat-count { font-size:12px; color:var(--text-secondary); }
.arrow { color:var(--text-secondary); font-size:18px; }
.delete-icon { color:var(--el-color-danger); font-size:18px; cursor:pointer; padding:4px; }
.delete-icon:hover { background:var(--el-color-danger-light-9); border-radius:50%; }
.add-category-card { background:white; border-radius:16px; padding:16px; display:flex; align-items:center; gap:14px; border:2px dashed var(--el-color-primary-light-5); cursor:pointer; transition:all .2s; }
.add-category-card:hover { border-color:var(--el-color-primary); background:var(--el-color-primary-light-9); }
.add-icon { width:52px; height:52px; border-radius:14px; background:var(--el-color-primary-light-9); color:var(--el-color-primary); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.add-text { font-size:15px; color:var(--el-color-primary); font-weight:500; }
.add-form { padding:8px 0; }
.form-item { margin-bottom:16px; }
.form-item label { display:block; font-size:13px; color:var(--text-primary); margin-bottom:8px; font-weight:500; }
.icon-picker { display:flex; flex-wrap:wrap; gap:8px; }
.icon-option { width:40px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px; background:var(--bg-cream); cursor:pointer; border:2px solid transparent; transition:all .15s; }
.icon-option.active { border-color:var(--el-color-primary); background:var(--el-color-primary-light-9); transform:scale(1.1); }
</style>
