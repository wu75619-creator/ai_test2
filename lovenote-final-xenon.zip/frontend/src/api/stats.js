import request from '../utils/request'

/**
 * 获取时间轴统计面板数据
 */
export function getTimelineStats() {
  return request({
    url: '/api/stats/timeline',
    method: 'get'
  })
}

/**
 * 获取情侣空间信息
 */
export function getCoupleInfo() {
  return request({
    url: '/api/stats/couple',
    method: 'get'
  })
}

/**
 * 更新情侣空间信息
 */
export function updateCoupleInfo(data) {
  return request({
    url: '/api/stats/couple',
    method: 'put',
    params: data
  })
}
