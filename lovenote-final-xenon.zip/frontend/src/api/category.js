import request from '../utils/request'

/**
 * 获取所有分类列表（含自定义分类）
 */
export function getCategories() {
  return request({
    url: '/api/categories',
    method: 'get'
  })
}

/**
 * 获取分类下的消息
 */
export function getCategoryMessages(categoryName, year, month) {
  return request({
    url: `/api/categories/${encodeURIComponent(categoryName)}`,
    method: 'get',
    params: { year, month }
  })
}

/**
 * 获取分类统计概览
 */
export function getCategoryStats() {
  return request({
    url: '/api/categories/stats/overview',
    method: 'get'
  })
}

/**
 * 创建自定义分类
 * @param {Object} data { name, icon, description }
 */
export function createCategory(data) {
  return request({
    url: '/api/categories',
    method: 'post',
    data
  })
}

/**
 * 删除自定义分类
 * @param {number} categoryId
 */
export function deleteCategory(categoryId) {
  return request({
    url: `/api/categories/${categoryId}`,
    method: 'delete'
  })
}
