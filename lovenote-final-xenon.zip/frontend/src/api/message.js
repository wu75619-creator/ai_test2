import request from '../utils/request'

/**
 * 获取历史消息列表
 */
export function getMessages(order = 'asc') {
  return request({
    url: '/api/messages',
    method: 'get',
    params: { order, limit: 500 }
  })
}

/**
 * 发送新消息
 */
export function sendMessage(data) {
  const formData = new FormData()
  formData.append('sender_role', data.sender_role)
  formData.append('is_ai_auto', data.is_ai_auto)

  if (data.text_content) {
    formData.append('text_content', data.text_content)
  }
  if (!data.is_ai_auto && data.manual_category) {
    formData.append('manual_category', data.manual_category)
  }
  if (data.voice_duration != null) {
    formData.append('voice_duration', data.voice_duration)
  }
  if (data.video_duration != null) {
    formData.append('video_duration', data.video_duration)
  }
  if (data.images && data.images.length > 0) {
    data.images.forEach(img => formData.append('images', img))
  }
  if (data.voice) {
    formData.append('voice', data.voice)
  }
  if (data.video) {
    formData.append('video', data.video)
  }

  return request({
    url: '/api/messages',
    method: 'post',
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120000
  })
}
