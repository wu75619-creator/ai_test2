import { createRouter, createWebHistory } from 'vue-router'
import ChatView from '../views/ChatView.vue'
import CategoriesView from '../views/CategoriesView.vue'
import TimelineView from '../views/TimelineView.vue'
import CategoryView from '../views/CategoryView.vue'

const routes = [
  {
    path: '/',
    name: 'Chat',
    component: ChatView
  },
  {
    path: '/categories',
    name: 'Categories',
    component: CategoriesView
  },
  {
    path: '/category/:id',
    name: 'Category',
    component: CategoryView
  },
  {
    path: '/timeline',
    name: 'Timeline',
    component: TimelineView
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
