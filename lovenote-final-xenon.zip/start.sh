#!/bin/bash
# 情侣智能随手恋爱日记本 - 生产启动脚本
set -e

cd "$(dirname "$0")"

echo "💑 情侣智能随手恋爱日记本 v2.0"
echo "================================"

# 创建数据目录
mkdir -p backend/data/uploads/images
mkdir -p backend/data/uploads/voices
mkdir -p backend/data/uploads/videos
mkdir -p backend/data/uploads/thumbnails

# 如果前端未构建，先构建
if [ ! -d "frontend/dist" ]; then
    echo "📦 构建前端..."
    cd frontend
    npm install
    npm run build
    cd ..
fi

# 安装Python依赖（如果需要）
if ! python3 -c "import fastapi" 2>/dev/null; then
    echo "📦 安装Python依赖..."
    pip3 install -r backend/requirements.txt
fi

# 启动服务
echo "🚀 启动服务器..."
cd backend
export DATA_DIR=./data
export UPLOAD_DIR=./data/uploads
export AI_ENABLED=${AI_ENABLED:-false}

exec gunicorn main:app \
    -w 2 \
    -k uvicorn.workers.UvicornWorker \
    --bind 0.0.0.0:${PORT:-8000} \
    --timeout 120 \
    --access-logfile - \
    --error-logfile -
