# 💑 情侣智能随手恋爱日记本 v2.0

> 双人专属、对话式随手记录、AI智能分类归档的情侣恋爱纪念网页应用

## ✨ 核心功能

### 1. 对话式随手记录
- 💬 **聊天式界面**：仿微信对话气泡，男主蓝色/女主粉色区分
- 📝 **全媒介支持**：文字、多图、实时语音录制、实时视频录制、本地文件上传
- 🎤 **语音录制**：浏览器MediaRecorder API，最长60秒，波形动画播放条
- 📹 **视频录制**：摄像头实时录制，最长60秒，直接发送
- 🏷️ **AI自动分类**：发送即自动归类，也可手动选择分类

### 2. 自定义分类系统
- 📂 **8大系统分类**：美食/旅行/合照/日常/昵称/谈心/矛盾/语音
- ➕ **自定义分类**：用户可添加任意分类（如装修日记、养宠日常）
- 🎨 **图标选择**：20+预设图标，分类卡片化展示
- 🗑️ **可删除**：自定义分类可删除，记录自动移至趣味日常
- 🤖 **AI学习**：AI自动将内容匹配到自定义分类

### 3. 全局时间轴统计面板
- 💕 **恋爱天数**：从设定的纪念日开始实时计算，顶部悬浮卡片
- 📅 **本周统计**：消息数、活跃天数、每日互动柱状图、双方对比条
- 📆 **本月统计**：消息数、活跃天数、热门分类、最活跃时段
- 📊 **总览统计**：近30天热力图、24小时时段分布图、分类归档占比

## 🚀 一键部署

### 方式一：Render.com（推荐，免费永久在线）

1. 将项目推送到 GitHub
2. 访问 [render.com](https://render.com)，注册账号并连接 GitHub
3. New > Web Service > 选择你的仓库
4. Render 会自动识别 `render.yaml` 和 `Dockerfile`，无需手动配置
5. 在 Environment 中添加环境变量（可选）
6. 点击 Deploy，等待2-3分钟
7. 获得永久公网链接，如 `https://lovenote.onrender.com`
8. 手机/平板/电脑均可随时通过网址访问

### 方式二：Railway.app

1. 访问 [railway.app](https://railway.app)
2. New Project > Deploy from GitHub repo
3. 自动识别 `railway.json` + `Dockerfile`
4. 部署后获得公网域名

### 方式三：自有服务器/VPS

```bash
git clone <your-repo>
cd lovenote1
chmod +x start.sh
./start.sh
# 访问 http://your-server:8000
```

### 方式四：Docker

```bash
docker build -t lovenote .
docker run -d -p 8000:8000 -v lovenote-data:/app/backend/data lovenote
```

## 📁 项目结构

```
lovenote1/
├── Dockerfile              # Docker容器配置
├── render.yaml             # Render.com一键部署
├── railway.json            # Railway.app部署
├── start.sh                # 一键启动脚本
├── backend/                # FastAPI后端
│   ├── main.py             # 应用入口
│   └── app/
│       ├── api/            # API路由（messages/categories/stats）
│       ├── core/           # 数据库、初始化、共享工具
│       ├── models/         # SQLAlchemy数据模型
│       ├── schemas/        # Pydantic数据模式
│       └── services/       # AI分类服务
└── frontend/               # Vue3前端
    └── src/
        ├── views/          # 页面组件
        ├── api/            # API请求层
        ├── utils/          # 工具（音视频录制）
        └── assets/         # 全局样式
```

## 🔧 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| AI_ENABLED | false | 启用真实大模型分类 |
| OPENAI_API_KEY | - | OpenAI API Key |
| MAX_UPLOAD_SIZE | 100 | 最大上传大小(MB) |
| PORT | 8000 | 服务端口 |

## 📱 响应式设计

- ✅ 手机端完美适配（核心使用场景）
- ✅ 平板/桌面端自适应
- ✅ iOS Safari / Android Chrome 音视频录制
- ✅ PWA可添加到主屏幕
