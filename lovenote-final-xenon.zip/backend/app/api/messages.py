import os
import uuid
import aiofiles
from pathlib import Path
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db, SessionLocal
from app.core.couple import get_or_create_default_couple
from app.models import Message, User, Couple, Category, MessageAttachment, AIProcessLog
from app.schemas.message import MessageResponse, AttachmentInfo
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/messages", tags=["消息接口"])

# 上传目录配置（可通过UPLOAD_DIR环境变量配置持久化路径）
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "./data/uploads"))
IMAGE_DIR = UPLOAD_DIR / "images"
VOICE_DIR = UPLOAD_DIR / "voices"
VIDEO_DIR = UPLOAD_DIR / "videos"
THUMB_DIR = UPLOAD_DIR / "thumbnails"
for d in [IMAGE_DIR, VOICE_DIR, VIDEO_DIR, THUMB_DIR]:
    d.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = int(os.getenv("MAX_UPLOAD_SIZE", 100)) * 1024 * 1024


async def save_upload_file(upload_file: UploadFile, save_dir: Path) -> tuple[str, int]:
    """保存上传文件，返回(访问URL, 文件大小)"""
    file_ext = os.path.splitext(upload_file.filename or "file")[1].lower()
    if not file_ext:
        # 根据content-type推断扩展名
        ct = (upload_file.content_type or "").lower()
        ext_map = {"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
                   "image/webp": ".webp", "video/mp4": ".mp4", "video/webm": ".webm",
                   "video/quicktime": ".mov", "audio/webm": ".webm", "audio/ogg": ".ogg",
                   "audio/mpeg": ".mp3", "audio/mp4": ".m4a"}
        file_ext = ext_map.get(ct, ".bin")
    file_name = f"{uuid.uuid4().hex}{file_ext}"
    file_path = save_dir / file_name

    file_size = 0
    async with aiofiles.open(file_path, 'wb') as f:
        while chunk := await upload_file.read(1024 * 1024):
            file_size += len(chunk)
            if file_size > MAX_FILE_SIZE:
                await f.close()
                if file_path.exists():
                    os.remove(file_path)
                raise HTTPException(status_code=400, detail=f"文件大小超过限制{MAX_FILE_SIZE//1024//1024}MB")
            await f.write(chunk)

    url_path = f"/uploads/{save_dir.name}/{file_name}"
    return url_path, file_size


def generate_thumbnail(image_path: str, thumb_dir: Path) -> Optional[str]:
    """为图片生成缩略图，返回缩略图URL路径"""
    try:
        from PIL import Image
        import io as _io
        img = Image.open(image_path)
        img.thumbnail((400, 400))
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        thumb_name = f"thumb_{uuid.uuid4().hex}.jpg"
        thumb_path = thumb_dir / thumb_name
        img.save(thumb_path, "JPEG", quality=75)
        return f"/uploads/thumbnails/{thumb_name}"
    except Exception as e:
        print(f"缩略图生成失败: {e}")
        return None


async def _process_ai_classification(
    message_id: int,
    text_content: str,
    content_type: str,
    image_paths: List[str],
    db_session_factory,
    custom_categories: List[dict] = None
):
    """后台异步处理AI分类，支持自定义分类"""
    db = db_session_factory()
    try:
        start_time = datetime.utcnow()
        # 传入自定义分类给AI服务
        ai_result = await ai_service.process_message(
            text_content, content_type, image_paths,
            custom_categories=custom_categories
        )

        msg = db.query(Message).get(message_id)
        if not msg:
            return

        msg.main_category_id = ai_result["main_category_id"]
        msg.ai_summary = ai_result["ai_summary"]
        msg.ai_confidence = ai_result["ai_confidence"]
        msg.extracted_nicknames = ai_result.get("extracted_nicknames", [])
        msg.ai_processed = True
        msg.ai_processed_at = datetime.utcnow()

        process_time = int((datetime.utcnow() - start_time).total_seconds() * 1000)
        log = AIProcessLog(
            message_id=message_id,
            model_used="mock" if not ai_service.ai_enabled else ai_service.model,
            raw_response=ai_result,
            processing_time_ms=process_time,
            status="success"
        )
        db.add(log)
        db.commit()

    except Exception as e:
        db.rollback()
        print(f"AI处理消息{message_id}失败: {e}")
        try:
            log = AIProcessLog(message_id=message_id, status="failed", error_message=str(e))
            db.add(log)
            db.commit()
        except:
            pass
    finally:
        db.close()


@router.post("", response_model=MessageResponse, summary="发送新消息（支持文字/图片/语音/视频/录音）")
async def create_message(
    background_tasks: BackgroundTasks,
    sender_role: str = Form(..., description="发送人角色：男主/女主"),
    text_content: Optional[str] = Form(None, description="文本内容"),
    is_ai_auto: bool = Form(True, description="是否AI自动分类"),
    manual_category: Optional[str] = Form(None, description="手动选择的分类名称"),
    voice_duration: Optional[int] = Form(None, description="语音时长（秒）"),
    video_duration: Optional[int] = Form(None, description="视频时长（秒）"),
    images: List[UploadFile] = File([], description="图片文件列表"),
    voice: Optional[UploadFile] = File(None, description="语音文件"),
    video: Optional[UploadFile] = File(None, description="视频文件"),
    db: Session = Depends(get_db)
):
    """发送消息，支持multipart/form-data格式"""
    if sender_role not in ["男主", "女主", "其他"]:
        raise HTTPException(status_code=400, detail="发送人角色只能是男主/女主")

    has_content = bool(text_content and text_content.strip()) or bool(images) or voice is not None or video is not None
    if not has_content:
        raise HTTPException(status_code=400, detail="消息内容不能为空")

    # 判断内容类型
    if video:
        content_type = "video"
    elif voice:
        content_type = "voice"
    elif images:
        content_type = "image"
    else:
        content_type = "text"

    couple = get_or_create_default_couple(db)
    role_map = {"男主": "male", "女主": "female", "其他": "other"}
    sender = db.query(User).filter(
        User.couple_id == couple.id,
        User.role == role_map[sender_role]
    ).first()
    if not sender:
        raise HTTPException(status_code=400, detail="发送用户不存在")

    # 查找手动分类ID（先从系统分类查，再从自定义分类查）
    manual_category_id = None
    if not is_ai_auto:
        if not manual_category:
            raise HTTPException(status_code=400, detail="关闭AI自动分类时必须手动选择分类")
        sys_cat = ai_service.get_category_id_by_name(manual_category)
        if sys_cat:
            manual_category_id = sys_cat
        else:
            db_cat = db.query(Category).filter(
                Category.name == manual_category,
                Category.couple_id == couple.id
            ).first()
            if db_cat:
                manual_category_id = db_cat.id
            else:
                raise HTTPException(status_code=400, detail=f"分类不存在: {manual_category}")

    # 保存附件
    attachments = []
    local_image_paths = []
    msg_voice_duration = voice_duration

    # 保存图片
    for img in images:
        if not img.content_type or not img.content_type.startswith("image/"):
            continue
        url_path, file_size = await save_upload_file(img, IMAGE_DIR)
        local_path = str(IMAGE_DIR / url_path.split("/")[-1])
        local_image_paths.append(local_path)
        width, height = None, None
        thumb_url = None
        try:
            from PIL import Image as PILImage
            with PILImage.open(local_path) as pil_img:
                width, height = pil_img.size
            thumb_url = generate_thumbnail(local_path, THUMB_DIR)
        except:
            pass
        attachments.append(MessageAttachment(
            file_type="image",
            file_url=url_path,
            thumbnail_url=thumb_url,
            file_size=file_size,
            width=width,
            height=height,
            mime_type=img.content_type
        ))

    # 保存视频
    if video:
        if video.content_type and not video.content_type.startswith("video/"):
            raise HTTPException(status_code=400, detail="视频文件格式错误")
        url_path, file_size = await save_upload_file(video, VIDEO_DIR)
        attachments.append(MessageAttachment(
            file_type="video",
            file_url=url_path,
            file_size=file_size,
            duration=video_duration,
            mime_type=video.content_type or "video/mp4"
        ))

    # 保存语音
    if voice:
        url_path, file_size = await save_upload_file(voice, VOICE_DIR)
        attachments.append(MessageAttachment(
            file_type="voice",
            file_url=url_path,
            file_size=file_size,
            duration=msg_voice_duration,
            mime_type=voice.content_type or "audio/webm"
        ))

    # 创建消息
    db_message = Message(
        couple_id=couple.id,
        sender_id=sender.id,
        content_type=content_type,
        text_content=text_content.strip() if text_content else None,
        ai_processed=False,
        voice_transcribed=False,
        voice_duration=msg_voice_duration,
        is_manual_category=not is_ai_auto
    )

    if not is_ai_auto:
        db_message.main_category_id = manual_category_id
        db_message.ai_processed = True
        db_message.ai_confidence = 1.0

    db.add(db_message)
    db.flush()

    for att in attachments:
        att.message_id = db_message.id
        db.add(att)

    db.commit()
    db.refresh(db_message)

    # AI自动分类
    if is_ai_auto:
        # 查询当前情侣的自定义分类传给AI
        custom_cats = db.query(Category).filter(
            Category.couple_id == couple.id,
            Category.is_system == False
        ).all()
        custom_cat_list = [{"id": c.id, "name": c.name, "icon": c.icon or "📂", "keywords": []} for c in custom_cats]

        background_tasks.add_task(
            _process_ai_classification,
            db_message.id,
            text_content or "",
            content_type,
            local_image_paths,
            SessionLocal,
            custom_cat_list
        )

    return await _build_message_response(db, db_message)


@router.get("", response_model=List[MessageResponse], summary="获取历史消息")
async def list_messages(
    limit: int = 500,
    offset: int = 0,
    order: str = "asc",
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)
    query = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    )
    query = query.order_by(Message.created_at.asc() if order.lower() == "asc" else Message.created_at.desc())
    messages = query.offset(offset).limit(limit).all()
    return [await _build_message_response(db, msg) for msg in messages]


@router.get("/{message_id}", response_model=MessageResponse, summary="获取单条消息")
async def get_message(message_id: int, db: Session = Depends(get_db)):
    couple = get_or_create_default_couple(db)
    msg = db.query(Message).filter(
        Message.id == message_id,
        Message.couple_id == couple.id,
        Message.is_deleted == False
    ).first()
    if not msg:
        raise HTTPException(status_code=404, detail="消息不存在")
    return await _build_message_response(db, msg)


async def _build_message_response(db: Session, msg: Message) -> MessageResponse:
    """构建消息响应"""
    sender = db.query(User).get(msg.sender_id)

    category_name = None
    category_icon = None
    if msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id)
        if cat:
            category_name = cat["name"]
            category_icon = cat["icon"]
        else:
            db_cat = db.query(Category).get(msg.main_category_id)
            if db_cat:
                category_name = db_cat.name
                category_icon = db_cat.icon or "📂"

    atts = db.query(MessageAttachment).filter(MessageAttachment.message_id == msg.id).all()
    attachments = []
    for att in atts:
        attachments.append(AttachmentInfo(
            file_type=att.file_type,
            file_url=att.file_url,
            thumbnail_url=att.thumbnail_url,
            duration=att.duration if att.duration is not None else (msg.voice_duration if att.file_type == "voice" else None),
            width=att.width,
            height=att.height
        ))

    sender_role_map = {"male": "男主", "female": "女主", "other": "其他"}
    return MessageResponse(
        id=msg.id,
        sender_role=sender_role_map.get(sender.role, "其他"),
        sender_nickname=sender.nickname,
        content_type=msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        text_content=msg.text_content,
        ai_summary=msg.ai_summary,
        main_category_id=msg.main_category_id,
        main_category_name=category_name,
        main_category_icon=category_icon,
        ai_processed=msg.ai_processed,
        is_manual_category=msg.is_manual_category,
        attachments=attachments,
        voice_duration=msg.voice_duration,
        created_at=msg.created_at
    )
