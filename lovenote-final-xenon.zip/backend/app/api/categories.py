from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from app.core.database import get_db
from app.core.couple import get_or_create_default_couple
from app.models import Message, User, Couple, Category, MessageAttachment
from app.schemas.message import MessageResponse, AttachmentInfo
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/categories", tags=["分类归档接口"])


class CustomCategoryCreate(BaseModel):
    name: str
    icon: Optional[str] = "📂"
    description: Optional[str] = ""


def get_default_couple(db: Session) -> Couple:
    couple = db.query(Couple).first()
    if not couple:
        raise HTTPException(status_code=400, detail="请先初始化情侣空间，发送第一条消息")
    return couple


def build_message_response(db: Session, msg: Message) -> MessageResponse:
    sender = db.query(User).get(msg.sender_id)
    category_name = None
    category_icon = None
    if msg.main_category_id:
        cat = ai_service.get_category_by_id(msg.main_category_id)
        if cat:
            category_name = cat["name"]
            category_icon = cat["icon"]
        else:
            db_cat = db.query(Category).get(msg.main_category_id)
            if db_cat:
                category_name = db_cat.name
                category_icon = db_cat.icon or "📂"

    atts = db.query(MessageAttachment).filter(MessageAttachment.message_id == msg.id).all()
    attachments = []
    for att in atts:
        attachments.append(AttachmentInfo(
            file_type=att.file_type,
            file_url=att.file_url,
            thumbnail_url=att.thumbnail_url,
            duration=att.duration,
            width=att.width,
            height=att.height
        ))

    sender_role_map = {"male": "男主", "female": "女主", "other": "其他"}
    return MessageResponse(
        id=msg.id,
        sender_role=sender_role_map.get(sender.role, "其他"),
        sender_nickname=sender.nickname,
        content_type=msg.content_type.value if hasattr(msg.content_type, 'value') else msg.content_type,
        text_content=msg.text_content,
        ai_summary=msg.ai_summary,
        main_category_id=msg.main_category_id,
        main_category_name=category_name,
        main_category_icon=category_icon,
        ai_processed=msg.ai_processed,
        is_manual_category=msg.is_manual_category,
        attachments=attachments,
        voice_duration=msg.voice_duration,
        created_at=msg.created_at
    )


def _get_couple_or_none(db: Session):
    return db.query(Couple).first()


@router.get("", summary="获取所有分类列表（含自定义分类）")
async def list_categories(db: Session = Depends(get_db)):
    """获取系统分类 + 情侣自定义分类"""
    system_cats = ai_service.get_all_categories()
    couple = _get_couple_or_none(db)
    couple_id = couple.id if couple else None

    result = []
    for cat in system_cats:
        count = 0
        if couple_id:
            count = db.query(Message).filter(
                Message.couple_id == couple_id,
                Message.main_category_id == cat["id"],
                Message.is_deleted == False
            ).count()
        result.append({
            "id": cat["id"],
            "name": cat["name"],
            "icon": cat["icon"],
            "description": cat.get("description", ""),
            "message_count": count,
            "is_system": True,
            "can_delete": False
        })

    if couple_id:
        custom_cats = db.query(Category).filter(
            Category.couple_id == couple_id,
            Category.is_system == False
        ).order_by(Category.created_at.asc()).all()
        for cc in custom_cats:
            count = db.query(Message).filter(
                Message.couple_id == couple_id,
                Message.main_category_id == cc.id,
                Message.is_deleted == False
            ).count()
            result.append({
                "id": cc.id, "name": cc.name, "icon": cc.icon or "📂",
                "description": cc.description or "", "message_count": count,
                "is_system": False, "can_delete": True
            })

    return result


@router.post("", summary="创建自定义分类")
async def create_custom_category(
    data: CustomCategoryCreate,
    db: Session = Depends(get_db)
):
    """新增自定义分类"""
    if not data.name or not data.name.strip():
        raise HTTPException(status_code=400, detail="分类名称不能为空")

    name = data.name.strip()
    if len(name) > 20:
        raise HTTPException(status_code=400, detail="分类名称不能超过20字")

    couple = get_or_create_default_couple(db)

    # 检查是否与系统分类重名
    if ai_service.get_category_id_by_name(name):
        raise HTTPException(status_code=400, detail="该分类名称已存在（系统分类）")

    # 检查是否与已有自定义分类重名
    existing = db.query(Category).filter(
        Category.couple_id == couple.id,
        Category.name == name,
        Category.is_system == False
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="该自定义分类已存在")

    # 检查自定义分类数量上限（最多20个）
    custom_count = db.query(Category).filter(
        Category.couple_id == couple.id,
        Category.is_system == False
    ).count()
    if custom_count >= 20:
        raise HTTPException(status_code=400, detail="自定义分类数量已达上限（20个）")

    cat = Category(
        couple_id=couple.id,
        parent_id=None,
        name=name,
        icon=data.icon or "📂",
        description=data.description or "",
        sort_order=100 + custom_count,
        is_system=False
    )
    db.add(cat)
    db.commit()
    db.refresh(cat)

    return {
        "id": cat.id,
        "name": cat.name,
        "icon": cat.icon,
        "description": cat.description,
        "message_count": 0,
        "is_system": False,
        "can_delete": True
    }


@router.delete("/{category_id}", summary="删除自定义分类")
async def delete_custom_category(category_id: int, db: Session = Depends(get_db)):
    """删除自定义分类（系统分类不可删除）"""
    couple = get_or_create_default_couple(db)
    cat = db.query(Category).filter(
        Category.id == category_id,
        Category.couple_id == couple.id,
        Category.is_system == False
    ).first()
    if not cat:
        raise HTTPException(status_code=404, detail="自定义分类不存在")

    # 将该分类下的消息移到"趣味日常存档"(id=4)
    db.query(Message).filter(
        Message.main_category_id == category_id,
        Message.couple_id == couple.id
    ).update({"main_category_id": 4})

    db.delete(cat)
    db.commit()
    return {"message": "删除成功，相关记录已移至趣味日常存档"}


@router.get("/stats/overview", summary="获取分类统计概览")
async def get_category_stats(db: Session = Depends(get_db)):
    couple = _get_couple_or_none(db)
    couple_id = couple.id if couple else None
    system_cats = ai_service.get_all_categories()

    stats = []
    total = 0
    for cat in system_cats:
        count = 0
        if couple_id:
            count = db.query(Message).filter(
                Message.couple_id == couple_id,
                Message.main_category_id == cat["id"],
                Message.is_deleted == False
            ).count()
        total += count
        stats.append({**cat, "count": count, "is_system": True})

    # 加入自定义分类统计
    if couple_id:
        custom_cats = db.query(Category).filter(
            Category.couple_id == couple_id,
            Category.is_system == False
        ).all()
        for cc in custom_cats:
            count = db.query(Message).filter(
                Message.couple_id == couple_id,
                Message.main_category_id == cc.id,
                Message.is_deleted == False
            ).count()
            total += count
            stats.append({
                "id": cc.id, "name": cc.name, "icon": cc.icon or "📂",
                "description": cc.description or "", "count": count, "is_system": False
            })

    return {"total_messages": total, "categories": stats}


@router.get("/name/{category_name}", summary="按分类名称获取归档消息（支持自定义分类）")
async def get_category_messages_by_name(
    category_name: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    return await _get_category_messages(category_name, year, month, db)


@router.get("/{category_name}", response_model=List[MessageResponse], summary="按分类名称获取归档消息")
async def get_category_messages(
    category_name: str,
    year: Optional[int] = None,
    month: Optional[int] = None,
    db: Session = Depends(get_db)
):
    return await _get_category_messages(category_name, year, month, db)


async def _get_category_messages(category_name, year, month, db):
    cat_info = ai_service.get_category_by_name(category_name)
    category_id = None
    if cat_info:
        category_id = cat_info["id"]
    else:
        couple = get_default_couple(db)
        db_cat = db.query(Category).filter(
            Category.name == category_name,
            Category.couple_id == couple.id
        ).first()
        if not db_cat:
            raise HTTPException(status_code=404, detail=f"分类 {category_name} 不存在")
        category_id = db_cat.id

    couple = get_default_couple(db)
    query = db.query(Message).filter(
        Message.couple_id == couple.id,
        Message.main_category_id == category_id,
        Message.is_deleted == False
    )

    if year:
        if month:
            start = datetime(year, month, 1)
            end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
            query = query.filter(Message.created_at >= start, Message.created_at < end)
        else:
            start = datetime(year, 1, 1)
            end = datetime(year + 1, 1, 1)
            query = query.filter(Message.created_at >= start, Message.created_at < end)

    messages = query.order_by(Message.created_at.desc()).all()
    return [build_message_response(db, msg) for msg in messages]
