"""
统计分析接口 - 周度/月度恋爱天数及聊天活跃度统计
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, case, extract
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta, date
from collections import defaultdict

from app.core.database import get_db
from app.core.couple import get_or_create_default_couple
from app.models import Message, User, Couple, Category
from app.services.ai_service import ai_service

router = APIRouter(prefix="/api/stats", tags=["统计分析接口"])


def get_default_couple(db: Session) -> Couple:
    couple = db.query(Couple).first()
    if not couple:
        raise HTTPException(status_code=400, detail="请先初始化情侣空间，发送第一条消息")
    return couple


def _get_couple_or_none(db: Session):
    return db.query(Couple).first()


def _get_category_name(db: Session, cat_id: Optional[int]) -> tuple:
    if not cat_id:
        return (None, None)
    cat = ai_service.get_category_by_id(cat_id)
    if cat:
        return (cat["name"], cat["icon"])
    db_cat = db.query(Category).get(cat_id)
    if db_cat:
        return (db_cat.name, db_cat.icon or "📂")
    return (None, None)


@router.get("/timeline", summary="全局时间轴统计面板数据")
async def get_timeline_stats(db: Session = Depends(get_db)):
    """
    返回统计面板所需的全部数据：
    - 恋爱总天数
    - 消息总数
    - 男主/女主各自发送消息数
    - 本周/本月统计：消息数、活跃天数、每人消息数、最活跃时段
    - 分类分布
    - 每日消息热力数据（近30天）
    - 时段分布（24小时）
    """
    couple = _get_couple_or_none(db)
    if not couple:
        return {
            "love_days": 0, "together_date": None, "total_messages": 0,
            "male_count": 0, "female_count": 0,
            "this_week": {"total": 0, "male_count": 0, "female_count": 0, "active_days": 0, "peak_hour_label": "暂无数据", "daily": [{"date":"","day":d,"count":0} for d in ["一","二","三","四","五","六","日"]]},
            "this_month": {"total": 0, "male_count": 0, "female_count": 0, "active_days": 0, "peak_hour_label": "暂无数据", "categories": []},
            "heatmap_30d": [{"date":"","count":0} for _ in range(30)],
            "hour_distribution": {"labels": [f"{h}时" for h in range(24)], "data": [0]*24},
            "category_distribution": []
        }

    # 基础统计
    total_msgs = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id,
        Message.is_deleted == False
    ).scalar() or 0

    # 男主/女主ID
    male = db.query(User).filter(User.couple_id == couple.id, User.role == "male").first()
    female = db.query(User).filter(User.couple_id == couple.id, User.role == "female").first()
    male_count = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.sender_id == (male.id if male else 0),
        Message.is_deleted == False
    ).scalar() or 0
    female_count = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.sender_id == (female.id if female else 0),
        Message.is_deleted == False
    ).scalar() or 0

    # 恋爱天数：从together_date算起；若没有则从第一条消息算起
    love_days = 0
    start_date = None
    if couple.together_date:
        start_date = couple.together_date
        love_days = (date.today() - start_date).days + 1
    else:
        first_msg = db.query(func.min(Message.created_at)).filter(
            Message.couple_id == couple.id, Message.is_deleted == False
        ).scalar()
        if first_msg:
            start_date = first_msg.date() if hasattr(first_msg, 'date') else first_msg
            love_days = (datetime.utcnow().date() - first_msg.date()).days + 1 if first_msg else 0

    # 时间范围
    now = datetime.utcnow()
    week_start = now - timedelta(days=now.weekday())
    week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    # ========== 本周统计（SQL聚合优化） ==========
    from sqlalchemy import cast, Integer as SQLInt
    week_total = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= week_start
    ).scalar() or 0
    week_male = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= week_start,
        Message.sender_id == (male.id if male else 0)
    ).scalar() or 0
    week_female = week_total - week_male

    # 本周每日分布（SQL GROUP BY weekday）
    week_day_rows = db.query(
        cast(func.strftime('%w', Message.created_at), SQLInt).label('wd'),
        func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= week_start
    ).group_by('wd').all()
    # SQLite strftime('%w'): 0=Sunday, 1=Monday...6=Saturday; convert to 0=Mon..6=Sun
    week_day_counts = {}
    for row in week_day_rows:
        py_wd = (row.wd - 1) % 7
        week_day_counts[py_wd] = row.cnt
    week_active_days_count = len(week_day_counts)

    # 本周最活跃时段
    week_hour_rows = db.query(
        cast(func.strftime('%H', Message.created_at), SQLInt).label('hr'),
        func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= week_start
    ).group_by('hr').all()
    week_peak_hour = max((row.hr for row in week_hour_rows), key=lambda h: next(r.cnt for r in week_hour_rows if r.hr == h), default=None)
    week_peak_label = _format_hour_label(week_peak_hour) if week_peak_hour is not None else "暂无数据"

    week_daily = []
    for i in range(7):
        d = week_start + timedelta(days=i)
        week_daily.append({
            "date": d.strftime("%m-%d"),
            "day": ["一", "二", "三", "四", "五", "六", "日"][i],
            "count": week_day_counts.get(i, 0)
        })

    # ========== 本月统计（SQL聚合优化） ==========
    month_total = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= month_start
    ).scalar() or 0
    month_male = db.query(func.count(Message.id)).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= month_start,
        Message.sender_id == (male.id if male else 0)
    ).scalar() or 0
    month_female = month_total - month_male

    # 本月活跃天数
    month_day_rows = db.query(
        func.date(Message.created_at).label('d'), func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= month_start
    ).group_by('d').all()
    month_active_days_count = len(month_day_rows)

    # 本月最活跃时段
    month_hour_rows = db.query(
        cast(func.strftime('%H', Message.created_at), SQLInt).label('hr'), func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= month_start
    ).group_by('hr').all()
    month_peak_hour = max((r.hr for r in month_hour_rows), key=lambda h: next(r.cnt for r in month_hour_rows if r.hr == h), default=None)
    month_peak_label = _format_hour_label(month_peak_hour) if month_peak_hour is not None else "暂无数据"

    # 本月分类分布
    month_cat_rows = db.query(
        Message.main_category_id.label('cid'), func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False, Message.created_at >= month_start,
        Message.main_category_id.isnot(None)
    ).group_by('cid').order_by(func.count(Message.id).desc()).limit(6).all()
    month_categories = []
    for row in month_cat_rows:
        cname, cicon = _get_category_name(db, row.cid)
        if cname:
            month_categories.append({"name": cname, "icon": cicon, "count": row.cnt})

    # ========== 近30天每日消息数（热力图，SQL GROUP BY优化） ==========
    heatmap_start = now - timedelta(days=29)
    heatmap_start = heatmap_start.replace(hour=0, minute=0, second=0, microsecond=0)
    heatmap_rows = db.query(
        func.date(Message.created_at).label('d'), func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False,
        Message.created_at >= heatmap_start
    ).group_by('d').all()
    heatmap_map = {str(row.d): row.cnt for row in heatmap_rows}
    heatmap_data = []
    for i in range(30):
        d = heatmap_start + timedelta(days=i)
        d_str = d.strftime("%Y-%m-%d")
        heatmap_data.append({"date": d.strftime("%m-%d"), "count": heatmap_map.get(d_str, 0)})

    # ========== 24小时时段分布（SQL聚合） ==========
    hour_rows = db.query(
        cast(func.strftime('%H', Message.created_at), SQLInt).label('hour'),
        func.count(Message.id).label('cnt')
    ).filter(
        Message.couple_id == couple.id, Message.is_deleted == False
    ).group_by('hour').all()
    hour_dist_map = {row.hour: row.cnt for row in hour_rows}
    hour_labels = [f"{h}时" for h in range(24)]
    hour_data = [hour_dist_map.get(h, 0) for h in range(24)]

    # ========== 分类总分布 ==========
    cat_dist = []
    all_cats = ai_service.get_all_categories()
    for cat in all_cats:
        cnt = db.query(func.count(Message.id)).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cat["id"],
            Message.is_deleted == False
        ).scalar() or 0
        if cnt > 0:
            cat_dist.append({"name": cat["name"], "icon": cat["icon"], "count": cnt})
    # 加上自定义分类
    custom_cats = db.query(Category).filter(
        Category.couple_id == couple.id, Category.is_system == False
    ).all()
    for cc in custom_cats:
        cnt = db.query(func.count(Message.id)).filter(
            Message.couple_id == couple.id,
            Message.main_category_id == cc.id,
            Message.is_deleted == False
        ).scalar() or 0
        if cnt > 0:
            cat_dist.append({"name": cc.name, "icon": cc.icon or "📂", "count": cnt})
    cat_dist.sort(key=lambda x: -x["count"])

    return {
        "love_days": love_days,
        "together_date": start_date.isoformat() if start_date else None,
        "total_messages": total_msgs,
        "male_count": male_count,
        "female_count": female_count,
        "this_week": {
            "total": week_total,
            "male_count": week_male,
            "female_count": week_female,
            "active_days": week_active_days_count,
            "peak_hour_label": week_peak_label,
            "daily": week_daily
        },
        "this_month": {
            "total": month_total,
            "male_count": month_male,
            "female_count": month_female,
            "active_days": month_active_days_count,
            "peak_hour_label": month_peak_label,
            "categories": month_categories
        },
        "heatmap_30d": heatmap_data,
        "hour_distribution": {"labels": hour_labels, "data": hour_data},
        "category_distribution": cat_dist
    }


def _format_hour_label(hour: int) -> str:
    if 0 <= hour < 6:
        return f"凌晨{hour}时"
    elif 6 <= hour < 12:
        return f"上午{hour}时"
    elif hour == 12:
        return "中午12时"
    elif 13 <= hour < 18:
        return f"下午{hour-12}时"
    else:
        return f"晚上{hour-12}时"


@router.get("/couple", summary="获取情侣空间信息")
async def get_couple_info(db: Session = Depends(get_db)):
    couple = _get_couple_or_none(db)
    if not couple:
        return {"couple_name": "我们的小窝", "together_date": None, "love_days": 0,
                "male": {"nickname": "男主", "color": "#4a90e2"},
                "female": {"nickname": "女主", "color": "#ff6b9d"}}
    male = db.query(User).filter(User.couple_id == couple.id, User.role == "male").first()
    female = db.query(User).filter(User.couple_id == couple.id, User.role == "female").first()

    love_days = 0
    if couple.together_date:
        love_days = (date.today() - couple.together_date).days + 1
    else:
        first_msg = db.query(func.min(Message.created_at)).filter(
            Message.couple_id == couple.id, Message.is_deleted == False
        ).scalar()
        if first_msg:
            love_days = (datetime.utcnow().date() - first_msg.date()).days + 1

    return {
        "couple_name": couple.couple_name,
        "together_date": couple.together_date.isoformat() if couple.together_date else None,
        "love_days": love_days,
        "male": {"id": male.id, "nickname": male.nickname, "color": male.theme_color} if male else None,
        "female": {"id": female.id, "nickname": female.nickname, "color": female.theme_color} if female else None
    }


@router.put("/couple", summary="更新情侣空间信息（昵称、纪念日等）")
async def update_couple_info(
    couple_name: Optional[str] = None,
    together_date: Optional[str] = None,
    male_nickname: Optional[str] = None,
    female_nickname: Optional[str] = None,
    db: Session = Depends(get_db)
):
    couple = get_or_create_default_couple(db)
    if couple_name:
        couple.couple_name = couple_name.strip()
    if together_date:
        try:
            couple.together_date = datetime.strptime(together_date, "%Y-%m-%d").date()
        except:
            raise HTTPException(status_code=400, detail="日期格式错误，请使用YYYY-MM-DD")

    if male_nickname:
        male = db.query(User).filter(User.couple_id == couple.id, User.role == "male").first()
        if male:
            male.nickname = male_nickname.strip()
    if female_nickname:
        female = db.query(User).filter(User.couple_id == couple.id, User.role == "female").first()
        if female:
            female.nickname = female_nickname.strip()

    db.commit()
    return {"message": "更新成功"}
