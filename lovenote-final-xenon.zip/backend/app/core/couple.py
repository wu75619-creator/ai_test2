"""共享情侣空间工具函数"""
import bcrypt
import datetime as dt
from sqlalchemy.orm import Session
from app.models import Couple, User


def get_or_create_default_couple(db: Session) -> Couple:
    """获取或创建默认情侣空间"""
    couple = db.query(Couple).first()
    if not couple:
        password = "123456"
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        couple = Couple(
            access_password=hashed,
            couple_name="我们的小窝",
            together_date=dt.date.today()
        )
        db.add(couple)
        db.flush()
        male = User(couple_id=couple.id, role="male", nickname="男主", theme_color="#4a90e2")
        female = User(couple_id=couple.id, role="female", nickname="女主", theme_color="#ff6b9d")
        db.add_all([male, female])
        db.commit()
        db.refresh(couple)
    return couple
