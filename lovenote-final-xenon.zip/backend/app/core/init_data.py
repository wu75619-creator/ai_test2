"""初始化系统预设分类数据"""
from app.core.database import SessionLocal
from app.models import Category


def init_system_categories():
    """初始化8大系统主分类"""
    db = SessionLocal()
    try:
        # 检查是否已初始化
        existing = db.query(Category).filter(Category.is_system == True, Category.parent_id == None).count()
        if existing >= 8:
            return

        system_categories = [
            {"name": "美食探店存档", "icon": "🍜", "description": "一起吃过的美食、喝过的奶茶、探店记录", "sort_order": 1},
            {"name": "旅行外出约会存档", "icon": "✈️", "description": "旅行、逛街、看电影、约会游玩记录", "sort_order": 2},
            {"name": "情侣合照存档", "icon": "📸", "description": "双人自拍、同框合照、甜蜜合影", "sort_order": 3},
            {"name": "趣味日常存档", "icon": "😂", "description": "搞笑对话、互怼日常、可爱瞬间、表情包", "sort_order": 4},
            {"name": "专属昵称存档", "icon": "💌", "description": "专属称呼、私密代号、只有我们懂的梗", "sort_order": 5},
            {"name": "深度谈心存档", "icon": "💬", "description": "走心对话、三观交流、情绪倾诉、爱意表达", "sort_order": 6},
            {"name": "矛盾复盘存档", "icon": "🤝", "description": "小矛盾、争吵、反思、道歉、和解约定、成长记录", "sort_order": 7},
            {"name": "语音专属存档", "icon": "🎤", "description": "所有语音消息独立归档，甜蜜声音收藏", "sort_order": 8},
        ]

        for cat in system_categories:
            exists = db.query(Category).filter(Category.name == cat["name"], Category.is_system == True).first()
            if not exists:
                db.add(Category(
                    couple_id=None,
                    parent_id=None,
                    is_system=True,
                    **cat
                ))

        db.commit()
        print("✅ 系统分类初始化完成")
    finally:
        db.close()
