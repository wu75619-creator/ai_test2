"""
情侣智能随手恋爱日记本 - 后端入口 v2.0
FastAPI application with SPA frontend serving
"""
import os
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response

from app.core.database import engine, Base
from app import models

# 创建所有数据库表
Base.metadata.create_all(bind=engine)

# 初始化系统预设8大分类
from app.core.init_data import init_system_categories
init_system_categories()

app = FastAPI(
    title="情侣智能随手恋爱日记本 API",
    description="对话式随手记录 + AI自动分类归档的双人恋爱日记本",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 上传文件目录（可通过UPLOAD_DIR环境变量配置）
upload_dir = Path(os.getenv("UPLOAD_DIR", "./data/uploads"))
upload_dir.mkdir(parents=True, exist_ok=True)
for sub in ["images", "voices", "videos", "thumbnails"]:
    (upload_dir / sub).mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(upload_dir)), name="uploads")

# 注册API路由
from app.api.messages import router as messages_router
from app.api.categories import router as categories_router
from app.api.stats import router as stats_router
app.include_router(messages_router)
app.include_router(categories_router)
app.include_router(stats_router)


@app.get("/api/health", summary="健康检查")
async def health_check():
    ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
    return {
        "status": "ok",
        "message": "情侣日记本服务运行中 💑",
        "ai_mode": "真实大模型" if ai_enabled else "Mock模拟模式",
        "version": "2.0.0"
    }


# ========== SPA 前端静态文件服务 ==========
FRONTEND_DIST = Path(__file__).parent.parent / "frontend" / "dist"

if FRONTEND_DIST.exists():
    # 挂载静态资源目录
    assets_dir = FRONTEND_DIST / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str, request: Request):
        """SPA路由回退：所有非API路径返回index.html"""
        if full_path.startswith("api/") or full_path.startswith("uploads/"):
            return Response(status_code=404)
        file_path = FRONTEND_DIST / full_path
        if full_path and file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(FRONTEND_DIST / "index.html"))
else:
    @app.get("/", include_in_schema=False)
    async def root():
        return {"message": "情侣日记本API运行中，请先构建前端: cd frontend && npm run build", "docs": "/api/docs"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
